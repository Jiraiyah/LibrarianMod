/*    */ package com.rwtema.extrautils2.entity;
/*    */ 
/*    */ import com.google.common.base.Throwables;
/*    */ import java.lang.reflect.Constructor;
/*    */ import net.minecraft.client.renderer.entity.Render;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraftforge.fml.client.registry.IRenderFactory;
/*    */ import net.minecraftforge.fml.client.registry.RenderingRegistry;
/*    */ 
/*    */ public class RenderFactory<T extends net.minecraft.entity.Entity> implements IRenderFactory<T>
/*    */ {
/*    */   Class<Render<? super T>> clazz;
/*    */   
/*    */   public RenderFactory(Class clazz)
/*    */   {
/* 16 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */   public static void registerRenderer(Class<EntityBoomerang> entityClass, Class<RenderEntityBoomerang> renderEntityClass) {
/* 20 */     RenderingRegistry.registerEntityRenderingHandler(entityClass, new RenderFactory(renderEntityClass));
/*    */   }
/*    */   
/*    */   public Render<? super T> createRenderFor(RenderManager manager)
/*    */   {
/*    */     try {
/* 26 */       Constructor<? extends Render<? super T>> constructor = this.clazz.getConstructor(new Class[] { RenderManager.class });
/* 27 */       return (Render)constructor.newInstance(new Object[] { manager });
/*    */     } catch (Throwable e) {
/* 29 */       throw Throwables.propagate(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\entity\RenderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */