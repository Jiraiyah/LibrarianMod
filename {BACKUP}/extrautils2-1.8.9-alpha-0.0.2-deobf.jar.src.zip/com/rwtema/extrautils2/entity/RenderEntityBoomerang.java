/*     */ package com.rwtema.extrautils2.entity;
/*     */ 
/*     */ import com.google.common.base.Optional;
/*     */ import com.rwtema.extrautils2.backend.model.CachedRenderers;
/*     */ import com.rwtema.extrautils2.backend.model.IClientClearCache;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.utils.MCTimer;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.WorldRenderer;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.texture.ITextureObject;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.client.model.ItemLayerModel;
/*     */ import net.minecraftforge.client.model.TRSRTransformation;
/*     */ import net.minecraftforge.client.model.pipeline.LightUtil;
/*     */ 
/*     */ public class RenderEntityBoomerang extends Render<EntityBoomerang> implements IClientClearCache
/*     */ {
/*     */   TextureAtlasSprite sprite;
/*     */   List<BakedQuad> model;
/*     */   
/*     */   public RenderEntityBoomerang(RenderManager renderManager)
/*     */   {
/*  33 */     super(renderManager);CachedRenderers.register(this);
/*     */   }
/*     */   
/*     */   public static void renderModel(List<BakedQuad> bakedQuads) {
/*  37 */     Tessellator tessellator = Tessellator.getInstance();
/*  38 */     WorldRenderer worldrenderer = tessellator.getBuffer();
/*  39 */     worldrenderer.begin(7, DefaultVertexFormats.ITEM);
/*     */     
/*  41 */     for (BakedQuad bakedquad : bakedQuads) {
/*  42 */       LightUtil.renderQuadColor(worldrenderer, bakedquad, -1);
/*     */     }
/*     */     
/*  45 */     tessellator.draw();
/*     */   }
/*     */   
/*     */   public void doRender(EntityBoomerang entity, double x, double y, double z, float entityYaw, float partialTicks)
/*     */   {
/*  50 */     if (this.sprite == null) {
/*  51 */       this.sprite = ((TextureAtlasSprite)Textures.sprites.get("boomerang"));
/*  52 */       if (this.sprite == null) this.sprite = Textures.MISSING_SPRITE;
/*  53 */       this.model = ItemLayerModel.instance.getQuadsForSprite(-1, this.sprite, DefaultVertexFormats.ITEM, Optional.of(TRSRTransformation.identity()));
/*     */     }
/*     */     
/*  56 */     boolean flag = false;
/*     */     
/*  58 */     if (bindEntityTexture(entity)) {
/*  59 */       this.renderManager.renderEngine.getTexture(getEntityTexture(entity)).setBlurMipmap(false, false);
/*  60 */       flag = true;
/*     */     }
/*     */     
/*  63 */     GlStateManager.enableRescaleNormal();
/*  64 */     GlStateManager.alphaFunc(516, 0.1F);
/*  65 */     GlStateManager.enableBlend();
/*  66 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/*  67 */     GlStateManager.pushMatrix();
/*     */     
/*     */ 
/*  70 */     GlStateManager.translate((float)x, (float)y, (float)z);
/*     */     
/*  72 */     GlStateManager.translate(0.0F, 0.125F, 0.0F);
/*  73 */     GlStateManager.rotate(entity.prevRotationYaw + (entity.rotationYaw - entity.prevRotationYaw) * partialTicks + 90.0F, 0.0F, -1.0F, 0.0F);
/*     */     
/*  75 */     GlStateManager.rotate(entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks, 0.0F, 0.0F, -1.0F);
/*     */     
/*     */ 
/*  78 */     GlStateManager.rotate(-45.0F, 0.0F, 0.0F, 1.0F);
/*  79 */     GlStateManager.rotate(90.0F, 1.0F, 1.0F, 0.0F);
/*     */     
/*  81 */     GlStateManager.rotate(90.0F + MCTimer.renderTimer * 16.0F, 0.0F, 0.0F, 1.0F);
/*     */     
/*     */ 
/*  84 */     GlStateManager.scale(0.5F, 0.5F, 0.5F);
/*     */     
/*     */ 
/*  87 */     GlStateManager.translate(-0.5F, -0.5F, -0.5F);
/*     */     
/*     */ 
/*     */ 
/*  91 */     renderModel(this.model);
/*     */     
/*  93 */     GlStateManager.popMatrix();
/*  94 */     GlStateManager.disableRescaleNormal();
/*  95 */     GlStateManager.disableBlend();
/*  96 */     bindEntityTexture(entity);
/*     */     
/*  98 */     if (flag) {
/*  99 */       this.renderManager.renderEngine.getTexture(getEntityTexture(entity)).restoreLastBlurMipmap();
/*     */     }
/*     */     
/* 102 */     super.doRender(entity, x, y, z, entityYaw, partialTicks);
/*     */   }
/*     */   
/*     */   protected ResourceLocation getEntityTexture(EntityBoomerang entity)
/*     */   {
/* 107 */     return TextureMap.locationBlocksTexture;
/*     */   }
/*     */   
/*     */   public void clientClear()
/*     */   {
/* 112 */     this.sprite = null;
/* 113 */     this.model = null;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\entity\RenderEntityBoomerang.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */