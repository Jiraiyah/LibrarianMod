/*     */ package com.rwtema.extrautils2.entity;
/*     */ 
/*     */ import com.google.common.collect.Iterables;
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.utils.helpers.PlayerHelper;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.DataWatcher;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.item.EntityXPOrb;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetHandlerPlayServer;
/*     */ import net.minecraft.network.play.server.S2BPacketChangeGameState;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EntityDamageSourceIndirect;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraftforge.items.ItemHandlerHelper;
/*     */ 
/*     */ public class EntityBoomerang extends Entity implements net.minecraftforge.fml.common.registry.IEntityAdditionalSpawnData, net.minecraft.entity.IProjectile
/*     */ {
/*  47 */   public static final WeakHashMap<Object, WeakReference<EntityBoomerang>> boomerangOwners = new WeakHashMap();
/*  48 */   public static final WeakHashMap<Object, WeakReference<EntityBoomerang>> boomerangOwnersClient = (WeakHashMap)ExtraUtils2.proxy.nullifyOnServer(new WeakHashMap());
/*     */   
/*     */   private static final int DATAWATCHER_OUT_FLAG = 16;
/*     */   private static final int DATAWATCHER_HOME_X = 17;
/*     */   private static final int DATAWATCHER_HOME_Y = 18;
/*     */   private static final int DATAWATCHER_HOME_Z = 19;
/*     */   private static final int DATAWATCHER_OWNER_ID = 20;
/*     */   int flyTime;
/*  56 */   UUID owner = null;
/*     */   
/*     */   public EntityBoomerang(World worldIn)
/*     */   {
/*  60 */     super(worldIn);
/*  61 */     setSize(0.5F, 0.5F);
/*  62 */     this.noClip = true;
/*  63 */     this.renderDistanceWeight = 10.0D;
/*     */   }
/*     */   
/*     */   public EntityBoomerang(World worldIn, double x, double y, double z, Object owner) {
/*  67 */     this(worldIn);
/*  68 */     setLocationAndAngles(x, y, z, 0.0F, 0.0F);
/*  69 */     setHome((float)this.posX, (float)this.posY, (float)this.posZ);
/*  70 */     if (owner != null) {
/*  71 */       getBoomerangOwners(worldIn).put(owner, new WeakReference(this));
/*     */     }
/*     */   }
/*     */   
/*     */   public EntityBoomerang(World worldIn, EntityLivingBase shooter) {
/*  76 */     this(worldIn);
/*     */     
/*  78 */     if ((!(shooter instanceof EntityPlayer)) || (PlayerHelper.isPlayerReal((EntityPlayer)shooter))) {
/*  79 */       this.owner = shooter.getUniqueID();
/*  80 */       if (worldIn.isRemote) {
/*  81 */         boomerangOwnersClient.put(shooter, new WeakReference(this));
/*     */       } else {
/*  83 */         boomerangOwners.put(shooter, new WeakReference(this));
/*     */       }
/*     */     }
/*     */     
/*  87 */     Vec3 eyeVec = getEyeVec(shooter);
/*  88 */     setLocationAndAngles(eyeVec.xCoord, eyeVec.yCoord, eyeVec.zCoord, shooter.rotationYaw, shooter.rotationPitch);
/*  89 */     this.motionX = (-MathHelper.sin(this.rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(this.rotationPitch / 180.0F * 3.1415927F));
/*  90 */     this.motionZ = (MathHelper.cos(this.rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(this.rotationPitch / 180.0F * 3.1415927F));
/*  91 */     this.motionY = (-MathHelper.sin(this.rotationPitch / 180.0F * 3.1415927F));
/*  92 */     setThrowableHeading(this.motionX, this.motionY, this.motionZ, 1.25F, 0.0F);
/*     */     
/*  94 */     setHome((float)eyeVec.xCoord, (float)eyeVec.yCoord, (float)eyeVec.zCoord);
/*     */   }
/*     */   
/*     */   public static WeakHashMap<Object, WeakReference<EntityBoomerang>> getBoomerangOwners(World worldIn) {
/*  98 */     return worldIn.isRemote ? boomerangOwnersClient : boomerangOwners;
/*     */   }
/*     */   
/*     */   public void setThrowableHeading(double x, double y, double z, float velocity, float inaccuracy) {
/* 102 */     float f = MathHelper.sqrt_double(x * x + y * y + z * z);
/* 103 */     x /= f;
/* 104 */     y /= f;
/* 105 */     z /= f;
/* 106 */     x += this.rand.nextGaussian() * (this.rand.nextBoolean() ? -1 : 1) * 0.007499999832361937D * inaccuracy;
/* 107 */     y += this.rand.nextGaussian() * (this.rand.nextBoolean() ? -1 : 1) * 0.007499999832361937D * inaccuracy;
/* 108 */     z += this.rand.nextGaussian() * (this.rand.nextBoolean() ? -1 : 1) * 0.007499999832361937D * inaccuracy;
/* 109 */     x *= velocity;
/* 110 */     y *= velocity;
/* 111 */     z *= velocity;
/* 112 */     this.motionX = x;
/* 113 */     this.motionY = y;
/* 114 */     this.motionZ = z;
/* 115 */     float f1 = MathHelper.sqrt_double(x * x + z * z);
/* 116 */     this.prevRotationYaw = (this.rotationYaw = (float)(MathHelper.atan2(x, z) * 180.0D / 3.141592653589793D));
/* 117 */     this.prevRotationPitch = (this.rotationPitch = (float)(MathHelper.atan2(y, f1) * 180.0D / 3.141592653589793D));
/*     */   }
/*     */   
/*     */   public void setHome(float x, float y, float z) {
/* 121 */     this.dataManager.func_75692_b(17, Float.valueOf(x));
/* 122 */     this.dataManager.func_75692_b(18, Float.valueOf(y));
/* 123 */     this.dataManager.func_75692_b(19, Float.valueOf(z));
/*     */   }
/*     */   
/*     */   public Vec3 getHome() {
/* 127 */     return new Vec3(this.dataManager.func_111145_d(17), this.dataManager.func_111145_d(18), this.dataManager.func_111145_d(19));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*     */   public void setVelocity(double x, double y, double z)
/*     */   {
/* 136 */     this.motionX = x;
/* 137 */     this.motionY = y;
/* 138 */     this.motionZ = z;
/*     */     
/* 140 */     if ((this.prevRotationPitch == 0.0F) && (this.prevRotationYaw == 0.0F)) {
/* 141 */       float f = MathHelper.sqrt_double(x * x + z * z);
/* 142 */       this.prevRotationYaw = (this.rotationYaw = (float)(MathHelper.atan2(x, z) * 180.0D / 3.141592653589793D));
/* 143 */       this.prevRotationPitch = (this.rotationPitch = (float)(MathHelper.atan2(y, f) * 180.0D / 3.141592653589793D));
/* 144 */       this.prevRotationPitch = this.rotationPitch;
/* 145 */       this.prevRotationYaw = this.rotationYaw;
/* 146 */       setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void entityInit()
/*     */   {
/* 152 */     this.dataManager.func_75682_a(16, Byte.valueOf((byte)0));
/* 153 */     this.dataManager.func_75682_a(17, Float.valueOf(0.0F));
/* 154 */     this.dataManager.func_75682_a(18, Float.valueOf(0.0F));
/* 155 */     this.dataManager.func_75682_a(19, Float.valueOf(0.0F));
/* 156 */     this.dataManager.func_75682_a(20, Integer.valueOf(-1));
/*     */   }
/*     */   
/*     */   protected void readEntityFromNBT(NBTTagCompound tag)
/*     */   {
/* 161 */     XUEntityManager.readDataWatchersFromNBT(this.dataManager, tag);
/* 162 */     if (tag.hasKey("Target_UUIDL")) {
/* 163 */       this.owner = new UUID(tag.getLong("Target_UUIDU"), tag.getLong("Target_UUIDL"));
/*     */     } else {
/* 165 */       this.owner = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeEntityToNBT(NBTTagCompound tag) {
/* 170 */     XUEntityManager.writeDataWatchersToNBT(this.dataManager, tag);
/*     */     
/* 172 */     if (this.owner != null) {
/* 173 */       tag.setLong("Target_UUIDL", this.owner.getLeastSignificantBits());
/* 174 */       tag.setLong("Target_UUIDU", this.owner.getMostSignificantBits());
/*     */     }
/*     */   }
/*     */   
/*     */   public void onUpdate()
/*     */   {
/* 180 */     super.onUpdate();
/*     */     
/* 182 */     Entity owner = getOwner();
/* 183 */     boolean isRemote = this.worldObj.isRemote;
/*     */     
/* 185 */     Vec3 dest = calcTargetVec();
/* 186 */     this.flyTime += 1;
/*     */     
/* 188 */     byte flag = this.dataManager.func_75683_a(16);
/*     */     
/*     */ 
/*     */ 
/* 192 */     Vec3 destDiff = dest.subtract(this.posX, this.posY, this.posZ);
/*     */     
/* 194 */     float d = MathHelper.sqrt_double(destDiff.xCoord * destDiff.xCoord + destDiff.yCoord * destDiff.yCoord + destDiff.zCoord * destDiff.zCoord);
/*     */     
/* 196 */     destDiff = destDiff.normalize();
/*     */     
/*     */ 
/* 199 */     double ACCELERATION = this.flyTime * 0.001D + flag * 0.05D;
/*     */     
/* 201 */     if (((d < 1.0E-4D) && (this.flyTime > 25)) || (ACCELERATION > 1.0D)) {
/* 202 */       setMeDead();
/* 203 */       return;
/*     */     }
/*     */     
/* 206 */     this.motionX *= (1.0D - ACCELERATION);
/* 207 */     this.motionY *= (1.0D - ACCELERATION);
/* 208 */     this.motionZ *= (1.0D - ACCELERATION);
/*     */     
/*     */ 
/* 211 */     this.motionX += destDiff.xCoord * ACCELERATION;
/* 212 */     this.motionY += destDiff.yCoord * ACCELERATION;
/* 213 */     this.motionZ += destDiff.zCoord * ACCELERATION;
/*     */     
/* 215 */     float f = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
/* 216 */     this.rotationYaw = ((float)(MathHelper.atan2(this.motionX, this.motionZ) * 180.0D / 3.141592653589793D));
/* 217 */     this.rotationPitch = ((float)(MathHelper.atan2(this.motionY, f) * 180.0D / 3.141592653589793D));
/*     */     
/*     */ 
/* 220 */     if (((this.flyTime > 5) || (flag != 0)) && 
/* 221 */       (MathHelper.sqrt_double(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ) >= d)) {
/* 222 */       setLocationAndAngles(dest.xCoord, dest.yCoord, dest.zCoord, this.rotationYaw, this.rotationPitch);
/* 223 */       setMeDead(); return;
/*     */     }
/*     */     
/*     */     HashSet<BlockPos> prevPosSet;
/* 227 */     if (this.worldObj.isRemote) {
/* 228 */       moveEntity(this.motionX, this.motionY, this.motionZ);
/*     */     } else {
/* 230 */       prevPosSet = new HashSet();
/* 231 */       Iterables.addAll(prevPosSet, getNeighbourBlocks());
/*     */       
/* 233 */       moveEntity(this.motionX, this.motionY, this.motionZ);
/*     */       
/* 235 */       for (BlockPos newPos : getNeighbourBlocks()) {
/* 236 */         if (!prevPosSet.contains(newPos)) {
/* 237 */           IBlockState blockState = this.worldObj.getBlockState(newPos);
/* 238 */           Block block = blockState.getBlock();
/* 239 */           if ((block == Blocks.stone_button) || (block == Blocks.wooden_button) || (block == Blocks.lever)) {
/* 240 */             block.onBlockActivated(this.worldObj, newPos, blockState, net.minecraftforge.common.util.FakePlayerFactory.getMinecraft((WorldServer)this.worldObj), EnumFacing.DOWN, 0.0F, 0.0F, 0.0F);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */     if (flag == 0) {
/* 252 */       for (int k = 0; k < 4; k++) {
/* 253 */         double t = k / 4.0D;
/* 254 */         double dx = this.posX - this.prevPosX;
/* 255 */         double dy = this.posY - this.prevPosY;
/* 256 */         double dz = this.posZ - this.prevPosZ;
/* 257 */         this.worldObj.spawnParticle(EnumParticleTypes.CRIT, this.posX + dx * t, this.posY + dy * t, this.posZ + dz * t, -dx, -dy + 0.2D, -dz, new int[0]);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 268 */     Vec3 startVec = new Vec3(this.posX, this.posY, this.posZ);
/* 269 */     Vec3 endVec = new Vec3(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
/* 270 */     MovingObjectPosition movingobjectposition = this.worldObj.rayTraceBlocks(startVec, endVec, false, true, false);
/*     */     
/*     */ 
/*     */ 
/* 274 */     if (!isRemote) {
/* 275 */       Entity entity = null;
/* 276 */       List<Entity> list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, getEntityBoundingBox().addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0D, 1.0D, 1.0D));
/* 277 */       double d0 = 0.0D;
/*     */       
/* 279 */       for (Entity e : list) {
/* 280 */         if (((e instanceof EntityItem)) || ((e instanceof EntityXPOrb))) {
/* 281 */           if (e.field_70154_o == null) {
/* 282 */             addItem(e);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 287 */         else if (flag != 1)
/*     */         {
/* 289 */           if ((e.canBeCollidedWith()) && (!isOwner(e))) {
/* 290 */             if ((e instanceof EntityPlayer)) {
/* 291 */               EntityPlayer entityplayer = (EntityPlayer)e;
/* 292 */               if ((entityplayer.capabilities.disableDamage) || (((owner instanceof EntityPlayer)) && (!((EntityPlayer)owner).canAttackPlayer(entityplayer)))) {}
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/* 297 */               float f1 = 0.3F;
/* 298 */               AxisAlignedBB axisAlignedBB = e.getEntityBoundingBox().expand(f1, f1, f1);
/* 299 */               MovingObjectPosition mop = axisAlignedBB.calculateIntercept(startVec, endVec);
/*     */               
/* 301 */               if (mop != null) {
/* 302 */                 double d1 = startVec.squareDistanceTo(mop.hitVec);
/*     */                 
/* 304 */                 if ((d1 < d0) || (d0 == 0.0D)) {
/* 305 */                   entity = e;
/* 306 */                   d0 = d1;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 313 */       if ((flag == 0) && (entity != null) && 
/* 314 */         (entity.attackEntityFrom(new DamageSourceBoomerang(this, owner), 4.0F)) && 
/* 315 */         ((entity instanceof EntityLivingBase)) && (!(entity instanceof EntityEnderman))) {
/* 316 */         this.motionX = (this.motionY = this.motionZ = 0.0D);
/* 317 */         this.dataManager.func_75692_b(16, Byte.valueOf((byte)1));
/*     */         
/*     */ 
/* 320 */         EntityLivingBase entitylivingbase = (EntityLivingBase)entity;
/* 321 */         if ((owner instanceof EntityLivingBase)) {
/* 322 */           EnchantmentHelper.applyThornEnchantments(entitylivingbase, owner);
/* 323 */           EnchantmentHelper.applyArthropodEnchantments((EntityLivingBase)owner, entitylivingbase);
/*     */         }
/*     */         
/* 326 */         entitylivingbase.addPotionEffect(new PotionEffect(Potion.moveSlowdown.field_76415_H, 60, 0));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 333 */         if ((owner != null) && (entity != owner) && ((entity instanceof EntityPlayer)) && ((owner instanceof EntityPlayerMP))) {
/* 334 */           ((EntityPlayerMP)owner).playerNetServerHandler.sendPacket(new S2BPacketChangeGameState(6, 0.0F));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 341 */     if (movingobjectposition != null) {
/* 342 */       this.motionX = (this.motionY = this.motionZ = 0.0D);
/* 343 */       this.dataManager.func_75692_b(16, Byte.valueOf((byte)1));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void addItem(Entity entity)
/*     */   {
/* 350 */     if ((this.isDead) || (entity == null) || (entity.isDead)) {
/* 351 */       return;
/*     */     }
/* 353 */     EntityItem entityItem = (entity instanceof EntityItem) ? (EntityItem)entity : null;
/* 354 */     EntityXPOrb xp = (entity instanceof EntityXPOrb) ? (EntityXPOrb)entity : null;
/*     */     
/* 356 */     Entity parent = this;
/*     */     
/* 358 */     while (parent.field_70153_n != null) {
/* 359 */       Entity checkEntity = parent = parent.field_70153_n;
/* 360 */       if ((entityItem != null) && ((checkEntity instanceof EntityItem)) && 
/* 361 */         (combine(entityItem, (EntityItem)checkEntity))) {
/* 362 */         this.worldObj.removeEntity(entityItem);
/* 363 */         return;
/*     */       }
/*     */       
/* 366 */       if ((xp != null) && ((checkEntity instanceof EntityXPOrb))) {
/* 367 */         ((EntityXPOrb)checkEntity).xpValue += xp.xpValue;
/* 368 */         this.worldObj.removeEntity(xp);
/* 369 */         return;
/*     */       }
/*     */     }
/*     */     
/* 373 */     entity.func_70078_a(parent);
/*     */   }
/*     */   
/*     */   public boolean combine(EntityItem adding, EntityItem current) {
/* 377 */     if (adding == current) return true;
/* 378 */     if ((!adding.isEntityAlive()) || (!current.isEntityAlive())) {
/* 379 */       return true;
/*     */     }
/* 381 */     ItemStack addingStack = adding.getEntityItem();
/* 382 */     ItemStack currentStack = current.getEntityItem();
/* 383 */     if ((addingStack == null) || (currentStack == null)) { return true;
/*     */     }
/* 385 */     if (!ItemHandlerHelper.canItemStacksStack(addingStack, currentStack)) {
/* 386 */       return false;
/*     */     }
/*     */     
/* 389 */     int allowedAmount = currentStack.getMaxStackSize() - currentStack.stackSize;
/* 390 */     if (allowedAmount == 0) { return false;
/*     */     }
/* 392 */     int toAdd = addingStack.stackSize;
/* 393 */     if (toAdd <= allowedAmount) {
/* 394 */       addingStack.stackSize -= toAdd;
/* 395 */       adding.setEntityItemStack(addingStack);
/* 396 */       currentStack.stackSize += toAdd;
/* 397 */       current.setEntityItemStack(currentStack);
/* 398 */       return true;
/*     */     }
/* 400 */     addingStack.stackSize -= allowedAmount;
/* 401 */     adding.setEntityItemStack(addingStack);
/* 402 */     currentStack.stackSize += allowedAmount;
/* 403 */     current.setEntityItemStack(currentStack);
/* 404 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMeDead()
/*     */   {
/* 410 */     this.motionX = (this.motionY = this.motionZ = 0.0D);
/*     */     
/* 412 */     if (this.field_70153_n != null) {
/* 413 */       Entity riddenByEntity = this.field_70153_n;
/* 414 */       while (riddenByEntity != null) {
/* 415 */         riddenByEntity.func_70078_a(null);
/* 416 */         riddenByEntity.setLocationAndAngles(this.posX, this.posY, this.posZ, riddenByEntity.rotationYaw, riddenByEntity.rotationPitch);
/* 417 */         riddenByEntity = riddenByEntity.field_70153_n;
/*     */       }
/*     */     }
/*     */     
/* 421 */     if (this.field_70154_o != null) {
/* 422 */       func_70078_a(null);
/*     */     }
/*     */     
/*     */ 
/* 426 */     this.worldObj.removeEntity(this);
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public HashSet<BlockPos> getNeighbourBlocksSet() {
/* 431 */     Iterable<BlockPos> allInBox = getNeighbourBlocks();
/* 432 */     HashSet<BlockPos> pos = new HashSet();
/* 433 */     Iterables.addAll(pos, allInBox);
/*     */     
/* 435 */     return pos;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public Iterable<BlockPos> getNeighbourBlocks() {
/* 440 */     AxisAlignedBB expand = getEntityBoundingBox();
/* 441 */     return BlockPos.getAllInBox(new BlockPos(MathHelper.floor_double(expand.minX), MathHelper.floor_double(expand.minY), MathHelper.floor_double(expand.minZ)), new BlockPos(MathHelper.ceiling_double_int(expand.maxX), MathHelper.ceiling_double_int(expand.maxY), MathHelper.ceiling_double_int(expand.maxZ)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOwner(Entity entity)
/*     */   {
/* 454 */     if (this.worldObj.isRemote) {
/* 455 */       int i = this.dataManager.func_75679_c(20);
/* 456 */       return entity.getEntityId() == i;
/*     */     }
/* 458 */     return (this.owner != null) && (this.owner.equals(entity.getUniqueID()));
/*     */   }
/*     */   
/*     */   public Entity getOwner()
/*     */   {
/*     */     WeakHashMap<Object, WeakReference<EntityBoomerang>> boomerangOwners;
/*     */     Entity entity;
/*     */     WeakHashMap<Object, WeakReference<EntityBoomerang>> boomerangOwners;
/* 466 */     if (this.worldObj.isRemote) {
/* 467 */       int i = this.dataManager.func_75679_c(20);
/* 468 */       Entity entity = this.worldObj.getEntityByID(i);
/* 469 */       boomerangOwners = boomerangOwnersClient;
/*     */     } else {
/* 471 */       if (this.owner == null) return null;
/* 472 */       entity = ((WorldServer)this.worldObj).getEntityFromUuid(this.owner);
/* 473 */       boomerangOwners = boomerangOwners;
/*     */     }
/*     */     
/* 476 */     if (entity != null) {
/* 477 */       WeakReference<EntityBoomerang> reference = (WeakReference)boomerangOwners.get(entity);
/* 478 */       if ((reference == null) || (reference.get() == null)) {
/* 479 */         boomerangOwners.put(entity, new WeakReference(this));
/*     */       }
/*     */     }
/* 482 */     return entity;
/*     */   }
/*     */   
/*     */   public void setDead()
/*     */   {
/* 487 */     super.setDead();
/* 488 */     if (this.worldObj.isRemote) {
/* 489 */       boomerangOwnersClient.remove(getOwner());
/*     */     } else
/* 491 */       boomerangOwners.remove(getOwner());
/*     */   }
/*     */   
/*     */   public Vec3 calcTargetVec() {
/* 495 */     if (this.worldObj.isRemote) {
/* 496 */       int i = this.dataManager.func_75679_c(20);
/* 497 */       if (i != -1) {
/* 498 */         Entity entity = this.worldObj.getEntityByID(i);
/* 499 */         if (entity != null) {
/* 500 */           return getEyeVec(entity);
/*     */         }
/*     */       }
/*     */     } else {
/* 504 */       if (this.owner != null) {
/* 505 */         Entity entity = ((WorldServer)this.worldObj).getEntityFromUuid(this.owner);
/* 506 */         if (entity != null) {
/* 507 */           this.dataManager.func_75692_b(20, Integer.valueOf(entity.getEntityId()));
/* 508 */           Vec3 eyeVec = getEyeVec(entity);
/* 509 */           setHome((float)eyeVec.xCoord, (float)eyeVec.yCoord, (float)eyeVec.zCoord);
/* 510 */           return eyeVec;
/*     */         }
/*     */       }
/*     */       
/* 514 */       this.dataManager.func_75692_b(20, Integer.valueOf(-1));
/*     */     }
/*     */     
/* 517 */     return getHome();
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public Vec3 getEyeVec(Entity entity) {
/* 522 */     return new Vec3(entity.posX, entity.posY + entity.getEyeHeight() * 0.8D, entity.posZ);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeSpawnData(ByteBuf buffer)
/*     */   {
/* 528 */     buffer.writeInt(this.flyTime);
/*     */   }
/*     */   
/*     */   public void readSpawnData(ByteBuf additionalData)
/*     */   {
/* 533 */     this.flyTime = additionalData.readInt();
/*     */   }
/*     */   
/*     */   public class DamageSourceBoomerang extends EntityDamageSourceIndirect
/*     */   {
/*     */     public DamageSourceBoomerang(EntityBoomerang indirectEntityIn, Entity owner) {
/* 539 */       super(indirectEntityIn, owner);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\entity\EntityBoomerang.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */