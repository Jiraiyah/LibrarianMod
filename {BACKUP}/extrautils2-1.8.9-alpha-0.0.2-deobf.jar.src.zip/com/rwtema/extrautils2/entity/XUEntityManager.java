/*     */ package com.rwtema.extrautils2.entity;
/*     */ 
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.XUProxy;
/*     */ import com.rwtema.extrautils2.backend.ClientCallable;
/*     */ import net.minecraft.entity.DataWatcher;
/*     */ import net.minecraft.entity.DataWatcher.WatchableObject;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagByte;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagFloat;
/*     */ import net.minecraft.nbt.NBTTagInt;
/*     */ import net.minecraft.nbt.NBTTagLong;
/*     */ import net.minecraft.nbt.NBTTagShort;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.Rotations;
/*     */ import net.minecraftforge.fml.common.registry.EntityRegistry;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class XUEntityManager
/*     */ {
/*  25 */   static int id = 0;
/*     */   
/*     */   public static void init() {
/*  28 */     registerEntity(EntityBoomerang.class, 64, 5, true);
/*     */     
/*  30 */     ExtraUtils2.proxy.run(new ClientCallable()
/*     */     {
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void runClient() {
/*  34 */         RenderFactory.registerRenderer(EntityBoomerang.class, RenderEntityBoomerang.class);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private static void registerEntity(Class<EntityBoomerang> clazz, int trackingRange, int updateFrequency, boolean sendsVelocityUpdates) {
/*  40 */     String name = clazz.getSimpleName().toLowerCase();
/*  41 */     if (name.startsWith("entity")) name = name.replace("entity", "");
/*  42 */     EntityRegistry.registerModEntity(clazz, name, id, ExtraUtils2.instance, trackingRange, updateFrequency, sendsVelocityUpdates);
/*  43 */     id += 1;
/*     */   }
/*     */   
/*     */   public static void readDataWatchersFromNBT(DataWatcher watcher, NBTTagCompound tags)
/*     */   {
/*  48 */     for (DataWatcher.WatchableObject watchableObject : watcher.func_75685_c()) {
/*  49 */       int id = watchableObject.func_75672_a();
/*  50 */       if (id > 4) {
/*  51 */         String key = "Watcher " + id;
/*  52 */         if (tags.hasKey(key)) {
/*     */           Object value;
/*  54 */           switch (watchableObject.func_75674_c()) {
/*     */           case 0: 
/*  56 */             value = Byte.valueOf(tags.getByte(key));
/*  57 */             break;
/*     */           case 1: 
/*  59 */             value = Short.valueOf(tags.getShort(key));
/*  60 */             break;
/*     */           case 2: 
/*  62 */             value = Integer.valueOf(tags.getInteger(key));
/*  63 */             break;
/*     */           case 3: 
/*  65 */             value = Float.valueOf(tags.getFloat(key));
/*  66 */             break;
/*     */           case 4: 
/*  68 */             value = tags.getString(key);
/*  69 */             break;
/*     */           case 5: 
/*  71 */             value = ItemStack.loadItemStackFromNBT(tags.getCompoundTag(key));
/*  72 */             break;
/*     */           case 6: 
/*  74 */             value = BlockPos.fromLong(tags.getLong(key));
/*  75 */             break;
/*     */           case 7: 
/*  77 */             value = new Rotations(tags.getTagList(key, 5));
/*  78 */             break;
/*     */           }
/*     */           
/*     */           
/*  82 */           watcher.func_75692_b(id, value);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*  88 */   public static void writeDataWatchersToNBT(DataWatcher watcher, NBTTagCompound tags) { for (DataWatcher.WatchableObject watchableObject : watcher.func_75685_c()) {
/*  89 */       int id = watchableObject.func_75672_a();
/*  90 */       if (id > 4) {
/*  91 */         String key = "Watcher " + id;
/*     */         
/*  93 */         Object object = watchableObject.func_75669_b();
/*  94 */         NBTBase value; switch (watchableObject.func_75674_c()) {
/*     */         case 0: 
/*  96 */           value = new NBTTagByte(((Byte)object).byteValue());
/*  97 */           break;
/*     */         case 1: 
/*  99 */           value = new NBTTagShort(((Short)object).shortValue());
/* 100 */           break;
/*     */         case 2: 
/* 102 */           value = new NBTTagInt(((Integer)object).intValue());
/* 103 */           break;
/*     */         case 3: 
/* 105 */           value = new NBTTagFloat(((Float)object).floatValue());
/* 106 */           break;
/*     */         case 4: 
/* 108 */           value = new NBTTagString((String)object);
/* 109 */           break;
/*     */         case 5: 
/* 111 */           NBTTagCompound tag = new NBTTagCompound();
/* 112 */           if (object != null)
/* 113 */             ((ItemStack)object).writeToNBT(tag);
/* 114 */           value = tag;
/* 115 */           break;
/*     */         case 6: 
/* 117 */           value = new NBTTagLong(((BlockPos)object).toLong());
/* 118 */           break;
/*     */         case 7: 
/* 120 */           Rotations rotations = (Rotations)object;
/* 121 */           value = rotations.writeToNBT();
/* 122 */           break;
/*     */         }
/*     */         
/*     */         
/* 126 */         tags.setTag(key, value);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\entity\XUEntityManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */