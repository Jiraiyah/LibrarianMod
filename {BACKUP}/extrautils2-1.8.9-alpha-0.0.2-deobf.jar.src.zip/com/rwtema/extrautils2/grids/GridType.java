/*    */ package com.rwtema.extrautils2.grids;
/*    */ 
/*    */ import java.util.Set;
/*    */ 
/*    */ public abstract class GridType {
/*    */   public abstract Grid createGrid();
/*    */   
/*  8 */   public Grid mergeGrids(Grid a, Grid b) { if (a.refList.size() < b.refList.size()) {
/*  9 */       Grid t = b;
/* 10 */       b = a;
/* 11 */       a = t;
/*    */     }
/*    */     
/* 14 */     b.isValid = false;
/* 15 */     for (TileGridRef<XUTileGrid> refs : b.refList) {
/* 16 */       refs.grids.remove(b);
/* 17 */       a.refList.add(refs);
/* 18 */       refs.grids.add(a);
/*    */     }
/*    */     
/* 21 */     a.onMerge();
/* 22 */     return a;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\grids\GridType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */