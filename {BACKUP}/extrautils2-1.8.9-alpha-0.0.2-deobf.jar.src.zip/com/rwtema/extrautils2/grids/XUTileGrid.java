/*    */ package com.rwtema.extrautils2.grids;
/*    */ 
/*    */ import com.rwtema.extrautils2.tile.XUTile;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public abstract class XUTileGrid extends XUTile
/*    */ {
/* 13 */   TileGridRef<XUTileGrid> myRef = new TileGridRef(this);
/*    */   
/* 15 */   final HashMap<GridType, Grid> gridTypes = new HashMap();
/*    */   
/*    */   protected XUTileGrid(GridType... gridTypes) {
/* 18 */     for (GridType gridType : gridTypes) {
/* 19 */       this.gridTypes.put(gridType, null);
/*    */     }
/*    */   }
/*    */   
/*    */   public void invalidate()
/*    */   {
/* 25 */     super.invalidate();
/* 26 */     for (Grid grid : this.myRef.grids) {
/* 27 */       grid.destroy();
/*    */     }
/* 29 */     this.myRef.grids.clear();
/*    */   }
/*    */   
/*    */   public void loadIntoGrids() {
/* 33 */     List<XUTileGrid> xuTileGrids = adjacentTiles();
/*    */     
/* 35 */     for (Map.Entry<GridType, Grid> entry : this.gridTypes.entrySet()) {
/* 36 */       if ((entry.getValue() == null) || (!((Grid)entry.getValue()).isValid)) {
/* 37 */         GridType gridType = (GridType)entry.getKey();
/* 38 */         Grid myGrid = null;
/* 39 */         for (XUTileGrid xuTileGrid : xuTileGrids) {
/* 40 */           Grid otherGrid = (Grid)xuTileGrid.gridTypes.get(gridType);
/* 41 */           if (otherGrid != null) {
/* 42 */             if (myGrid == null) {
/* 43 */               myGrid = otherGrid;
/*    */             } else {
/* 45 */               myGrid = gridType.mergeGrids(myGrid, otherGrid);
/*    */             }
/*    */           }
/*    */         }
/*    */         
/* 50 */         if (myGrid == null) myGrid = gridType.createGrid();
/* 51 */         myGrid.add(this);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public List<XUTileGrid> adjacentTiles() {
/* 57 */     List<XUTileGrid> list = new java.util.ArrayList(2);
/* 58 */     for (EnumFacing enumFacing : EnumFacing.values()) {
/* 59 */       BlockPos offset = this.pos.offset(enumFacing);
/* 60 */       if ((enumFacing == EnumFacing.UP) || (enumFacing == EnumFacing.DOWN) || (this.worldObj.isBlockLoaded(offset))) {
/* 61 */         net.minecraft.tileentity.TileEntity tileEntity = this.worldObj.getTileEntity(this.pos);
/* 62 */         if ((tileEntity instanceof XUTileGrid)) {
/* 63 */           XUTileGrid tileGrid = (XUTileGrid)tileEntity;
/* 64 */           if ((isUnblockedNeighbour(enumFacing, tileGrid)) && (tileGrid.isUnblockedNeighbour(enumFacing.getOpposite(), this)))
/* 65 */             list.add(tileGrid);
/*    */         }
/*    */       }
/*    */     }
/* 69 */     return list;
/*    */   }
/*    */   
/*    */   protected boolean isUnblockedNeighbour(EnumFacing enumFacing, XUTileGrid otherTile) {
/* 73 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\grids\XUTileGrid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */