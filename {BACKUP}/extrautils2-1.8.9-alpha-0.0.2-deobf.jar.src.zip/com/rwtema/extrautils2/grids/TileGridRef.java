/*    */ package com.rwtema.extrautils2.grids;
/*    */ 
/*    */ import gnu.trove.set.hash.THashSet;
/*    */ import java.lang.ref.WeakReference;
/*    */ 
/*    */ public final class TileGridRef<T extends XUTileGrid>
/*    */   extends WeakReference<T>
/*    */ {
/*    */   final int hash;
/* 10 */   public THashSet<Grid> grids = new THashSet(2);
/*    */   
/*    */   public TileGridRef(T referent) {
/* 13 */     super(referent, GridHandler.gridQueue);
/* 14 */     this.hash = System.identityHashCode(referent);
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 19 */     if (this == o) return true;
/* 20 */     if (o == null) { return false;
/*    */     }
/* 22 */     Object t = get();
/* 23 */     if (t == null) return false;
/* 24 */     if (getClass() != o.getClass()) { return t == o;
/*    */     }
/* 26 */     TileGridRef<?> tileGridRef = (TileGridRef)o;
/* 27 */     return (this.hash == tileGridRef.hash) && (t == tileGridRef.get());
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 33 */     return this.hash;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\grids\TileGridRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */