/*    */ package com.rwtema.extrautils2.grids;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.datastructures.WeakSet;
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent.ServerTickEvent;
/*    */ 
/*    */ public class GridHandler
/*    */ {
/*  9 */   public static final ReferenceQueue<? super XUTileGrid> gridQueue = new ReferenceQueue();
/*    */   
/* 11 */   static WeakSet<XUTileGrid> pendingTiles = new WeakSet();
/*    */   
/*    */   @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
/*    */   public void handlePendingTiles(TickEvent.ServerTickEvent event) {
/* 15 */     for (XUTileGrid pendingTile : pendingTiles) {
/* 16 */       if (pendingTile.isLoaded()) {
/* 17 */         pendingTile.loadIntoGrids();
/*    */       }
/*    */     }
/*    */     
/*    */     Object x;
/* 22 */     while ((x = gridQueue.poll()) != null) {
/* 23 */       TileGridRef<?> x1 = (TileGridRef)x;
/* 24 */       for (Grid grid : x1.grids) {
/* 25 */         grid.destroy();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\grids\GridHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */