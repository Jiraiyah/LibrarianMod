/*    */ package com.rwtema.extrautils2.grids;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ 
/*    */ public class WeakRefIterable<T> implements Iterable<T> { boolean removeStaleEntries;
/*    */   final Iterable<? extends WeakReference<T>> iterable;
/*    */   
/*  8 */   public WeakRefIterable(Iterable<? extends WeakReference<T>> iterable) { this(iterable, true); }
/*    */   
/*    */   public WeakRefIterable(Iterable<? extends WeakReference<T>> iterable, boolean removeStaleEntries)
/*    */   {
/* 12 */     this.removeStaleEntries = removeStaleEntries;
/* 13 */     this.iterable = iterable;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public java.util.Iterator<T> iterator()
/*    */   {
/* 22 */     new java.util.Iterator() {
/*    */       T t;
/* 24 */       java.util.Iterator<? extends WeakReference<T>> iterator = WeakRefIterable.this.iterable.iterator();
/*    */       
/*    */       public boolean hasNext()
/*    */       {
/*    */         for (;;) {
/* 29 */           if (!this.iterator.hasNext()) return false;
/* 30 */           WeakReference<T> next = (WeakReference)this.iterator.next();
/* 31 */           this.t = next.get();
/* 32 */           if (this.t == null) {
/* 33 */             if (WeakRefIterable.this.removeStaleEntries)
/* 34 */               this.iterator.remove();
/*    */           } else {
/* 36 */             return true;
/*    */           }
/*    */         }
/*    */       }
/*    */       
/*    */       public T next() {
/* 42 */         return (T)this.t;
/*    */       }
/*    */       
/*    */       public void remove()
/*    */       {
/* 47 */         this.iterator.remove();
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\grids\WeakRefIterable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */