/*    */ package com.rwtema.extrautils2.grids;
/*    */ 
/*    */ import gnu.trove.set.hash.THashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class Grid
/*    */ {
/*  9 */   public final Set<TileGridRef<XUTileGrid>> refList = new gnu.trove.set.hash.TLinkedHashSet();
/*    */   public final GridType gridType;
/*    */   
/*    */   public Grid(GridType gridType)
/*    */   {
/* 14 */     this.gridType = gridType;
/*    */   }
/*    */   
/*    */   public void add(XUTileGrid t) {
/* 18 */     TileGridRef<XUTileGrid> myRef = t.myRef;
/* 19 */     myRef.grids.add(this);
/* 20 */     this.refList.add(new TileGridRef(t));
/*    */   }
/*    */   
/*    */   public void remove(XUTileGrid t) {
/* 24 */     if (this.refList.remove(t.myRef)) {
/* 25 */       t.myRef.grids.remove(this);
/* 26 */       destroy();
/*    */     }
/*    */   }
/*    */   
/* 30 */   boolean isValid = true;
/*    */   
/*    */   public void destroy() {
/* 33 */     this.isValid = false;
/* 34 */     for (TileGridRef<XUTileGrid> xuTileGridTileGridRef : this.refList) {
/* 35 */       XUTileGrid tileGrid = (XUTileGrid)xuTileGridTileGridRef.get();
/* 36 */       if (tileGrid != null) {
/* 37 */         xuTileGridTileGridRef.grids.remove(this);
/* 38 */         GridHandler.pendingTiles.add(tileGrid);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void check() {
/* 44 */     for (Iterator<TileGridRef<XUTileGrid>> iterator = this.refList.iterator(); iterator.hasNext();) {
/* 45 */       TileGridRef<XUTileGrid> xuTileGridTileGridRef = (TileGridRef)iterator.next();
/* 46 */       XUTileGrid tileGrid = (XUTileGrid)xuTileGridTileGridRef.get();
/* 47 */       if ((tileGrid == null) || (!tileGrid.isLoaded())) {
/* 48 */         destroy();
/* 49 */         break;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void onMerge() {}
/*    */   
/*    */   public class TileSet
/*    */     extends gnu.trove.set.hash.TLinkedHashSet<TileGridRef<XUTileGrid>>
/*    */   {
/*    */     public TileSet() {}
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\grids\Grid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */