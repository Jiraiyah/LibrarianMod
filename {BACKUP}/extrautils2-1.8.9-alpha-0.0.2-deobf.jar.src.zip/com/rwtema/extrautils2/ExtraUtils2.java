/*     */ package com.rwtema.extrautils2;
/*     */ 
/*     */ import com.rwtema.extrautils2.asm.CoreXU2;
/*     */ import com.rwtema.extrautils2.backend.ClientCallable;
/*     */ import com.rwtema.extrautils2.backend.entries.BlockEntry;
/*     */ import com.rwtema.extrautils2.backend.entries.EntryHandler;
/*     */ import com.rwtema.extrautils2.backend.entries.XU2Entries;
/*     */ import com.rwtema.extrautils2.backend.model.ModelHandler;
/*     */ import com.rwtema.extrautils2.backend.save.SaveManager;
/*     */ import com.rwtema.extrautils2.banner.Banner;
/*     */ import com.rwtema.extrautils2.book.BookHandler;
/*     */ import com.rwtema.extrautils2.chunkloading.XUChunkLoaderManager;
/*     */ import com.rwtema.extrautils2.commands.CommandDebug;
/*     */ import com.rwtema.extrautils2.commands.CommandFriendship;
/*     */ import com.rwtema.extrautils2.entity.XUEntityManager;
/*     */ import com.rwtema.extrautils2.gui.backend.GuiHandler;
/*     */ import com.rwtema.extrautils2.keyhandler.KeyAlt;
/*     */ import com.rwtema.extrautils2.power.Freq;
/*     */ import com.rwtema.extrautils2.power.PowerManager;
/*     */ import com.rwtema.extrautils2.utils.LogHelper;
/*     */ import com.rwtema.extrautils2.utils.errors.LegalException;
/*     */ import com.rwtema.extrautils2.utils.errors.LegalException.LawLevel;
/*     */ import com.rwtema.extrautils2.worldgen.SingleChunkWorldGenManager;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.client.ClientCommandHandler;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ import net.minecraftforge.fml.common.LoaderException;
/*     */ import net.minecraftforge.fml.common.Mod.EventHandler;
/*     */ import net.minecraftforge.fml.common.Mod.Instance;
/*     */ import net.minecraftforge.fml.common.event.FMLInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLLoadCompleteEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLServerAboutToStartEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLServerStoppingEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*     */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*     */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ 
/*     */ @net.minecraftforge.fml.common.Mod(modid="ExtraUtils2", version="1.0", dependencies="required-after:Forge@[11.15.0.1718,);before:JEI@[2.24.2.125,)", acceptedMinecraftVersions="[1.8.9]")
/*     */ public class ExtraUtils2
/*     */ {
/*     */   public static final String MODID = "ExtraUtils2";
/*     */   public static final String RESOURCE_FOLDER = "extrautils2";
/*     */   public static final String VERSION = "1.0";
/*     */   public static final boolean deobf;
/*     */   public static final boolean deobf_folder;
/*  63 */   public static final Random RANDOM = new Random();
/*     */   public static Configuration config;
/*  65 */   public static CreativeTabs creativeTabExtraUtils = new MyCreativeTabs();
/*     */   @net.minecraftforge.fml.common.SidedProxy(serverSide="com.rwtema.extrautils2.XUProxyServer", clientSide="com.rwtema.extrautils2.XUProxyClient")
/*     */   public static XUProxy proxy;
/*     */   @Mod.Instance("ExtraUtils2")
/*     */   public static ExtraUtils2 instance;
/*     */   
/*     */   static {
/*  72 */     boolean d = false;
/*     */     try {
/*  74 */       net.minecraft.world.World.class.getMethod("getBlockState", new Class[] { net.minecraft.util.BlockPos.class });
/*  75 */       d = true;
/*  76 */       LogHelper.info("Dev Enviroment detected. Releasing hounds...", new Object[0]);
/*     */     } catch (NoSuchMethodException e) {
/*  78 */       d = false;
/*     */     } catch (SecurityException e) {
/*  80 */       d = false;
/*     */     }
/*  82 */     deobf = d;
/*     */     
/*     */ 
/*  85 */     if (deobf) {
/*  86 */       URL resource = ExtraUtils2.class.getClassLoader().getResource(ExtraUtils2.class.getName().replace('.', '/').concat(".class"));
/*  87 */       deobf_folder = (resource != null) && ("file".equals(resource.getProtocol()));
/*     */     } else {
/*  89 */       deobf_folder = false;
/*     */     }
/*  91 */     if (!CoreXU2.loaded) {
/*  92 */       String message = "ExtraUtilities2 CoreMod Failed To Load";
/*  93 */       if (deobf) {
/*  94 */         message = message + ": Add to VM Options:  \"-Dfml.coreMods.load=" + CoreXU2.class.getName() + "\"";
/*     */       }
/*  96 */       throw new LoaderException(message);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 102 */     if (System.getProperty("os.name").equals("GovtOS")) {
/* 103 */       throw new LegalException(LegalException.LawLevel.CONSTITUTIONAL, "Unconstitutional search method detected. Taking ethical stand.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Mod.EventHandler
/*     */   public void preInit(FMLPreInitializationEvent event)
/*     */   {
/* 111 */     com.rwtema.extrautils2.network.NetworkHandler.init(event.getAsmData());
/* 112 */     NetworkRegistry.INSTANCE.registerGuiHandler(this, new GuiHandler());
/* 113 */     ModelHandler.init();
/* 114 */     config = new Configuration(event.getSuggestedConfigurationFile());
/* 115 */     XU2Entries.init();
/* 116 */     XUEntityManager.init();
/* 117 */     EntryHandler.loadConfig(config);
/* 118 */     KeyAlt.isAltSneaking(null);
/*     */     
/* 120 */     EntryHandler.preInit();
/*     */     
/* 122 */     proxy.registerHandlers();
/* 123 */     proxy.registerClientCommand();
/*     */     
/* 125 */     MinecraftForge.EVENT_BUS.register(Freq.INSTANCE);
/*     */     
/* 127 */     XUChunkLoaderManager.init();
/* 128 */     GameRegistry.registerWorldGenerator(SingleChunkWorldGenManager.INSTANCE, 0);
/*     */   }
/*     */   
/*     */   @Mod.EventHandler
/*     */   public void init(FMLInitializationEvent event)
/*     */   {
/* 134 */     OreDictionary.registerOre("bricksStone", Blocks.stonebrick);
/* 135 */     OreDictionary.registerOre("endstone", Blocks.end_stone);
/*     */     
/* 137 */     proxy.run(new ClientCallable()
/*     */     {
/*     */       public void runClient() {
/* 140 */         LogHelper.info(Boolean.valueOf(BookHandler.book == null), new Object[0]);
/*     */       }
/* 142 */     });
/* 143 */     Banner.init();
/* 144 */     EntryHandler.init();
/*     */   }
/*     */   
/*     */   @Mod.EventHandler
/*     */   public void postInit(FMLPostInitializationEvent event) {
/* 149 */     EntryHandler.postInit();
/*     */     
/* 151 */     com.rwtema.extrautils2.gui.ContainerPlayerAlliances.init();
/* 152 */     proxy.run(new ClientCallable()
/*     */     {
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void runClient() {
/* 156 */         ClientCommandHandler.instance.registerCommand(new CommandFriendship());
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   @Mod.EventHandler
/*     */   public void complete(FMLLoadCompleteEvent event)
/*     */   {
/* 164 */     if (config.hasChanged()) {
/* 165 */       config.save();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Mod.EventHandler
/*     */   public void serverStarting(FMLServerStartingEvent event)
/*     */   {
/* 176 */     SaveManager.init();
/*     */     
/* 178 */     event.registerServerCommand(new CommandDebug());
/*     */   }
/*     */   
/*     */   @Mod.EventHandler
/*     */   public void serverStopping(FMLServerStoppingEvent event) {
/* 183 */     PowerManager.instance.clear();
/* 184 */     XUChunkLoaderManager.clear(); }
/*     */   
/*     */   @Mod.EventHandler
/*     */   public void serverAboutToStart(FMLServerAboutToStartEvent event) {}
/*     */   
/* 189 */   private static class MyCreativeTabs extends CreativeTabs implements Comparator<ItemStack> { public MyCreativeTabs() { super(); }
/*     */     
/*     */ 
/*     */     @SideOnly(Side.CLIENT)
/*     */     public Item getTabIconItem()
/*     */     {
/* 195 */       return Item.getItemFromBlock((Block)XU2Entries.angelBlock.value);
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public void displayAllRelevantItems(List<ItemStack> list)
/*     */     {
/* 201 */       List<ItemStack> newList = com.google.common.collect.Lists.newArrayList();
/* 202 */       super.displayAllRelevantItems(newList);
/* 203 */       Collections.sort(newList, this);
/* 204 */       list.addAll(newList);
/*     */     }
/*     */     
/*     */     public int compare(ItemStack o1, ItemStack o2)
/*     */     {
/* 209 */       int i = -compare_boolean(isBlock(o1), isBlock(o2));
/* 210 */       if (i != 0) return i;
/* 211 */       i = new ItemStack(o1.getItem()).getDisplayName().compareTo(new ItemStack(o2.getItem()).getDisplayName());
/* 212 */       if (i != 0) { return i;
/*     */       }
/* 214 */       return o1.getDisplayName().compareTo(o2.getDisplayName());
/*     */     }
/*     */     
/*     */     public int compare_boolean(boolean x, boolean y) {
/* 218 */       return x ? 1 : x == y ? 0 : -1;
/*     */     }
/*     */     
/*     */     public boolean isBlock(ItemStack a) {
/* 222 */       return a.getItem() instanceof ItemBlock;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\ExtraUtils2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */