/*    */ package com.rwtema.extrautils2.eventhandlers;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import com.rwtema.extrautils2.XUProxy;
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.entity.player.PlayerCapabilities;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.event.ForgeEventFactory;
/*    */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class CreativeEPHandler
/*    */ {
/*    */   public static void init()
/*    */   {
/* 22 */     MinecraftForge.EVENT_BUS.register(new CreativeEPHandler());
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void enderRightClick(PlayerInteractEvent event) {
/* 27 */     if (event.action != net.minecraftforge.event.entity.player.PlayerInteractEvent.Action.RIGHT_CLICK_AIR) return;
/* 28 */     EntityPlayer player = event.entityPlayer;
/* 29 */     if (!player.capabilities.isCreativeMode) return;
/* 30 */     ItemStack currentItem = player.inventory.getCurrentItem();
/* 31 */     if ((currentItem == null) || (currentItem.getItem() != Items.ender_pearl)) { return;
/*    */     }
/* 33 */     World worldIn = event.world;
/* 34 */     event.useItem = net.minecraftforge.fml.common.eventhandler.Event.Result.DENY;
/* 35 */     event.setCanceled(true);
/*    */     
/*    */ 
/* 38 */     worldIn.func_72956_a(player, "random.bow", 0.5F, 0.4F / (com.rwtema.extrautils2.utils.XURandom.rand.nextFloat() * 0.4F + 0.8F));
/*    */     
/* 40 */     if (!worldIn.isRemote) {
/* 41 */       worldIn.spawnEntityInWorld(new net.minecraft.entity.item.EntityEnderPearl(worldIn, player));
/*    */     } else {
/* 43 */       ExtraUtils2.proxy.run(XUProxy.sendRightClick);
/*    */     }
/*    */     
/* 46 */     player.addStat(net.minecraft.stats.StatList.objectUseStats[net.minecraft.item.Item.getIdFromItem(Items.ender_pearl)]);
/*    */     
/* 48 */     currentItem.stackSize -= 1;
/*    */     
/* 50 */     if (currentItem.stackSize == 0) {
/* 51 */       player.inventory.mainInventory[player.inventory.currentItem] = null;
/* 52 */       ForgeEventFactory.onPlayerDestroyItem(player, currentItem);
/*    */     }
/*    */     
/* 55 */     if ((player instanceof EntityPlayerMP)) {
/* 56 */       ((EntityPlayerMP)player).sendContainerToPlayer(player.inventoryContainer);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\eventhandlers\CreativeEPHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */