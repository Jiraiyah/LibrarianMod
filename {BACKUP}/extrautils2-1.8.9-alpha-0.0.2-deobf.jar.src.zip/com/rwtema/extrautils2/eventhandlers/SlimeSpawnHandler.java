/*    */ package com.rwtema.extrautils2.eventhandlers;
/*    */ 
/*    */ import net.minecraft.entity.monster.EntitySlime;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.event.entity.living.LivingSpawnEvent.CheckSpawn;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event.Result;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ 
/*    */ public class SlimeSpawnHandler
/*    */ {
/*    */   public static void init()
/*    */   {
/* 13 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new SlimeSpawnHandler());
/*    */   }
/*    */   
/*    */   @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
/*    */   public void preventSlime(LivingSpawnEvent.CheckSpawn event) {
/* 18 */     if (!(event.entity instanceof EntitySlime)) { return;
/*    */     }
/* 20 */     World worldObj = event.entity.worldObj;
/* 21 */     if ((worldObj != null) && (worldObj.getWorldType() == net.minecraft.world.WorldType.FLAT)) {
/* 22 */       event.setResult(Event.Result.DENY);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\eventhandlers\SlimeSpawnHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */