/*    */ package com.rwtema.extrautils2.eventhandlers;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.XURandom;
/*    */ import gnu.trove.map.hash.TObjectDoubleHashMap;
/*    */ import gnu.trove.procedure.TObjectDoubleProcedure;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.WeightedRandom.Item;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent.ServerTickEvent;
/*    */ 
/*    */ public class RareSeedHandler
/*    */ {
/* 18 */   private static final List<WeightedRandom.Item> seedEntries = (List)net.minecraftforge.fml.common.ObfuscationReflectionHelper.getPrivateValue(net.minecraftforge.common.ForgeHooks.class, null, new String[] { "seedList" });
/*    */   
/* 20 */   private static final TObjectDoubleHashMap<WeightedRandom.Item> probabilities = new TObjectDoubleHashMap();
/*    */   
/*    */   static {
/* 23 */     MinecraftForge.EVENT_BUS.register(new RareSeedHandler());
/*    */   }
/*    */   
/*    */   public static void register(ItemStack seed, double probability) {
/* 27 */     int p = -Math.abs(XURandom.rand.nextInt() | 0x57EF);
/* 28 */     MinecraftForge.addGrassSeed(seed, p);
/*    */     
/* 30 */     WeightedRandom.Item item = null;
/* 31 */     for (WeightedRandom.Item seedEntry : seedEntries) {
/* 32 */       if (seedEntry.itemWeight == p) {
/* 33 */         if (item != null) throw new RuntimeException("Unable to register seed entry");
/* 34 */         item = seedEntry;
/*    */       }
/*    */     }
/* 37 */     if (item == null) { throw new RuntimeException("Unable to register seed entry");
/*    */     }
/* 39 */     item.itemWeight = 0;
/*    */     
/* 41 */     probabilities.put(item, probability);
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void tick(TickEvent.ServerTickEvent event) {
/* 46 */     recalcProb();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onDrops(BlockEvent.HarvestDropsEvent event) {
/* 51 */     recalcProb();
/*    */   }
/*    */   
/*    */   public void recalcProb() {
/* 55 */     probabilities.forEachEntry(new TObjectDoubleProcedure()
/*    */     {
/*    */       public boolean execute(WeightedRandom.Item a, double b) {
/* 58 */         a.itemWeight = 0;
/* 59 */         return true;
/*    */       }
/*    */       
/* 62 */     });
/* 63 */     int i = 0;
/*    */     
/*    */ 
/* 66 */     for (int i1 = 0; i1 < seedEntries.size(); i1++) {
/* 67 */       WeightedRandom.Item entry = (WeightedRandom.Item)seedEntries.get(i1);
/* 68 */       i += entry.itemWeight;
/*    */     }
/*    */     
/* 71 */     final int totalWeight = i;
/*    */     
/* 73 */     probabilities.forEachEntry(new TObjectDoubleProcedure()
/*    */     {
/*    */       public boolean execute(WeightedRandom.Item a, double b) {
/* 76 */         double k = b * totalWeight;
/* 77 */         int w = (int)Math.floor(k);
/* 78 */         double p = k - w;
/* 79 */         if (XURandom.rand.nextDouble() < p) {
/* 80 */           w++;
/*    */         }
/* 82 */         a.itemWeight = w;
/* 83 */         return true;
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\eventhandlers\RareSeedHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */