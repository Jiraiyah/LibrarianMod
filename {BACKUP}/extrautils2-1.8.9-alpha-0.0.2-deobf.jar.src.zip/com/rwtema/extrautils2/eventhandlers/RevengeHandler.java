/*     */ package com.rwtema.extrautils2.eventhandlers;
/*     */ 
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.scoreboard.Team;
/*     */ import net.minecraft.scoreboard.Team.EnumVisible;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.management.ServerConfigurationManager;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*     */ 
/*     */ public class RevengeHandler
/*     */ {
/*     */   public static void init()
/*     */   {
/*  21 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new RevengeHandler());
/*     */   }
/*     */   
/*     */   @net.minecraftforge.fml.common.eventhandler.SubscribeEvent(priority=net.minecraftforge.fml.common.eventhandler.EventPriority.LOWEST)
/*     */   public void onLivingDeath(LivingDeathEvent event) {
/*  26 */     if (event.isCanceled()) return;
/*  27 */     Entity victim = event.entity;
/*  28 */     World worldObj = victim.worldObj;
/*  29 */     if ((worldObj == null) || (worldObj.isRemote)) { return;
/*     */     }
/*  31 */     if (!worldObj.getGameRules().getBoolean("showDeathMessages")) { return;
/*     */     }
/*  33 */     Entity attacker = event.source.getEntity();
/*  34 */     if (!(attacker instanceof net.minecraft.entity.EntityLivingBase)) {
/*  35 */       return;
/*     */     }
/*     */     
/*  38 */     boolean attackerIsPlayer = attacker instanceof EntityPlayerMP;
/*  39 */     boolean victimIsPlayer = victim instanceof EntityPlayerMP;
/*     */     
/*  41 */     if ((victimIsPlayer) || (attackerIsPlayer)) {
/*  42 */       if (!attackerIsPlayer) {
/*  43 */         NBTTagCompound killList = NBTHelper.getOrInitTagCompound(attacker.getEntityData(), "entityKillList");
/*  44 */         EntityPlayerMP victimPlayer = (EntityPlayerMP)victim;
/*  45 */         String tagKey = getTagKey(victimPlayer);
/*  46 */         int kills = killList.getInteger(tagKey);
/*  47 */         kills++;
/*  48 */         if (kills == 4) {
/*  49 */           sendToPlayersFriends(victimPlayer, getDominationMessage(attacker, victim));
/*     */         }
/*  51 */         killList.setInteger(tagKey, kills);
/*  52 */       } else if (!victimIsPlayer) {
/*  53 */         NBTTagCompound entityData = victim.getEntityData();
/*  54 */         if (!entityData.hasKey("entityKillList", 10)) return;
/*  55 */         NBTTagCompound killList = entityData.getCompoundTag("entityKillList");
/*  56 */         EntityPlayerMP attackerPlayer = (EntityPlayerMP)attacker;
/*  57 */         String tagKey = getTagKey(attackerPlayer);
/*  58 */         int kills = killList.getInteger(tagKey);
/*  59 */         if (kills > 0) {
/*  60 */           sendToPlayersFriends(attackerPlayer, getRevengeMessage(attacker, victim, kills >= 4));
/*     */         }
/*  62 */         killList.setInteger(tagKey, 0);
/*     */       } else {
/*  64 */         EntityPlayerMP victimPlayer = (EntityPlayerMP)victim;
/*  65 */         NBTTagCompound victimPersistentTag = NBTHelper.getPersistentTag(victimPlayer);
/*  66 */         if (victimPersistentTag.hasKey("playerKillList", 10)) {
/*  67 */           NBTTagCompound killList = victimPersistentTag.getCompoundTag("playerKillList");
/*  68 */           String tagKey = getTagKey((EntityPlayerMP)attacker);
/*  69 */           int kills = killList.getInteger(tagKey);
/*  70 */           if (kills >= 4) {
/*  71 */             sendToPlayersFriends(victimPlayer, getRevengeMessage(attacker, victim, true));
/*     */           }
/*  73 */           killList.setInteger(tagKey, 0);
/*     */         }
/*     */         
/*     */ 
/*  77 */         NBTTagCompound killList = NBTHelper.getOrInitTagCompound(NBTHelper.getPersistentTag((EntityPlayerMP)attacker), "playerKillList");
/*  78 */         String tagKey = getTagKey((EntityPlayerMP)victim);
/*  79 */         int kills = killList.getInteger(tagKey);
/*  80 */         kills++;
/*  81 */         if (kills == 4) {
/*  82 */           sendToPlayersFriends(victimPlayer, getDominationMessage(attacker, victim));
/*     */         }
/*  84 */         killList.setInteger(tagKey, kills);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void sendToPlayersFriends(EntityPlayerMP playerMP, IChatComponent chatComponent)
/*     */   {
/*  91 */     Team team = playerMP.getTeam();
/*  92 */     if ((team != null) && (team.getDeathMessageVisibility() != Team.EnumVisible.ALWAYS))
/*     */     {
/*  94 */       if (team.getDeathMessageVisibility() == Team.EnumVisible.HIDE_FOR_OTHER_TEAMS) {
/*  95 */         playerMP.mcServer.func_71203_ab().sendMessageToAllTeamMembers(playerMP, chatComponent);
/*  96 */       } else if (team.getDeathMessageVisibility() == Team.EnumVisible.HIDE_FOR_OWN_TEAM) {
/*  97 */         playerMP.mcServer.func_71203_ab().sendMessageToTeamOrAllPlayers(playerMP, chatComponent);
/*     */       }
/*     */     } else {
/* 100 */       sendToAllPlayers(playerMP.mcServer, chatComponent);
/*     */     }
/*     */   }
/*     */   
/*     */   private void sendToAllPlayers(MinecraftServer mcServer, IChatComponent chatComponent) {
/* 105 */     mcServer.func_71203_ab().sendChatMsg(chatComponent);
/*     */   }
/*     */   
/*     */   private IChatComponent getRevengeMessage(Entity attacker, Entity victim, boolean endDomination)
/*     */   {
/* 110 */     if (endDomination) {
/* 111 */       return Lang.chat("%s got revenge on nemesis %s", new Object[] { attacker.getDisplayName(), victim.getDisplayName() });
/*     */     }
/* 113 */     return Lang.chat("%s got revenge on %s", new Object[] { attacker.getDisplayName(), victim.getDisplayName() });
/*     */   }
/*     */   
/*     */   private IChatComponent getDominationMessage(Entity attacker, Entity victim) {
/* 117 */     return Lang.chat("%s is dominating %s", new Object[] { attacker.getDisplayName(), victim.getDisplayName() });
/*     */   }
/*     */   
/*     */   public String getTagKey(EntityPlayerMP player)
/*     */   {
/* 122 */     return player.getName();
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\eventhandlers\RevengeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */