/*    */ package com.rwtema.extrautils2.eventhandlers;
/*    */ 
/*    */ import com.google.common.collect.HashMultimap;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import org.apache.commons.lang3.tuple.Pair;
/*    */ 
/*    */ public class DropsHandler
/*    */ {
/* 14 */   public static HashMultimap<IBlockState, Pair<ItemStack, Double>> drops2add = ;
/*    */   
/*    */   static {
/* 17 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new DropsHandler());
/*    */   }
/*    */   
/*    */   public static void registerDrops(IBlockState state, ItemStack stack, double propability) {
/* 21 */     drops2add.put(state, Pair.of(stack, Double.valueOf(propability)));
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onDrop(BlockEvent.HarvestDropsEvent event) {
/* 26 */     java.util.Set<Pair<ItemStack, Double>> pairs = drops2add.get(event.state);
/* 27 */     if (pairs != null) {
/* 28 */       for (Pair<ItemStack, Double> pair : pairs) {
/* 29 */         while (com.rwtema.extrautils2.utils.XURandom.rand.nextDouble() < ((Double)pair.getRight()).doubleValue()) {
/* 30 */           event.drops.add(((ItemStack)pair.getLeft()).copy());
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\eventhandlers\DropsHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */