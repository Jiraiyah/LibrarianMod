/*    */ package com.rwtema.extrautils2.eventhandlers;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.boss.EntityDragonPart;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.event.entity.player.EntityInteractEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class ItemEntityInteractionOverride
/*    */ {
/* 15 */   public static final HashSet<net.minecraft.item.Item> items = ;
/*    */   
/*    */   static {
/* 18 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new ItemEntityInteractionOverride());
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void allowItemToInteract(EntityInteractEvent event) {
/* 23 */     ItemStack itemstack = event.entityPlayer.func_71045_bC();
/* 24 */     if ((itemstack != null) && (items.contains(itemstack.getItem()))) {
/* 25 */       Entity entity = event.target;
/* 26 */       if ((entity instanceof EntityDragonPart)) {
/* 27 */         entity = (Entity)((EntityDragonPart)entity).entityDragonObj;
/*    */       }
/*    */       
/* 30 */       if (((entity instanceof EntityLivingBase)) && 
/* 31 */         (itemstack.interactWithEntity(event.entityPlayer, (EntityLivingBase)entity))) {
/* 32 */         if (itemstack.stackSize <= 0) {
/* 33 */           event.entityPlayer.func_71028_bD();
/*    */         }
/*    */         
/* 36 */         event.setCanceled(true);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\eventhandlers\ItemEntityInteractionOverride.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */