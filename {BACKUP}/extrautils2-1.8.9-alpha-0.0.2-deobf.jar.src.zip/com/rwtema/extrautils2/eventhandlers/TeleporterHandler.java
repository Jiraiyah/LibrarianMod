/*    */ package com.rwtema.extrautils2.eventhandlers;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraftforge.event.entity.EntityEvent.EntityConstructing;
/*    */ import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TeleporterHandler
/*    */ {
/*    */   HashMap<net.minecraft.entity.EntityLivingBase, Loc> locations;
/*    */   
/* 15 */   public TeleporterHandler() { this.locations = new HashMap(); }
/*    */   
/*    */   @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
/*    */   public void entityConstructing(EntityEvent.EntityConstructing event) {
/* 19 */     if (!(event.entity instanceof net.minecraft.entity.EntityLivingBase)) return;
/* 20 */     event.entity.registerExtendedProperties("XUTele", new Loc());
/*    */   }
/*    */   
/*    */   @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
/*    */   public void entity(LivingEvent.LivingUpdateEvent event) {}
/*    */   
/*    */   public class Loc
/*    */     implements net.minecraftforge.common.IExtendedEntityProperties
/*    */   {
/*    */     double x;
/*    */     double y;
/*    */     double z;
/*    */     int dim;
/*    */     
/*    */     public Loc() {}
/*    */     
/*    */     public void saveNBTData(NBTTagCompound compound) {}
/*    */     
/*    */     public void loadNBTData(NBTTagCompound compound) {}
/*    */     
/*    */     public void init(Entity entity, net.minecraft.world.World world) {}
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\eventhandlers\TeleporterHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */