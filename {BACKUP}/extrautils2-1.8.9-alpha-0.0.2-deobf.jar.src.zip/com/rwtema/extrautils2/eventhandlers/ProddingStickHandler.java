/*    */ package com.rwtema.extrautils2.eventhandlers;
/*    */ 
/*    */ import net.minecraft.enchantment.EnchantmentHelper;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.network.NetHandlerPlayServer;
/*    */ import net.minecraft.util.DamageSource;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.event.entity.player.AttackEntityEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class ProddingStickHandler
/*    */ {
/*    */   public static void register()
/*    */   {
/* 22 */     MinecraftForge.EVENT_BUS.register(new ProddingStickHandler());
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void prod(AttackEntityEvent event)
/*    */   {
/* 28 */     EntityPlayer player = event.entityPlayer;
/* 29 */     if ((player == null) || (player.worldObj == null) || (player.worldObj.isRemote)) return;
/* 30 */     ItemStack heldItem = player.func_71045_bC();
/* 31 */     if ((heldItem == null) || (heldItem.getItem() != net.minecraft.init.Items.stick)) { return;
/*    */     }
/* 33 */     Entity targetEntity = event.target;
/*    */     
/* 35 */     if ((!targetEntity.canAttackWithItem()) || (targetEntity.hitByEntity(player)) || (!(targetEntity instanceof EntityLivingBase))) {
/* 36 */       return;
/*    */     }
/*    */     
/* 39 */     double i = 1 + EnchantmentHelper.getKnockbackModifier(player) + (player.isSprinting() ? 1 : 0);
/*    */     
/* 41 */     if (i <= 0.0D) { return;
/*    */     }
/* 43 */     double d0 = targetEntity.motionX;
/* 44 */     double d1 = targetEntity.motionY;
/* 45 */     double d2 = targetEntity.motionZ;
/*    */     
/* 47 */     if (!targetEntity.attackEntityFrom(DamageSource.causePlayerDamage(player), 1.0E-4F)) { return;
/*    */     }
/* 49 */     float rotation = player.rotationYaw * 3.1415927F / 180.0F;
/* 50 */     targetEntity.addVelocity(-MathHelper.sin(rotation) * i * 0.5D, 0.1D, MathHelper.cos(rotation) * i * 0.5D);
/*    */     
/*    */ 
/*    */ 
/* 54 */     player.motionX *= 0.6D;
/* 55 */     player.motionZ *= 0.6D;
/* 56 */     player.setSprinting(false);
/*    */     
/* 58 */     if (((targetEntity instanceof EntityPlayerMP)) && (targetEntity.velocityChanged)) {
/* 59 */       EntityPlayerMP playerMP = (EntityPlayerMP)targetEntity;
/* 60 */       playerMP.playerNetServerHandler.sendPacket(new net.minecraft.network.play.server.S12PacketEntityVelocity(targetEntity));
/* 61 */       com.rwtema.extrautils2.network.SpecialChat.sendChat(playerMP, com.rwtema.extrautils2.utils.Lang.chat("Poke!", new Object[0]));
/* 62 */       targetEntity.velocityChanged = false;
/* 63 */       targetEntity.motionX = d0;
/* 64 */       targetEntity.motionY = d1;
/* 65 */       targetEntity.motionZ = d2;
/*    */     }
/*    */     
/* 68 */     player.setLastAttacker(targetEntity);
/*    */     
/* 70 */     EnchantmentHelper.applyThornEnchantments((EntityLivingBase)targetEntity, player);
/*    */     
/* 72 */     heldItem.hitEntity((EntityLivingBase)targetEntity, player);
/*    */     
/* 74 */     if (heldItem.stackSize <= 0) {
/* 75 */       player.func_71028_bD();
/*    */     }
/*    */     
/* 78 */     player.addExhaustion(0.3F);
/*    */     
/* 80 */     event.setCanceled(true);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\eventhandlers\ProddingStickHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */