/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*     */ import com.rwtema.extrautils2.backend.entries.ItemEntry;
/*     */ import com.rwtema.extrautils2.network.NetworkHandler;
/*     */ import com.rwtema.extrautils2.power.ClientPower;
/*     */ import com.rwtema.extrautils2.power.PowerManager;
/*     */ import com.rwtema.extrautils2.power.player.IPlayerPowerCreator;
/*     */ import com.rwtema.extrautils2.power.player.PlayerPower;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.List;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ItemAngelRing extends XUItemFlatMetadata implements IPlayerPowerCreator
/*     */ {
/*  29 */   public static final String[] textures = { "angelring_base", "angelring_feather", "angelring_butterfly", "angelring_demon", "angelring_golden", "angelring_bat" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int POWER = 32;
/*     */   
/*     */ 
/*     */ 
/*  38 */   public static TObjectIntHashMap<String> serverFlyingPlayers = new TObjectIntHashMap(5, 0.5F, -1);
/*  39 */   public static TObjectIntHashMap<String> clientFlyingPlayers = new TObjectIntHashMap(5, 0.5F, -1);
/*     */   
/*     */   public ItemAngelRing() {
/*  42 */     super(textures);
/*  43 */     setMaxStackSize(1);
/*  44 */     setHasSubtypes(true);
/*     */   }
/*     */   
/*     */   public void getSubItems(Item itemIn, CreativeTabs tab, List<ItemStack> subItems)
/*     */   {
/*  49 */     for (int i = 0; i < 6; i++) {
/*  50 */       subItems.add(new ItemStack(itemIn, 1, i));
/*     */     }
/*     */   }
/*     */   
/*     */   public int getEntityLifespan(ItemStack itemStack, World world)
/*     */   {
/*  56 */     return 1073741822;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/*  62 */     super.addInformation(stack, playerIn, tooltip, advanced);
/*  63 */     tooltip.add(Lang.translateArgs("Uses %s GP", new Object[] { Integer.valueOf(32) }));
/*  64 */     tooltip.add(ClientPower.powerStatusString());
/*     */   }
/*     */   
/*     */   public boolean hasCustomEntity(ItemStack stack)
/*     */   {
/*  69 */     return true;
/*     */   }
/*     */   
/*     */   public Entity createEntity(World world, Entity location, ItemStack itemstack)
/*     */   {
/*  74 */     NBTTagCompound tag = new NBTTagCompound();
/*  75 */     location.writeToNBT(tag);
/*  76 */     tag.setBoolean("Invulnerable", true);
/*  77 */     location.readFromNBT(tag);
/*  78 */     return null;
/*     */   }
/*     */   
/*     */   public PlayerPower createPower(EntityPlayer player, ItemStack params)
/*     */   {
/*  83 */     return new PlayerPowerAngelRing(player, params.getItemDamage());
/*     */   }
/*     */   
/*     */   public static class PlayerPowerAngelRing extends PlayerPower {
/*     */     int type;
/*  88 */     boolean wasFlying = false;
/*     */     String name;
/*     */     int power;
/*     */     
/*     */     public PlayerPowerAngelRing(EntityPlayer referent, int type)
/*     */     {
/*  94 */       super();
/*     */       
/*  96 */       this.name = referent.getGameProfile().getName();
/*  97 */       this.type = type;
/*     */     }
/*     */     
/*     */     public float power(EntityPlayer playerMP)
/*     */     {
/* 102 */       return this.power;
/*     */     }
/*     */     
/*     */     public void powerChanged(boolean powered)
/*     */     {
/* 107 */       if (this.invalid) { return;
/*     */       }
/* 109 */       EntityPlayerMP entityPlayerMP = getPlayerMP();
/* 110 */       if (entityPlayerMP.capabilities.isCreativeMode) powered = true;
/* 111 */       if (entityPlayerMP.capabilities.allowFlying != powered) {
/* 112 */         entityPlayerMP.capabilities.allowFlying = powered;
/* 113 */         if (!powered) entityPlayerMP.capabilities.isFlying = false;
/* 114 */         entityPlayerMP.sendPlayerAbilities();
/*     */       }
/*     */     }
/*     */     
/*     */     @javax.annotation.Nonnull
/*     */     public String getName()
/*     */     {
/* 121 */       return ((ItemAngelRing)com.rwtema.extrautils2.backend.entries.XU2Entries.angelRing.value).getUnlocalizedName() + ".name";
/*     */     }
/*     */     
/*     */     public void onAdd()
/*     */     {
/* 126 */       if (PowerManager.instance.isPowered(getPlayerMP()))
/* 127 */         getPlayer().capabilities.allowFlying = true;
/* 128 */       getPlayer().sendPlayerAbilities();
/*     */       
/* 130 */       ItemAngelRing.serverFlyingPlayers.put(this.name, this.type);
/* 131 */       NetworkHandler.sendToAllPlayers(new ItemAngelRing.PacketAngelRingNotifier(this.name, this.type));
/*     */     }
/*     */     
/*     */     public void onRemove()
/*     */     {
/* 136 */       EntityPlayer player = getPlayer();
/* 137 */       if (!player.capabilities.isCreativeMode) {
/* 138 */         player.capabilities.allowFlying = false;
/* 139 */         player.capabilities.isFlying = false;
/* 140 */         player.sendPlayerAbilities();
/*     */       }
/*     */       
/* 143 */       ItemAngelRing.serverFlyingPlayers.remove(this.name);
/* 144 */       NetworkHandler.sendToAllPlayers(new ItemAngelRing.PacketAngelRingNotifier(this.name, 0));
/*     */     }
/*     */     
/*     */     public void update(boolean selected, ItemStack params)
/*     */     {
/* 149 */       if (this.invalid) { return;
/*     */       }
/* 151 */       int t = params.getItemDamage();
/*     */       
/* 153 */       if ((!ItemAngelRing.serverFlyingPlayers.containsKey(this.name)) || ((selected) && (ItemAngelRing.serverFlyingPlayers.get(this.name) != t))) {
/* 154 */         ItemAngelRing.serverFlyingPlayers.put(this.name, this.type);
/* 155 */         NetworkHandler.sendToAllPlayers(new ItemAngelRing.PacketAngelRingNotifier(this.name, t));
/*     */       }
/*     */       
/* 158 */       EntityPlayerMP player = getPlayerMP();
/*     */       
/*     */ 
/* 161 */       if ((!player.capabilities.allowFlying) && 
/* 162 */         (PowerManager.instance.isPowered(player))) {
/* 163 */         player.capabilities.allowFlying = true;
/* 164 */         player.sendPlayerAbilities();
/*     */       }
/*     */       
/*     */ 
/* 168 */       if (player.capabilities.isFlying) {
/* 169 */         this.wasFlying = true;
/* 170 */         this.power = 32;
/*     */       }
/*     */       
/* 173 */       if (this.wasFlying) {
/* 174 */         if (player.onGround) {
/* 175 */           this.wasFlying = false;
/* 176 */           this.power = 0;
/*     */         }
/* 178 */         this.power = 32;
/*     */       } else {
/* 180 */         this.power = 0;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     @SideOnly(Side.CLIENT)
/*     */     public void tickClient() {}
/*     */   }
/*     */   
/*     */ 
/*     */   @com.rwtema.extrautils2.network.NetworkHandler.XUPacket
/*     */   public static class PacketAngelRingNotifier
/*     */     extends com.rwtema.extrautils2.network.XUPacketServerToClient
/*     */   {
/*     */     String username;
/*     */     
/*     */     int wingType;
/*     */     
/*     */ 
/*     */     public PacketAngelRingNotifier() {}
/*     */     
/*     */     public PacketAngelRingNotifier(String player, int wing)
/*     */     {
/* 203 */       this.username = player;
/* 204 */       this.wingType = wing;
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/* 209 */       writeString(this.username);
/* 210 */       this.data.writeByte(this.wingType);
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player)
/*     */     {
/* 215 */       this.username = readString();
/* 216 */       this.wingType = this.data.readByte();
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public Runnable doStuffClient()
/*     */     {
/* 222 */       new Runnable()
/*     */       {
/*     */         public void run() {
/* 225 */           if (ItemAngelRing.PacketAngelRingNotifier.this.wingType > 0) {
/* 226 */             ItemAngelRing.clientFlyingPlayers.put(ItemAngelRing.PacketAngelRingNotifier.this.username, ItemAngelRing.PacketAngelRingNotifier.this.wingType);
/*     */           } else {
/* 228 */             ItemAngelRing.clientFlyingPlayers.remove(ItemAngelRing.PacketAngelRingNotifier.this.username);
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemAngelRing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */