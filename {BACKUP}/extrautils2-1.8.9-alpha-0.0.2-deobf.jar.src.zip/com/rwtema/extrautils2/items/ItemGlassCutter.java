/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.PlayerCapabilities;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemGlassCutter extends XUItemFlatMetadata
/*    */ {
/*    */   public ItemGlassCutter()
/*    */   {
/* 21 */     super(new String[] { "glasscutter" });
/* 22 */     setMaxStackSize(1);
/* 23 */     setMaxDamage(250);
/*    */   }
/*    */   
/*    */   public boolean onBlockDestroyed(ItemStack stack, World worldIn, Block blockIn, BlockPos pos, EntityLivingBase playerIn)
/*    */   {
/* 28 */     if (blockIn.getBlockHardness(worldIn, pos) != 0.0F) {
/* 29 */       stack.damageItem(1, playerIn);
/*    */     }
/* 31 */     return true;
/*    */   }
/*    */   
/*    */   public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected)
/*    */   {
/* 36 */     NBTTagList tagList = stack.getEnchantmentTagList();
/* 37 */     if (tagList != null) {
/* 38 */       for (int i = 0; i < tagList.tagCount(); i++) {
/* 39 */         if (tagList.getCompoundTagAt(i).getShort("id") == Enchantment.field_77348_q.field_77352_x) {
/* 40 */           tagList.removeTag(i);
/* 41 */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean hasEffect(ItemStack stack)
/*    */   {
/* 49 */     return false;
/*    */   }
/*    */   
/*    */   public boolean renderAsTool()
/*    */   {
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   public boolean onBlockStartBreak(ItemStack itemstack, BlockPos pos, EntityPlayer player)
/*    */   {
/* 59 */     if ((!player.capabilities.isCreativeMode) && (player.worldObj.getBlockState(pos).getBlock().getMaterial() == Material.glass)) {
/* 60 */       if (net.minecraft.enchantment.EnchantmentHelper.getEnchantmentLevel(Enchantment.field_77348_q.field_77352_x, itemstack) == 0)
/* 61 */         itemstack.addEnchantment(Enchantment.field_77348_q, 1);
/*    */     } else {
/* 63 */       NBTTagList tagList = itemstack.getEnchantmentTagList();
/* 64 */       if (tagList != null) {
/* 65 */         for (int i = 0; i < tagList.tagCount(); i++) {
/* 66 */           if (tagList.getCompoundTagAt(i).getShort("id") == Enchantment.field_77348_q.field_77352_x) {
/* 67 */             tagList.removeTag(i);
/* 68 */             break;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 73 */     return super.onBlockStartBreak(itemstack, pos, player);
/*    */   }
/*    */   
/*    */   public boolean canHarvestBlock(Block par1Block, ItemStack itemStack)
/*    */   {
/* 78 */     return par1Block.getMaterial() == Material.glass;
/*    */   }
/*    */   
/*    */   public float getStrVsBlock(ItemStack stack, Block block)
/*    */   {
/* 83 */     return block.getMaterial() == Material.glass ? 4.0F : super.getStrVsBlock(stack, block);
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack toRepair, ItemStack repair) {
/* 87 */     return (net.minecraftforge.oredict.OreDictionary.itemMatches(new ItemStack(net.minecraft.init.Items.iron_ingot), repair, false)) || (super.getIsRepairable(toRepair, repair));
/*    */   }
/*    */   
/*    */   public ItemStack getContainerItem(ItemStack itemStack)
/*    */   {
/* 92 */     ItemStack copy = itemStack.copy();
/* 93 */     copy.attemptDamageItem(1, com.rwtema.extrautils2.ExtraUtils2.RANDOM);
/* 94 */     return copy;
/*    */   }
/*    */   
/*    */   public boolean hasContainerItem(ItemStack stack)
/*    */   {
/* 99 */     return stack.getItemDamage() < stack.getMaxDamage();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemGlassCutter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */