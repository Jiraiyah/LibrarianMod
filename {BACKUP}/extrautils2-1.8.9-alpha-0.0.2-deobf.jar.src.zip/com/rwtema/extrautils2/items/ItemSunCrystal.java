/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.ImmutableList.Builder;
/*     */ import com.rwtema.extrautils2.backend.XUItem;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem.ModelLayer;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.backend.model.UV;
/*     */ import com.rwtema.extrautils2.power.player.IPlayerPowerCreator;
/*     */ import com.rwtema.extrautils2.power.player.PlayerPower;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.MCTimer;
/*     */ import com.rwtema.extrautils2.utils.helpers.ColorHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.QuadHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javax.vecmath.Matrix4f;
/*     */ import javax.vecmath.Vector4f;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.EnumSkyBlock;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldProvider;
/*     */ import net.minecraftforge.client.model.TRSRTransformation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ 
/*     */ public class ItemSunCrystal extends XUItem
/*     */ {
/*  44 */   public static IPlayerPowerCreator creator = new IPlayerPowerCreator()
/*     */   {
/*     */ 
/*  47 */     public PlayerPower createPower(EntityPlayer player, ItemStack params) { return new ItemSunCrystal.PlayerLight(player); } };
/*     */   @SideOnly(Side.CLIENT)
/*     */   TextureAtlasSprite sprite;
/*     */   @SideOnly(Side.CLIENT)
/*     */   TextureAtlasSprite sprite2;
/*     */   @SideOnly(Side.CLIENT)
/*     */   TextureAtlasSprite gradient; @SideOnly(Side.CLIENT)
/*  54 */   List<BakedQuad> rays; float prevTime = -1.0F;
/*     */   @SideOnly(Side.CLIENT)
/*     */   Vector3f[] vecs;
/*     */   
/*     */   public ItemSunCrystal() {
/*  59 */     setMaxDamage(250);
/*  60 */     setMaxStackSize(1);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/*  66 */     Textures.register(new String[] { "gradient", "sun_crystal", "sun_crystal2" });
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void postTextureRegister()
/*     */   {
/*  72 */     this.sprite = ((TextureAtlasSprite)Textures.sprites.get("sun_crystal"));
/*  73 */     this.sprite2 = ((TextureAtlasSprite)Textures.sprites.get("sun_crystal2"));
/*  74 */     this.gradient = ((TextureAtlasSprite)Textures.sprites.get("gradient"));
/*     */   }
/*     */   
/*     */   public void getSubItems(Item itemIn, CreativeTabs tab, List<ItemStack> subItems)
/*     */   {
/*  79 */     subItems.add(new ItemStack(itemIn, 1, 0));
/*  80 */     subItems.add(new ItemStack(itemIn, 1, itemIn.getMaxDamage()));
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public TextureAtlasSprite getBaseTexture()
/*     */   {
/*  86 */     return this.sprite;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean onEntityItemUpdate(EntityItem entityItem)
/*     */   {
/*  96 */     ItemStack item = entityItem.getEntityItem();
/*  97 */     int itemDamage = item.getItemDamage();
/*  98 */     if (itemDamage > 0) {
/*  99 */       World worldObj = entityItem.worldObj;
/* 100 */       if (!worldObj.provider.getHasNoSky()) {
/* 101 */         BlockPos pos = new BlockPos(entityItem.posX, entityItem.getEntityBoundingBox().minY, entityItem.posZ);
/*     */         
/* 103 */         if (!worldObj.canSeeSky(pos)) { return false;
/*     */         }
/* 105 */         int i = worldObj.getLightFor(EnumSkyBlock.SKY, pos) - worldObj.getSkylightSubtracted();
/* 106 */         float f = worldObj.getCelestialAngleRadians(1.0F);
/* 107 */         float f1 = f < 3.1415927F ? 0.0F : 6.2831855F;
/* 108 */         f += (f1 - f) * 0.2F;
/* 109 */         i = Math.round(i * MathHelper.cos(f));
/* 110 */         if ((i > 0) && ((i >= 15) || (worldObj.rand.nextInt(15) < i))) {
/* 111 */           item.setItemDamage(itemDamage - 1);
/*     */         }
/*     */       }
/*     */     }
/* 115 */     return false;
/*     */   }
/*     */   
/*     */   public boolean allowOverride()
/*     */   {
/* 120 */     return false;
/*     */   }
/*     */   
/*     */   public int getMaxMetadata()
/*     */   {
/* 125 */     return 0;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addQuads(PassthruModelItem.ModelLayer model, ItemStack stack)
/*     */   {
/* 131 */     model.addSprite(this.sprite);
/* 132 */     TextureAtlasSprite sprite2 = this.sprite2;
/*     */     
/* 134 */     model.addGLState(new com.rwtema.extrautils2.utils.client.GLState.DepthState(false));
/*     */     
/* 136 */     int progress = 255 - stack.getItemDamage() * 255 / stack.getMaxDamage();
/* 137 */     int color = ColorHelper.makeAlphaWhite(progress);
/*     */     
/* 139 */     if (this.rays == null) {
/* 140 */       this.rays = new ArrayList();
/*     */       
/* 142 */       this.vecs = new Vector3f[] { new Vector3f(1.0F, 0.0F, 0.0F), new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(0.0F, 0.0F, 1.0F), new Vector3f(1.0F, 0.0F, 0.0F), new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(0.0F, 0.0F, 1.0F) };
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */     this.rays.clear();
/*     */     
/* 154 */     ImmutableList.Builder<BakedQuad> builder = ImmutableList.builder();
/*     */     
/* 156 */     builder.add(QuadHelper.buildQuad(DefaultVertexFormats.ITEM, TRSRTransformation.identity(), EnumFacing.SOUTH, -1, 0.0F, 0.0F, 0.46875F, sprite2.getMinU(), sprite2.getMaxV(), 0.0F, 1.0F, 0.46875F, sprite2.getMinU(), sprite2.getMinV(), 1.0F, 1.0F, 0.46875F, sprite2.getMaxU(), sprite2.getMinV(), 1.0F, 0.0F, 0.46875F, sprite2.getMaxU(), sprite2.getMaxV(), color));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */     builder.add(QuadHelper.buildQuad(DefaultVertexFormats.ITEM, TRSRTransformation.identity(), EnumFacing.NORTH, -1, 0.0F, 0.0F, 0.53125F, sprite2.getMinU(), sprite2.getMaxV(), 1.0F, 0.0F, 0.53125F, sprite2.getMaxU(), sprite2.getMaxV(), 1.0F, 1.0F, 0.53125F, sprite2.getMaxU(), sprite2.getMinV(), 0.0F, 1.0F, 0.53125F, sprite2.getMinU(), sprite2.getMinV(), color));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     this.rays.addAll(builder.build());
/*     */     
/*     */ 
/* 172 */     Random rand = new Random(425L + System.identityHashCode(stack));
/*     */     
/* 174 */     Matrix4f matrix = new Matrix4f();
/* 175 */     matrix.setIdentity();
/*     */     
/* 177 */     Vector4f b = new Vector4f();
/* 178 */     Vector4f c = new Vector4f();
/* 179 */     Vector4f d = new Vector4f();
/*     */     
/*     */ 
/* 182 */     for (int i = 0; i < 16; i++) {
/* 183 */       for (Vector3f vec : this.vecs) {
/* 184 */         QuadHelper.rotate(6.2831855F * rand.nextFloat() + MCTimer.renderTimer / 360.0F, vec, matrix, matrix);
/*     */       }
/*     */       
/* 187 */       float r = (1.0F + rand.nextFloat() * 0.5F) * progress / 255.0F;
/*     */       
/* 189 */       QuadHelper.rotate(MCTimer.renderTimer / 180.0F, new Vector3f(0.0F, 1.0F, 0.0F), matrix, matrix);
/*     */       
/* 191 */       b.set(0.0F, 0.126F * r, 0.5F * r, 1.0F);
/* 192 */       c.set(0.0F, -0.126F * r, 0.5F * r, 1.0F);
/* 193 */       d.set(0.0F, 0.0F, 0.6F * r, 1.0F);
/*     */       
/* 195 */       matrix.transform(b);
/* 196 */       matrix.transform(c);
/* 197 */       matrix.transform(d);
/*     */       
/* 199 */       this.rays.add(QuadHelper.createBakedQuad(new UV[] { new UV(0.5F, 0.5F, 0.5F, 0.5F, 1.0F), new UV(0.5F + b.x, 0.5F + b.y, 0.5F + b.z, 1.0F, 0.0F), new UV(0.5F + d.x, 0.5F + d.y, 0.5F + d.z, 0.5F, 0.0F), new UV(0.5F + c.x, 0.5F + c.y, 0.5F + c.z, 0.0F, 0.0F) }, "gradient", false, -1));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 206 */       this.rays.add(QuadHelper.createBakedQuad(new UV[] { new UV(0.5F, 0.5F, 0.5F, 0.5F, 1.0F), new UV(0.5F + c.x, 0.5F + c.y, 0.5F + c.z, 0.0F, 0.0F), new UV(0.5F + d.x, 0.5F + d.y, 0.5F + d.z, 0.5F, 0.0F), new UV(0.5F + b.x, 0.5F + b.y, 0.5F + b.z, 1.0F, 0.0F) }, "gradient", false, -1));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 229 */     model.addAllQuads(this.rays);
/*     */   }
/*     */   
/*     */   public String getUnlocalizedName(ItemStack stack)
/*     */   {
/* 234 */     if (stack.getItemDamage() == stack.getMaxDamage())
/* 235 */       return super.getUnlocalizedName(stack) + ".empty";
/* 236 */     return super.getUnlocalizedName(stack);
/*     */   }
/*     */   
/*     */   public static class PlayerLight extends PlayerPower implements com.rwtema.extrautils2.lighting.ILight {
/* 240 */     final double RADIUS = 5.0D;
/*     */     Vec3 center;
/*     */     
/*     */     public PlayerLight(@javax.annotation.Nonnull EntityPlayer player)
/*     */     {
/* 245 */       super();
/* 246 */       loadPlayerCenter(player);
/*     */     }
/*     */     
/*     */     public World getLightWorld()
/*     */     {
/* 251 */       return getPlayer().worldObj;
/*     */     }
/*     */     
/*     */     public float getLightOffset(BlockPos pos)
/*     */     {
/* 256 */       double dx = pos.getX() - this.center.xCoord;
/* 257 */       double dy = pos.getY() - this.center.yCoord;
/* 258 */       double dz = pos.getZ() - this.center.zCoord;
/* 259 */       double t = 1.0D - Math.sqrt(dx * dx + dy * dy + dz * dz) / 5.0D;
/*     */       
/* 261 */       return MathHelper.clamp_int((int)(t * 16.0D), 0, 15);
/*     */     }
/*     */     
/*     */     public EnumSkyBlock[] getLightType()
/*     */     {
/* 266 */       return new EnumSkyBlock[] { EnumSkyBlock.BLOCK };
/*     */     }
/*     */     
/*     */     public float power(EntityPlayer playerMP)
/*     */     {
/* 271 */       return 0.0F;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void powerChanged(boolean powered) {}
/*     */     
/*     */ 
/*     */     public String getName()
/*     */     {
/* 281 */       return Lang.translate("FlashLight");
/*     */     }
/*     */     
/*     */     public void tick()
/*     */     {
/* 286 */       EntityPlayer player = getPlayer();
/* 287 */       loadPlayerCenter(player);
/*     */     }
/*     */     
/*     */     public void loadPlayerCenter(EntityPlayer player) {
/* 291 */       this.center = new Vec3(player.posX, player.posY, player.posZ);
/*     */     }
/*     */     
/*     */     public void tickClient()
/*     */     {
/* 296 */       Vec3 pos = this.center;
/* 297 */       tick();
/* 298 */       if (this.center.distanceTo(pos) > 0.01D) {
/* 299 */         World world = getPlayer().worldObj;
/* 300 */         world.markBlockRangeForRenderUpdate((int)(this.center.xCoord - 5.0D), (int)(this.center.yCoord - 5.0D), (int)(this.center.zCoord - 5.0D), (int)(this.center.xCoord + 5.0D), (int)(this.center.yCoord + 5.0D), (int)(this.center.zCoord + 5.0D));
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 309 */         this.center = pos;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemSunCrystal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */