/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*     */ import com.rwtema.extrautils2.backend.entries.ItemClassEntry;
/*     */ import com.rwtema.extrautils2.backend.entries.XU2Entries;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainer;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicGui;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicWindow;
/*     */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*     */ import com.rwtema.extrautils2.gui.backend.IWidget;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetButton;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetEntity;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetRawData;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetTextSmallText;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.passive.EntityVillager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ItemContract extends XUItemFlatMetadata implements IDynamicHandler
/*     */ {
/*     */   public static final String TAG_UNDER_CONTRACT = "Contracted";
/*     */   static final String TAG_CONTRACT_LEVEL = "ContractLevel";
/*     */   
/*     */   public ItemContract()
/*     */   {
/*  42 */     super(new String[] { "contract" });
/*  43 */     com.rwtema.extrautils2.eventhandlers.ItemEntityInteractionOverride.items.add(this);
/*     */   }
/*     */   
/*     */   public boolean itemInteractionForEntity(ItemStack stack, EntityPlayer playerIn, EntityLivingBase target)
/*     */   {
/*  48 */     if (!(target instanceof EntityVillager)) {
/*  49 */       return false;
/*     */     }
/*  51 */     EntityVillager villager = (EntityVillager)target;
/*  52 */     if (villager.worldObj.isRemote) return true;
/*  53 */     if (villager.isChild()) return true;
/*  54 */     if (villager.getCustomer() != null) { return true;
/*     */     }
/*  56 */     if (!com.rwtema.extrautils2.utils.helpers.PlayerHelper.isPlayerReal(playerIn)) { return true;
/*     */     }
/*  58 */     NBTTagCompound data = villager.getEntityData();
/*  59 */     if (data.getBoolean("Contracted")) {
/*  60 */       return false;
/*     */     }
/*  62 */     if (!data.hasKey("ContractLevel", 3)) {
/*     */       int value;
/*  64 */       switch (playerIn.worldObj.rand.nextInt(3)) {
/*     */       case 0: 
/*  66 */         value = 2;
/*  67 */         break;
/*     */       default: 
/*  69 */         value = 0;
/*     */       }
/*     */       
/*     */       
/*  73 */       data.setInteger("ContractLevel", value);
/*     */     }
/*     */     
/*  76 */     int i = data.getInteger("ContractLevel");
/*     */     
/*  78 */     int r = 0;
/*  79 */     UUID uuid = villager.getPersistentID();
/*     */     
/*  81 */     long l = uuid.getLeastSignificantBits();
/*  82 */     r ^= (int)(l >>> 32 ^ l);
/*  83 */     l = uuid.getMostSignificantBits();
/*  84 */     r ^= (int)(l >>> 32 ^ l);
/*     */     
/*  86 */     playerIn.openGui(com.rwtema.extrautils2.ExtraUtils2.instance, -1, playerIn.worldObj, villager.getEntityId(), r, i);
/*     */     
/*  88 */     return true;
/*     */   }
/*     */   
/*     */   public DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int id, int rng, int responseLevel)
/*     */   {
/*  93 */     Entity entityByID = world.getEntityByID(id);
/*  94 */     if (!(entityByID instanceof EntityVillager)) return null;
/*  95 */     EntityVillager villager = (EntityVillager)entityByID;
/*  96 */     villager.setCustomer(player);
/*  97 */     return new ContainerContract(villager, player, id, rng, responseLevel);
/*     */   }
/*     */   
/*     */   public static class ContainerContract extends DynamicContainer {
/* 101 */     public static final ResourceLocation texBackground = new ResourceLocation("extrautils2", "textures/parchment.png");
/* 102 */     private static final BigInteger TWO_64 = BigInteger.ONE.shiftLeft(64);
/* 103 */     static String[] keys = { "villager.response.no_deal", "villager.response.trade_first", "villager.response.deal" };
/*     */     
/*     */     public final DynamicWindow sideWindow;
/*     */     
/*     */     EntityVillager villager;
/*     */     
/*     */     EntityPlayer player;
/*     */     InventoryPlayer inventory;
/*     */     
/*     */     public ContainerContract(final EntityVillager villager, final EntityPlayer player, int id, int rng, int responseLevel)
/*     */     {
/* 114 */       this.villager = villager;
/* 115 */       this.player = player;
/* 116 */       this.inventory = player.inventory;
/*     */       
/* 118 */       final WidgetTextSmallText text = new WidgetTextSmallText(9, 9, "", 111);
/* 119 */       addWidget(text);
/*     */       
/* 121 */       addWidget(new WidgetRawData()
/*     */       {
/*     */         public void addToDescription(PacketBuffer packet) {
/* 124 */           EntityVillager villager1 = ItemContract.ContainerContract.this.villager;
/* 125 */           UUID uniqueID = villager1.getUniqueID();
/* 126 */           packet.writeLong(uniqueID.getLeastSignificantBits() | uniqueID.getMostSignificantBits());
/* 127 */           packet.writeChatComponent(villager1.getDisplayName());
/*     */         }
/*     */         
/*     */         public void handleDescriptionPacket(PacketBuffer packet)
/*     */         {
/* 132 */           long num = packet.readLong();
/* 133 */           IChatComponent iChatComponent = packet.readChatComponent();
/* 134 */           text.msg = Lang.translateArgs(false, "villager.contract", "I, \"Villager No. %s\",\nalso known as \"%s\",\n\nbeing of sound mind and body, do agree to allow my physical, spiritual and/or mental essences to be bound to a physical object, and to use any skills that I may currently possess to provide useful service to \"%s\". I agree that my essence shall remain bound to the physical object until either...\n\n1. The object is destroyed\n2. The universe ends\n3. The very concept of time and/or entropy is destroyed or rendered untenable\n4. I get bored of standing around in limbo making weird noises, and float away to the next life (which is unlikely since I like making weird noises).\n\n\nSigned  ______________", new Object[] { ItemContract.ContainerContract.unsigned(num), iChatComponent.getFormattedText(), ItemContract.ContainerContract.this.player.getName() }).replaceAll("\\\\n", "\n");
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 142 */       });
/* 143 */       this.width = 130;
/* 144 */       this.height = 165;
/*     */       
/* 146 */       this.sideWindow = new DynamicWindow();
/* 147 */       IWidget w = new WidgetEntity(villager, 20, 4, 4, 100, 60);
/* 148 */       addWidget(w, this.sideWindow);
/*     */       
/* 150 */       int i = responseLevel % 3;
/* 151 */       if (i == 2) {
/* 152 */         addWidget( = new WidgetButton(w.getX(), w.getY() + w.getH() + 4, w.getW(), 20, Lang.translate("Sign"))
/*     */         {
/*     */           public void onClickServer(PacketBuffer buffer) {
/* 155 */             if (villager.isDead) { return;
/*     */             }
/* 157 */             NBTTagCompound data = villager.getEntityData();
/* 158 */             if (data.getBoolean("Contracted")) {
/* 159 */               return;
/*     */             }
/* 161 */             int i = data.getInteger("ContractLevel");
/*     */             
/* 163 */             if (i == 2) {
/* 164 */               if (player.inventory.func_146028_b((Item)XU2Entries.contract.value)) {
/* 165 */                 player.inventory.func_146026_a((Item)XU2Entries.contract.value);
/* 166 */                 data.setBoolean("Contracted", true);
/*     */               }
/* 168 */               player.closeScreen(); } } }, this.sideWindow);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 174 */       addWidget(w = new com.rwtema.extrautils2.gui.backend.WidgetTextMultiline(w.getX(), w.getY() + w.getH() + 4, Lang.random(keys[i], rng).replaceAll("\\\\n", "\n"), w.getW()), this.sideWindow);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */       validate();
/*     */     }
/*     */     
/*     */     private static String unsigned(long num) {
/* 186 */       BigInteger a = BigInteger.valueOf(num);
/* 187 */       if (a.signum() < 0) a = a.add(TWO_64);
/* 188 */       return a.toString();
/*     */     }
/*     */     
/*     */     public void onContainerClosed(EntityPlayer playerIn)
/*     */     {
/* 193 */       this.villager.setCustomer(null);
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public boolean drawBackgroundOverride(DynamicGui gui)
/*     */     {
/* 199 */       Minecraft.getMinecraft().renderEngine.bindTexture(texBackground);
/* 200 */       gui.drawTexturedModalRect(gui.guiLeft, gui.guiTop, 0, 0, this.width, this.height);
/* 201 */       return true;
/*     */     }
/*     */     
/*     */     public boolean canInteractWith(EntityPlayer playerIn)
/*     */     {
/* 206 */       return (this.villager.getCustomer() == playerIn) && (!this.villager.isDead);
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public void loadGuiDimensions(DynamicGui dynamicGui)
/*     */     {
/* 212 */       dynamicGui.xSize = this.width;
/* 213 */       dynamicGui.ySize = this.height;
/* 214 */       dynamicGui.guiLeft = ((dynamicGui.width - dynamicGui.xSize - this.sideWindow.w) / 2);
/* 215 */       dynamicGui.guiTop = ((dynamicGui.height - dynamicGui.ySize) / 2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemContract.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */