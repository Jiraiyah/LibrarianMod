/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemFlashlight
/*    */   extends XUItemFlatMetadata
/*    */ {
/*    */   public ItemFlashlight()
/*    */   {
/* 18 */     super(new String[] { "" });
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemFlashlight.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */