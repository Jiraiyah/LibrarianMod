/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUItemFlat;
/*    */ import com.rwtema.extrautils2.backend.model.Textures;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class ItemEnderShard extends XUItemFlat
/*    */ {
/*    */   @SideOnly(Side.CLIENT)
/*    */   String[] tex;
/*    */   
/*    */   public ItemEnderShard()
/*    */   {
/* 16 */     setMaxStackSize(8);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void registerTextures()
/*    */   {
/* 22 */     this.tex = new String[8];
/* 23 */     for (int i = 1; i <= 8; i++) {
/* 24 */       this.tex[(i - 1)] = ("endershards/endershard_" + i);
/* 25 */       Textures.register(new String[] { this.tex[(i - 1)] });
/*    */     }
/*    */   }
/*    */   
/*    */   public int getMaxMetadata()
/*    */   {
/* 31 */     return 0;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public String getTexture(@javax.annotation.Nullable ItemStack itemStack, int renderPass) {
/*    */     int size;
/*    */     int size;
/* 38 */     if (itemStack == null) {
/* 39 */       size = 1;
/*    */     } else {
/* 41 */       size = itemStack.stackSize;
/* 42 */       if ((size < 1) || (size > 8)) { size = 1;
/*    */       }
/*    */     }
/* 45 */     return this.tex[(size - 1)];
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemEnderShard.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */