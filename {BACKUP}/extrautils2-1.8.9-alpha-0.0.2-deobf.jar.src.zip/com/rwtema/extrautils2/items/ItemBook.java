/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import com.rwtema.extrautils2.XUProxy;
/*    */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*    */ import com.rwtema.extrautils2.book.BookHandler;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiScreenBook;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class ItemBook extends XUItemFlatMetadata
/*    */ {
/*    */   public ItemBook()
/*    */   {
/* 19 */     super(new String[] { "book" });
/* 20 */     setMaxStackSize(1);
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn, final EntityPlayer playerIn)
/*    */   {
/* 25 */     if (worldIn.isRemote) {
/* 26 */       ExtraUtils2.proxy.run(new com.rwtema.extrautils2.backend.ClientCallable()
/*    */       {
/*    */         @SideOnly(Side.CLIENT)
/*    */         public void runClient() {
/*    */           try {
/* 31 */             ItemStack bookStack = BookHandler.newStack();
/* 32 */             if (bookStack == null) return;
/* 33 */             Minecraft.getMinecraft().displayGuiScreen(new GuiScreenBook(playerIn, bookStack, false));
/*    */           } catch (Throwable err) {
/* 35 */             err.printStackTrace();
/*    */           }
/*    */         }
/*    */       });
/*    */     }
/* 40 */     return itemStackIn;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemBook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */