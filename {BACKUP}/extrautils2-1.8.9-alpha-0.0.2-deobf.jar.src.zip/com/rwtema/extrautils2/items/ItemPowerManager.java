/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*    */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemPowerManager extends XUItemFlatMetadata implements IDynamicHandler
/*    */ {
/*    */   public ItemPowerManager()
/*    */   {
/* 13 */     super(new String[] { "power_scanner" });
/* 14 */     setMaxStackSize(1);
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn)
/*    */   {
/* 19 */     if (!worldIn.isRemote) {
/* 20 */       openItemGui(playerIn);
/*    */     }
/*    */     
/* 23 */     return itemStackIn;
/*    */   }
/*    */   
/*    */   public com.rwtema.extrautils2.gui.backend.DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z)
/*    */   {
/* 28 */     return new com.rwtema.extrautils2.gui.ContainerPowerReport(player);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemPowerManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */