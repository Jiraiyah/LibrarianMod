/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainer;
/*     */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetSlotItemHandler;
/*     */ import com.rwtema.extrautils2.itemhandler.SingleStackHandlerBase;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.capabilities.Capability;
/*     */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*     */ import net.minecraftforge.items.CapabilityItemHandler;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import net.minecraftforge.items.IItemHandlerModifiable;
/*     */ import net.minecraftforge.items.ItemHandlerHelper;
/*     */ import net.minecraftforge.items.wrapper.EmptyHandler;
/*     */ 
/*     */ public class ItemBagOfHolding extends XUItemFlatMetadata implements IDynamicHandler
/*     */ {
/*     */   public ItemBagOfHolding()
/*     */   {
/*  29 */     super(new String[] { "bag_of_holding" });
/*  30 */     setMaxStackSize(1);
/*     */   }
/*     */   
/*     */   public ICapabilityProvider initCapabilities(ItemStack stack, NBTTagCompound nbt)
/*     */   {
/*  35 */     return new BagHoldingItemHandler(stack);
/*     */   }
/*     */   
/*     */   public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn)
/*     */   {
/*  40 */     if (!worldIn.isRemote) {
/*  41 */       openItemGui(playerIn);
/*     */     }
/*     */     
/*  44 */     return itemStackIn;
/*     */   }
/*     */   
/*     */   public DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/*  49 */     if (player == null) { return null;
/*     */     }
/*  51 */     InventoryPlayer inventory = player.inventory;
/*  52 */     int slot = inventory.currentItem;
/*     */     
/*  54 */     ItemStack heldItem = player.func_70694_bm();
/*  55 */     if ((heldItem == null) || (heldItem.getItem() != this)) {
/*  56 */       return null;
/*     */     }
/*  58 */     IItemHandler handler = (IItemHandler)heldItem.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
/*     */     
/*  60 */     if ((handler == null) || (handler.getClass() != BagHoldingItemHandler.class)) {
/*  61 */       return null;
/*     */     }
/*  63 */     return new ContainerBagHolding(player, slot, (BagHoldingItemHandler)handler);
/*     */   }
/*     */   
/*     */   public class BagHoldingItemHandler implements ICapabilityProvider, IItemHandler {
/*     */     final ItemStack bagStack;
/*     */     
/*     */     public BagHoldingItemHandler(ItemStack bagStack) {
/*  70 */       this.bagStack = bagStack;
/*     */     }
/*     */     
/*     */     public int getSlots()
/*     */     {
/*  75 */       return 54;
/*     */     }
/*     */     
/*     */     public IItemHandler getSlotHandler(final int slot) {
/*  79 */       if ((slot < 0) || (slot >= 54)) { return EmptyHandler.INSTANCE;
/*     */       }
/*  81 */       new SingleStackHandlerBase()
/*     */       {
/*     */         public ItemStack getStack() {
/*  84 */           NBTTagCompound itemsTag = NBTHelper.getOrInitTagCompound(NBTHelper.getOrInitTagCompound(ItemBagOfHolding.BagHoldingItemHandler.this.bagStack), "Items");
/*  85 */           String key = getSlotKey();
/*  86 */           if (itemsTag.hasKey(key, 10)) {
/*  87 */             ItemStack itemStack = ItemStack.loadItemStackFromNBT(itemsTag.getCompoundTag(key));
/*  88 */             if (itemStack == null) {
/*  89 */               itemsTag.removeTag(key);
/*     */             }
/*     */             
/*  92 */             return itemStack;
/*     */           }
/*  94 */           return null;
/*     */         }
/*     */         
/*     */         @javax.annotation.Nonnull
/*     */         public String getSlotKey() {
/*  99 */           return com.rwtema.extrautils2.utils.helpers.CollectionHelper.STRING_DIGITS[slot];
/*     */         }
/*     */         
/*     */         protected int getStackLimit(ItemStack stack)
/*     */         {
/* 104 */           if (stack.getItem() == ItemBagOfHolding.this)
/* 105 */             return 0;
/* 106 */           if (stack.hasCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null)) {
/* 107 */             return 0;
/*     */           }
/* 109 */           return super.getStackLimit(stack);
/*     */         }
/*     */         
/*     */         public void setStack(ItemStack curStack)
/*     */         {
/* 114 */           NBTTagCompound itemsTag = NBTHelper.getOrInitTagCompound(NBTHelper.getOrInitTagCompound(ItemBagOfHolding.BagHoldingItemHandler.this.bagStack), "Items");
/* 115 */           String key = getSlotKey();
/* 116 */           if (curStack == null) {
/* 117 */             itemsTag.removeTag(key);
/*     */           } else {
/* 119 */             curStack.writeToNBT(NBTHelper.getOrInitTagCompound(itemsTag, key));
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */     
/*     */     public ItemStack getStackInSlot(int slot)
/*     */     {
/* 127 */       return getSlotHandler(slot).getStackInSlot(slot);
/*     */     }
/*     */     
/*     */     public ItemStack insertItem(int slot, ItemStack stack, boolean simulate)
/*     */     {
/* 132 */       return getSlotHandler(slot).insertItem(slot, stack, simulate);
/*     */     }
/*     */     
/*     */     public ItemStack extractItem(int slot, int amount, boolean simulate)
/*     */     {
/* 137 */       return getSlotHandler(slot).extractItem(slot, amount, simulate);
/*     */     }
/*     */     
/*     */     public boolean hasCapability(Capability<?> capability, EnumFacing facing)
/*     */     {
/* 142 */       return (facing == null) && (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY);
/*     */     }
/*     */     
/*     */     public <T> T getCapability(Capability<T> capability, EnumFacing facing)
/*     */     {
/* 147 */       return hasCapability(capability, facing) ? this : null;
/*     */     }
/*     */   }
/*     */   
/*     */   public class ContainerBagHolding extends DynamicContainer
/*     */   {
/*     */     public final InventoryPlayer inventory;
/*     */     public final EntityPlayer player;
/*     */     public final int slot;
/*     */     
/*     */     public ContainerBagHolding(EntityPlayer player, int slot, ItemBagOfHolding.BagHoldingItemHandler handler)
/*     */     {
/* 159 */       this.player = player;
/* 160 */       this.inventory = player.inventory;
/* 161 */       this.slot = slot;
/*     */       
/* 163 */       addTitle(Lang.getItemName(ItemBagOfHolding.this), false);
/*     */       
/* 165 */       for (int i = 0; i < handler.getSlots(); i++) {
/* 166 */         int slotX = i % 9;
/* 167 */         int slotY = i / 9;
/*     */         
/* 169 */         final int dSlot = i;
/* 170 */         addWidget(new WidgetSlotItemHandler(handler, dSlot, 5 + slotX * 18, 15 + slotY * 18)
/*     */         {
/*     */           ItemStack lastReturned;
/*     */           
/*     */           public boolean isItemValid(ItemStack stack) {
/* 175 */             if (stack == null)
/* 176 */               return false;
/* 177 */             ItemStack remainder = ItemBagOfHolding.ContainerBagHolding.this.getHandler().insertItem(dSlot, stack, true);
/* 178 */             return (remainder == null) || (remainder.stackSize < stack.stackSize);
/*     */           }
/*     */           
/*     */           public ItemStack getStack()
/*     */           {
/* 183 */             return this.lastReturned = ItemBagOfHolding.ContainerBagHolding.this.getHandler().getStackInSlot(dSlot);
/*     */           }
/*     */           
/*     */           public void putStack(ItemStack stack)
/*     */           {
/* 188 */             IItemHandler handler1 = ItemBagOfHolding.ContainerBagHolding.this.getHandler();
/* 189 */             if ((handler1 instanceof ItemBagOfHolding.BagHoldingItemHandler)) {
/* 190 */               ((IItemHandlerModifiable)((ItemBagOfHolding.BagHoldingItemHandler)handler1).getSlotHandler(dSlot)).setStackInSlot(dSlot, stack);
/* 191 */               this.lastReturned = stack;
/* 192 */               onSlotChanged();
/*     */             }
/*     */           }
/*     */           
/*     */           public void onSlotChanged()
/*     */           {
/* 198 */             ItemStack lastReturned = this.lastReturned;
/* 199 */             ItemStack stack = ItemBagOfHolding.ContainerBagHolding.this.getHandler().getStackInSlot(dSlot);
/* 200 */             if ((lastReturned != null) && (stack != null) && (lastReturned.stackSize != stack.stackSize) && (ItemHandlerHelper.canItemStacksStack(stack, lastReturned))) {
/* 201 */               putStack(lastReturned);
/* 202 */               return;
/*     */             }
/*     */             
/* 205 */             super.onSlotChanged();
/*     */           }
/*     */           
/*     */           public void onSlotChange(ItemStack p_75220_1_, ItemStack p_75220_2_)
/*     */           {
/* 210 */             super.onSlotChange(p_75220_1_, p_75220_2_);
/*     */           }
/*     */           
/*     */ 
/*     */           public int getItemStackLimit(ItemStack stack)
/*     */           {
/* 216 */             ItemStack maxAdd = stack.copy();
/* 217 */             maxAdd.stackSize = maxAdd.getMaxStackSize();
/* 218 */             IItemHandler itemHandler = ItemBagOfHolding.ContainerBagHolding.this.getHandler();
/* 219 */             ItemStack currentStack = itemHandler.getStackInSlot(dSlot);
/* 220 */             ItemStack remainder = itemHandler.insertItem(dSlot, maxAdd, true);
/*     */             
/* 222 */             int current = currentStack == null ? 0 : currentStack.stackSize;
/* 223 */             int added = maxAdd.stackSize - (remainder != null ? remainder.stackSize : 0);
/* 224 */             return current + added;
/*     */           }
/*     */           
/*     */           public boolean canTakeStack(EntityPlayer playerIn)
/*     */           {
/* 229 */             return ItemBagOfHolding.ContainerBagHolding.this.getHandler().extractItem(dSlot, 1, true) != null;
/*     */           }
/*     */           
/*     */           public ItemStack decrStackSize(int amount)
/*     */           {
/* 234 */             ItemStack itemStack = ItemBagOfHolding.ContainerBagHolding.this.getHandler().extractItem(dSlot, amount, false);
/* 235 */             getStack();
/* 236 */             return itemStack;
/*     */           }
/*     */         });
/*     */       }
/*     */       
/* 241 */       cropAndAddPlayerSlots(this.inventory);
/* 242 */       validate();
/*     */     }
/*     */     
/*     */     public IItemHandler getHandler() {
/* 246 */       ItemStack heldItem = this.player.func_70694_bm();
/* 247 */       if ((heldItem == null) || (heldItem.getItem() != ItemBagOfHolding.this)) {
/* 248 */         return EmptyHandler.INSTANCE;
/*     */       }
/* 250 */       IItemHandler capability = (IItemHandler)heldItem.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
/* 251 */       if (!(capability instanceof ItemBagOfHolding.BagHoldingItemHandler)) {
/* 252 */         return EmptyHandler.INSTANCE;
/*     */       }
/* 254 */       return capability;
/*     */     }
/*     */     
/*     */     public ItemStack func_75144_a(int slotId, int clickedButton, int mode, EntityPlayer playerIn)
/*     */     {
/* 259 */       return super.func_75144_a(slotId, clickedButton, mode, playerIn);
/*     */     }
/*     */     
/*     */     public boolean canInteractWith(EntityPlayer playerIn)
/*     */     {
/* 264 */       return (playerIn == this.player) && (this.inventory.currentItem == this.slot) && (getHandler() != EmptyHandler.INSTANCE);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemBagOfHolding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */