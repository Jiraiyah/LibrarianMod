/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUItemFlat;
/*     */ import com.rwtema.extrautils2.backend.entries.ItemClassEntry;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.crafting.ICustomMatching;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.BlockFence;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.entity.EntityList.EntityEggInfo;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IMerchant;
/*     */ import net.minecraft.entity.boss.EntityDragonPart;
/*     */ import net.minecraft.entity.boss.IBossDisplayData;
/*     */ import net.minecraft.entity.monster.IMob;
/*     */ import net.minecraft.entity.passive.EntityAmbientCreature;
/*     */ import net.minecraft.entity.passive.EntityVillager;
/*     */ import net.minecraft.entity.passive.EntityWaterMob;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTBase.NBTPrimitive;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.EnumDifficulty;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldProvider;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.player.EntityInteractEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ 
/*     */ public class ItemGoldenLasso extends XUItemFlat implements ICustomMatching
/*     */ {
/*     */   public static final String NBT_ANIMAL = "Animal";
/*     */   public static final String NBT_ANIMAL_DISPLAY = "Animal_Metadata";
/*     */   public static final String NBT_GOLDEN_LASSO_PREVENT = "[GoldenLassoPrevent]";
/*  62 */   public static final List<ItemStack> genericNiceRecipeItemList = new ArrayList();
/*  63 */   public static final List<ItemStack> genericEvilRecipeItemList = new ArrayList();
/*     */   public static final String NBT_ANIMAL_ALREADYPICKEDUP = "CursedLassoPickedUp";
/*     */   public static final String NBT_ANIMAL_NOPLACE = "No_Place";
/*     */   public static final String NBT_ANIMAL_NOPLACE_OLD = "NoPlace";
/*     */   
/*     */   public ItemGoldenLasso()
/*     */   {
/*  70 */     setHasSubtypes(true);
/*  71 */     setMaxStackSize(1);
/*  72 */     MinecraftForge.EVENT_BUS.register(this);
/*  73 */     genericNiceRecipeItemList.add(new ItemStack(this, 1, 0));
/*  74 */     genericEvilRecipeItemList.add(new ItemStack(this, 1, 1));
/*     */   }
/*     */   
/*     */   public static ItemStack newCraftingVillagerStack(boolean needsContract, VillagerProfessions profession) {
/*  78 */     ItemStack itemStack = newCraftingStack(EntityVillager.class);
/*  79 */     NBTTagCompound tags = NBTHelper.getOrInitTagCompound(itemStack.getTagCompound(), "Animal");
/*     */     
/*  81 */     if (needsContract) {
/*  82 */       NBTHelper.getOrInitTagCompound(tags, "ForgeData").setBoolean("Contracted", true);
/*     */     }
/*     */     
/*  85 */     if (profession != null) {
/*  86 */       tags.setInteger("Profession", profession.profession);
/*  87 */       tags.setInteger("Career", profession.career);
/*     */     }
/*     */     
/*  90 */     return itemStack;
/*     */   }
/*     */   
/*     */   public static ItemStack newCraftingStack(Class entity) {
/*  94 */     int meta = IMob.class.isAssignableFrom(entity) ? 1 : 0;
/*  95 */     ItemStack itemStack = com.rwtema.extrautils2.backend.entries.XU2Entries.goldenLasso.newStack(1, meta);
/*  96 */     NBTTagCompound animalTag = NBTHelper.getOrInitTagCompound(NBTHelper.getOrInitTagCompound(itemStack), "Animal");
/*  97 */     animalTag.setString("id", (String)EntityList.classToStringMapping.get(entity));
/*  98 */     setNoPlace(itemStack);
/*  99 */     return itemStack;
/*     */   }
/*     */   
/*     */   public static void setNoPlace(ItemStack cursedLasso) {
/* 103 */     cursedLasso.getTagCompound().setBoolean("No_Place", true);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean renderAsTool()
/*     */   {
/* 109 */     return true;
/*     */   }
/*     */   
/*     */   public int getMaxMetadata()
/*     */   {
/* 114 */     return 2;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/* 120 */     genericNiceRecipeItemList.clear();
/* 121 */     genericEvilRecipeItemList.clear();
/* 122 */     genericNiceRecipeItemList.add(new ItemStack(this, 1, 0));
/* 123 */     genericEvilRecipeItemList.add(new ItemStack(this, 1, 1));
/* 124 */     for (Class<? extends Entity> aClass : EntityList.classToStringMapping.keySet()) {
/* 125 */       if (EntityLiving.class.isAssignableFrom(aClass)) {
/* 126 */         if (IMob.class.isAssignableFrom(aClass)) {
/* 127 */           ItemStack itemStack = newCraftingStack(aClass);
/* 128 */           genericEvilRecipeItemList.add(itemStack);
/* 129 */         } else if ((EntityCreature.class.isAssignableFrom(aClass)) || (EntityAmbientCreature.class.isAssignableFrom(aClass)) || (EntityWaterMob.class.isAssignableFrom(aClass))) {
/* 130 */           ItemStack itemStack = newCraftingStack(aClass);
/* 131 */           genericNiceRecipeItemList.add(itemStack);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 136 */     Textures.register(new String[] { "dark_lasso", "golden_lasso", "lasso_internal_1", "lasso_internal_2" });
/*     */   }
/*     */   
/*     */   public boolean hasContainerItem(ItemStack stack)
/*     */   {
/* 141 */     return hasAnimal(stack);
/*     */   }
/*     */   
/*     */   public ItemStack getContainerItem(ItemStack stack)
/*     */   {
/* 146 */     ItemStack copy = stack.copy();
/* 147 */     NBTTagCompound tagCompound = copy.getTagCompound();
/* 148 */     tagCompound.removeTag("Animal");
/* 149 */     tagCompound.removeTag("display");
/* 150 */     return copy;
/*     */   }
/*     */   
/*     */   public String getTexture(@Nullable ItemStack itemStack, int renderPass)
/*     */   {
/* 155 */     switch (renderPass) {
/*     */     case 1: 
/* 157 */       return "lasso_internal_1";
/*     */     case 2: 
/* 159 */       return "lasso_internal_2";
/*     */     }
/* 161 */     if ((itemStack != null) && (itemStack.getItemDamage() == 1)) {
/* 162 */       return "dark_lasso";
/*     */     }
/* 164 */     return "golden_lasso";
/*     */   }
/*     */   
/*     */ 
/*     */   public int getRenderLayers(@Nullable ItemStack itemStack)
/*     */   {
/* 170 */     return hasAnimal(itemStack) ? 3 : 1;
/*     */   }
/*     */   
/*     */   public boolean renderLayerIn3D(ItemStack stack, int renderPass)
/*     */   {
/* 175 */     return renderPass == 0;
/*     */   }
/*     */   
/*     */   public int getTint(ItemStack stack, int i)
/*     */   {
/* 180 */     switch (i) {
/*     */     case 1: 
/* 182 */       return 0;
/*     */     case 2: 
/* 184 */       return 1;
/*     */     }
/* 186 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasEffect(ItemStack stack)
/*     */   {
/* 192 */     return false;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int func_82790_a(ItemStack stack, int renderPass)
/*     */   {
/* 198 */     NBTTagCompound tags = stack.getTagCompound();
/* 199 */     if (!hasAnimal(tags)) {
/* 200 */       return 16777215;
/*     */     }
/* 202 */     EntityList.EntityEggInfo egg = getEgg(tags.getCompoundTag("Animal"));
/* 203 */     if (egg == null) { return 16777215;
/*     */     }
/*     */     
/* 206 */     if (renderPass == 0) {
/* 207 */       return egg.primaryColor;
/*     */     }
/* 209 */     return egg.secondaryColor;
/*     */   }
/*     */   
/*     */   public boolean hasAnimal(ItemStack itemStack)
/*     */   {
/* 214 */     NBTTagCompound tagCompound = itemStack.getTagCompound();
/* 215 */     return hasAnimal(tagCompound);
/*     */   }
/*     */   
/*     */   private boolean hasAnimal(NBTTagCompound tagCompound) {
/* 219 */     return (tagCompound != null) && (tagCompound.hasKey("Animal", 10));
/*     */   }
/*     */   
/*     */   public boolean itemInteractionForEntity(ItemStack stack, EntityPlayer playerIn, EntityLivingBase target)
/*     */   {
/* 224 */     if (hasAnimal(stack)) { return false;
/*     */     }
/* 226 */     if (target.worldObj.isRemote) { return true;
/*     */     }
/* 228 */     if (stack.getItemDamage() == 1) {
/* 229 */       if (!(target instanceof IMob)) {
/* 230 */         playerIn.addChatComponentMessage(Lang.chat("%s is not a hostile mob.", new Object[] { target.getDisplayName() }));
/* 231 */         return false;
/*     */       }
/*     */       
/* 234 */       if (!playerIn.capabilities.isCreativeMode) {
/* 235 */         if ((target instanceof IBossDisplayData)) {
/* 236 */           playerIn.addChatComponentMessage(Lang.chat("%s is too powerful.", new Object[] { target.getDisplayName() }));
/* 237 */           return false;
/*     */         }
/*     */         
/* 240 */         NBTTagCompound data = target.getEntityData();
/* 241 */         if (data.getBoolean("CursedLassoPickedUp")) {
/* 242 */           return true;
/*     */         }
/*     */         
/* 245 */         float health = target.getHealth();
/* 246 */         float maxHealth = target.getMaxHealth();
/*     */         
/* 248 */         float threshold = MathHelper.clamp_float(maxHealth / 4.0F, 4.0F, 10.0F);
/* 249 */         if (health > threshold) {
/* 250 */           playerIn.addChatComponentMessage(Lang.chat("%s has too much health (%s hearts). Reduce to %s hearts.", new Object[] { target.getDisplayName(), Integer.valueOf((int)Math.floor(health / 2.0F)), Integer.valueOf((int)Math.floor(threshold / 2.0F)) }));
/* 251 */           return false;
/*     */         }
/*     */       }
/*     */     } else {
/* 255 */       if ((target instanceof IMob)) {
/* 256 */         playerIn.addChatComponentMessage(Lang.chat("%s is a hostile mob.", new Object[] { target.getDisplayName() }));
/* 257 */         return false;
/*     */       }
/*     */       
/* 260 */       if ((!(target instanceof EntityCreature)) && (!(target instanceof EntityAmbientCreature)) && (!(target instanceof EntityWaterMob))) {
/* 261 */         return false;
/*     */       }
/*     */       
/* 264 */       if (((EntityLiving)target).getAttackTarget() != null) {
/* 265 */         playerIn.addChatComponentMessage(Lang.chat("%s is too busy attacking someone.", new Object[] { target.getDisplayName() }));
/* 266 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 270 */     return addTargetToLasso(stack, target);
/*     */   }
/*     */   
/*     */   public boolean addTargetToLasso(ItemStack stack, EntityLivingBase target) {
/* 274 */     if ((target instanceof IMerchant)) {
/* 275 */       target.getDisplayName();
/*     */     }
/*     */     
/* 278 */     float health = target.getHealth();
/* 279 */     float maxHealth = target.getMaxHealth();
/*     */     
/* 281 */     NBTTagCompound entityTags = new NBTTagCompound();
/* 282 */     entityTags.setBoolean("[GoldenLassoPrevent]", false);
/*     */     
/* 284 */     if (!target.func_98035_c(entityTags)) {
/* 285 */       return false;
/*     */     }
/*     */     
/* 288 */     if ((!entityTags.hasKey("[GoldenLassoPrevent]")) || (entityTags.getBoolean("[GoldenLassoPrevent]"))) {
/* 289 */       return false;
/*     */     }
/*     */     
/* 292 */     entityTags.removeTag("[GoldenLassoPrevent]");
/*     */     
/* 294 */     String name = "";
/*     */     
/* 296 */     if (target.hasCustomName()) {
/* 297 */       name = target.getCustomNameTag();
/*     */     }
/*     */     
/* 300 */     target.setDead();
/*     */     
/* 302 */     NBTTagCompound nbt = NBTHelper.getOrInitTagCompound(stack);
/* 303 */     nbt.setBoolean("No_Place", false);
/* 304 */     nbt.setTag("Animal", entityTags);
/* 305 */     NBTTagCompound display = NBTHelper.getOrInitTagCompound(nbt, "Animal_Metadata");
/* 306 */     display.setFloat("Health", health);
/* 307 */     display.setFloat("MaxHealth", maxHealth);
/*     */     
/*     */ 
/* 310 */     if (!name.equals("")) {
/* 311 */       stack.setStackDisplayName(name);
/*     */     }
/*     */     
/* 314 */     return true;
/*     */   }
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer playerIn, World worldIn, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/* 319 */     if (!hasAnimal(stack)) return false;
/* 320 */     NBTTagCompound stackTags = stack.getTagCompound();
/* 321 */     NBTTagCompound entityTags = stackTags.getCompoundTag("Animal");
/* 322 */     if ((entityTags.hasNoTags()) || (!entityTags.hasKey("id", 8))) {
/* 323 */       stackTags.removeTag("Animal");
/* 324 */       return false;
/*     */     }
/*     */     
/* 327 */     if (worldIn.isRemote) { return true;
/*     */     }
/* 329 */     if (!playerIn.canPlayerEdit(pos.offset(side), side, stack)) {
/* 330 */       return false;
/*     */     }
/*     */     
/* 333 */     if ((stack.getItemDamage() == 1) && (worldIn.getDifficulty() == EnumDifficulty.PEACEFUL)) {
/* 334 */       playerIn.addChatComponentMessage(Lang.chat("Difficulty set to peaceful.", new Object[0]));
/* 335 */       return false;
/*     */     }
/*     */     
/* 338 */     if (stackTags.getBoolean("No_Place")) {
/* 339 */       if (playerIn.isSneaking()) {
/* 340 */         stackTags.removeTag("Animal");
/* 341 */         stackTags.removeTag("Animal_Metadata");
/* 342 */         stackTags.removeTag("No_Place");
/* 343 */         playerIn.addChatComponentMessage(Lang.chat("Mob soul released.", new Object[0]));
/* 344 */         stack.clearCustomName();
/* 345 */         return true;
/*     */       }
/* 347 */       float health = stackTags.getCompoundTag("Animal_Metadata").getFloat("Health");
/* 348 */       playerIn.addChatComponentMessage(Lang.chat("Unable to place mob.", new Object[0]));
/* 349 */       if (health <= 1.0E-10D) {
/* 350 */         playerIn.addChatComponentMessage(Lang.chat("Mob's body is dead.", new Object[0]));
/*     */       }
/* 352 */       playerIn.addChatComponentMessage(Lang.chat("Sneak-right-click to release soul.", new Object[0]));
/* 353 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 358 */     IBlockState iblockstate = worldIn.getBlockState(pos);
/*     */     
/* 360 */     pos = pos.offset(side);
/* 361 */     double d0 = 0.0D;
/*     */     
/* 363 */     if ((side == EnumFacing.UP) && ((iblockstate.getBlock() instanceof BlockFence))) {
/* 364 */       d0 = 0.5D;
/*     */     }
/*     */     
/* 367 */     entityTags.setTag("Pos", newDoubleNBTList(new double[] { pos.getX() + 0.5D, pos.getY() + d0, pos.getZ() + 0.5D }));
/* 368 */     entityTags.setTag("Motion", newDoubleNBTList(new double[] { 0.0D, 0.0D, 0.0D }));
/* 369 */     entityTags.setFloat("FallDistance", 0.0F);
/* 370 */     entityTags.setInteger("Dimension", worldIn.provider.func_177502_q());
/*     */     
/* 372 */     Entity entity = EntityList.createEntityFromNBT(entityTags, worldIn);
/*     */     
/* 374 */     if (entity != null) {
/* 375 */       if (((entity instanceof EntityLiving)) && (stack.hasDisplayName())) {
/* 376 */         entity.setCustomNameTag(stack.getDisplayName());
/*     */       }
/*     */       
/* 379 */       if ((entity instanceof IMob)) {
/* 380 */         entity.getEntityData().setBoolean("CursedLassoPickedUp", true);
/*     */       }
/*     */       
/* 383 */       worldIn.spawnEntityInWorld(entity);
/*     */     }
/*     */     
/* 386 */     stackTags.removeTag("Animal");
/* 387 */     stackTags.removeTag("Animal_Metadata");
/* 388 */     stackTags.removeTag("No_Place");
/* 389 */     stack.clearCustomName();
/*     */     
/* 391 */     if (playerIn.capabilities.isCreativeMode) {
/* 392 */       playerIn.func_70062_b(0, stack.copy());
/*     */     }
/* 394 */     playerIn.inventory.markDirty();
/*     */     
/* 396 */     return true;
/*     */   }
/*     */   
/*     */   private NBTTagList newDoubleNBTList(double... numbers) {
/* 400 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 402 */     for (double d0 : numbers) {
/* 403 */       nbttaglist.appendTag(new net.minecraft.nbt.NBTTagDouble(d0));
/*     */     }
/*     */     
/* 406 */     return nbttaglist;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EntityList.EntityEggInfo getEgg(NBTTagCompound entityTag) {
/* 411 */     String id = entityTag.getString("id");
/* 412 */     Map<String, EntityList.EntityEggInfo> eggs = net.minecraftforge.fml.common.registry.EntityRegistry.getEggs();
/* 413 */     if (eggs.containsKey(id)) {
/* 414 */       return (EntityList.EntityEggInfo)eggs.get(id);
/*     */     }
/*     */     
/* 417 */     int i = EntityList.getIDFromString(id);
/* 418 */     if (EntityList.entityEggs.containsKey(Integer.valueOf(i)))
/* 419 */       return (EntityList.EntityEggInfo)EntityList.entityEggs.get(Integer.valueOf(i));
/* 420 */     return null;
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/* 425 */     NBTTagCompound itemTags = stack.getTagCompound();
/* 426 */     if (hasAnimal(itemTags)) {
/* 427 */       NBTTagCompound entityTags = itemTags.getCompoundTag("Animal");
/* 428 */       if (entityTags.hasKey("id")) {
/* 429 */         if (!tooltip.isEmpty())
/* 430 */           tooltip.set(0, ((String)tooltip.get(0)).replaceFirst(EnumChatFormatting.ITALIC + stack.getDisplayName() + EnumChatFormatting.RESET, getItemStackDisplayName(stack)));
/* 431 */         String id = entityTags.getString("id");
/* 432 */         String animal_name = StatCollector.translateToLocal("entity." + id + ".name");
/* 433 */         tooltip.add(animal_name);
/*     */         
/* 435 */         if ("Villager".equals(id)) {
/* 436 */           if (entityTags.hasKey("Profession")) {
/* 437 */             int career = entityTags.getInteger("Career");
/* 438 */             int profession = entityTags.getInteger("Profession");
/*     */             
/* 440 */             int t = com.rwtema.extrautils2.utils.MCTimer.clientTimer >> 4;
/*     */             
/* 442 */             String s1 = null;
/*     */             
/* 444 */             switch (profession) {
/*     */             case 0: 
/* 446 */               if (career == 0) { career = t % 4 + 1;
/*     */               }
/* 448 */               if (career == 1) {
/* 449 */                 s1 = "farmer";
/* 450 */               } else if (career == 2) {
/* 451 */                 s1 = "fisherman";
/* 452 */               } else if (career == 3) {
/* 453 */                 s1 = "shepherd";
/* 454 */               } else if (career == 4) {
/* 455 */                 s1 = "fletcher";
/*     */               }
/*     */               
/*     */               break;
/*     */             case 1: 
/* 460 */               s1 = "librarian";
/* 461 */               break;
/*     */             case 2: 
/* 463 */               s1 = "cleric";
/* 464 */               break;
/*     */             case 3: 
/* 466 */               if (career == 0) career = t % 3 + 1;
/* 467 */               if (career == 1) {
/* 468 */                 s1 = "armor";
/* 469 */               } else if (career == 2) {
/* 470 */                 s1 = "weapon";
/* 471 */               } else if (career == 3) {
/* 472 */                 s1 = "tool";
/*     */               }
/*     */               
/*     */               break;
/*     */             case 4: 
/* 477 */               if (career == 0) career = t % 2 + 1;
/* 478 */               if (career == 1) {
/* 479 */                 s1 = "butcher";
/* 480 */               } else if (career == 2) {
/* 481 */                 s1 = "leather";
/*     */               }
/*     */               break;
/*     */             }
/*     */             
/* 486 */             if (s1 != null) {
/* 487 */               tooltip.add(StatCollector.translateToLocal("entity.Villager." + s1));
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 492 */           if (entityTags.getCompoundTag("ForgeData").getBoolean("Contracted")) {
/* 493 */             tooltip.add(Lang.translate("*Under Contract*"));
/*     */           }
/*     */         }
/*     */         
/* 497 */         float health = itemTags.getCompoundTag("Animal_Metadata").getFloat("Health");
/* 498 */         float maxHealth = itemTags.getCompoundTag("Animal_Metadata").getFloat("MaxHealth");
/* 499 */         tooltip.add(Lang.translateArgs("Health: %s/%s", new Object[] { Float.valueOf(health), Float.valueOf(maxHealth) }));
/*     */         
/* 501 */         if (stack.hasDisplayName()) {
/* 502 */           tooltip.add(stack.getDisplayName());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void getSubItems(Item itemIn, CreativeTabs tab, List<ItemStack> subItems)
/*     */   {
/* 510 */     subItems.add(new ItemStack(itemIn, 1, 0));
/* 511 */     subItems.add(new ItemStack(itemIn, 1, 1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @SubscribeEvent(priority=EventPriority.HIGHEST)
/*     */   public void cursedLassoAbsorb(LivingDeathEvent event)
/*     */   {
/* 537 */     if ((!(event.entityLiving instanceof IMob)) || ((event.entityLiving instanceof IBossDisplayData))) return;
/* 538 */     Entity source = event.source.getEntity();
/* 539 */     if (!(source instanceof EntityPlayerMP)) return;
/* 540 */     EntityPlayerMP player = (EntityPlayerMP)source;
/* 541 */     ItemStack cursedLasso = check(player.func_70694_bm());
/*     */     
/* 543 */     if (cursedLasso == null) {
/* 544 */       for (int i = 0; (cursedLasso == null) && (i < player.inventory.getSizeInventory()); i++) {
/* 545 */         cursedLasso = check(player.inventory.getStackInSlot(i));
/*     */       }
/*     */     }
/* 548 */     if (cursedLasso == null) { return;
/*     */     }
/* 550 */     if (!addTargetToLasso(cursedLasso, event.entityLiving)) { return;
/*     */     }
/* 552 */     setNoPlace(cursedLasso);
/*     */     
/*     */ 
/*     */ 
/* 556 */     player.addChatComponentMessage(Lang.chat("%s absorbed into cursed lasso", new Object[] { event.entityLiving.getDisplayName() }));
/*     */   }
/*     */   
/*     */   public ItemStack check(ItemStack stack) {
/* 560 */     return (stack == null) || (stack.getItem() != this) || (stack.getItemDamage() != 1) || (hasAnimal(stack)) ? null : stack;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void goldenLassoActivate(EntityInteractEvent event)
/*     */   {
/* 566 */     ItemStack itemstack = event.entityPlayer.func_71045_bC();
/* 567 */     if ((itemstack != null) && (itemstack.getItem() == this)) {
/* 568 */       Entity entity = event.target;
/* 569 */       if ((entity instanceof EntityDragonPart)) {
/* 570 */         entity = (Entity)((EntityDragonPart)entity).entityDragonObj;
/*     */       }
/*     */       
/* 573 */       if ((entity instanceof EntityLivingBase)) {
/* 574 */         itemstack.interactWithEntity(event.entityPlayer, (EntityLivingBase)entity);
/* 575 */         if (itemstack.stackSize <= 0) {
/* 576 */           event.entityPlayer.func_71028_bD();
/*     */         }
/*     */         
/* 579 */         event.setCanceled(true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getUnlocalizedName(ItemStack stack)
/*     */   {
/* 586 */     return super.getUnlocalizedName(stack) + "." + stack.getItemDamage();
/*     */   }
/*     */   
/*     */   public boolean itemsMatch(ItemStack slot, @javax.annotation.Nonnull ItemStack target)
/*     */   {
/* 591 */     if (!OreDictionary.itemMatches(target, slot, false)) { return false;
/*     */     }
/* 593 */     boolean tAnim = hasAnimal(target);
/* 594 */     boolean sAnim = hasAnimal(slot);
/* 595 */     if (tAnim != sAnim) return false;
/* 596 */     if (!sAnim) return true;
/* 597 */     NBTTagCompound targetTags = getAnimalTags(target);
/* 598 */     String targetID = targetTags.getString("id");
/* 599 */     NBTTagCompound slotTags = getAnimalTags(slot);
/* 600 */     String slotID = slotTags.getString("id");
/* 601 */     return (targetID.equals(slotID)) && (satisfies(targetTags, slotTags));
/*     */   }
/*     */   
/*     */   public boolean satisfies(NBTBase target, NBTBase presented)
/*     */   {
/* 606 */     if (presented == null) return false;
/* 607 */     byte id = target.getId();
/* 608 */     if ((target instanceof NBTBase.NBTPrimitive)) {
/* 609 */       if (!(presented instanceof NBTBase.NBTPrimitive)) return false;
/* 610 */       NBTBase.NBTPrimitive a = (NBTBase.NBTPrimitive)target;
/* 611 */       NBTBase.NBTPrimitive b = (NBTBase.NBTPrimitive)presented;
/*     */       
/* 613 */       switch (id) {
/*     */       case 1: 
/* 615 */         return a.getByte() == b.getByte();
/*     */       case 2: 
/* 617 */         return a.getShort() == b.getShort();
/*     */       case 3: 
/* 619 */         return a.getInt() == b.getInt();
/*     */       case 4: 
/* 621 */         return a.getLong() == b.getLong();
/*     */       case 5: 
/* 623 */         return a.getFloat() == b.getFloat();
/*     */       case 6: 
/* 625 */         return a.getDouble() == b.getDouble();
/*     */       }
/* 627 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 631 */     if (presented.getId() != id) { return false;
/*     */     }
/* 633 */     if (id == 10) {
/* 634 */       NBTTagCompound nbt_a = (NBTTagCompound)target;
/* 635 */       NBTTagCompound nbt_b = (NBTTagCompound)presented;
/* 636 */       for (String s : nbt_a.getKeySet()) {
/* 637 */         if (!satisfies(nbt_a.getTag(s), nbt_b.getTag(s))) {
/* 638 */           return false;
/*     */         }
/*     */       }
/* 641 */       return true; }
/* 642 */     if (id == 9) {
/* 643 */       NBTTagList a = (NBTTagList)target;
/* 644 */       NBTTagList b = (NBTTagList)target;
/* 645 */       int n = a.tagCount();
/* 646 */       if (n != b.tagCount()) return false;
/* 647 */       for (int i = 0; i < n; i++) {
/* 648 */         if (!satisfies(a.get(i), b.get(i))) return false;
/*     */       }
/* 650 */       return true;
/*     */     }
/* 652 */     return target.equals(presented);
/*     */   }
/*     */   
/*     */   public NBTTagCompound getAnimalTags(ItemStack target)
/*     */   {
/* 657 */     return target.getTagCompound().getCompoundTag("Animal");
/*     */   }
/*     */   
/*     */   public boolean updateItemStackNBT(NBTTagCompound nbt)
/*     */   {
/* 662 */     nbt.removeTag("NoPlace");
/* 663 */     return super.updateItemStackNBT(nbt);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemGoldenLasso.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */