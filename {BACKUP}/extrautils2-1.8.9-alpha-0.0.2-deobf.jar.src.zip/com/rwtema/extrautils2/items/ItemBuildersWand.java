/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.rwtema.extrautils2.utils.PositionPool;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class ItemBuildersWand extends ItemSelectionWand
/*     */ {
/*     */   public ItemBuildersWand(String name, int range, String texture, float[] col)
/*     */   {
/*  21 */     super(texture, name, col, range);
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean initialCheck(World world, BlockPos pos, EnumFacing side, ItemStack pickBlock1, Block block)
/*     */   {
/*  27 */     return (!block.canPlaceBlockOnSide(world, pos.offset(side), side)) || (!world.canBlockBePlaced(block, pos.offset(side), false, side, null, pickBlock1));
/*     */   }
/*     */   
/*     */   protected int getNumBlocks(EntityPlayer player, int maxBlocks, ItemStack pickBlock1, boolean grassBlock)
/*     */   {
/*  32 */     int numBlocks = 0;
/*     */     
/*  34 */     for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
/*  35 */       ItemStack stack = player.inventory.getStackInSlot(i);
/*  36 */       if (stack != null) {
/*  37 */         if (((stack.getItem() == pickBlock1.getItem()) && (stack.getItemDamage() == pickBlock1.getItemDamage())) || ((grassBlock) && (stack.getItem() == net.minecraft.item.Item.getItemFromBlock(Blocks.dirt))))
/*     */         {
/*     */ 
/*  40 */           if (player.capabilities.isCreativeMode) {
/*  41 */             numBlocks = maxBlocks;
/*  42 */             break;
/*     */           }
/*     */           
/*  45 */           numBlocks += stack.stackSize;
/*     */         }
/*     */         
/*  48 */         if (numBlocks >= maxBlocks) {
/*  49 */           numBlocks = maxBlocks;
/*  50 */           break;
/*     */         }
/*     */       }
/*     */     }
/*  54 */     return numBlocks;
/*     */   }
/*     */   
/*     */   protected boolean checkAndAddBlocks(EntityPlayer player, World world, EnumFacing side, ItemStack pickBlock1, Block block, PositionPool pool, BlockPos p, List<BlockPos> blocks)
/*     */   {
/*  59 */     BlockPos loc = pool.offset(p, side);
/*     */     
/*  61 */     if (!player.canPlayerEdit(loc, side, pickBlock1)) {
/*  62 */       return false;
/*     */     }
/*  64 */     if (!world.canBlockBePlaced(block, loc, false, side, null, pickBlock1)) {
/*  65 */       return false;
/*     */     }
/*  67 */     blocks.add(loc);
/*  68 */     return true;
/*     */   }
/*     */   
/*     */   public boolean onItemUseFirst(ItemStack stack, EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*  73 */     if ((onItemUse(stack, player, world, pos, side, hitX, hitY, hitZ)) && (world.isRemote))
/*  74 */       com.rwtema.extrautils2.ExtraUtils2.proxy.sendUsePacket(stack, player, world, pos, side, hitX, hitY, hitZ);
/*  75 */     return true;
/*     */   }
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*  80 */     if (world.isRemote) {
/*  81 */       return true;
/*     */     }
/*     */     
/*  84 */     if (!player.capabilities.allowEdit) {
/*  85 */       return false;
/*     */     }
/*     */     
/*  88 */     IBlockState blockState = world.getBlockState(pos);
/*  89 */     Block block = blockState.getBlock();
/*     */     
/*  91 */     ItemStack pickBlock = getStack(world, pos);
/*     */     
/*  93 */     List<BlockPos> blocks = getPotentialBlocks(player, world, pos, side, this.range, pickBlock, blockState, block);
/*  94 */     if (blocks.isEmpty()) return false;
/*  95 */     int slot = 0;
/*     */     
/*  97 */     boolean grassBlock = (block == Blocks.grass) || (block == Blocks.mycelium);
/*     */     
/*  99 */     for (BlockPos p : blocks)
/*     */     {
/* 101 */       ItemStack stackInSlot = null;
/* 102 */       for (; slot < player.inventory.getSizeInventory(); slot++) {
/* 103 */         stackInSlot = player.inventory.getStackInSlot(slot);
/* 104 */         if (stackInSlot != null)
/*     */         {
/* 106 */           if ((stackInSlot.getItem() == pickBlock.getItem()) && (stackInSlot.getItemDamage() == pickBlock.getItemDamage()))
/*     */             break;
/* 108 */           if ((grassBlock) && (stackInSlot.getItem() == net.minecraft.item.Item.getItemFromBlock(Blocks.dirt))) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/* 113 */       if ((slot >= player.inventory.getSizeInventory()) || (stackInSlot == null)) {
/*     */         break;
/*     */       }
/* 116 */       if (player.capabilities.isCreativeMode) {
/* 117 */         stackInSlot = stackInSlot.copy();
/*     */       }
/* 119 */       if ((stackInSlot.onItemUse(player, world, p, side, hitX, hitY, hitZ)) && 
/* 120 */         (!player.capabilities.isCreativeMode) && (stackInSlot.stackSize == 0)) {
/* 121 */         player.inventory.setInventorySlotContents(slot, null);
/*     */       }
/*     */       
/*     */ 
/* 125 */       player.inventory.markDirty();
/*     */       
/* 127 */       if ((player instanceof EntityPlayerMP)) {
/* 128 */         ((EntityPlayerMP)player).mcServer.func_71203_ab().syncPlayerInventory((EntityPlayerMP)player);
/*     */       }
/*     */     }
/*     */     
/* 132 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemBuildersWand.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */