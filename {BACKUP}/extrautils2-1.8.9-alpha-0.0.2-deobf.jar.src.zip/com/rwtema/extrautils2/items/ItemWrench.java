/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */ import com.rwtema.extrautils2.api.IWrench;
/*    */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraftforge.common.capabilities.Capability;
/*    */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*    */ 
/*    */ public class ItemWrench extends XUItemFlatMetadata implements IWrench
/*    */ {
/* 12 */   public ICapabilityProvider wrenchProvider = new ICapabilityProvider()
/*    */   {
/*    */     public boolean hasCapability(Capability<?> capability, EnumFacing facing)
/*    */     {
/* 16 */       return getCapability(capability, facing) != null;
/*    */     }
/*    */     
/*    */ 
/*    */     public <T> T getCapability(Capability<T> capability, EnumFacing facing)
/*    */     {
/* 22 */       if (capability == IWrench.CAPABILITY)
/* 23 */         return ItemWrench.this;
/* 24 */       return null;
/*    */     }
/*    */   };
/*    */   
/*    */   public ItemWrench() {
/* 29 */     super(new String[] { "pipe_wrench" });
/* 30 */     setMaxStackSize(1);
/*    */   }
/*    */   
/*    */   public boolean renderAsTool()
/*    */   {
/* 35 */     return true;
/*    */   }
/*    */   
/*    */   public ICapabilityProvider initCapabilities(net.minecraft.item.ItemStack stack, NBTTagCompound nbt)
/*    */   {
/* 40 */     return this.wrenchProvider;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemWrench.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */