/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUItemBlock;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraftforge.common.IPlantable;
/*    */ 
/*    */ public class ItemBlockPlantable extends XUItemBlock implements IPlantable
/*    */ {
/*    */   IPlantable plantable;
/*    */   
/*    */   public ItemBlockPlantable(net.minecraft.block.Block block)
/*    */   {
/* 14 */     super(block);
/* 15 */     this.plantable = ((IPlantable)block);
/*    */   }
/*    */   
/*    */   public net.minecraftforge.common.EnumPlantType getPlantType(IBlockAccess world, BlockPos pos)
/*    */   {
/* 20 */     return this.plantable.getPlantType(world, pos);
/*    */   }
/*    */   
/*    */   public net.minecraft.block.state.IBlockState getPlant(IBlockAccess world, BlockPos pos)
/*    */   {
/* 25 */     return this.plantable.getPlant(world, pos);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemBlockPlantable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */