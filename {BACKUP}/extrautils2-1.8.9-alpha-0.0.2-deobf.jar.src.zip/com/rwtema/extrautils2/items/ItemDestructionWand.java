/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.rwtema.extrautils2.utils.PositionPool;
/*     */ import com.rwtema.extrautils2.utils.helpers.PlayerHelper;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.MovingObjectPosition.MovingObjectType;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.event.entity.player.PlayerEvent.BreakSpeed;
/*     */ 
/*     */ public class ItemDestructionWand extends ItemSelectionWand
/*     */ {
/*  24 */   Item[] harvestDelegates = { Items.stone_shovel, Items.stone_pickaxe, Items.stone_pickaxe };
/*  25 */   Item[] speedDelegates = { Items.iron_shovel, Items.iron_pickaxe, Items.iron_pickaxe };
/*     */   
/*     */   public ItemDestructionWand(String texture, String name, float[] col, int range) {
/*  28 */     super(texture, name, col, range);
/*     */   }
/*     */   
/*     */   protected boolean initialCheck(World world, BlockPos pos, EnumFacing side, ItemStack pickBlock1, Block block)
/*     */   {
/*  33 */     return !canHarvestBlock(block);
/*     */   }
/*     */   
/*     */   protected int getNumBlocks(EntityPlayer player, int maxBlocks, ItemStack pickBlock1, boolean grassBlock)
/*     */   {
/*  38 */     return this.range;
/*     */   }
/*     */   
/*     */   protected boolean checkAndAddBlocks(EntityPlayer player, World world, EnumFacing side, ItemStack pickBlock1, Block block, PositionPool pool, BlockPos p, List<BlockPos> blocks)
/*     */   {
/*  43 */     if (!player.func_146099_a(block)) return false;
/*  44 */     BlockPos p1 = p.offset(side);
/*     */     
/*  46 */     if ((p.getX() == MathHelper.floor_double(player.posX)) && (p.getY() == MathHelper.floor_double(player.posY - 0.20000000298023224D)) && (p.getZ() == MathHelper.floor_double(player.posZ))) {
/*  47 */       return false;
/*     */     }
/*  49 */     IBlockState blockState1 = world.getBlockState(p1);
/*  50 */     Block block1 = blockState1.getBlock();
/*  51 */     if (block1.isNormalCube(world, p1)) return false;
/*  52 */     block1.func_180654_a(world, p1);
/*  53 */     AxisAlignedBB collisionBoundingBox = block1.getSelectedBoundingBox(world, p1, blockState1);
/*  54 */     if (collisionBoundingBox != null) {
/*  55 */       collisionBoundingBox = collisionBoundingBox.offset(-p1.getX(), -p1.getY(), -p1.getZ());
/*  56 */       switch (side) {
/*     */       case UP: 
/*  58 */         if (collisionBoundingBox.minY <= 0.0D) return false;
/*     */       case DOWN: 
/*  60 */         if (collisionBoundingBox.maxY >= 1.0D) return false;
/*     */       case SOUTH: 
/*  62 */         if (collisionBoundingBox.minZ <= 0.0D) return false;
/*     */         break;
/*     */       case NORTH: 
/*  65 */         if (collisionBoundingBox.maxZ >= 1.0D) return false;
/*     */         break;
/*     */       case EAST: 
/*  68 */         if (collisionBoundingBox.minX <= 0.0D) return false;
/*     */         break;
/*     */       case WEST: 
/*  71 */         if (collisionBoundingBox.maxX >= 1.0D) { return false;
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*  76 */     blocks.add(p);
/*  77 */     return true;
/*     */   }
/*     */   
/*     */   public boolean onBlockStartBreak(ItemStack itemstack, BlockPos pos, EntityPlayer player)
/*     */   {
/*  82 */     World world = player.worldObj;
/*  83 */     if (world.isAirBlock(pos)) { return false;
/*     */     }
/*  85 */     if (world.isRemote) { return false;
/*     */     }
/*  87 */     MovingObjectPosition mop = PlayerHelper.rayTrace(player);
/*     */     
/*  89 */     if ((mop == null) || (mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) || (!mop.getBlockPos().equals(pos))) {
/*  90 */       return false;
/*     */     }
/*  92 */     IBlockState blockState = world.getBlockState(pos);
/*  93 */     Block block = blockState.getBlock();
/*  94 */     ItemStack pickBlock = getStack(world, pos);
/*     */     
/*  96 */     List<BlockPos> potentialBlocks = getPotentialBlocks(player, world, pos, mop.sideHit, this.range, pickBlock, blockState, block);
/*  97 */     if (potentialBlocks.isEmpty()) {
/*  98 */       return false;
/*     */     }
/* 100 */     boolean doDrops = !player.capabilities.isCreativeMode;
/*     */     
/* 102 */     for (BlockPos potentialBlock : potentialBlocks) {
/* 103 */       IBlockState iblockstate = world.getBlockState(potentialBlock);
/* 104 */       Block block1 = iblockstate.getBlock();
/*     */       
/* 106 */       if (block1.getMaterial() != Material.air)
/*     */       {
/*     */ 
/* 109 */         if (doDrops) {
/* 110 */           block1.dropBlockAsItem(world, potentialBlock, iblockstate, 0);
/*     */         }
/*     */         
/* 113 */         world.setBlockState(potentialBlock, net.minecraft.init.Blocks.air.getDefaultState(), 3);
/* 114 */         world.func_175689_h(pos);
/*     */       }
/*     */     }
/*     */     
/* 118 */     return true;
/*     */   }
/*     */   
/*     */   public boolean canHarvestBlock(Block blockIn)
/*     */   {
/* 123 */     if (blockIn.getMaterial().isToolNotRequired()) return true;
/* 124 */     for (Item item : this.harvestDelegates) {
/* 125 */       if (item.canHarvestBlock(blockIn)) return true;
/*     */     }
/* 127 */     return super.canHarvestBlock(blockIn);
/*     */   }
/*     */   
/*     */   public float getStrVsBlock(ItemStack stack, Block block)
/*     */   {
/* 132 */     float t = super.getStrVsBlock(stack, block);
/* 133 */     for (Item item : this.speedDelegates) {
/* 134 */       t = Math.max(t, item.getStrVsBlock(stack, block));
/*     */     }
/* 136 */     return t;
/*     */   }
/*     */   
/*     */   public float getDigSpeed(ItemStack stack, IBlockState state)
/*     */   {
/* 141 */     float t = super.getDigSpeed(stack, state);
/* 142 */     for (Item item : this.speedDelegates) {
/* 143 */       t = Math.max(t, item.getDigSpeed(new ItemStack(item), state));
/*     */     }
/* 145 */     return t;
/*     */   }
/*     */   
/*     */   @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
/*     */   public void adjustDigSpeed(PlayerEvent.BreakSpeed event)
/*     */   {
/* 151 */     EntityPlayer player = event.entityPlayer;
/* 152 */     if ((player.func_70694_bm() == null) || (player.func_70694_bm().getItem() != this)) { return;
/*     */     }
/* 154 */     BlockPos pos = event.pos;
/*     */     
/* 156 */     World world = player.worldObj;
/* 157 */     if (world.isAirBlock(pos)) { return;
/*     */     }
/* 159 */     MovingObjectPosition mop = PlayerHelper.rayTrace(player);
/*     */     
/* 161 */     if ((mop == null) || (mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) || (!mop.getBlockPos().equals(pos))) {
/* 162 */       event.setCanceled(true);
/* 163 */       return;
/*     */     }
/*     */     
/* 166 */     IBlockState blockState = world.getBlockState(pos);
/* 167 */     Block block = blockState.getBlock();
/* 168 */     ItemStack pickBlock = getStack(world, pos);
/*     */     
/* 170 */     List<BlockPos> potentialBlocks = getPotentialBlocks(player, world, pos, mop.sideHit, this.range, pickBlock, blockState, block);
/*     */     
/* 172 */     if (potentialBlocks.isEmpty()) {
/* 173 */       event.setCanceled(true);
/* 174 */       return;
/*     */     }
/*     */     
/* 177 */     event.newSpeed /= potentialBlocks.size();
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemDestructionWand.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */