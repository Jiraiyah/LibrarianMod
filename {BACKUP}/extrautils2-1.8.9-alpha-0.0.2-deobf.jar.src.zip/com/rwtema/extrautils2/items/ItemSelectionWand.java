/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.utils.PositionPool;
/*     */ import com.rwtema.extrautils2.utils.helpers.SideHelper;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockMycelium;
/*     */ import net.minecraft.block.state.BlockState;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.WorldRenderer;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3i;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.DrawBlockHighlightEvent;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public abstract class ItemSelectionWand extends com.rwtema.extrautils2.backend.XUItemFlat
/*     */ {
/*     */   static double[][][] edgeLines;
/*     */   public final String texture;
/*     */   public final String name;
/*     */   public final int range;
/*     */   public final float[] col;
/*     */   
/*     */   public int getMaxMetadata()
/*     */   {
/*  47 */     return 0;
/*     */   }
/*     */   
/*     */   static {
/*  51 */     float offset = 0.50097656F;
/*     */     
/*  53 */     edgeLines = new double[12][2][3];
/*  54 */     for (int i = 0; i < SideHelper.edges.length; i++) {
/*  55 */       EnumFacing[] edge = SideHelper.edges[i];
/*     */       
/*  57 */       EnumFacing a = edge[0];
/*  58 */       EnumFacing b = edge[1];
/*  59 */       EnumFacing c = edge[2];
/*     */       
/*  61 */       edgeLines[i] = { { 0.5F + (a.getFrontOffsetX() + b.getFrontOffsetX() + c.getFrontOffsetX()) * offset, 0.5F + (a.getFrontOffsetY() + b.getFrontOffsetY() + c.getFrontOffsetY()) * offset, 0.5F + (a.getFrontOffsetZ() + b.getFrontOffsetZ() + c.getFrontOffsetZ()) * offset }, { 0.5F + (a.getFrontOffsetX() + b.getFrontOffsetX() - c.getFrontOffsetX()) * offset, 0.5F + (a.getFrontOffsetY() + b.getFrontOffsetY() - c.getFrontOffsetY()) * offset, 0.5F + (a.getFrontOffsetZ() + b.getFrontOffsetZ() - c.getFrontOffsetZ()) * offset } };
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemSelectionWand(String texture, String name, float[] col, int range)
/*     */   {
/*  83 */     this.texture = texture;
/*  84 */     this.name = name;
/*  85 */     this.col = col;
/*  86 */     this.range = range;
/*  87 */     setMaxStackSize(1);
/*  88 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);
/*     */   }
/*     */   
/*     */   public List<BlockPos> getPotentialBlocks(EntityPlayer player, World world, BlockPos pos, EnumFacing side, int maxBlocks, ItemStack pickBlock1, IBlockState blockState, Block block) {
/*  92 */     if ((pos.getY() >= 255) || (pos.getY() < 0) || (world.isAirBlock(pos)) || ((!world.isRemote) && (!com.rwtema.extrautils2.utils.helpers.PlayerHelper.isPlayerReal(player)))) {
/*  93 */       return ImmutableList.of();
/*     */     }
/*  95 */     if (pickBlock1 == null) {
/*  96 */       return ImmutableList.of();
/*     */     }
/*  98 */     if (initialCheck(world, pos, side, pickBlock1, block)) { return ImmutableList.of();
/*     */     }
/* 100 */     int data = block.damageDropped(blockState);
/*     */     
/* 102 */     boolean grassBlock = (block == Blocks.grass) || (block == Blocks.mycelium);
/*     */     
/* 104 */     int numBlocks = getNumBlocks(player, maxBlocks, pickBlock1, grassBlock);
/*     */     
/* 106 */     if (numBlocks == 0) { return ImmutableList.of();
/*     */     }
/* 108 */     EnumSet<EnumFacing> dirs2Search = EnumSet.allOf(EnumFacing.class);
/*     */     
/* 110 */     dirs2Search.remove(side);
/* 111 */     dirs2Search.remove(side.getOpposite());
/*     */     
/* 113 */     boolean sneaking = player.isSneaking();
/* 114 */     if (com.rwtema.extrautils2.ExtraUtils2.proxy.isAltSneaking(player)) {
/* 115 */       if (side.getFrontOffsetY() != 0) {
/* 116 */         EnumFacing horizontalFacing = player.getHorizontalFacing().rotateY();
/* 117 */         dirs2Search.remove(horizontalFacing);
/* 118 */         dirs2Search.remove(horizontalFacing.getOpposite());
/*     */       } else {
/* 120 */         dirs2Search.remove(EnumFacing.WEST);
/* 121 */         dirs2Search.remove(EnumFacing.EAST);
/* 122 */         dirs2Search.remove(EnumFacing.SOUTH);
/* 123 */         dirs2Search.remove(EnumFacing.NORTH);
/*     */       }
/* 125 */     } else if (sneaking) {
/* 126 */       if (side.getFrontOffsetY() != 0) {
/* 127 */         EnumFacing horizontalFacing = player.getHorizontalFacing();
/* 128 */         dirs2Search.remove(horizontalFacing);
/* 129 */         dirs2Search.remove(horizontalFacing.getOpposite());
/*     */       } else {
/* 131 */         dirs2Search.remove(EnumFacing.DOWN);
/* 132 */         dirs2Search.remove(EnumFacing.UP);
/*     */       }
/*     */     }
/*     */     
/* 136 */     if (dirs2Search.isEmpty()) { return ImmutableList.of();
/*     */     }
/* 138 */     LinkedHashSet<Vec3i> vecs = new LinkedHashSet();
/* 139 */     for (EnumFacing enumFacing : dirs2Search) {
/* 140 */       vecs.add(BlockPos.ORIGIN.offset(enumFacing));
/*     */     }
/*     */     
/* 143 */     for (Iterator i$ = dirs2Search.iterator(); i$.hasNext();) { enumFacing = (EnumFacing)i$.next();
/* 144 */       for (EnumFacing otherEnumFacing : dirs2Search) {
/* 145 */         BlockPos offset = BlockPos.ORIGIN.offset(enumFacing).offset(otherEnumFacing);
/* 146 */         if ((Math.abs(offset.getX()) < 2) && (Math.abs(offset.getY()) < 2) && (Math.abs(offset.getZ()) < 2)) {
/* 147 */           vecs.add(offset);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     EnumFacing enumFacing;
/*     */     
/*     */ 
/*     */ 
/* 159 */     HashSet<IBlockState> states = new HashSet();
/* 160 */     states.add(blockState);
/* 161 */     for (IBlockState otherState : block.getBlockState().getValidStates()) {
/* 162 */       if (block.damageDropped(otherState) == data) {
/* 163 */         states.add(otherState);
/*     */       }
/*     */     }
/*     */     
/* 167 */     if (grassBlock) {
/* 168 */       states.addAll(Blocks.dirt.getBlockState().getValidStates());
/* 169 */     } else if (block == Blocks.dirt) {
/* 170 */       states.addAll(Blocks.grass.getBlockState().getValidStates());
/* 171 */       states.addAll(Blocks.mycelium.getBlockState().getValidStates());
/*     */     }
/*     */     
/* 174 */     LinkedList<BlockPos> queue = new LinkedList();
/* 175 */     Set<BlockPos> checkedBlocks = new HashSet(numBlocks);
/*     */     
/* 177 */     queue.add(pos);
/* 178 */     checkedBlocks.add(pos);
/*     */     
/* 180 */     PositionPool pool = new PositionPool();
/*     */     
/*     */ 
/*     */ 
/* 184 */     List<BlockPos> blocks = new java.util.ArrayList();
/* 185 */     BlockPos p; label958: while (((p = (BlockPos)queue.poll()) != null) && (blocks.size() < numBlocks)) {
/* 186 */       if ((states.contains(world.getBlockState(p))) && 
/*     */       
/*     */ 
/* 189 */         (checkAndAddBlocks(player, world, side, pickBlock1, block, pool, p, blocks)))
/*     */       {
/*     */ 
/* 192 */         for (Vec3i offset : vecs) {
/* 193 */           BlockPos p2 = pool.add(p, offset);
/* 194 */           if (!checkedBlocks.contains(p2)) {
/* 195 */             checkedBlocks.add(p2);
/*     */             
/* 197 */             int d = Math.max(Math.max(Math.abs(p2.getX() - pos.getX()), Math.abs(p2.getY() - pos.getY())), Math.abs(p2.getZ() - pos.getZ()));
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 202 */             ListIterator<BlockPos> listIterator = queue.listIterator();
/* 203 */             for (;;) { if (!listIterator.hasNext()) break label958;
/* 204 */               BlockPos next = (BlockPos)listIterator.next();
/*     */               
/* 206 */               int d2 = Math.max(Math.max(Math.abs(next.getX() - pos.getX()), Math.abs(next.getY() - pos.getY())), Math.abs(next.getZ() - pos.getZ()));
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 211 */               if (d2 >= d) {
/* 212 */                 listIterator.add(p2);
/* 213 */                 break;
/*     */               }
/*     */             }
/* 216 */             queue.add(p2);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 221 */     return blocks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getRenderLayers(@Nullable ItemStack itemStack)
/*     */   {
/* 233 */     return 2;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean renderLayerIn3D(ItemStack stack, int renderPass)
/*     */   {
/* 239 */     return renderPass == 0;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/* 245 */     Textures.register(new String[] { this.texture + "0" });
/* 246 */     Textures.register(new String[] { this.texture + "1" });
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public String getTexture(@Nullable ItemStack itemStack, int renderPass)
/*     */   {
/* 252 */     return this.texture + renderPass;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean renderAsTool()
/*     */   {
/* 258 */     return true;
/*     */   }
/*     */   
/*     */   public ItemStack getStack(World world, BlockPos pos) {
/* 262 */     IBlockState state = world.getBlockState(pos);
/* 263 */     Block block = state.getBlock();
/*     */     
/* 265 */     Item item = Item.getItemFromBlock(block);
/* 266 */     if (item == null) { return null;
/*     */     }
/* 268 */     return new ItemStack(item, 1, block.func_176222_j(world, pos));
/*     */   }
/*     */   
/*     */   @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void drawSelection(DrawBlockHighlightEvent event) {
/* 274 */     ItemStack currentItem = event.currentItem;
/* 275 */     if ((currentItem == null) || (currentItem.getItem() != this) || (event.target.typeOfHit != net.minecraft.util.MovingObjectPosition.MovingObjectType.BLOCK)) {
/* 276 */       return;
/*     */     }
/* 278 */     event.setCanceled(true);
/*     */     
/* 280 */     BlockPos blockPos = event.target.getBlockPos();
/* 281 */     EntityPlayer player = event.player;
/* 282 */     IBlockState blockState = player.worldObj.getBlockState(blockPos);
/* 283 */     Block block = blockState.getBlock();
/* 284 */     if (block == Blocks.air) { return;
/*     */     }
/* 286 */     ItemStack pickBlock = getStack(player.worldObj, blockPos);
/*     */     
/* 288 */     List<BlockPos> potentialBlocks = getPotentialBlocks(player, player.worldObj, blockPos, event.target.sideHit, this.range, pickBlock, blockState, block);
/*     */     
/* 290 */     if (potentialBlocks.isEmpty()) { return;
/*     */     }
/* 292 */     LinkedHashSet<BlockPos> posSet = new LinkedHashSet(potentialBlocks);
/*     */     
/* 294 */     GlStateManager.enableBlend();
/* 295 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/* 296 */     GlStateManager.disableTexture2D();
/* 297 */     GlStateManager.depthMask(false);
/* 298 */     GlStateManager.disableDepth();
/*     */     
/* 300 */     Tessellator tessellator = Tessellator.getInstance();
/* 301 */     WorldRenderer worldrenderer = tessellator.getBuffer();
/*     */     
/* 303 */     float scale = 0.52F;
/*     */     
/* 305 */     double d0 = player.lastTickPosX + (player.posX - player.lastTickPosX) * event.partialTicks;
/* 306 */     double d1 = player.lastTickPosY + (player.posY - player.lastTickPosY) * event.partialTicks;
/* 307 */     double d2 = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * event.partialTicks;
/*     */     
/* 309 */     PositionPool pool = new PositionPool();
/*     */     
/* 311 */     int prevType = -1;
/*     */     
/* 313 */     EnumFacing[][] edges1 = SideHelper.edges;
/*     */     EnumFacing[] edges;
/* 315 */     double[][] line; for (int i = 0; i < edges1.length; i++) {
/* 316 */       edges = edges1[i];
/* 317 */       line = edgeLines[i];
/*     */       
/* 319 */       for (BlockPos pos : posSet)
/*     */       {
/* 321 */         BlockPos o1 = pool.offset(pos, edges[0]);
/* 322 */         boolean a = posSet.contains(o1);
/* 323 */         boolean b = posSet.contains(pool.offset(pos, edges[1]));
/* 324 */         int type; if ((a) && (b)) {
/* 325 */           if (posSet.contains(pool.offset(o1, edges[1]))) {
/*     */             continue;
/*     */           }
/* 328 */           int type = 1; } else { int type;
/* 329 */           if ((!a) && (!b)) {
/* 330 */             type = 1;
/*     */           } else {
/* 332 */             type = 2;
/*     */           }
/*     */         }
/* 335 */         if (type != prevType) {
/* 336 */           if (prevType != -1) tessellator.draw();
/* 337 */           worldrenderer.begin(1, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION);
/*     */           
/* 339 */           if (type == 1) {
/* 340 */             GlStateManager.color(this.col[0], this.col[1], this.col[2], 0.8F);
/* 341 */             GL11.glLineWidth(4.0F);
/*     */           } else {
/* 343 */             GlStateManager.color(this.col[0], this.col[1], this.col[2], 0.1F);
/* 344 */             GL11.glLineWidth(2.0F);
/*     */           }
/*     */           
/* 347 */           prevType = type;
/*     */         }
/*     */         
/* 350 */         for (double[] vec : line) {
/* 351 */           worldrenderer.pos(pos.getX() - d0 + vec[0], pos.getY() - d1 + vec[1], pos.getZ() - d2 + vec[2]).endVertex();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 359 */     if (prevType != -1) {
/* 360 */       tessellator.draw();
/*     */     }
/*     */     
/* 363 */     GlStateManager.enableDepth();
/* 364 */     GlStateManager.depthMask(true);
/* 365 */     GlStateManager.enableTexture2D();
/* 366 */     GlStateManager.disableBlend();
/*     */   }
/*     */   
/*     */   protected abstract boolean initialCheck(World paramWorld, BlockPos paramBlockPos, EnumFacing paramEnumFacing, ItemStack paramItemStack, Block paramBlock);
/*     */   
/*     */   protected abstract int getNumBlocks(EntityPlayer paramEntityPlayer, int paramInt, ItemStack paramItemStack, boolean paramBoolean);
/*     */   
/*     */   protected abstract boolean checkAndAddBlocks(EntityPlayer paramEntityPlayer, World paramWorld, EnumFacing paramEnumFacing, ItemStack paramItemStack, Block paramBlock, PositionPool paramPositionPool, BlockPos paramBlockPos, List<BlockPos> paramList);
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemSelectionWand.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */