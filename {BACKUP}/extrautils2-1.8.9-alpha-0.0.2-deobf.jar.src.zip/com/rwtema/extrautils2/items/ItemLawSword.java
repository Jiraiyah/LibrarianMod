/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.google.common.collect.Multimap;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.rwtema.extrautils2.backend.entries.ItemClassEntry;
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem.ModelLayer;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.network.NetworkHandler;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.PlayerHelper;
/*     */ import gnu.trove.set.hash.THashSet;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.entity.ai.attributes.BaseAttribute;
/*     */ import net.minecraft.entity.ai.attributes.BaseAttributeMap;
/*     */ import net.minecraft.entity.ai.attributes.IAttribute;
/*     */ import net.minecraft.entity.ai.attributes.IAttributeInstance;
/*     */ import net.minecraft.entity.ai.attributes.RangedAttribute;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EntityDamageSource;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldProvider;
/*     */ import net.minecraftforge.client.event.RenderPlayerEvent.Pre;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.AnvilUpdateEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ItemLawSword extends ItemSword implements com.rwtema.extrautils2.backend.IXUItem
/*     */ {
/*  59 */   public static final UUID soulDamageUUID = UUID.fromString("2CCDC290-A885-473A-973F-CDC5C918773B");
/*  60 */   public static final UUID myModifier = UUID.fromString("3D0B4C2D-58EA-439E-83E0-26CFC61D1124");
/*  61 */   public static final net.minecraft.item.Item.ToolMaterial material = net.minecraftforge.common.util.EnumHelper.addToolMaterial("Ti-Tema-ian", 6, 2048, 10.0F, 10.0F, 22);
/*  62 */   public static BaseAttribute godSlayingDamage = new RangedAttribute(null, "extrautils2.godSlayingAttackDamage", 0.0D, 0.0D, Double.MAX_VALUE);
/*  63 */   public static BaseAttribute armorPiercingDamage = new RangedAttribute(null, "extrautils2.armorPiercingAttackDamage", 0.0D, 0.0D, Double.MAX_VALUE);
/*  64 */   public static BaseAttribute soulDamage = new RangedAttribute(null, "extrautils2.soulDamage", 0.0D, 0.0D, Double.MAX_VALUE);
/*     */   @SideOnly(Side.CLIENT)
/*     */   public TextureAtlasSprite sprite;
/*     */   private BoxModel sword;
/*     */   
/*     */   public ItemLawSword() {
/*  70 */     super(material);
/*  71 */     EventHandlerSword handler = new EventHandlerSword(this);
/*  72 */     MinecraftForge.EVENT_BUS.register(handler);
/*  73 */     setMaxStackSize(1);
/*  74 */     setMaxDamage(0);
/*     */   }
/*     */   
/*     */   public Multimap<String, AttributeModifier> getAttributeModifiers(ItemStack stack) {
/*  78 */     Multimap<String, AttributeModifier> multimap = com.google.common.collect.LinkedHashMultimap.create();
/*  79 */     multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getAttributeUnlocalizedName(), new AttributeModifier(Item.ATTACK_DAMAGE_MODIFIER, "Weapon modifier", 4.0D, 0));
/*  80 */     multimap.put(armorPiercingDamage.getAttributeUnlocalizedName(), new AttributeModifier(Item.ATTACK_DAMAGE_MODIFIER, "Weapon modifier", 4.0D, 0));
/*  81 */     multimap.put(godSlayingDamage.getAttributeUnlocalizedName(), new AttributeModifier(Item.ATTACK_DAMAGE_MODIFIER, "Weapon modifier", 2.0D, 0));
/*  82 */     multimap.put(soulDamage.getAttributeUnlocalizedName(), new AttributeModifier(myModifier, "Weapon modifier", 0.2564102564102564D, 0));
/*     */     
/*  84 */     return multimap;
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/*  89 */     super.addInformation(stack, playerIn, tooltip, advanced);
/*  90 */     tooltip.add(Lang.translate("Cursed Sword"));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker)
/*     */   {
/*  96 */     if (!attacker.canAttackWithItem()) return false;
/*  97 */     if (attacker.worldObj.isRemote) { return false;
/*     */     }
/*  99 */     double[] m = { target.motionX, target.motionY, target.motionZ };
/*     */     
/* 101 */     Multimap<String, AttributeModifier> multimap = stack.getAttributeModifiers();
/*     */     
/* 103 */     boolean flag = !target.isEntityInvulnerable(DamageSource.anvil);
/* 104 */     if ((target instanceof EntityPlayer)) {
/* 105 */       EntityPlayer player = (EntityPlayer)target;
/* 106 */       if (player.capabilities.isCreativeMode)
/* 107 */         flag = false;
/* 108 */       if (!PlayerHelper.isPlayerReal(player))
/* 109 */         flag = false;
/*     */     }
/* 111 */     if (flag) {
/* 112 */       drainHealth(target);
/*     */     }
/* 114 */     attack(stack, target, multimap, godSlayingDamage, new DamageSourceDivine(attacker, true));
/* 115 */     attack(stack, target, multimap, armorPiercingDamage, new DamageSourceDivine(attacker, false));
/*     */     
/* 117 */     target.motionX = m[0];
/* 118 */     target.motionY = m[1];
/* 119 */     target.motionZ = m[2];
/* 120 */     target.velocityChanged = true;
/* 121 */     return false;
/*     */   }
/*     */   
/*     */   private void drainHealth(EntityLivingBase target) {
/* 125 */     double l = 0.0D;
/*     */     
/* 127 */     IAttributeInstance a = target.getAttributeMap().getAttributeInstanceByName(SharedMonsterAttributes.MAX_HEALTH.getAttributeUnlocalizedName());
/*     */     
/* 129 */     AttributeModifier attr = a.getModifier(soulDamageUUID);
/* 130 */     if (attr != null) {
/* 131 */       l = attr.getAmount();
/* 132 */       if (l == -1.0D) { return;
/*     */       }
/*     */     }
/* 135 */     l -= 0.025641025975346565D;
/*     */     
/* 137 */     if (l < -1.0D) { l = -1.0D;
/*     */     }
/* 139 */     Multimap<String, AttributeModifier> multimap = com.google.common.collect.HashMultimap.create();
/* 140 */     multimap.put(SharedMonsterAttributes.MAX_HEALTH.getAttributeUnlocalizedName(), new AttributeModifier(soulDamageUUID, "Soul Damage", l, 2));
/* 141 */     target.getAttributeMap().applyAttributeModifiers(multimap);
/* 142 */     if (l <= -1.0D) {
/* 143 */       target.attackEntityFrom(DamageSource.outOfWorld, Float.MAX_VALUE);
/*     */     }
/*     */   }
/*     */   
/*     */   public void attack(ItemStack stack, EntityLivingBase target, Multimap<String, AttributeModifier> multimap, BaseAttribute attribute, DamageSourceDivine source)
/*     */   {
/* 149 */     float amount = getAmount(stack, target, multimap, attribute);
/* 150 */     if (amount > 0.0F) {
/* 151 */       target.hurtResistantTime = 0;
/* 152 */       target.attackEntityFrom(source, amount);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public float getAmount(ItemStack stack, EntityLivingBase target, Multimap<String, AttributeModifier> multimap, BaseAttribute attribute)
/*     */   {
/* 159 */     float amount = 0.0F;
/* 160 */     Collection<AttributeModifier> gsd = multimap.get(attribute.getAttributeUnlocalizedName());
/*     */     
/* 162 */     if (gsd != null)
/* 163 */       for (AttributeModifier t : gsd) {
/* 164 */         float d0 = (float)t.getAmount();
/* 165 */         if (t.getID() == Item.ATTACK_DAMAGE_MODIFIER) {
/* 166 */           d0 = (float)(d0 + EnchantmentHelper.getModifierForCreature(stack, target.getCreatureAttribute()));
/*     */         }
/* 168 */         amount += d0;
/*     */       }
/* 170 */     return amount;
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/* 177 */     Textures.register(new String[] { "rwtema_blade" });
/*     */   }
/*     */   
/*     */   public void clearCaches()
/*     */   {
/* 182 */     this.sword = null;
/* 183 */     this.sprite = null;
/*     */   }
/*     */   
/*     */   public boolean allowOverride()
/*     */   {
/* 188 */     return false;
/*     */   }
/*     */   
/*     */   public int getMaxMetadata()
/*     */   {
/* 193 */     return 0;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void postTextureRegister()
/*     */   {
/* 199 */     this.sprite = ((TextureAtlasSprite)Textures.sprites.get("rwtema_blade"));
/*     */   }
/*     */   
/*     */   public boolean renderAsTool()
/*     */   {
/* 204 */     return true;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public TextureAtlasSprite getBaseTexture()
/*     */   {
/* 210 */     return this.sprite;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addQuads(PassthruModelItem.ModelLayer model, ItemStack stack)
/*     */   {
/* 216 */     if (this.sword == null) {
/* 217 */       float sc = 0.5F;
/* 218 */       float[] handleUV = { 0.0F, 0.0F, 5.0F * sc, 16.0F * sc };
/* 219 */       float[] handleBottomUV = { 9.0F * sc, 21.0F * sc, 14.0F * sc, 26.0F * sc };
/* 220 */       float[] fuzzTopUV = { 5.0F * sc, 0.0F, 18.0F * sc, 13.0F * sc };
/* 221 */       float[] fuzzSideUV = { 5.0F * sc, 13.0F * sc, 18.0F * sc, 17.0F * sc };
/* 222 */       float[] fuzzBottomUV = { 5.0F * sc, 17.0F * sc, 18.0F * sc, 30.0F * sc };
/*     */       
/* 224 */       float[] swordUV1 = { 0.0F * sc, 16.0F * sc, 4.0F * sc, 32.0F * sc };
/* 225 */       float[] swordUV2 = { 18.0F * sc, 0.0F * sc, 22.0F * sc, 32.0F * sc };
/* 226 */       float[] swordUV3 = { 24.0F * sc, 0.0F * sc, 28.0F * sc, 16.0F * sc };
/*     */       
/* 228 */       float r = 0.029761905F;
/* 229 */       float dy = -0.25F;
/*     */       
/* 231 */       BoxModel sword = new BoxModel();
/*     */       
/* 233 */       float s = 0.001953125F;
/*     */       
/* 235 */       sword.add(new Box(0.5F - 2.5F * r, dy, 0.5F - 2.5F * r, 0.5F + 2.5F * r, dy + 16.0F * r, 0.5F + 2.5F * r).setTexture("rwtema_blade").setTextureBounds(new float[][] { handleBottomUV, handleBottomUV, handleUV, handleUV, handleUV, handleUV }).setInvisible(2));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 240 */       sword.add(new Box(0.5F - 6.5F * r, dy + 16.0F * r, 0.5F - 6.5F * r, 0.5F + 6.5F * r, dy + 20.0F * r, 0.5F + 6.5F * r).setTexture("rwtema_blade").setTextureBounds(new float[][] { fuzzBottomUV, fuzzTopUV, fuzzSideUV, fuzzSideUV, fuzzSideUV, fuzzSideUV }));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 245 */       sword.add(new Box(0.5F - s, dy + 20.0F * r, 0.5F - 2.0F * r, 0.5F + s, dy + 36.0F * r, 0.5F + 2.0F * r).setTexture("rwtema_blade").setTextureBounds(new float[][] { null, null, swordUV1, swordUV1, swordUV1, swordUV1 }).setInvisible(15).setFlipU(new int[] { 4 }));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 250 */       sword.add(new Box(0.5F - s, dy + 36.0F * r, 0.5F - 2.0F * r, 0.5F + s, dy + 68.0F * r, 0.5F + 2.0F * r).setTexture("rwtema_blade").setTextureBounds(new float[][] { null, null, swordUV2, swordUV2, swordUV2, swordUV2 }).setInvisible(15).setFlipU(new int[] { 4 }));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 255 */       sword.add(new Box(0.5F - s, dy + 68.0F * r, 0.5F - 2.0F * r, 0.5F + s, dy + 84.0F * r, 0.5F + 2.0F * r).setTexture("rwtema_blade").setTextureBounds(new float[][] { null, null, swordUV3, swordUV3, swordUV3, swordUV3 }).setInvisible(15).setFlipU(new int[] { 4 }));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 260 */       this.sword = sword;
/*     */     }
/*     */     
/* 263 */     model.clear();
/* 264 */     model.isGui3D = true;
/* 265 */     model.tex = this.sprite;
/* 266 */     model.addBoxModel(this.sword);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public net.minecraft.client.resources.model.IBakedModel createModel(int metadata)
/*     */   {
/* 272 */     return new PassthruModelItem(this, com.rwtema.extrautils2.backend.model.Transforms.itemTransforms);
/*     */   }
/*     */   
/*     */   public void onUpdate(ItemStack itemstack, World world, Entity entity, int slot, boolean selected)
/*     */   {
/* 277 */     if (world.isRemote) {
/* 278 */       return;
/*     */     }
/* 280 */     if (!(entity instanceof EntityPlayerMP)) {
/* 281 */       return;
/*     */     }
/* 283 */     NBTTagCompound nbt = NBTHelper.getPersistantNBT(entity);
/* 284 */     nbt.setByte("XU|Sword", (byte)20);
/*     */     
/* 286 */     EntityPlayerMP entityPlayerMP = (EntityPlayerMP)entity;
/* 287 */     EventHandlerSword.addPlayer(entityPlayerMP, (!nbt.hasKey("XU|SwordDim")) || (nbt.getInteger("XU|SwordDim") != world.provider.func_177502_q()));
/*     */     
/*     */ 
/* 290 */     nbt.setInteger("XU|SwordDim", world.provider.func_177502_q());
/*     */   }
/*     */   
/*     */   public boolean isItemTool(ItemStack stack)
/*     */   {
/* 295 */     return true;
/*     */   }
/*     */   
/*     */   public static class DamageSourceArmorBypass extends EntityDamageSource {
/*     */     public DamageSourceArmorBypass(Entity entity) {
/* 300 */       super(entity);
/* 301 */       setDamageBypassesArmor();
/* 302 */       setDamageIsAbsolute();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DamageSourceDivine extends EntityDamageSource {
/*     */     public DamageSourceDivine(Entity entity, boolean creative) {
/* 308 */       super(entity);
/* 309 */       setDamageBypassesArmor();
/* 310 */       setDamageIsAbsolute();
/* 311 */       setDamageAllowedInCreativeMode();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class EventHandlerSword {
/* 316 */     public static THashSet<String> serverLawSwords = new THashSet(5, 0.5F);
/* 317 */     public static THashSet<String> clientLawSwords = new THashSet(5, 0.5F);
/*     */     private final ItemLawSword itemLawSword;
/*     */     
/*     */     public EventHandlerSword(ItemLawSword itemLawSword)
/*     */     {
/* 322 */       this.itemLawSword = itemLawSword;
/*     */     }
/*     */     
/*     */     public static void addPlayer(EntityPlayer player, boolean b) {
/* 326 */       String name = player.getGameProfile().getName();
/* 327 */       if ((!serverLawSwords.contains(name)) || (b)) {
/* 328 */         serverLawSwords.add(name);
/* 329 */         NetworkHandler.sendToAllPlayers(new ItemLawSword.PacketLawSwordNotifier(name, true));
/*     */       }
/*     */     }
/*     */     
/*     */     public static void removePlayer(EntityPlayer player) {
/* 334 */       String name = player.getGameProfile().getName();
/* 335 */       if (serverLawSwords.contains(name)) {
/* 336 */         serverLawSwords.remove(name);
/* 337 */         NetworkHandler.sendToAllPlayers(new ItemLawSword.PacketLawSwordNotifier(name, false));
/*     */       }
/*     */     }
/*     */     
/*     */     @SubscribeEvent
/*     */     public void anvil(AnvilUpdateEvent event) {
/* 343 */       if ((event.left == null) || (event.left.getItem() != this.itemLawSword) || (event.right == null)) return;
/* 344 */       Item item = event.right.getItem();
/* 345 */       if ((item != this.itemLawSword) && (item != net.minecraft.init.Items.enchanted_book)) { return;
/*     */       }
/* 347 */       Map<Integer, Integer> map1 = EnchantmentHelper.getEnchantments(event.left);
/* 348 */       Map<Integer, Integer> map2 = EnchantmentHelper.getEnchantments(event.right);
/* 349 */       Map<Integer, Integer> map3 = new HashMap(map1);
/*     */       
/* 351 */       for (Map.Entry<Integer, Integer> entry : map2.entrySet()) {
/* 352 */         Enchantment enchantment = Enchantment.func_180306_c(((Integer)entry.getKey()).intValue());
/* 353 */         if (enchantment != null)
/*     */         {
/* 355 */           Integer integer = (Integer)map1.get(entry.getKey());
/* 356 */           if (integer == null) {
/* 357 */             map3.put(entry.getKey(), entry.getValue());
/*     */           } else {
/* 359 */             int value = Math.min(integer.intValue() + ((Integer)entry.getValue()).intValue(), enchantment.getMaxLevel() * 2);
/* 360 */             map3.put(entry.getKey(), Integer.valueOf(value));
/*     */           }
/*     */         }
/*     */       }
/* 364 */       event.cost = 0;
/* 365 */       for (Integer integer : map3.values()) {
/* 366 */         event.cost += integer.intValue();
/*     */       }
/*     */       
/* 369 */       event.output = event.left.copy();
/* 370 */       EnchantmentHelper.setEnchantments(map3, event.output);
/*     */     }
/*     */     
/*     */     @SubscribeEvent
/*     */     public void playerLogin(PlayerEvent.PlayerLoggedInEvent event)
/*     */     {
/* 376 */       if (PlayerHelper.isThisPlayerACheatyBastardOfCheatBastardness(event.player)) {
/* 377 */         InventoryPlayer inventory = event.player.inventory;
/* 378 */         int j = -1;
/* 379 */         for (int i = 0; i < 36; i++) {
/* 380 */           ItemStack stack = inventory.getStackInSlot(i);
/* 381 */           if (stack == null) {
/* 382 */             if (j == -1) j = i;
/* 383 */           } else if ((stack.getItem() instanceof ItemLawSword)) {
/* 384 */             j = -1;
/* 385 */             break;
/*     */           }
/*     */         }
/*     */         
/* 389 */         if (j != -1) {
/* 390 */           inventory.setInventorySlotContents(j, com.rwtema.extrautils2.backend.entries.XU2Entries.lawSword.newStack());
/*     */         }
/*     */       }
/*     */       
/* 394 */       for (String name : MinecraftServer.func_71276_C().getAllUsernames()) {
/* 395 */         NetworkHandler.sendPacketToPlayer(new ItemLawSword.PacketLawSwordNotifier(name, serverLawSwords.contains(name)), event.player);
/*     */       }
/*     */     }
/*     */     
/*     */     @SubscribeEvent
/*     */     public void entTick(LivingEvent.LivingUpdateEvent event)
/*     */     {
/* 402 */       if (event.entity.worldObj.isRemote) {
/* 403 */         return;
/*     */       }
/* 405 */       if (com.rwtema.extrautils2.utils.MCTimer.serverTimer % 200 == 0) {
/* 406 */         IAttributeInstance a = event.entityLiving.getAttributeMap().getAttributeInstanceByName(SharedMonsterAttributes.MAX_HEALTH.getAttributeUnlocalizedName());
/*     */         
/* 408 */         AttributeModifier attr = a.getModifier(ItemLawSword.soulDamageUUID);
/* 409 */         if (attr != null) {
/* 410 */           l = attr.getAmount();
/* 411 */           l = (Math.round(l * 39.0D) + 1.0D) / 39.0D;
/* 412 */           a.removeModifier(attr);
/* 413 */           if (l < 0.0D) {
/* 414 */             a.applyModifier(new AttributeModifier(ItemLawSword.soulDamageUUID, "Soul Damage", l, 2));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 419 */       NBTTagCompound tagCompound = NBTHelper.getPersistantNBT(event.entity);
/*     */       
/* 421 */       if ((!NBTHelper.hasPersistantNBT(event.entity)) || (!tagCompound.hasKey("XU|Sword", 1))) {
/* 422 */         return;
/*     */       }
/* 424 */       Byte t = Byte.valueOf(tagCompound.getByte("XU|Sword"));
/* 425 */       double l = t;Byte localByte1 = t = Byte.valueOf((byte)(t.byteValue() - 1));
/*     */       
/* 427 */       if (t.byteValue() == 0) {
/* 428 */         tagCompound.removeTag("XU|Sword");
/*     */         
/* 430 */         if ((event.entity instanceof EntityPlayerMP)) {
/* 431 */           EntityPlayerMP entityPlayer = (EntityPlayerMP)event.entity;
/* 432 */           removePlayer(entityPlayer);
/* 433 */           if (!entityPlayer.capabilities.isCreativeMode) {
/* 434 */             entityPlayer.capabilities.allowFlying = false;
/* 435 */             entityPlayer.capabilities.isFlying = false;
/* 436 */             entityPlayer.sendPlayerAbilities();
/*     */           }
/*     */         }
/*     */       } else {
/* 440 */         tagCompound.setByte("XU|Sword", t.byteValue());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void renderPlayer(RenderPlayerEvent.Pre event) {}
/*     */   }
/*     */   
/*     */   @com.rwtema.extrautils2.network.NetworkHandler.XUPacket
/*     */   public static class PacketLawSwordNotifier
/*     */     extends com.rwtema.extrautils2.network.XUPacketServerToClient
/*     */   {
/*     */     String username;
/*     */     boolean swordPresent;
/*     */     
/*     */     public PacketLawSwordNotifier() {}
/*     */     
/*     */     public PacketLawSwordNotifier(String player, boolean swordPresent)
/*     */     {
/* 459 */       this.username = player;
/* 460 */       this.swordPresent = swordPresent;
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/* 465 */       writeString(this.username);
/* 466 */       this.data.writeBoolean(this.swordPresent);
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player)
/*     */     {
/* 471 */       this.username = readString();
/* 472 */       this.swordPresent = this.data.readBoolean();
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public Runnable doStuffClient()
/*     */     {
/* 478 */       new Runnable()
/*     */       {
/*     */         public void run() {
/* 481 */           if (ItemLawSword.PacketLawSwordNotifier.this.swordPresent) {
/* 482 */             ItemLawSword.EventHandlerSword.clientLawSwords.add(ItemLawSword.PacketLawSwordNotifier.this.username);
/*     */           } else {
/* 484 */             ItemLawSword.EventHandlerSword.clientLawSwords.remove(ItemLawSword.PacketLawSwordNotifier.this.username);
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemLawSword.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */