/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.achievements.AchievementHelper;
/*     */ import com.rwtema.extrautils2.backend.ISidedFunction;
/*     */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*     */ import com.rwtema.extrautils2.backend.entries.IItemStackMaker;
/*     */ import com.rwtema.extrautils2.backend.entries.ItemClassEntry;
/*     */ import com.rwtema.extrautils2.backend.entries.XU2Entries;
/*     */ import com.rwtema.extrautils2.crafting.CraftingHelper;
/*     */ import com.rwtema.extrautils2.eventhandlers.DropsHandler;
/*     */ import com.rwtema.extrautils2.power.ClientPower;
/*     */ import com.rwtema.extrautils2.power.PowerManager;
/*     */ import com.rwtema.extrautils2.power.PowerManager.PowerFreq;
/*     */ import com.rwtema.extrautils2.tile.TileResonator;
/*     */ import com.rwtema.extrautils2.transfernodes.IUpgradeProvider;
/*     */ import com.rwtema.extrautils2.transfernodes.Upgrade;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.StringHelper;
/*     */ import gnu.trove.map.hash.TIntObjectHashMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.EnumDyeColor;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraftforge.fml.common.IFuelHandler;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ItemIngredients extends XUItemFlatMetadata implements IUpgradeProvider
/*     */ {
/*     */   public static final int RED_COAL_MULTIPLIER = 8;
/*  39 */   public static TIntObjectHashMap<Type> metaMap = new TIntObjectHashMap();
/*     */   
/*     */   public ItemIngredients() {
/*  42 */     super(getTextureArray());
/*  43 */     setHasSubtypes(true);
/*     */   }
/*     */   
/*     */   public static String[] getTextureArray() {
/*  47 */     int maxMeta = 0;
/*  48 */     for (Type type : Type.values()) {
/*  49 */       maxMeta = Math.max(maxMeta, type.meta);
/*     */     }
/*     */     
/*  52 */     String[] strings = new String[maxMeta + 1];
/*  53 */     for (Type type : Type.values()) {
/*  54 */       if (type.meta >= 0)
/*  55 */         strings[type.meta] = type.texture;
/*     */     }
/*  57 */     return strings;
/*     */   }
/*     */   
/*     */   public void getSubItems(Item itemIn, CreativeTabs tab, List<ItemStack> subItems)
/*     */   {
/*  62 */     for (int i : metaMap.keys()) {
/*  63 */       if (i >= 0) subItems.add(new ItemStack(itemIn, 1, i));
/*     */     }
/*     */   }
/*     */   
/*     */   public Type getType(ItemStack stack) {
/*  68 */     Type type = (Type)metaMap.get(stack.getItemDamage());
/*  69 */     return type == null ? Type.SYMBOL_ERROR : type;
/*     */   }
/*     */   
/*     */   public String getUnlocalizedName(ItemStack stack)
/*     */   {
/*  74 */     return super.getUnlocalizedName(stack) + "." + getType(stack).name().toLowerCase();
/*     */   }
/*     */   
/*     */   public String getItemStackDisplayName(ItemStack stack)
/*     */   {
/*  79 */     return Lang.translate(getUnlocalizedNameInefficiently(stack) + ".name", getType(stack).defaultName());
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/*  85 */     getType(stack).addInformation(stack, playerIn, tooltip, advanced);
/*     */   }
/*     */   
/*     */   public Upgrade getUpgrades(ItemStack stack)
/*     */   {
/*  90 */     return getType(stack).getUpgrades(stack);
/*     */   }
/*     */   
/*     */   public static enum Type implements IItemStackMaker, IUpgradeProvider {
/*  94 */     SYMBOL_NOCRAFT(-2), 
/*  95 */     SYMBOL_ERROR(-1), 
/*  96 */     REDSTONE_CRYSTAL(0), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */     REDSTONE_GEAR(1), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     EYE_REDSTONE(2), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */     DYE_POWDER_LUNAR(3), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */     RED_COAL(4), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */     MOON_STONE(5), 
/*     */     
/* 203 */     UPGRADE_SPEED(6), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */     UPGRADE_STACK(7), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */     UPGRADE_MINING(8), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */     UPGRADE_BASE(9);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int meta;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String texture;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Type(int meta)
/*     */     {
/* 291 */       this.meta = meta;
/* 292 */       this.texture = name().toLowerCase();
/* 293 */       ItemIngredients.metaMap.put(meta, this);
/*     */     }
/*     */     
/*     */     public String defaultName() {
/* 297 */       StringBuilder builder = new StringBuilder();
/* 298 */       String[] split = name().split("_");
/* 299 */       for (int i = 0; i < split.length; i++) {
/* 300 */         if (i > 0) builder.append(" ");
/* 301 */         builder.append(StringHelper.capFirst(split[i], true));
/*     */       }
/* 303 */       return builder.toString();
/*     */     }
/*     */     
/*     */ 
/*     */     public void addRecipes() {}
/*     */     
/*     */     public ItemStack newStack(int amount)
/*     */     {
/* 311 */       return XU2Entries.itemIngredients.newStack(amount, this.meta);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     @SideOnly(Side.CLIENT)
/*     */     public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced) {}
/*     */     
/*     */ 
/*     */     public ItemStack newStack()
/*     */     {
/* 322 */       return newStack(1);
/*     */     }
/*     */     
/*     */ 
/*     */     public Upgrade getUpgrades(ItemStack stack)
/*     */     {
/* 328 */       return null;
/*     */     }
/*     */     
/*     */     public void addAchievement() {}
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemIngredients.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */