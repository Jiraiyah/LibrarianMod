/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ import net.minecraft.util.Vec3;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemAngelBlock extends com.rwtema.extrautils2.backend.XUItemBlock
/*    */ {
/*    */   public ItemAngelBlock(Block block)
/*    */   {
/* 14 */     super(block);
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer player)
/*    */   {
/* 19 */     if (worldIn.isRemote) { return itemStackIn;
/*    */     }
/* 21 */     int x = (int)Math.floor(player.posX);
/* 22 */     int y = (int)Math.floor(player.posY + player.getEyeHeight());
/* 23 */     int z = (int)Math.floor(player.posZ);
/*    */     
/* 25 */     Vec3 look = player.getLookVec();
/*    */     
/* 27 */     net.minecraft.util.EnumFacing side = net.minecraft.util.EnumFacing.getFacingFromVector((float)look.xCoord, (float)look.yCoord, (float)look.zCoord);
/*    */     
/* 29 */     switch (side)
/*    */     {
/*    */     case DOWN: 
/* 32 */       y = (int)(Math.floor(player.getEntityBoundingBox().minY) - 1.0D);
/* 33 */       break;
/*    */     case UP: 
/* 35 */       y = (int)(Math.ceil(player.getEntityBoundingBox().maxY) + 1.0D);
/* 36 */       break;
/*    */     case NORTH: 
/* 38 */       z = (int)(Math.floor(player.getEntityBoundingBox().minZ) - 1.0D);
/* 39 */       break;
/*    */     case SOUTH: 
/* 41 */       z = (int)(Math.floor(player.getEntityBoundingBox().maxZ) + 1.0D);
/* 42 */       break;
/*    */     case WEST: 
/* 44 */       x = (int)(Math.floor(player.getEntityBoundingBox().minX) - 1.0D);
/* 45 */       break;
/*    */     case EAST: 
/* 47 */       x = (int)(Math.floor(player.getEntityBoundingBox().maxX) + 1.0D);
/*    */     }
/*    */     
/*    */     
/* 51 */     net.minecraft.util.BlockPos pos = new net.minecraft.util.BlockPos(x, y, z);
/* 52 */     if (worldIn.canBlockBePlaced(this.block, pos, false, side, player, itemStackIn)) {
/* 53 */       itemStackIn.onItemUse(player, worldIn, pos, side, 0.0F, 0.0F, 0.0F);
/*    */     }
/*    */     
/* 56 */     return itemStackIn;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemAngelBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */