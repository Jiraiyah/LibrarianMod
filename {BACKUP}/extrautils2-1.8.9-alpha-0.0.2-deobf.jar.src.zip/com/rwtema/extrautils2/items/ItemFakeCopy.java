/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.IXUItem;
/*     */ import com.rwtema.extrautils2.backend.XUItem;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem.ModelLayer;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.renderer.ItemModelMesher;
/*     */ import net.minecraft.client.resources.model.IBakedModel;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.ContainerWorkbench;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.entity.player.ItemTooltipEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ItemFakeCopy extends XUItem
/*     */ {
/*     */   public ItemFakeCopy()
/*     */   {
/*  29 */     MinecraftForge.EVENT_BUS.register(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void registerTextures() {}
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public net.minecraft.client.renderer.texture.TextureAtlasSprite getBaseTexture()
/*     */   {
/*  40 */     return com.rwtema.extrautils2.backend.model.Textures.MISSING_SPRITE;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IBakedModel createModel(int metadata)
/*     */   {
/*  46 */     new PassthruModelItem(this)
/*     */     {
/*     */       public IBakedModel handleItemState(ItemStack stack) {
/*  49 */         return Minecraft.getMinecraft().getRenderItem().getItemModelMesher().getItemModel(ItemFakeCopy.this.getDuplicate(stack));
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addQuads(PassthruModelItem.ModelLayer model, ItemStack stack) {}
/*     */   
/*     */ 
/*     */   public int getMaxMetadata()
/*     */   {
/*  62 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean hasEffect(ItemStack stack)
/*     */   {
/*  67 */     return getDuplicate(stack).hasEffect();
/*     */   }
/*     */   
/*     */   public net.minecraft.item.EnumRarity getRarity(ItemStack stack)
/*     */   {
/*  72 */     return getDuplicate(stack).getRarity();
/*     */   }
/*     */   
/*     */   public ItemStack getDuplicate(ItemStack stack) {
/*  76 */     return new ItemStack(net.minecraft.init.Items.nether_star);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public String getItemStackDisplayName(ItemStack stack)
/*     */   {
/*  82 */     return getDuplicate(stack).getDisplayName();
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/*  88 */     super.addInformation(stack, playerIn, tooltip, advanced);
/*  89 */     ItemStack duplicate = getDuplicate(stack);
/*  90 */     tooltip.add(Lang.translateArgs("On close inspection, this %s", new Object[] { duplicate.getDisplayName() }));
/*  91 */     if (duplicate.hasEffect()) {
/*  92 */       tooltip.add(Lang.translate("is a fake made out of enchanted cardboard."));
/*     */     } else {
/*  94 */       tooltip.add(Lang.translate("is a fake made out of cardboard."));
/*     */     }
/*     */     
/*  97 */     tooltip.add(Lang.translate("Hope you got a receipt."));
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent(priority=net.minecraftforge.fml.common.eventhandler.EventPriority.LOWEST)
/*     */   public void changeToolTip(ItemTooltipEvent event)
/*     */   {
/* 104 */     if ((event.itemStack == null) || (event.itemStack.getItem() != this)) { return;
/*     */     }
/* 106 */     if (isInsideInventory(event.itemStack)) { return;
/*     */     }
/* 108 */     ItemStack duplicate = getDuplicate(event.itemStack);
/* 109 */     event.toolTip.clear();
/* 110 */     event.toolTip.addAll(duplicate.getTooltip(event.entityPlayer, event.showAdvancedItemTooltips));
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private boolean isInsideInventory(ItemStack itemStack) {
/* 115 */     EntityPlayerSP thePlayer = Minecraft.getMinecraft().thePlayer;
/* 116 */     if ((thePlayer.openContainer instanceof ContainerWorkbench)) {
/* 117 */       return true;
/*     */     }
/* 119 */     InventoryPlayer inv = thePlayer.inventory;
/* 120 */     for (int i = 0; i < inv.getSizeInventory(); i++) {
/* 121 */       if (inv.getStackInSlot(i) == itemStack) {
/* 122 */         return true;
/*     */       }
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   public void getSubItems(Item itemIn, CreativeTabs tab, List<ItemStack> subItems) {}
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemFakeCopy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */