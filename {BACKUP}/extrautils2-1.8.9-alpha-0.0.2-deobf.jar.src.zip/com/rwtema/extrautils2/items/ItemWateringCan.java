/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUItemFlat;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.MovingObjectPosition.MovingObjectType;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fluids.FluidRegistry;
/*     */ import net.minecraftforge.fluids.FluidStack;
/*     */ import net.minecraftforge.fluids.IFluidContainerItem;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ItemWateringCan extends XUItemFlat implements IFluidContainerItem
/*     */ {
/*     */   public ItemWateringCan()
/*     */   {
/*  38 */     setMaxDamage(1000);
/*  39 */     setMaxStackSize(1);
/*     */   }
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer playerIn, World worldIn, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*  44 */     return super.onItemUse(stack, playerIn, worldIn, pos, side, hitX, hitY, hitZ);
/*     */   }
/*     */   
/*     */   public void getSubItems(Item itemIn, CreativeTabs tab, List<ItemStack> subItems)
/*     */   {
/*  49 */     subItems.add(new ItemStack(itemIn, 1, 0));
/*  50 */     subItems.add(new ItemStack(itemIn, 1, getMaxDamage()));
/*     */   }
/*     */   
/*     */   public int getMaxItemUseDuration(ItemStack par1ItemStack)
/*     */   {
/*  55 */     return 72000;
/*     */   }
/*     */   
/*     */   public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn)
/*     */   {
/*  60 */     MovingObjectPosition movingobjectposition = getMovingObjectPositionFromPlayer(worldIn, playerIn, true);
/*     */     
/*  62 */     if ((movingobjectposition != null) && 
/*  63 */       (movingobjectposition.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK)) {
/*  64 */       BlockPos pos = movingobjectposition.getBlockPos();
/*     */       
/*  66 */       if (worldIn.getBlockState(pos).getBlock().getMaterial() == Material.water) {
/*  67 */         playerIn.func_71008_a(itemStackIn, getMaxItemUseDuration(itemStackIn));
/*  68 */         return itemStackIn;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  73 */     if ((itemStackIn.getItemDamage() == getMaxDamage(itemStackIn)) && (!playerIn.capabilities.isCreativeMode)) {
/*  74 */       return itemStackIn;
/*     */     }
/*  76 */     playerIn.func_71008_a(itemStackIn, getMaxItemUseDuration(itemStackIn));
/*  77 */     return itemStackIn;
/*     */   }
/*     */   
/*     */   public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged)
/*     */   {
/*  82 */     return (slotChanged) || (oldStack == null) || (newStack == null) || (oldStack.getItem() != this) || (newStack.getItem() != this);
/*     */   }
/*     */   
/*     */   public void onUsingTick(ItemStack stack, EntityPlayer player, int count)
/*     */   {
/*  87 */     int i = stack.getItemDamage();
/*  88 */     World worldObj = player.worldObj;
/*     */     
/*     */ 
/*     */ 
/*  92 */     MovingObjectPosition movingobjectposition = getMovingObjectPositionFromPlayer(worldObj, player, true);
/*  93 */     if (movingobjectposition == null) { return;
/*     */     }
/*  95 */     if (movingobjectposition.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
/*  96 */       BlockPos pos = movingobjectposition.getBlockPos();
/*     */       
/*  98 */       if (worldObj.getBlockState(pos).getBlock().getMaterial() == Material.water) {
/*  99 */         if ((!worldObj.isRemote) && (!player.capabilities.isCreativeMode)) {
/* 100 */           i -= 5;
/* 101 */           if (i < 0) i = 0;
/* 102 */           stack.setItemDamage(i - 1);
/*     */         }
/* 104 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 109 */     if (i == stack.getMaxDamage()) {
/* 110 */       player.func_71034_by();
/* 111 */       return;
/*     */     }
/*     */     
/* 114 */     waterLocation(worldObj, movingobjectposition.hitVec.xCoord, movingobjectposition.hitVec.yCoord, movingobjectposition.hitVec.zCoord, movingobjectposition.sideHit, stack, player, 1);
/*     */     
/* 116 */     if ((!player.capabilities.isCreativeMode) && 
/* 117 */       (i < stack.getMaxDamage())) {
/* 118 */       stack.setItemDamage(i + 1);
/*     */     }
/*     */   }
/*     */   
/*     */   private void waterLocation(World worldObj, double hitX, double hitY, double hitZ, EnumFacing side, ItemStack stack, EntityPlayer play, int range)
/*     */   {
/* 124 */     List enderman = worldObj.getEntitiesWithinAABB(EntityEnderman.class, new AxisAlignedBB(hitX - range, hitY - range, hitZ - range, hitX + range, hitY + 6.0D, hitZ + range));
/*     */     
/*     */ 
/* 127 */     if (enderman != null) {
/* 128 */       for (Object anEnderman : enderman) {
/* 129 */         ((EntityEnderman)anEnderman).attackEntityFrom(DamageSource.drown, 1.0F);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 134 */     boolean cheat = false;
/*     */     
/* 136 */     if (worldObj.isRemote) {
/* 137 */       double dx = side.getFrontOffsetX();double dy = side.getFrontOffsetY();double dz = side.getFrontOffsetZ();
/* 138 */       double x2 = hitX + dx * 0.1D;double y2 = hitY + dy * 0.1D;double z2 = hitZ + dz * 0.1D;
/*     */       
/* 140 */       for (int i = 0; i < 4 * range; i++) {
/* 141 */         worldObj.spawnParticle(EnumParticleTypes.WATER_SPLASH, x2 + worldObj.rand.nextGaussian() * 0.6D * range, y2, z2 + worldObj.rand.nextGaussian() * 0.6D * range, 0.0D, 0.0D, 0.0D, new int[0]);
/*     */       }
/*     */     } else {
/* 144 */       List ents = worldObj.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(hitX - range, hitY - range, hitZ - range, hitX + range, hitY + range + 6.0D, hitZ + range));
/*     */       
/*     */ 
/* 147 */       if (ents != null) {
/* 148 */         for (Object ent : ents) {
/* 149 */           if (((Entity)ent).isBurning()) {
/* 150 */             float p = 0.01F;
/*     */             
/* 152 */             if ((ent instanceof EntityPlayer)) {
/* 153 */               p = 0.333F;
/*     */             }
/*     */             
/* 156 */             ((Entity)ent).extinguish();
/*     */             
/* 158 */             if (worldObj.rand.nextDouble() < p) {
/* 159 */               if (stack.getItemDamage() < 3)
/* 160 */                 stack.setItemDamage(1);
/* 161 */               if (play != null)
/* 162 */                 play.func_71034_by();
/* 163 */               return;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 169 */       int blockX = (int)Math.floor(hitX);
/* 170 */       int blockY = (int)Math.floor(hitY);
/* 171 */       int blockZ = (int)Math.floor(hitZ);
/*     */       
/* 173 */       for (int x = blockX - range; x <= blockX + range; x++) {
/* 174 */         for (int y = blockY - range; y <= blockY + range; y++) {
/* 175 */           for (int z = blockZ - range; z <= blockZ + range; z++) {
/* 176 */             BlockPos pos = new BlockPos(x, y, z);
/* 177 */             Block id = worldObj.getBlockState(pos).getBlock();
/*     */             
/* 179 */             if (!worldObj.isAirBlock(pos)) {
/* 180 */               if (id == Blocks.fire) {
/* 181 */                 worldObj.setBlockToAir(pos);
/*     */               }
/*     */               
/* 184 */               if (id == Blocks.farmland) {
/* 185 */                 worldObj.setBlockState(pos, id.getDefaultState().withProperty(net.minecraft.block.BlockFarmland.MOISTURE, Integer.valueOf(7)), 2);
/*     */               }
/*     */               
/* 188 */               int timer = -1;
/*     */               
/* 190 */               if (id == Blocks.grass) {
/* 191 */                 timer = 20;
/*     */                 
/* 193 */                 if ((cheat) || (worldObj.rand.nextInt(4500) != 0) || 
/* 194 */                   (!worldObj.isAirBlock(pos.up()))) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               }
/* 208 */               else if (id == Blocks.mycelium) {
/* 209 */                 timer = 20;
/* 210 */               } else if (id == Blocks.wheat) {
/* 211 */                 timer = 40;
/* 212 */               } else if ((id instanceof net.minecraft.block.BlockSapling)) {
/* 213 */                 timer = 50;
/* 214 */               } else if (((id instanceof net.minecraftforge.common.IPlantable)) || ((id instanceof net.minecraft.block.IGrowable))) {
/* 215 */                 timer = 40;
/* 216 */               } else if (id.getMaterial() == Material.grass) {
/* 217 */                 timer = 20;
/*     */               }
/*     */               
/* 220 */               if (stack.getItemDamage() == 2) {
/* 221 */                 timer *= 20;
/*     */               }
/*     */               
/* 224 */               timer /= range;
/*     */               
/* 226 */               if ((timer > 0) && 
/* 227 */                 (id.getTickRandomly())) {
/* 228 */                 worldObj.scheduleUpdate(pos, id, worldObj.rand.nextInt(timer));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EnumAction getItemUseAction(ItemStack stack)
/*     */   {
/* 253 */     return EnumAction.NONE;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/* 259 */     com.rwtema.extrautils2.backend.model.Textures.register(new String[] { "watering_can" });
/*     */   }
/*     */   
/*     */   public int getMaxMetadata()
/*     */   {
/* 264 */     return 0;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public String getTexture(@Nullable ItemStack itemStack, int renderPass)
/*     */   {
/* 270 */     return "watering_can";
/*     */   }
/*     */   
/*     */   public FluidStack getFluid(ItemStack container)
/*     */   {
/* 275 */     int amount = getMaxDamage(container) - container.getItemDamage();
/* 276 */     return new FluidStack(FluidRegistry.WATER, amount);
/*     */   }
/*     */   
/*     */   public int getCapacity(ItemStack container)
/*     */   {
/* 281 */     return getMaxDamage(container);
/*     */   }
/*     */   
/*     */   public int fill(ItemStack container, FluidStack resource, boolean doFill)
/*     */   {
/* 286 */     if ((resource == null) || (resource.getFluid() != FluidRegistry.WATER) || (resource.amount <= 0)) {
/* 287 */       return 0;
/*     */     }
/* 289 */     if (container.getItemDamage() <= resource.amount) {
/* 290 */       if (doFill) {
/* 291 */         container.setItemDamage(container.getItemDamage() - resource.amount);
/*     */       }
/* 293 */       return resource.amount;
/*     */     }
/* 295 */     int m = container.getItemDamage();
/* 296 */     if (doFill) {
/* 297 */       container.setItemDamage(0);
/*     */     }
/* 299 */     return m;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FluidStack drain(ItemStack container, int maxDrain, boolean doDrain)
/*     */   {
/* 306 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemWateringCan.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */