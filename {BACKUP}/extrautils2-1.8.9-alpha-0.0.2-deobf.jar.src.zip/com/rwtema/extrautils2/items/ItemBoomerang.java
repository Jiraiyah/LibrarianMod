/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUItemFlat;
/*    */ import com.rwtema.extrautils2.entity.EntityBoomerang;
/*    */ import java.lang.ref.WeakReference;
/*    */ import java.util.WeakHashMap;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.entity.player.PlayerCapabilities;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class ItemBoomerang extends XUItemFlat
/*    */ {
/*    */   public static final String TEXTURE_NAME = "boomerang";
/*    */   public static final String TEXTURE_NAME_EMPTY = "boomerang_missing";
/*    */   
/*    */   public ItemBoomerang()
/*    */   {
/* 24 */     setMaxStackSize(1);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void registerTextures()
/*    */   {
/* 30 */     com.rwtema.extrautils2.backend.model.Textures.register(new String[] { "boomerang", "boomerang_missing" });
/*    */   }
/*    */   
/*    */   public int getMaxMetadata()
/*    */   {
/* 35 */     return 0;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public String getTexture(@javax.annotation.Nullable ItemStack itemStack, int renderPass)
/*    */   {
/* 41 */     if (!canThrowBoomerang(Minecraft.getMinecraft().thePlayer, EntityBoomerang.boomerangOwnersClient)) {
/* 42 */       InventoryPlayer inventory = Minecraft.getMinecraft().thePlayer.inventory;
/* 43 */       if (inventory.getItemStack() == itemStack) {
/* 44 */         return "boomerang_missing";
/*    */       }
/* 46 */       for (int i = 0; i < inventory.getSizeInventory(); i++) {
/* 47 */         if (inventory.getStackInSlot(i) == itemStack) {
/* 48 */           return "boomerang_missing";
/*    */         }
/*    */       }
/*    */     }
/* 52 */     return "boomerang";
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn)
/*    */   {
/* 57 */     if (!worldIn.isRemote) {
/* 58 */       if (!canThrowBoomerang(playerIn, EntityBoomerang.boomerangOwners)) { return itemStackIn;
/*    */       }
/* 60 */       EntityBoomerang boomerang = new EntityBoomerang(worldIn, playerIn);
/* 61 */       worldIn.spawnEntityInWorld(boomerang);
/*    */     }
/* 63 */     return itemStackIn;
/*    */   }
/*    */   
/*    */   public boolean canThrowBoomerang(EntityPlayer playerIn, WeakHashMap<Object, WeakReference<EntityBoomerang>> boomerangOwners) {
/* 67 */     if ((playerIn != null) && (!playerIn.capabilities.isCreativeMode)) {
/* 68 */       WeakReference<EntityBoomerang> reference = (WeakReference)boomerangOwners.get(playerIn);
/* 69 */       if (reference != null) {
/* 70 */         EntityBoomerang boomerang = (EntityBoomerang)reference.get();
/* 71 */         if ((boomerang != null) && (!boomerang.isDead)) return false;
/*    */       }
/*    */     }
/* 74 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemBoomerang.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */