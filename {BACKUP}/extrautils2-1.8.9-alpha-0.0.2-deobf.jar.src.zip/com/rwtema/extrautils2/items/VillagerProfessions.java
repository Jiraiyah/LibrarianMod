/*    */ package com.rwtema.extrautils2.items;
/*    */ 
/*    */  enum VillagerProfessions {
/*  4 */   farmer(0, 1), 
/*  5 */   fisherman(0, 2), 
/*  6 */   shepherd(0, 3), 
/*  7 */   fletcher(0, 4), 
/*  8 */   librarian(1, 0), 
/*  9 */   cleric(2, 0), 
/* 10 */   armor(3, 1), 
/* 11 */   weapon(3, 2), 
/* 12 */   tool(3, 3), 
/* 13 */   butcher(4, 1), 
/* 14 */   leather(4, 2);
/*    */   
/*    */   final int profession;
/*    */   final int career;
/*    */   
/*    */   private VillagerProfessions(int profession, int career) {
/* 20 */     this.profession = profession;
/* 21 */     this.career = career;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\VillagerProfessions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */