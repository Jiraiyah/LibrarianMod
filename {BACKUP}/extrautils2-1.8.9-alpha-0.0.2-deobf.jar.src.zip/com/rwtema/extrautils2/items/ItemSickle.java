/*     */ package com.rwtema.extrautils2.items;
/*     */ 
/*     */ import com.google.common.base.Throwables;
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem.ModelLayer;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.datastructures.ThreadLocalBoolean;
/*     */ import com.rwtema.extrautils2.utils.helpers.StringHelper;
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.Item.ToolMaterial;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemTool;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.BlockPos.MutableBlockPos;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.IPlantable;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ItemSickle extends ItemTool implements com.rwtema.extrautils2.backend.IXUItem
/*     */ {
/*  32 */   public static final String[] TYPE_NAMES = { "sickle_wood", "sickle_stone", "sickle_iron", "sickle_gold", "sickle_diamond" };
/*  33 */   private static final Set<Block> EFFECTIVE_ON = com.google.common.collect.Sets.newHashSet(new Block[] { Blocks.tallgrass, Blocks.leaves, Blocks.leaves2 });
/*  34 */   public static Item.ToolMaterial[] VANILLA_MATERIALS = { Item.ToolMaterial.WOOD, Item.ToolMaterial.STONE, Item.ToolMaterial.IRON, Item.ToolMaterial.GOLD, Item.ToolMaterial.EMERALD };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  41 */   static ThreadLocal<Boolean> calling = new ThreadLocalBoolean(false);
/*     */   private final String name;
/*  43 */   public HashMap<Item.ToolMaterial, Integer> toolRanges = (HashMap)com.rwtema.extrautils2.utils.helpers.CollectionHelper.populateMap(new HashMap(), new Object[] { Item.ToolMaterial.WOOD, Integer.valueOf(1), Item.ToolMaterial.STONE, Integer.valueOf(2), Item.ToolMaterial.IRON, Integer.valueOf(3), Item.ToolMaterial.GOLD, Integer.valueOf(1), Item.ToolMaterial.EMERALD, Integer.valueOf(4) });
/*     */   
/*     */ 
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   TextureAtlasSprite sprite;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemSickle(int i)
/*     */   {
/*  55 */     super(3.0F, VANILLA_MATERIALS[i], EFFECTIVE_ON);
/*  56 */     this.name = TYPE_NAMES[i];
/*  57 */     setUnlocalizedName("ExtraUtils2:" + StringHelper.capFirst(this.name, false));
/*  58 */     setCreativeTab(ExtraUtils2.creativeTabExtraUtils);
/*  59 */     setMaxDamage(this.toolMaterial.getMaxUses() * 9);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/*  65 */     Textures.register(new String[] { "tools/" + this.name });
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public net.minecraft.client.resources.model.IBakedModel createModel(int metadata)
/*     */   {
/*  72 */     return new PassthruModelItem(this);
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public TextureAtlasSprite getBaseTexture()
/*     */   {
/*  79 */     return this.sprite;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addQuads(PassthruModelItem.ModelLayer model, ItemStack stack)
/*     */   {
/*  85 */     model.addSprite(this.sprite);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void postTextureRegister()
/*     */   {
/*  91 */     this.sprite = ((TextureAtlasSprite)Textures.sprites.get("tools/" + this.name));
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean renderAsTool()
/*     */   {
/*  97 */     return true;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void clearCaches()
/*     */   {
/* 103 */     this.sprite = null;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean allowOverride()
/*     */   {
/* 109 */     return true;
/*     */   }
/*     */   
/*     */   public String getItemStackDisplayName(ItemStack stack)
/*     */   {
/* 114 */     return Lang.translate(getUnlocalizedNameInefficiently(stack) + ".name", StringHelper.sepWords(((ResourceLocation)Item.itemRegistry.getNameForObject(this)).getResourcePath().replace("Item", "")));
/*     */   }
/*     */   
/*     */   public boolean canHarvestBlock(Block blockIn)
/*     */   {
/* 119 */     return ((blockIn instanceof IPlantable)) || ((blockIn instanceof net.minecraftforge.common.IShearable));
/*     */   }
/*     */   
/*     */   public float getStrVsBlock(ItemStack stack, Block block)
/*     */   {
/* 124 */     return (block instanceof IPlantable) ? this.efficiencyOnProperMaterial : super.getStrVsBlock(stack, block);
/*     */   }
/*     */   
/*     */   public boolean onBlockStartBreak(ItemStack itemstack, BlockPos pos, EntityPlayer player)
/*     */   {
/* 129 */     if (((Boolean)calling.get()).booleanValue()) return false;
/* 130 */     World worldObj = player.worldObj;
/*     */     
/* 132 */     Block block = worldObj.getBlockState(pos).getBlock();
/* 133 */     if ((worldObj.isRemote) || (!canHarvestBlock(block))) { return false;
/*     */     }
/* 135 */     Item.ToolMaterial toolMaterial = ((ItemSickle)itemstack.getItem()).getToolMaterial();
/* 136 */     if (!this.toolRanges.containsKey(toolMaterial)) { return false;
/*     */     }
/* 138 */     int range = ((Integer)this.toolRanges.get(toolMaterial)).intValue();
/*     */     
/*     */     try
/*     */     {
/* 142 */       calling.set(Boolean.valueOf(true));
/* 143 */       for (BlockPos.MutableBlockPos blockPos : BlockPos.getAllInBoxMutable(pos.add(-range, -range, -range), pos.add(range, range, range))) {
/* 144 */         IBlockState blockState = worldObj.getBlockState(blockPos);
/* 145 */         if (block == blockState.getBlock()) {
/* 146 */           ExtraUtils2.proxy.onBlockStartBreak(worldObj, itemstack, blockPos, player, true);
/*     */         }
/*     */       }
/*     */       
/* 150 */       calling.set(Boolean.valueOf(false));
/*     */     } catch (Throwable throwable) {
/* 152 */       calling.set(Boolean.valueOf(false));
/* 153 */       throw Throwables.propagate(throwable);
/*     */     }
/*     */     
/* 156 */     return true;
/*     */   }
/*     */   
/*     */   public int getMaxMetadata()
/*     */   {
/* 161 */     return 0;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\items\ItemSickle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */