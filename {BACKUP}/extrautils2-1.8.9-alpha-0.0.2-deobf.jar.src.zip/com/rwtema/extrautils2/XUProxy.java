/*     */ package com.rwtema.extrautils2;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.ClientCallable;
/*     */ import com.rwtema.extrautils2.backend.ISidedFunction;
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.model.IClientClearCache;
/*     */ import com.rwtema.extrautils2.eventhandlers.RevengeHandler;
/*     */ import com.rwtema.extrautils2.eventhandlers.SlimeSpawnHandler;
/*     */ import com.rwtema.extrautils2.keyhandler.KeyAlt;
/*     */ import com.rwtema.extrautils2.network.PacketHandler;
/*     */ import com.rwtema.extrautils2.tile.XUTile;
/*     */ import com.rwtema.extrautils2.utils.LogHelper;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.network.NetHandlerPlayClient;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.INetHandler;
/*     */ import net.minecraft.network.NetHandlerPlayServer;
/*     */ import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
/*     */ import net.minecraft.server.management.ItemInWorldManager;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class XUProxy
/*     */ {
/*  31 */   public static final ClientCallable sendRightClick = new ClientCallable()
/*     */   {
/*     */     @SideOnly(Side.CLIENT)
/*     */     public void runClient() {
/*  35 */       EntityPlayerSP thePlayer = Minecraft.getMinecraft().thePlayer;
/*  36 */       thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(thePlayer.func_70694_bm()));
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */   public void run(ClientCallable callable) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void clearClientCache(IClientClearCache box) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void registerTexture(String... texture) {}
/*     */   
/*     */ 
/*     */   public boolean isClientSide()
/*     */   {
/*  55 */     return false;
/*     */   }
/*     */   
/*     */   public EntityPlayer getPlayerFromNetHandler(INetHandler handler) {
/*  59 */     if ((handler instanceof NetHandlerPlayServer)) {
/*  60 */       return ((NetHandlerPlayServer)handler).playerEntity;
/*     */     }
/*  62 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public EntityPlayer getClientPlayer()
/*     */   {
/*  68 */     throw new RuntimeException("getClientPlayer called on server");
/*     */   }
/*     */   
/*     */   public World getClientWorld() {
/*  72 */     throw new RuntimeException("getClientWorld called on server");
/*     */   }
/*     */   
/*     */   public PacketHandler getNewPacketHandler()
/*     */   {
/*  77 */     LogHelper.oneTimeInfo("CreatePacketHandler Server");
/*  78 */     return new PacketHandler();
/*     */   }
/*     */   
/*     */   public boolean isAltSneaking(EntityPlayer player) {
/*  82 */     return KeyAlt.isAltSneaking(player);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void sendUsePacket(ItemStack stack, EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ) {}
/*     */   
/*     */ 
/*     */   public void registerBlock(XUBlock xuBlock) {}
/*     */   
/*     */ 
/*     */   public void registerClientCommand() {}
/*     */   
/*     */ 
/*     */   public void registerHandlers()
/*     */   {
/*  98 */     SlimeSpawnHandler.init();
/*  99 */     RevengeHandler.init();
/*     */   }
/*     */   
/*     */   public <F, T> T apply(ISidedFunction<F, T> func, F input)
/*     */   {
/* 104 */     return (T)func.applyServer(input);
/*     */   }
/*     */   
/*     */   public boolean onBlockStartBreak(World world, ItemStack itemstack, BlockPos pos, EntityPlayer player, boolean reduceParticles) {
/* 108 */     if (world.isRemote) throw new IllegalStateException("Client World on Server");
/* 109 */     ItemInWorldManager theItemInWorldManager = ((EntityPlayerMP)player).interactionManager;
/* 110 */     world.func_175689_h(pos);
/* 111 */     return theItemInWorldManager.tryHarvestBlock(pos);
/*     */   }
/*     */   
/*     */   public <T> T nullifyOnServer(T object) {
/* 115 */     return null;
/*     */   }
/*     */   
/*     */   public void registerTESR(Class<? extends XUTile> clazz) {}
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\XUProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */