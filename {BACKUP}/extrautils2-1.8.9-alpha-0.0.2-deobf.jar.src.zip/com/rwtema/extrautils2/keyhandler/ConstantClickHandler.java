/*    */ package com.rwtema.extrautils2.keyhandler;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.client.multiplayer.PlayerControllerMP;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.MovingObjectPosition;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
/*    */ 
/*    */ public class ConstantClickHandler
/*    */ {
/*    */   static BlockPos dest;
/*    */   static net.minecraft.block.state.IBlockState state;
/*    */   static boolean rightClickReleased;
/*    */   
/*    */   static
/*    */   {
/* 21 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new ConstantClickHandler());
/*    */   }
/*    */   
/*    */   public static void setPlayerRightClicking(World world, BlockPos pos) {
/* 25 */     if (!world.isRemote) return;
/* 26 */     state = world.getBlockState(pos);
/* 27 */     dest = pos;
/* 28 */     rightClickReleased = false;
/*    */   }
/*    */   
/*    */   @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
/*    */   @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void constantRightClick(TickEvent.ClientTickEvent event) {
/* 34 */     if ((dest == null) || (state == null)) return;
/* 35 */     if (event.phase != net.minecraftforge.fml.common.gameevent.TickEvent.Phase.START) {
/* 36 */       return;
/*    */     }
/* 38 */     Minecraft mc = Minecraft.getMinecraft();
/* 39 */     if ((mc.theWorld == null) || (mc.thePlayer == null) || (mc.thePlayer.isSneaking()) || (mc.thePlayer.func_71039_bw()) || (mc.gameSettings.keyBindAttack.isKeyDown()) || (mc.gameSettings.keyBindPickBlock.isKeyDown()) || (mc.playerController.getIsHittingBlock()) || (mc.objectMouseOver == null) || (mc.objectMouseOver.typeOfHit != net.minecraft.util.MovingObjectPosition.MovingObjectType.BLOCK) || (!dest.equals(mc.objectMouseOver.getBlockPos())) || (mc.theWorld.getBlockState(dest) != state))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 51 */       dest = null;
/* 52 */       state = null;
/* 53 */       return;
/*    */     }
/*    */     
/* 56 */     if (mc.rightClickDelayTimer > 1) {
/* 57 */       return;
/*    */     }
/* 59 */     mc.rightClickDelayTimer = 5;
/*    */     
/* 61 */     ItemStack itemstack = mc.thePlayer.inventory.getCurrentItem();
/*    */     
/* 63 */     BlockPos blockpos = mc.objectMouseOver.getBlockPos();
/*    */     
/* 65 */     if (mc.theWorld.isAirBlock(blockpos)) { return;
/*    */     }
/* 67 */     int i = itemstack != null ? itemstack.stackSize : 0;
/*    */     
/* 69 */     boolean result = !net.minecraftforge.event.ForgeEventFactory.onPlayerInteract(mc.thePlayer, net.minecraftforge.event.entity.player.PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK, mc.theWorld, blockpos, mc.objectMouseOver.sideHit, mc.objectMouseOver.hitVec).isCanceled();
/* 70 */     if ((result) && 
/* 71 */       (mc.playerController.func_178890_a(mc.thePlayer, mc.theWorld, itemstack, blockpos, mc.objectMouseOver.sideHit, mc.objectMouseOver.hitVec))) {
/* 72 */       mc.thePlayer.func_71038_i();
/*    */     }
/*    */     
/*    */ 
/* 76 */     if (itemstack == null) {
/* 77 */       return;
/*    */     }
/*    */     
/* 80 */     if (itemstack.stackSize == 0) {
/* 81 */       mc.thePlayer.inventory.mainInventory[mc.thePlayer.inventory.currentItem] = null;
/* 82 */     } else if ((itemstack.stackSize != i) || (mc.playerController.isInCreativeMode())) {
/* 83 */       mc.entityRenderer.itemRenderer.func_78444_b();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\keyhandler\ConstantClickHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */