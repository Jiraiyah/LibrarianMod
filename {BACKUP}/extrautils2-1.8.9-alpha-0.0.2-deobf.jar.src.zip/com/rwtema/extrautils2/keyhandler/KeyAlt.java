/*    */ package com.rwtema.extrautils2.keyhandler;
/*    */ 
/*    */ import com.rwtema.extrautils2.network.NetworkHandler;
/*    */ import com.rwtema.extrautils2.network.packets.PacketUseItemAlt;
/*    */ import java.util.Map;
/*    */ import java.util.WeakHashMap;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class KeyAlt
/*    */ {
/* 19 */   private static Map<EntityPlayer, Boolean> keyMap = java.util.Collections.synchronizedMap(new WeakHashMap());
/*    */   
/*    */   static {
/* 22 */     MinecraftForge.EVENT_BUS.register(new KeyAlt());
/* 23 */     com.rwtema.extrautils2.utils.LogHelper.oneTimeInfo("Key Alt Register");
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   @SubscribeEvent
/*    */   public void onPress(TickEvent.ClientTickEvent event) {
/* 29 */     Minecraft mc = Minecraft.getMinecraft();
/* 30 */     Boolean isKeyPressed = Boolean.valueOf(KeyHandler.getIsKeyPressed(mc.gameSettings.keyBindSprint));
/* 31 */     if (keyMap.get(mc.thePlayer) != isKeyPressed) {
/* 32 */       keyMap.put(mc.thePlayer, isKeyPressed);
/* 33 */       NetworkHandler.sendPacketToServer(new PacketUseItemAlt(isKeyPressed.booleanValue()));
/*    */     }
/*    */   }
/*    */   
/*    */   public static boolean isAltSneaking(EntityPlayer player) {
/* 38 */     return keyMap.get(player) == Boolean.TRUE;
/*    */   }
/*    */   
/*    */   public static void setValue(EntityPlayer player, boolean sprint) {
/* 42 */     keyMap.put(player, Boolean.valueOf(sprint));
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\keyhandler\KeyAlt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */