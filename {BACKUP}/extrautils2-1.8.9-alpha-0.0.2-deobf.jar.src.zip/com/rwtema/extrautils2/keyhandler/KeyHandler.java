/*    */ package com.rwtema.extrautils2.keyhandler;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ 
/*    */ public class KeyHandler
/*    */ {
/*    */   private static net.minecraft.util.IntHashMap hash;
/*    */   
/*    */   static
/*    */   {
/* 12 */     for (Field field : KeyBinding.class.getDeclaredFields())
/* 13 */       if (field.getType() == net.minecraft.util.IntHashMap.class) {
/* 14 */         field.setAccessible(true);
/*    */         try {
/* 16 */           hash = (net.minecraft.util.IntHashMap)field.get(null);
/*    */         } catch (IllegalAccessException e) {
/* 18 */           throw com.google.common.base.Throwables.propagate(e);
/*    */         }
/*    */       }
/*    */   }
/*    */   
/*    */   public void register() {}
/*    */   
/* 25 */   public static boolean getIsKeyPressed(KeyBinding key) { KeyBinding lookup = (KeyBinding)hash.lookup(key.getKeyCode());
/* 26 */     return (lookup != null) && (lookup.isKeyDown());
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\keyhandler\KeyHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */