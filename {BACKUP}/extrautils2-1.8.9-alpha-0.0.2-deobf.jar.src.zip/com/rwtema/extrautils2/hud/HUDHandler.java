/*    */ package com.rwtema.extrautils2.hud;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraftforge.client.GuiIngameForge;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ 
/*    */ public class HUDHandler
/*    */ {
/* 12 */   static ArrayList<IHudHandler> handlers = new ArrayList();
/*    */   
/*    */   public static void init() {
/* 15 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new HUDHandler());
/*    */   }
/*    */   
/*    */   public static void register(IHudHandler handler) {
/* 19 */     handlers.add(handler);
/*    */   }
/*    */   
/*    */   @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
/*    */   public void hudDraw(RenderGameOverlayEvent.Post event) {
/* 24 */     if (event.type != net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType.ALL) return;
/* 25 */     GuiIngameForge currentScreen = (GuiIngameForge)Minecraft.getMinecraft().ingameGUI;
/* 26 */     for (IHudHandler handler : handlers) {
/* 27 */       handler.render(currentScreen, event.resolution, event.partialTicks);
/*    */     }
/*    */   }
/*    */   
/*    */   public static abstract interface IHudHandler
/*    */   {
/*    */     public abstract void render(GuiIngameForge paramGuiIngameForge, ScaledResolution paramScaledResolution, float paramFloat);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\hud\HUDHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */