/*     */ package com.rwtema.extrautils2.itemhandler;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ 
/*     */ public class InventoryHelper
/*     */ {
/*  13 */   private static final Random RANDOM = new Random();
/*     */   
/*     */   public static void dropAll(World world, BlockPos pos, IItemHandler handler) {
/*  16 */     dropAll(world, pos.getX(), pos.getY(), pos.getZ(), handler);
/*     */   }
/*     */   
/*     */   public static void dropAll(World world, int x, int y, int z, IItemHandler handler) {
/*  20 */     for (int i = 0; i < handler.getSlots(); i++) {
/*  21 */       ItemStack stack = handler.getStackInSlot(i);
/*  22 */       if (stack != null)
/*  23 */         dropItemStack(world, x, y, z, stack);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void dropItemStack(World worldIn, double x, double y, double z, ItemStack stack) {
/*  28 */     float dx = RANDOM.nextFloat() * 0.8F + 0.1F;
/*  29 */     float dy = RANDOM.nextFloat() * 0.8F + 0.1F;
/*  30 */     float dz = RANDOM.nextFloat() * 0.8F + 0.1F;
/*     */     
/*  32 */     while (stack.stackSize > 0) {
/*  33 */       int i = RANDOM.nextInt(21) + 10;
/*     */       
/*  35 */       if (i > stack.stackSize) {
/*  36 */         i = stack.stackSize;
/*     */       }
/*     */       
/*  39 */       stack.stackSize -= i;
/*  40 */       EntityItem entityitem = new EntityItem(worldIn, x + dx, y + dy, z + dz, new ItemStack(stack.getItem(), i, stack.getMetadata()));
/*     */       
/*  42 */       if (stack.hasTagCompound()) {
/*  43 */         entityitem.getEntityItem().setTagCompound((NBTTagCompound)stack.getTagCompound().copy());
/*     */       }
/*     */       
/*  46 */       entityitem.motionX = (RANDOM.nextGaussian() * 0.05D);
/*  47 */       entityitem.motionY = (RANDOM.nextGaussian() * 0.05D + 0.2D);
/*  48 */       entityitem.motionZ = (RANDOM.nextGaussian() * 0.05D);
/*  49 */       worldIn.spawnEntityInWorld(entityitem);
/*     */     }
/*     */   }
/*     */   
/*     */   public static int transfer(IItemHandler src, int srcSlot, IItemHandler dest, int maxAmount, boolean allSlots)
/*     */   {
/*  55 */     int sent = 0;
/*  56 */     maxAmount = getStackLimit(src.extractItem(srcSlot, maxAmount, true));
/*     */     
/*  58 */     if (maxAmount == 0) { return sent;
/*     */     }
/*  60 */     int firstEmptySlot = -1;
/*     */     
/*  62 */     for (int i = 0; i < dest.getSlots(); i++) {
/*  63 */       if (dest.getStackInSlot(i) != null) {
/*  64 */         sent += transferSlotAtoSlotB(src, srcSlot, dest, i, maxAmount - sent);
/*  65 */         if (((sent > 0) && (allSlots)) || (sent >= maxAmount)) {
/*  66 */           return sent;
/*     */         }
/*  68 */       } else if (firstEmptySlot == -1) { firstEmptySlot = i;
/*     */       }
/*     */     }
/*  71 */     if (firstEmptySlot == -1) { return sent;
/*     */     }
/*  73 */     for (int i = firstEmptySlot; i < dest.getSlots(); i++) {
/*  74 */       if (dest.getStackInSlot(i) == null) {
/*  75 */         sent += transferSlotAtoSlotB(src, srcSlot, dest, i, maxAmount - sent);
/*  76 */         if (((sent > 0) && (allSlots)) || (sent >= maxAmount)) {
/*  77 */           return sent;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  82 */     return sent;
/*     */   }
/*     */   
/*     */   public static int getStackLimit(ItemStack stack) {
/*  86 */     return stack != null ? stack.stackSize : 0;
/*     */   }
/*     */   
/*     */   public static int transferSlotAtoSlotB(IItemHandler handlerA, int slotA, IItemHandler handlerB, int slotB, int maxAmount) {
/*  90 */     ItemStack initExtract = handlerA.extractItem(slotA, maxAmount, true);
/*  91 */     if (initExtract == null) return 0;
/*  92 */     ItemStack initRemainder = handlerB.insertItem(slotB, initExtract, true);
/*  93 */     int i = initExtract.stackSize - getStackLimit(initRemainder);
/*  94 */     if (i == 0) return 0;
/*  95 */     ItemStack actualExtract = handlerA.extractItem(slotA, i, false);
/*  96 */     handlerB.insertItem(slotB, actualExtract, false);
/*  97 */     return i;
/*     */   }
/*     */   
/*     */   public static ItemStack insert(IItemHandler handler, ItemStack insert, boolean simulate) {
/* 101 */     int firstEmptySlot = -1;
/* 102 */     for (int i = 0; i < handler.getSlots(); i++) {
/* 103 */       ItemStack stackInSlot = handler.getStackInSlot(i);
/* 104 */       if (stackInSlot != null) {
/* 105 */         if (net.minecraftforge.items.ItemHandlerHelper.canItemStacksStack(stackInSlot, insert)) {
/* 106 */           insert = handler.insertItem(i, insert, simulate);
/* 107 */           if (insert == null) return null;
/*     */         }
/* 109 */       } else if (firstEmptySlot == -1) {
/* 110 */         firstEmptySlot = i;
/*     */       }
/*     */     }
/* 113 */     if (firstEmptySlot == -1) { return insert;
/*     */     }
/* 115 */     for (int i = firstEmptySlot; i < handler.getSlots(); i++) {
/* 116 */       ItemStack stackInSlot = handler.getStackInSlot(i);
/* 117 */       if (stackInSlot == null) {
/* 118 */         insert = handler.insertItem(i, insert, simulate);
/* 119 */         if (insert == null) return null;
/*     */       }
/*     */     }
/* 122 */     return insert;
/*     */   }
/*     */   
/*     */   public static int getMaxInsert(IItemHandler handler, ItemStack insert) {
/* 126 */     if (insert == null) return 0;
/* 127 */     int adding = insert.stackSize;
/* 128 */     for (int i = 0; i < handler.getSlots(); i++) {
/* 129 */       insert = handler.insertItem(i, insert, true);
/* 130 */       if (insert == null) { return adding;
/*     */       }
/*     */     }
/* 133 */     return adding - insert.stackSize;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\InventoryHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */