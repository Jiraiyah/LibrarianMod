/*    */ package com.rwtema.extrautils2.itemhandler;
/*    */ 
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ import net.minecraftforge.items.IItemHandlerModifiable;
/*    */ import net.minecraftforge.items.ItemHandlerHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ItemStackHandlerBase
/*    */   implements IItemHandler, IItemHandlerModifiable
/*    */ {
/*    */   public abstract ItemStack getStack(int paramInt);
/*    */   
/*    */   public abstract void setStack(int paramInt, ItemStack paramItemStack);
/*    */   
/*    */   public void setStackInSlot(int slot, ItemStack stack)
/*    */   {
/* 19 */     if (ItemStack.areItemStacksEqual(getStack(slot), stack))
/* 20 */       return;
/* 21 */     setStack(slot, stack);
/* 22 */     onContentsChanged(slot);
/*    */   }
/*    */   
/*    */   public ItemStack getStackInSlot(int slot)
/*    */   {
/* 27 */     return getStack(slot);
/*    */   }
/*    */   
/*    */   public ItemStack insertItem(int slot, ItemStack stack, boolean simulate)
/*    */   {
/* 32 */     if ((stack == null) || (stack.stackSize == 0)) {
/* 33 */       return null;
/*    */     }
/* 35 */     ItemStack existing = getStack(slot);
/*    */     
/* 37 */     int limit = getStackLimit(slot, stack);
/*    */     
/* 39 */     if (existing != null) {
/* 40 */       if (!ItemHandlerHelper.canItemStacksStack(stack, existing)) {
/* 41 */         return stack;
/*    */       }
/* 43 */       limit -= existing.stackSize;
/*    */     }
/*    */     
/* 46 */     if (limit <= 0) {
/* 47 */       return stack;
/*    */     }
/* 49 */     boolean reachedLimit = stack.stackSize > limit;
/*    */     
/* 51 */     if (!simulate) {
/* 52 */       if (existing == null) {
/* 53 */         setStack(slot, reachedLimit ? ItemHandlerHelper.copyStackWithSize(stack, limit) : stack);
/*    */       } else {
/* 55 */         existing.stackSize += (reachedLimit ? limit : stack.stackSize);
/*    */       }
/* 57 */       onContentsChanged(slot);
/*    */     }
/*    */     
/* 60 */     return reachedLimit ? ItemHandlerHelper.copyStackWithSize(stack, stack.stackSize - limit) : null;
/*    */   }
/*    */   
/*    */   public ItemStack extractItem(int slot, int amount, boolean simulate) {
/* 64 */     if (amount == 0) {
/* 65 */       return null;
/*    */     }
/* 67 */     ItemStack existing = getStack(slot);
/*    */     
/* 69 */     if (existing == null) {
/* 70 */       return null;
/*    */     }
/* 72 */     int toExtract = Math.min(amount, existing.getMaxStackSize());
/*    */     
/* 74 */     if (existing.stackSize <= toExtract) {
/* 75 */       if (!simulate) {
/* 76 */         setStack(slot, null);
/* 77 */         onContentsChanged(slot);
/*    */       }
/* 79 */       return existing;
/*    */     }
/* 81 */     if (!simulate) {
/* 82 */       setStack(slot, ItemHandlerHelper.copyStackWithSize(existing, existing.stackSize - toExtract));
/* 83 */       onContentsChanged(slot);
/*    */     }
/*    */     
/* 86 */     return ItemHandlerHelper.copyStackWithSize(existing, toExtract);
/*    */   }
/*    */   
/*    */   protected int getStackLimit(int slot, ItemStack stack)
/*    */   {
/* 91 */     return stack.getMaxStackSize();
/*    */   }
/*    */   
/*    */   protected void onContentsChanged(int slot) {}
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\ItemStackHandlerBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */