/*    */ package com.rwtema.extrautils2.itemhandler;
/*    */ 
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ 
/*    */ public class ConcatFixedLength implements net.minecraftforge.items.IItemHandlerModifiable
/*    */ {
/*    */   final IItemHandler[] handlers;
/*    */   final int[] firstSlot;
/*    */   final int totalSlots;
/*    */   
/*    */   public ConcatFixedLength(IItemHandler... handlers)
/*    */   {
/* 14 */     this.handlers = handlers;
/* 15 */     this.firstSlot = new int[handlers.length];
/* 16 */     int v = 0;
/* 17 */     for (int i = 0; i < handlers.length; i++) {
/* 18 */       this.firstSlot[i] = v;
/* 19 */       v += handlers[i].getSlots();
/*    */     }
/* 21 */     this.totalSlots = v;
/*    */   }
/*    */   
/*    */   public static IItemHandler create(IItemHandler... handlers) {
/* 25 */     for (IItemHandler handler : handlers) {
/* 26 */       if (handler.getSlots() != 1) {
/* 27 */         return new ConcatFixedLength(handlers);
/*    */       }
/*    */     }
/* 30 */     return new ConcatFixedLengthSingleSlot(handlers);
/*    */   }
/*    */   
/*    */   public int getSlots()
/*    */   {
/* 35 */     return this.totalSlots;
/*    */   }
/*    */   
/*    */   public int getHandlerIndex(int slot) {
/* 39 */     int i = java.util.Arrays.binarySearch(this.firstSlot, slot);
/* 40 */     return i >= 0 ? i : -i - 2;
/*    */   }
/*    */   
/*    */   public ItemStack getStackInSlot(int slot)
/*    */   {
/* 45 */     int i = getHandlerIndex(slot);
/* 46 */     return this.handlers[i].getStackInSlot(slot - this.firstSlot[i]);
/*    */   }
/*    */   
/*    */   public ItemStack insertItem(int slot, ItemStack stack, boolean simulate)
/*    */   {
/* 51 */     int i = getHandlerIndex(slot);
/* 52 */     return this.handlers[i].insertItem(slot - this.firstSlot[i], stack, simulate);
/*    */   }
/*    */   
/*    */   public ItemStack extractItem(int slot, int amount, boolean simulate)
/*    */   {
/* 57 */     int i = getHandlerIndex(slot);
/* 58 */     return this.handlers[i].extractItem(slot - this.firstSlot[i], amount, simulate);
/*    */   }
/*    */   
/*    */   public void setStackInSlot(int slot, ItemStack stack)
/*    */   {
/* 63 */     int i = getHandlerIndex(slot);
/* 64 */     if ((this.handlers[i] instanceof net.minecraftforge.items.IItemHandlerModifiable)) {
/* 65 */       ((net.minecraftforge.items.IItemHandlerModifiable)this.handlers[i]).setStackInSlot(slot - this.firstSlot[i], stack);
/*    */     } else {
/* 67 */       throw new UnsupportedOperationException();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\ConcatFixedLength.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */