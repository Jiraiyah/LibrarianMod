/*    */ package com.rwtema.extrautils2.itemhandler;
/*    */ 
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ 
/*    */ public class ConcatFixedLengthSingleSlot implements IItemHandler
/*    */ {
/*    */   IItemHandler[] slotHandlers;
/*    */   
/*    */   public ConcatFixedLengthSingleSlot(IItemHandler... handlers) {
/* 10 */     this.slotHandlers = handlers;
/*    */   }
/*    */   
/*    */   public int getSlots()
/*    */   {
/* 15 */     return this.slotHandlers.length;
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack getStackInSlot(int slot)
/*    */   {
/* 20 */     return this.slotHandlers[slot].getStackInSlot(0);
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack insertItem(int slot, net.minecraft.item.ItemStack stack, boolean simulate)
/*    */   {
/* 25 */     return this.slotHandlers[slot].insertItem(0, stack, simulate);
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack extractItem(int slot, int amount, boolean simulate)
/*    */   {
/* 30 */     return this.slotHandlers[slot].extractItem(0, amount, simulate);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\ConcatFixedLengthSingleSlot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */