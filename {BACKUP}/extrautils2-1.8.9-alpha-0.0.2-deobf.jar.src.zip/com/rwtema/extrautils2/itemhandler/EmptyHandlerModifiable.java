/*   */ package com.rwtema.extrautils2.itemhandler;
/*   */ 
/*   */ import net.minecraft.item.ItemStack;
/*   */ import net.minecraftforge.items.wrapper.EmptyHandler;
/*   */ 
/*   */ public class EmptyHandlerModifiable extends EmptyHandler implements net.minecraftforge.items.IItemHandlerModifiable
/*   */ {
/* 8 */   public static final EmptyHandlerModifiable INSTANCE = new EmptyHandlerModifiable();
/*   */   
/*   */   public void setStackInSlot(int slot, ItemStack stack) {}
/*   */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\EmptyHandlerModifiable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */