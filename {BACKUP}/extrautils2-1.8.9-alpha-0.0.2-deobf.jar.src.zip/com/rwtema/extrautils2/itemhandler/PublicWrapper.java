/*    */ package com.rwtema.extrautils2.itemhandler;
/*    */ 
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ 
/*    */ public class PublicWrapper implements IItemHandler
/*    */ {
/*    */   public final IItemHandler handler;
/*    */   
/*    */   public PublicWrapper(IItemHandler handler) {
/* 10 */     this.handler = handler;
/*    */   }
/*    */   
/*    */   public int getSlots()
/*    */   {
/* 15 */     return this.handler.getSlots();
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack getStackInSlot(int slot)
/*    */   {
/* 20 */     return this.handler.getStackInSlot(slot);
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack insertItem(int slot, net.minecraft.item.ItemStack stack, boolean simulate)
/*    */   {
/* 25 */     return this.handler.insertItem(slot, stack, simulate);
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack extractItem(int slot, int amount, boolean simulate)
/*    */   {
/* 30 */     return this.handler.extractItem(slot, amount, simulate);
/*    */   }
/*    */   
/*    */   public static class Extract extends PublicWrapper
/*    */   {
/*    */     public Extract(IItemHandler handler) {
/* 36 */       super();
/*    */     }
/*    */     
/*    */     public net.minecraft.item.ItemStack insertItem(int slot, net.minecraft.item.ItemStack stack, boolean simulate)
/*    */     {
/* 41 */       return stack;
/*    */     }
/*    */   }
/*    */   
/*    */   public static class Insert extends PublicWrapper
/*    */   {
/*    */     public Insert(IItemHandler handler) {
/* 48 */       super();
/*    */     }
/*    */     
/*    */     public net.minecraft.item.ItemStack extractItem(int slot, int amount, boolean simulate)
/*    */     {
/* 53 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\PublicWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */