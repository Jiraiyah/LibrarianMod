/*    */ package com.rwtema.extrautils2.itemhandler;
/*    */ 
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ public class SingleStackHandler extends SingleStackHandlerBase implements net.minecraftforge.common.util.INBTSerializable<NBTTagCompound>
/*    */ {
/*    */   protected ItemStack curStack;
/*    */   
/*    */   public ItemStack getStack()
/*    */   {
/* 12 */     return this.curStack;
/*    */   }
/*    */   
/*    */   public void setStack(ItemStack curStack)
/*    */   {
/* 17 */     this.curStack = curStack;
/*    */   }
/*    */   
/*    */   public NBTTagCompound serializeNBT()
/*    */   {
/* 22 */     NBTTagCompound tagCompound = new NBTTagCompound();
/* 23 */     if (this.curStack != null) {
/* 24 */       this.curStack.writeToNBT(tagCompound);
/* 25 */       if (this.curStack.stackSize > 64)
/* 26 */         tagCompound.setInteger("ExtendedCount", this.curStack.stackSize);
/*    */     }
/* 28 */     return tagCompound;
/*    */   }
/*    */   
/*    */   public void deserializeNBT(NBTTagCompound nbt)
/*    */   {
/* 33 */     this.curStack = null;
/* 34 */     if (nbt.hasKey("id")) {
/* 35 */       this.curStack = ItemStack.loadItemStackFromNBT(nbt);
/* 36 */       if ((this.curStack != null) && (nbt.hasKey("ExtendedCount"))) {
/* 37 */         this.curStack.stackSize = nbt.getInteger("ExtendedCount");
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\SingleStackHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */