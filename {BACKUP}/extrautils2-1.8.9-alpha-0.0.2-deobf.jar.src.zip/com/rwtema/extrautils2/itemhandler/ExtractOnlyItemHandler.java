/*    */ package com.rwtema.extrautils2.itemhandler;
/*    */ 
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ 
/*    */ public class ExtractOnlyItemHandler implements IItemHandler
/*    */ {
/*    */   IItemHandler p;
/*    */   
/*    */   public int getSlots()
/*    */   {
/* 11 */     return this.p.getSlots();
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack getStackInSlot(int slot)
/*    */   {
/* 16 */     return this.p.getStackInSlot(slot);
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack insertItem(int slot, net.minecraft.item.ItemStack stack, boolean simulate)
/*    */   {
/* 21 */     return stack;
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack extractItem(int slot, int amount, boolean simulate)
/*    */   {
/* 26 */     return this.p.extractItem(slot, amount, simulate);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\ExtractOnlyItemHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */