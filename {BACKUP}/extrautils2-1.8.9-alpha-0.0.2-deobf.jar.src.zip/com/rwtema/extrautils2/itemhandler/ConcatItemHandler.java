/*    */ package com.rwtema.extrautils2.itemhandler;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ import org.apache.commons.lang3.tuple.Pair;
/*    */ 
/*    */ public class ConcatItemHandler implements IItemHandler
/*    */ {
/*    */   final IItemHandler[] handlers;
/*    */   
/*    */   public ConcatItemHandler(IItemHandler... handlers)
/*    */   {
/* 15 */     this.handlers = handlers;
/*    */   }
/*    */   
/*    */   public ConcatItemHandler(Collection<IItemHandler> handlers) {
/* 19 */     this.handlers = ((IItemHandler[])handlers.toArray(new IItemHandler[handlers.size()]));
/*    */   }
/*    */   
/*    */   public static IItemHandler concatNonNull(IItemHandler... values) {
/* 23 */     boolean single = true;
/* 24 */     ArrayList<IItemHandler> nonNullHandlers = new ArrayList(values.length);
/* 25 */     for (IItemHandler value : values) {
/* 26 */       if ((value != null) && (value != net.minecraftforge.items.wrapper.EmptyHandler.INSTANCE)) {
/* 27 */         nonNullHandlers.add(value);
/*    */         
/* 29 */         IItemHandler t = value;
/* 30 */         while ((t instanceof PublicWrapper)) {
/* 31 */           t = ((PublicWrapper)t).handler;
/*    */         }
/*    */         
/* 34 */         if ((!(t instanceof SingleStackHandler)) && (!(t instanceof net.minecraftforge.items.ItemStackHandler))) {
/* 35 */           single = false;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 40 */     if (nonNullHandlers.isEmpty()) {
/* 41 */       return net.minecraftforge.items.wrapper.EmptyHandler.INSTANCE;
/*    */     }
/* 43 */     if (nonNullHandlers.size() == 1) { return (IItemHandler)nonNullHandlers.get(0);
/*    */     }
/* 45 */     if (single) {
/* 46 */       return ConcatFixedLength.create((IItemHandler[])nonNullHandlers.toArray(new IItemHandler[nonNullHandlers.size()]));
/*    */     }
/* 48 */     return new ConcatItemHandler(nonNullHandlers);
/*    */   }
/*    */   
/*    */ 
/*    */   public int getSlots()
/*    */   {
/* 54 */     int size = 0;
/* 55 */     for (IItemHandler handler : this.handlers) {
/* 56 */       size += handler.getSlots();
/*    */     }
/* 58 */     return size;
/*    */   }
/*    */   
/*    */   public Pair<IItemHandler, Integer> getDestination(int slot) {
/* 62 */     for (IItemHandler handler : this.handlers) {
/* 63 */       int numSlots = handler.getSlots();
/* 64 */       if (slot < numSlots) {
/* 65 */         return Pair.of(handler, Integer.valueOf(slot));
/*    */       }
/*    */       
/* 68 */       slot -= numSlots;
/*    */     }
/* 70 */     return null;
/*    */   }
/*    */   
/*    */   public ItemStack getStackInSlot(int slot)
/*    */   {
/* 75 */     Pair<IItemHandler, Integer> pair = getDestination(slot);
/* 76 */     return pair != null ? ((IItemHandler)pair.getLeft()).getStackInSlot(((Integer)pair.getRight()).intValue()) : null;
/*    */   }
/*    */   
/*    */   public ItemStack insertItem(int slot, ItemStack stack, boolean simulate)
/*    */   {
/* 81 */     Pair<IItemHandler, Integer> pair = getDestination(slot);
/* 82 */     return pair != null ? ((IItemHandler)pair.getLeft()).insertItem(((Integer)pair.getRight()).intValue(), stack, simulate) : stack;
/*    */   }
/*    */   
/*    */   public ItemStack extractItem(int slot, int amount, boolean simulate)
/*    */   {
/* 87 */     Pair<IItemHandler, Integer> pair = getDestination(slot);
/* 88 */     return pair != null ? ((IItemHandler)pair.getLeft()).extractItem(((Integer)pair.getRight()).intValue(), amount, simulate) : null;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\ConcatItemHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */