/*     */ package com.rwtema.extrautils2.itemhandler;
/*     */ 
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.items.ItemHandlerHelper;
/*     */ 
/*     */ public abstract class SingleStackHandlerBase implements net.minecraftforge.items.IItemHandlerModifiable
/*     */ {
/*     */   public abstract ItemStack getStack();
/*     */   
/*     */   public abstract void setStack(ItemStack paramItemStack);
/*     */   
/*     */   public void setStackInSlot(int slot, ItemStack stack)
/*     */   {
/*  14 */     if (ItemStack.areItemStacksEqual(getStack(), stack))
/*  15 */       return;
/*  16 */     setStack(stack);
/*  17 */     onContentsChanged();
/*     */   }
/*     */   
/*     */   public int getSlots()
/*     */   {
/*  22 */     return 1;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  27 */     return getStack();
/*     */   }
/*     */   
/*     */   public ItemStack insertItem(int slot, ItemStack stack, boolean simulate)
/*     */   {
/*  32 */     if ((stack == null) || (stack.stackSize == 0)) {
/*  33 */       return null;
/*     */     }
/*  35 */     int limit = getStackLimit(stack);
/*     */     
/*  37 */     if (limit <= 0) { return stack;
/*     */     }
/*  39 */     ItemStack curStack = getStack();
/*  40 */     if (curStack != null) {
/*  41 */       if (!ItemHandlerHelper.canItemStacksStack(stack, curStack)) {
/*  42 */         return stack;
/*     */       }
/*  44 */       limit -= curStack.stackSize;
/*     */       
/*  46 */       if (limit <= 0) { return stack;
/*     */       }
/*     */     }
/*  49 */     boolean reachedLimit = stack.stackSize > limit;
/*     */     
/*  51 */     stack = ItemStack.copyItemStack(stack);
/*     */     
/*  53 */     if (!simulate) {
/*  54 */       if (curStack == null) {
/*  55 */         setStack(reachedLimit ? ItemHandlerHelper.copyStackWithSize(stack, limit) : stack);
/*     */       } else {
/*  57 */         curStack.stackSize += (reachedLimit ? limit : stack.stackSize);
/*  58 */         setStack(curStack);
/*     */       }
/*  60 */       onContentsChanged();
/*     */     }
/*     */     
/*  63 */     return reachedLimit ? ItemHandlerHelper.copyStackWithSize(stack, stack.stackSize - limit) : null;
/*     */   }
/*     */   
/*     */   public ItemStack extractItem(int slot, int amount, boolean simulate) {
/*  67 */     if (amount == 0) {
/*  68 */       return null;
/*     */     }
/*  70 */     ItemStack existing = getStack();
/*     */     
/*  72 */     if (existing == null) {
/*  73 */       return null;
/*     */     }
/*  75 */     int toExtract = amount == 1 ? 1 : Math.min(amount, existing.getMaxStackSize());
/*     */     
/*  77 */     if (existing.stackSize <= toExtract) {
/*  78 */       if (!simulate) {
/*  79 */         setStack(null);
/*  80 */         onContentsChanged();
/*     */       }
/*  82 */       return existing;
/*     */     }
/*  84 */     if (!simulate) {
/*  85 */       existing.stackSize -= toExtract;
/*  86 */       setStack(existing);
/*  87 */       onContentsChanged();
/*     */     }
/*     */     
/*  90 */     return ItemHandlerHelper.copyStackWithSize(existing, toExtract);
/*     */   }
/*     */   
/*     */   protected int getStackLimit(ItemStack stack)
/*     */   {
/*  95 */     return stack.getMaxStackSize();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void onContentsChanged() {}
/*     */   
/*     */   public boolean canInsertAll(ItemStack stack)
/*     */   {
/* 103 */     if (stack == null) return false;
/* 104 */     ItemStack item = insertItem(0, stack, true);
/* 105 */     return item == null;
/*     */   }
/*     */   
/*     */   public boolean canExtractAll(int amount) {
/* 109 */     ItemStack item = extractItem(0, amount, true);
/* 110 */     return (item != null) && (item.stackSize == amount);
/*     */   }
/*     */   
/*     */   public boolean isFull() {
/* 114 */     ItemStack curStack = getStack();
/* 115 */     return (curStack != null) && (curStack.stackSize >= curStack.getMaxStackSize());
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 119 */     ItemStack curStack = getStack();
/* 120 */     return (curStack == null) || (curStack.stackSize == 0);
/*     */   }
/*     */   
/*     */   public int getStackLevel() {
/* 124 */     ItemStack curStack = getStack();
/* 125 */     return curStack == null ? 0 : curStack.stackSize;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\SingleStackHandlerBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */