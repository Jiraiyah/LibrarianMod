/*    */ package com.rwtema.extrautils2.itemhandler;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ 
/*    */ public class PlayerInvItemHandler extends ConcatItemHandler
/*    */ {
/*    */   public PlayerInvItemHandler(EntityPlayer player)
/*    */   {
/* 13 */     super(gatherInventories(player));
/*    */   }
/*    */   
/*    */   public static java.util.List<IItemHandler> gatherInventories(EntityPlayer player) {
/* 17 */     ImmutableList.of(new net.minecraftforge.items.wrapper.InvWrapper(player.inventory), new SingleStackHandlerBase()
/*    */     {
/*    */ 
/*    */ 
/* 21 */       public InventoryPlayer inventory = this.val$player.inventory;
/*    */       
/*    */       public ItemStack getStack()
/*    */       {
/* 25 */         return this.inventory.getItemStack();
/*    */       }
/*    */       
/*    */       public void setStack(ItemStack curStack)
/*    */       {
/* 30 */         this.inventory.setItemStack(curStack);
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\itemhandler\PlayerInvItemHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */