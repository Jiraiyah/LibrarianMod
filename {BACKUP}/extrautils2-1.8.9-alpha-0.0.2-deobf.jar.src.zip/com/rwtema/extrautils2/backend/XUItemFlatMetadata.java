/*    */ package com.rwtema.extrautils2.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.model.Textures;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public abstract class XUItemFlatMetadata extends XUItemFlat
/*    */ {
/*    */   private final String[] textures;
/*    */   
/*    */   public XUItemFlatMetadata(String... textures)
/*    */   {
/* 14 */     this.textures = textures;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public final void registerTextures()
/*    */   {
/* 20 */     Textures.register(this.textures);
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public final String getTexture(@javax.annotation.Nullable ItemStack itemStack, int renderPass)
/*    */   {
/* 27 */     int damage = itemStack != null ? itemStack.getItemDamage() : 0;
/* 28 */     if (damage < 0) damage = 0;
/* 29 */     if (damage >= this.textures.length) damage = this.textures.length - 1;
/* 30 */     return this.textures[damage];
/*    */   }
/*    */   
/*    */   public int getMaxMetadata()
/*    */   {
/* 35 */     return this.textures.length - 1;
/*    */   }
/*    */   
/*    */   public boolean allowOverride()
/*    */   {
/* 40 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUItemFlatMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */