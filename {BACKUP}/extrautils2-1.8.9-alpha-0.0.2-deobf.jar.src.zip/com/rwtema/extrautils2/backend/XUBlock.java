/*     */ package com.rwtema.extrautils2.backend;
/*     */ 
/*     */ import com.google.common.base.Throwables;
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.achievements.AchievementHelper;
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.backend.model.MutableModel;
/*     */ import com.rwtema.extrautils2.backend.model.Transforms;
/*     */ import com.rwtema.extrautils2.backend.model.XUBlockState;
/*     */ import com.rwtema.extrautils2.tile.XUTile;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.BlockState;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public abstract class XUBlock extends Block
/*     */ {
/*  40 */   public static final List<XUBlock> blocks = ;
/*  41 */   public final ThreadLocal<Box> boundsOverride = new ThreadLocal();
/*     */   public XUBlockStateCreator xuBlockState;
/*     */   public XUItemBlock itemBlock;
/*     */   private boolean hasTile;
/*     */   
/*     */   public XUBlock(Material materialIn) {
/*  47 */     super(materialIn);
/*  48 */     setCreativeTab(ExtraUtils2.creativeTabExtraUtils);
/*  49 */     setHardness(1.0F);
/*  50 */     setSoundType(Block.field_149769_e);
/*  51 */     setBlockState((XUBlockStateCreator)this.blockState);
/*  52 */     ExtraUtils2.proxy.registerBlock(this);
/*  53 */     blocks.add(this);
/*     */   }
/*     */   
/*     */   protected static boolean isSolidForPlacing(World world, BlockPos pos, EnumFacing side) {
/*  57 */     return ((side == EnumFacing.DOWN) && (World.func_175683_a(world, pos.down()))) || (world.isSideSolid(pos.offset(side), side));
/*     */   }
/*     */   
/*     */   public static <T extends Comparable<T>> T getPropertySafe(World world, BlockPos pos, IProperty<T> property, T _default) {
/*  61 */     IBlockState blockState = world.getBlockState(pos);
/*  62 */     if (blockState.getProperties().containsKey(property)) {
/*  63 */       return blockState.getValue(property);
/*     */     }
/*  65 */     return _default;
/*     */   }
/*     */   
/*     */   public boolean isBlockSolid(IBlockAccess worldIn, BlockPos pos, EnumFacing side)
/*     */   {
/*  70 */     return getWorldModel(worldIn, pos, null).isFullCube();
/*     */   }
/*     */   
/*     */   public boolean isOpaqueCube()
/*     */   {
/*  75 */     return false;
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/*  80 */     return new XUBlockStateCreator(this);
/*     */   }
/*     */   
/*     */   public void setBlockName(String s) {
/*  84 */     setUnlocalizedName(s);
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public abstract BoxModel getWorldModel(IBlockAccess paramIBlockAccess, BlockPos paramBlockPos, @Nullable IBlockState paramIBlockState);
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BoxModel getRenderModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state) {
/*  92 */     return getWorldModel(world, pos, state);
/*     */   }
/*     */   
/*     */   public boolean isNormalCube(IBlockAccess world, BlockPos pos)
/*     */   {
/*  97 */     return getWorldModel(world, pos, null).isFullCube();
/*     */   }
/*     */   
/*     */   public boolean isFullCube()
/*     */   {
/* 102 */     return false;
/*     */   }
/*     */   
/*     */   public void getSubBlocks(Item itemIn, CreativeTabs tab, List<ItemStack> list)
/*     */   {
/* 107 */     if (this.xuBlockState.mainBlock == this) {
/* 108 */       for (int i = 0; i < this.xuBlockState.dropmeta2state.length; i++) {
/* 109 */         list.add(new ItemStack(itemIn, 1, i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public ItemStack getPickBlock(MovingObjectPosition target, World world, BlockPos pos, EntityPlayer player) {
/* 116 */     return super.getPickBlock(target, world, pos, player);
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   @SideOnly(Side.CLIENT)
/*     */   public abstract BoxModel getInventoryModel(@Nullable ItemStack paramItemStack);
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IBlockState getExtendedState(IBlockState state, IBlockAccess world, BlockPos pos)
/*     */   {
/* 126 */     BoxModel worldModel = getRenderModel(world, pos, state);
/* 127 */     ((XUBlockState)state).load(worldModel);
/* 128 */     return state;
/*     */   }
/*     */   
/*     */   public BlockState getBlockState()
/*     */   {
/* 133 */     return this.xuBlockState;
/*     */   }
/*     */   
/*     */   public void setBlockState(XUBlockStateCreator creator) {
/* 137 */     this.xuBlockState = creator;
/* 138 */     boolean hasTile = false;
/* 139 */     for (IBlockState iBlockState : this.xuBlockState.getValidStates()) {
/* 140 */       if (hasTileEntity(iBlockState)) {
/* 141 */         hasTile = true;
/* 142 */         break;
/*     */       }
/*     */     }
/* 145 */     this.hasTile = hasTile;
/*     */     
/* 147 */     if (this.itemBlock != null) {
/* 148 */       this.itemBlock.setHasSubtypes(this.xuBlockState.dropmeta2state.length > 1);
/*     */     }
/*     */     
/* 151 */     setDefaultState(creator.defaultState);
/*     */   }
/*     */   
/*     */   public void func_180638_a(World worldIn, BlockPos pos, IBlockState state, AxisAlignedBB mask, List<AxisAlignedBB> list, Entity collidingEntity)
/*     */   {
/* 156 */     BoxModel models = getWorldModel(worldIn, pos, state);
/*     */     
/* 158 */     if (models.isEmpty()) { return;
/*     */     }
/* 160 */     for (Box b : models) {
/* 161 */       if (!b.noCollide)
/*     */       {
/* 163 */         AxisAlignedBB aabb = new AxisAlignedBB(pos.getX() + b.minX, pos.getY() + b.minY, pos.getZ() + b.minZ, pos.getX() + b.maxX, pos.getY() + b.maxY, pos.getZ() + b.maxZ);
/*     */         
/* 165 */         if (mask.intersectsWith(aabb)) {
/* 166 */           list.add(aabb);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void func_180654_a(IBlockAccess worldIn, BlockPos pos) {
/* 173 */     Box bounds = (Box)this.boundsOverride.get();
/* 174 */     if (bounds == null) bounds = BoxModel.boundingBox(getWorldModel(worldIn, pos, null), false);
/* 175 */     if (bounds != null) {
/* 176 */       func_149676_a(bounds.minX, bounds.minY, bounds.minZ, bounds.maxX, bounds.maxY, bounds.maxZ);
/*     */     }
/*     */   }
/*     */   
/*     */   public MovingObjectPosition collisionRayTrace(World worldIn, BlockPos pos, Vec3 start, Vec3 end)
/*     */   {
/* 182 */     BoxModel worldModel = getWorldModel(worldIn, pos, null);
/* 183 */     if (worldModel.overrideBounds != null) {
/* 184 */       return super.collisionRayTrace(worldIn, pos, start, end);
/*     */     }
/* 186 */     MovingObjectPosition result = null;
/*     */     try {
/* 188 */       for (Box box : worldModel) {
/* 189 */         this.boundsOverride.set(box);
/* 190 */         MovingObjectPosition r = super.collisionRayTrace(worldIn, pos, start, end);
/* 191 */         if ((r != null) && ((result == null) || (start.distanceTo(r.hitVec) < start.distanceTo(result.hitVec)))) {
/* 192 */           result = r;
/* 193 */           result.subHit = box.tint;
/*     */         }
/*     */       }
/*     */       
/* 197 */       this.boundsOverride.set(null);
/*     */     } catch (Throwable err) {
/* 199 */       this.boundsOverride.set(null);
/* 200 */       throw Throwables.propagate(err);
/*     */     }
/*     */     
/* 203 */     return result;
/*     */   }
/*     */   
/*     */   public IBlockState onBlockPlaced(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer)
/*     */   {
/* 208 */     return this.xuBlockState.getStateFromDropMeta(meta);
/*     */   }
/*     */   
/*     */   public int damageDropped(IBlockState state)
/*     */   {
/* 213 */     return this.xuBlockState.getDropMetaFromState(state);
/*     */   }
/*     */   
/*     */   public IBlockState getStateFromMeta(int meta)
/*     */   {
/* 218 */     return this.xuBlockState.getStateFromMeta(this, meta);
/*     */   }
/*     */   
/*     */   public int getMetaFromState(IBlockState state)
/*     */   {
/* 223 */     return this.xuBlockState.getMetaFromState(state);
/*     */   }
/*     */   
/*     */   protected ItemStack createStackedBlock(IBlockState state)
/*     */   {
/* 228 */     int i = 0;
/* 229 */     Item item = Item.getItemFromBlock(this.xuBlockState.mainBlock);
/*     */     
/* 231 */     if ((item != null) && (item.getHasSubtypes())) {
/* 232 */       i = this.xuBlockState.getDropMetaFromState(state);
/*     */     }
/*     */     
/* 235 */     return new ItemStack(item, 1, i);
/*     */   }
/*     */   
/*     */   public Item getItemDropped(IBlockState state, Random rand, int fortune)
/*     */   {
/* 240 */     return Item.getItemFromBlock(this.xuBlockState.mainBlock);
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures() {}
/*     */   
/*     */ 
/*     */   public void postTextureRegister() {}
/*     */   
/*     */ 
/*     */   public XUTile getTile(World world, BlockPos pos)
/*     */   {
/* 253 */     return this.hasTile ? (XUTile)world.getTileEntity(pos) : null;
/*     */   }
/*     */   
/*     */   public <T extends XUTile> T getTileCast(World world, BlockPos pos)
/*     */   {
/* 258 */     return getTile(world, pos);
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
/*     */   {
/*     */     XUTile checkTile;
/* 264 */     if ((this.hasTile) && ((checkTile = getTile(worldIn, pos)) != null)) {
/* 265 */       checkTile.onBlockPlacedBy(worldIn, pos, state, placer, stack, this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void harvestBlock(World worldIn, EntityPlayer player, BlockPos pos, IBlockState state, TileEntity te) {
/* 270 */     if ((this.hasTile) && (te != null) && 
/* 271 */       (((XUTile)te).harvestBlock(worldIn, player, pos, state))) {
/* 272 */       return;
/*     */     }
/* 274 */     super.harvestBlock(worldIn, player, pos, state, te);
/*     */   }
/*     */   
/*     */   public void onNeighborBlockChange(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock)
/*     */   {
/*     */     XUTile checkTile;
/* 280 */     if ((this.hasTile) && (hasTileEntity(state)) && ((checkTile = getTile(worldIn, pos)) != null)) {
/* 281 */       checkTile.onNeighborBlockChange(worldIn, pos, state, neighborBlock);
/*     */     }
/*     */   }
/*     */   
/*     */   public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
/*     */     XUTile checkTile;
/* 287 */     if ((this.hasTile) && ((checkTile = getTile(worldIn, pos)) != null)) {
/* 288 */       checkTile.breakBlock(worldIn, pos, state);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void clearCaches() {}
/*     */   
/*     */ 
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced) {}
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addInventoryQuads(MutableModel result, ItemStack stack)
/*     */   {
/* 301 */     BoxModel inventoryModel = getInventoryModel(stack);
/* 302 */     inventoryModel.loadIntoMutable(result, null);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public MutableModel createInventoryMutableModel() {
/* 307 */     return new MutableModel(Transforms.blockTransforms);
/*     */   }
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBox(World worldIn, BlockPos pos)
/*     */   {
/* 312 */     return getWorldModel(worldIn, pos, null).getAABB(pos, false);
/*     */   }
/*     */   
/*     */   public AxisAlignedBB getSelectedBoundingBox(World worldIn, BlockPos pos, IBlockState state)
/*     */   {
/* 317 */     return super.getSelectedBoundingBox(worldIn, pos, state);
/*     */   }
/*     */   
/*     */   public <T extends Comparable<T>> T getMyPropertySafe(World world, BlockPos pos, IProperty<T> property) {
/* 321 */     IBlockState state = world.getBlockState(pos);
/* 322 */     if (state.getBlock() == this) {
/* 323 */       return state.getValue(property);
/*     */     }
/* 325 */     return getDefaultState().getValue(property);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*     */     XUTile checkTile;
/* 332 */     if ((this.hasTile) && (hasTileEntity(state)) && ((checkTile = getTile(worldIn, pos)) != null))
/* 333 */       return checkTile.onBlockActivated(worldIn, pos, state, playerIn, side, hitX, hitY, hitZ);
/* 334 */     return super.onBlockActivated(worldIn, pos, state, playerIn, side, hitX, hitY, hitZ);
/*     */   }
/*     */   
/*     */   public boolean isPassable(IBlockAccess worldIn, BlockPos pos)
/*     */   {
/* 339 */     return (super.isPassable(worldIn, pos)) || (getWorldModel(worldIn, pos, null).getPassable());
/*     */   }
/*     */   
/*     */   public void onCreated(ItemStack stack, World worldIn, EntityPlayer playerIn) {
/* 343 */     AchievementHelper.checkForPotentialAwards(playerIn, stack);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */