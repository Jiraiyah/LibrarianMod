/*    */ package com.rwtema.extrautils2.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.model.PassthruModelItem.ModelLayer;
/*    */ import com.rwtema.extrautils2.backend.model.Textures;
/*    */ import java.util.HashMap;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ public abstract class XUItemFlat
/*    */   extends XUItem
/*    */ {
/*    */   @SideOnly(Side.CLIENT)
/*    */   public abstract void registerTextures();
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public abstract String getTexture(@Nullable ItemStack paramItemStack, int paramInt);
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public TextureAtlasSprite getSprite(@Nullable ItemStack itemStack, int renderPass)
/*    */   {
/* 25 */     String texture = getTexture(itemStack, renderPass);
/* 26 */     TextureAtlasSprite sprite = (TextureAtlasSprite)Textures.sprites.get(texture);
/* 27 */     if (sprite == null) sprite = Textures.MISSING_SPRITE;
/* 28 */     return sprite;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public int getRenderLayers(@Nullable ItemStack itemStack) {
/* 33 */     return 1;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public TextureAtlasSprite getBaseTexture()
/*    */   {
/* 39 */     return getSprite(null, 0);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void addQuads(PassthruModelItem.ModelLayer model, ItemStack stack)
/*    */   {
/* 45 */     for (int i = 0; i < getRenderLayers(stack); i++) {
/* 46 */       model.addTintedSprite(getSprite(stack, i), renderLayerIn3D(stack, i), getTint(stack, i));
/*    */     }
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public int getTint(ItemStack stack, int i) {
/* 52 */     return -1;
/*    */   }
/*    */   
/*    */   public boolean renderLayerIn3D(ItemStack stack, int renderPass) {
/* 56 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUItemFlat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */