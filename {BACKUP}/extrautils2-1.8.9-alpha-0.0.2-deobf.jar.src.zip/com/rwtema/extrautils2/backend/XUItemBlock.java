/*    */ package com.rwtema.extrautils2.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.Lang;
/*    */ import com.rwtema.extrautils2.utils.helpers.StringHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.RegistryNamespacedDefaultedByKey;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class XUItemBlock extends ItemBlock
/*    */ {
/* 17 */   public static final List<XUItemBlock> itemBlocks = ;
/*    */   public XUBlock block;
/*    */   
/*    */   public XUItemBlock(Block block) {
/* 21 */     super(block);
/* 22 */     this.block = ((XUBlock)block);
/* 23 */     this.block.itemBlock = this;
/* 24 */     itemBlocks.add(this);
/* 25 */     setMaxDamage(0);
/* 26 */     if (this.block.xuBlockState.dropmeta2state.length > 1) {
/* 27 */       setHasSubtypes(true);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public String getUnlocalizedName(ItemStack stack)
/*    */   {
/* 34 */     if (!this.hasSubtypes) {
/* 35 */       return super.getUnlocalizedName(stack);
/*    */     }
/* 37 */     int i = stack.getItemDamage();
/* 38 */     String[] dropNames = this.block.xuBlockState.dropNames;
/* 39 */     if ((i < 0) || (i >= dropNames.length)) return super.getUnlocalizedName(stack);
/* 40 */     return this.block.getUnlocalizedName() + "." + dropNames[i];
/*    */   }
/*    */   
/*    */ 
/*    */   public String getItemStackDisplayName(ItemStack stack)
/*    */   {
/* 46 */     if (!com.rwtema.extrautils2.ExtraUtils2.deobf_folder) {
/* 47 */       return super.getItemStackDisplayName(stack);
/*    */     }
/* 49 */     String key = getUnlocalizedNameInefficiently(stack) + ".name";
/* 50 */     if (!this.hasSubtypes) {
/* 51 */       return Lang.translate(key, StringHelper.sepWords(((ResourceLocation)Block.blockRegistry.getNameForObject(this.block)).getResourcePath().replace("Block", "")));
/*    */     }
/* 53 */     int i = stack.getItemDamage();
/* 54 */     String[] dropNames = this.block.xuBlockState.dropNames;
/* 55 */     if ((i < 0) || (i >= dropNames.length)) return super.getItemStackDisplayName(stack);
/* 56 */     return Lang.translate(key, StringHelper.sepWords(StringHelper.capFirst(dropNames[i], false)));
/*    */   }
/*    */   
/*    */ 
/*    */   public int getMetadata(int damage)
/*    */   {
/* 62 */     return damage;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void registerTextures() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public void postTextureRegister() {}
/*    */   
/*    */ 
/*    */   public void clearCaches() {}
/*    */   
/*    */ 
/*    */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*    */   {
/* 80 */     this.block.addInformation(stack, playerIn, tooltip, advanced);
/*    */   }
/*    */   
/*    */   public void onCreated(ItemStack stack, World worldIn, EntityPlayer playerIn)
/*    */   {
/* 85 */     this.block.onCreated(stack, worldIn, playerIn);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUItemBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */