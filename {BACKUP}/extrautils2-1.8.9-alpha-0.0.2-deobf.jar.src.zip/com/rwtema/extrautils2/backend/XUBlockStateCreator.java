/*     */ package com.rwtema.extrautils2.backend;
/*     */ 
/*     */ import com.google.common.base.Optional;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import com.rwtema.extrautils2.backend.model.XUBlockState;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyBool;
/*     */ import net.minecraft.block.properties.PropertyDirection;
/*     */ import net.minecraft.block.state.BlockState;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumFacing.Plane;
/*     */ import net.minecraft.util.MapPopulator;
/*     */ import net.minecraftforge.common.property.IUnlistedProperty;
/*     */ 
/*     */ public class XUBlockStateCreator extends BlockState
/*     */ {
/*  33 */   public static final PropertyDirection ROTATION_HORIZONTAL = PropertyDirection.create("facing", EnumFacing.Plane.HORIZONTAL);
/*  34 */   public static final PropertyDirection ROTATION_ALL = PropertyDirection.create("facing", Arrays.asList(EnumFacing.values()));
/*  35 */   public static final PropertyDirection ROTATION_HORIZONTAL_INC_DOWN = PropertyDirection.create("facing", Arrays.asList(new EnumFacing[] { EnumFacing.DOWN, EnumFacing.WEST, EnumFacing.EAST, EnumFacing.NORTH, EnumFacing.SOUTH }));
/*  36 */   public static final java.util.Map<EnumFacing, PropertyBool> FACING_BOOLEANS = new java.util.EnumMap(MapPopulator.createMap(Lists.newArrayList(EnumFacing.values()), Lists.transform(Lists.newArrayList(EnumFacing.values()), new com.google.common.base.Function()
/*     */   {
/*     */ 
/*     */ 
/*     */     @Nullable
/*     */     public PropertyBool apply(EnumFacing input)
/*     */     {
/*     */ 
/*  44 */       return PropertyBool.create(input.getName().toLowerCase());
/*     */     }
/*  36 */   })));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */   public static final Comparator<IProperty> property_sorter = new Comparator() {
/*     */     public int compare(IProperty p_compare_1_, IProperty p_compare_2_) {
/*  49 */       return p_compare_1_.getName().compareTo(p_compare_2_.getName());
/*     */     }
/*     */   };
/*     */   public final String[] dropNames;
/*     */   public final HashMap<IProperty, Comparable> defaultValues;
/*     */   public final IBlockState defaultState;
/*  55 */   protected final TObjectIntHashMap<IBlockState> state2meta = new TObjectIntHashMap();
/*  56 */   protected final TObjectIntHashMap<IBlockState> state2dropMeta = new TObjectIntHashMap();
/*     */   final IBlockState[] meta2state;
/*     */   protected final IBlockState[] dropmeta2state;
/*     */   public XUBlock mainBlock;
/*     */   
/*     */   protected XUBlockStateCreator(XUBlock block, IProperty<? extends Comparable>[] worldProperties, IProperty<? extends Comparable>[] dropProperties, HashMap<IProperty, Comparable> defaultValues)
/*     */   {
/*  63 */     super(block, joinProperties(worldProperties, dropProperties), null);
/*     */     
/*  65 */     this.mainBlock = block;
/*     */     
/*  67 */     Arrays.sort(worldProperties, property_sorter);
/*  68 */     Arrays.sort(dropProperties, property_sorter);
/*     */     
/*  70 */     this.defaultValues = (defaultValues == null ? new HashMap() : defaultValues);
/*     */     
/*  72 */     for (IProperty<? extends Comparable> iProperty : getProperties()) {
/*  73 */       if ((defaultValues == null) || (!this.defaultValues.containsKey(iProperty))) {
/*  74 */         Collection<? extends Comparable> allowedValues = iProperty.getAllowedValues();
/*  75 */         this.defaultValues.put(iProperty, Collections.min(allowedValues));
/*     */       }
/*     */     }
/*     */     
/*  79 */     ImmutableList<IBlockState> validStates = super.getValidStates();
/*     */     
/*  81 */     IBlockState defaultState = (IBlockState)validStates.get(0);
/*  82 */     for (Map.Entry<IProperty, Comparable> entry : this.defaultValues.entrySet()) {
/*  83 */       defaultState = defaultState.withProperty((IProperty)entry.getKey(), (Comparable)entry.getValue());
/*     */     }
/*  85 */     this.defaultState = defaultState;
/*     */     
/*  87 */     this.meta2state = createBlockStateArray(validStates);
/*  88 */     for (int i = 0; i < this.meta2state.length; i++) {
/*  89 */       this.state2meta.put(this.meta2state[i], i);
/*     */     }
/*     */     
/*  92 */     LinkedHashSet<IBlockState> dropMetas = new LinkedHashSet();
/*  93 */     for (IBlockState validState : validStates) {
/*  94 */       IBlockState metaState = validState;
/*  95 */       for (IProperty property : worldProperties) {
/*  96 */         metaState = metaState.withProperty(property, (Comparable)this.defaultValues.get(property));
/*     */       }
/*     */       
/*  99 */       dropMetas.add(metaState);
/*     */     }
/*     */     
/* 102 */     this.dropmeta2state = ((IBlockState[])dropMetas.toArray(new IBlockState[dropMetas.size()]));
/*     */     
/* 104 */     for (int i = 0; i < this.dropmeta2state.length; i++) {
/* 105 */       this.state2dropMeta.put(this.dropmeta2state[i], i);
/*     */     }
/* 107 */     for (IBlockState validState : validStates) {
/* 108 */       if (!this.state2dropMeta.containsKey(validState)) {
/* 109 */         IBlockState metaState = validState;
/* 110 */         for (IProperty property : worldProperties) {
/* 111 */           metaState = metaState.withProperty(property, (Comparable)this.defaultValues.get(property));
/*     */         }
/* 113 */         this.state2dropMeta.put(validState, this.state2dropMeta.get(metaState));
/*     */       }
/*     */     }
/*     */     
/* 117 */     this.dropNames = new String[this.dropmeta2state.length];
/* 118 */     for (int i = 0; i < this.dropNames.length; i++) {
/* 119 */       IBlockState iBlockState = this.dropmeta2state[i];
/* 120 */       StringBuilder builder = new StringBuilder();
/*     */       
/* 122 */       for (int j = 0; j < dropProperties.length; j++) {
/* 123 */         if (j != 0) builder.append(".");
/* 124 */         builder.append(iBlockState.getValue(dropProperties[j]).toString().toLowerCase());
/*     */       }
/*     */       
/* 127 */       this.dropNames[i] = builder.toString();
/*     */     }
/*     */     
/* 130 */     for (IBlockState validState : validStates) {
/* 131 */       XUBlockState xuBlockState = (XUBlockState)validState;
/* 132 */       xuBlockState.metadata = this.state2meta.get(xuBlockState);
/* 133 */       xuBlockState.dropMeta = this.state2dropMeta.get(xuBlockState);
/* 134 */       xuBlockState.dropName = this.dropNames[xuBlockState.dropMeta];
/*     */     }
/*     */   }
/*     */   
/*     */   public XUBlockStateCreator(XUBlock xuBlock) {
/* 139 */     this(xuBlock, new IProperty[0]);
/*     */   }
/*     */   
/*     */   public XUBlockStateCreator(XUBlock xuBlock, IProperty<?>... properties) {
/* 143 */     this(xuBlock, properties, new IProperty[0]);
/*     */   }
/*     */   
/*     */   public XUBlockStateCreator(XUBlock xuBlock, boolean dummy, IProperty<?>... dropProperties) {
/* 147 */     this(xuBlock, new IProperty[0], dropProperties);
/*     */   }
/*     */   
/*     */   public XUBlockStateCreator(XUBlock xuBlock, IProperty<?>[] properties, IProperty<?>[] dropProperties) {
/* 151 */     this(xuBlock, properties, dropProperties, null);
/*     */   }
/*     */   
/*     */   public static IProperty<?>[] joinProperties(IProperty[] a, IProperty[] b) {
/* 155 */     if ((b == null) || (b.length == 0)) { return a;
/*     */     }
/* 157 */     IProperty[] properties = new IProperty[a.length + b.length];
/*     */     
/* 159 */     System.arraycopy(a, 0, properties, 0, a.length);
/* 160 */     System.arraycopy(b, 0, properties, a.length, b.length);
/*     */     
/* 162 */     return properties;
/*     */   }
/*     */   
/*     */   protected IBlockState[] createBlockStateArray(ImmutableList<IBlockState> validStates) {
/* 166 */     return (IBlockState[])validStates.toArray(new IBlockState[validStates.size()]);
/*     */   }
/*     */   
/*     */   protected net.minecraft.block.state.BlockState.StateImplementation createState(Block block, ImmutableMap<IProperty, Comparable> properties, ImmutableMap<IUnlistedProperty<?>, Optional<?>> unlistedProperties)
/*     */   {
/* 171 */     return new XUBlockState(block, properties);
/*     */   }
/*     */   
/*     */   public IBlockState getStateFromMeta(XUBlock xuBlock, int meta) {
/* 175 */     if ((meta < 0) || (meta >= this.meta2state.length)) {
/* 176 */       return this.defaultState;
/*     */     }
/* 178 */     return this.meta2state[meta];
/*     */   }
/*     */   
/*     */   public int getMetaFromState(IBlockState state) {
/* 182 */     int i = this.state2meta.get(state);
/* 183 */     return i >= 0 ? i : 0;
/*     */   }
/*     */   
/*     */   public IBlockState getStateFromDropMeta(int meta)
/*     */   {
/* 188 */     if ((meta < 0) || (meta >= this.dropmeta2state.length)) {
/* 189 */       return this.defaultState;
/*     */     }
/* 191 */     return this.dropmeta2state[meta];
/*     */   }
/*     */   
/*     */   public int getDropMetaFromState(IBlockState state) {
/* 195 */     int i = this.state2dropMeta.get(state);
/* 196 */     return i >= 0 ? i : 0;
/*     */   }
/*     */   
/*     */   public IBlockState getStateFromItemStack(ItemStack item) {
/* 200 */     if (item == null) return this.defaultState;
/* 201 */     return getStateFromDropMeta(item.getItemDamage());
/*     */   }
/*     */   
/*     */   public static class Builder
/*     */   {
/* 206 */     final List<IProperty<? extends Comparable>> worldProperties = Lists.newArrayList();
/* 207 */     final List<IProperty<? extends Comparable>> dropProperties = Lists.newArrayList();
/* 208 */     final HashMap<IProperty, Comparable> defaultValues = Maps.newHashMap();
/*     */     final XUBlock block;
/*     */     
/*     */     public Builder(XUBlock block) {
/* 212 */       this.block = block;
/*     */     }
/*     */     
/*     */     public <T extends Comparable<T>> Builder addWorldPropertyWithDefault(IProperty<T> property, T value) {
/* 216 */       this.worldProperties.add(property);
/* 217 */       this.defaultValues.put(property, value);
/* 218 */       return this;
/*     */     }
/*     */     
/*     */     public <T extends Comparable<T>> Builder addDropPropertyWithDefault(IProperty<T> property, T value) {
/* 222 */       this.dropProperties.add(property);
/* 223 */       this.defaultValues.put(property, value);
/* 224 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addWorldProperties(IProperty<?>... properties) {
/* 228 */       Collections.addAll(this.worldProperties, properties);
/* 229 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addDropProperties(IProperty<?>... properties) {
/* 233 */       Collections.addAll(this.dropProperties, properties);
/* 234 */       return this;
/*     */     }
/*     */     
/*     */     public <T extends Comparable<T>> Builder setDefaultValue(IProperty<T> property, T value) {
/* 238 */       this.defaultValues.put(property, value);
/* 239 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addWorldProperties(Collection<IProperty<?>> properties)
/*     */     {
/* 244 */       this.worldProperties.addAll(properties);
/* 245 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addDropProperties(Collection<IProperty<?>> properties) {
/* 249 */       this.dropProperties.addAll(properties);
/* 250 */       return this;
/*     */     }
/*     */     
/*     */     public XUBlockStateCreator build()
/*     */     {
/* 255 */       IProperty<?>[] worldProperties = (IProperty[])this.worldProperties.toArray(new IProperty[this.worldProperties.size()]);
/* 256 */       IProperty<?>[] dropProperties = (IProperty[])this.dropProperties.toArray(new IProperty[this.dropProperties.size()]);
/* 257 */       return new XUBlockStateCreator(this.block, worldProperties, dropProperties, this.defaultValues.isEmpty() ? null : this.defaultValues);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUBlockStateCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */