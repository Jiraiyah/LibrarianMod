/*     */ package com.rwtema.extrautils2.backend.entries;
/*     */ 
/*     */ import com.google.common.cache.LoadingCache;
/*     */ import com.rwtema.extrautils2.achievements.AchievementHelper;
/*     */ import com.rwtema.extrautils2.backend.MultiBlockStateBuilder;
/*     */ import com.rwtema.extrautils2.blocks.BlockAngelBlock;
/*     */ import com.rwtema.extrautils2.blocks.BlockCursedEarth;
/*     */ import com.rwtema.extrautils2.blocks.BlockDecorativeGlass;
/*     */ import com.rwtema.extrautils2.blocks.BlockDecorativeGlass.DecorStates;
/*     */ import com.rwtema.extrautils2.blocks.BlockDecorativeSolid;
/*     */ import com.rwtema.extrautils2.blocks.BlockDecorativeSolid.DecorStates;
/*     */ import com.rwtema.extrautils2.blocks.BlockDecorativeSolidWood;
/*     */ import com.rwtema.extrautils2.blocks.BlockDecorativeSolidWood.DecorStates;
/*     */ import com.rwtema.extrautils2.blocks.BlockEnderLilly;
/*     */ import com.rwtema.extrautils2.blocks.BlockMoonStone;
/*     */ import com.rwtema.extrautils2.blocks.BlockPassiveGenerator;
/*     */ import com.rwtema.extrautils2.blocks.BlockPassiveGenerator.GeneratorTypes;
/*     */ import com.rwtema.extrautils2.blocks.BlockPlayerChest;
/*     */ import com.rwtema.extrautils2.blocks.BlockPowerOverload;
/*     */ import com.rwtema.extrautils2.blocks.BlockRedOrchid;
/*     */ import com.rwtema.extrautils2.blocks.BlockRedstoneClock;
/*     */ import com.rwtema.extrautils2.blocks.BlockResonator;
/*     */ import com.rwtema.extrautils2.blocks.BlockScreen;
/*     */ import com.rwtema.extrautils2.blocks.BlockSoundMuffler;
/*     */ import com.rwtema.extrautils2.blocks.BlockSpotlight;
/*     */ import com.rwtema.extrautils2.blocks.BlockTrashCan;
/*     */ import com.rwtema.extrautils2.blocks.BlockWardChunkLoader;
/*     */ import com.rwtema.extrautils2.crafting.AlwaysLast.XUShapedRecipeAlwaysLast;
/*     */ import com.rwtema.extrautils2.crafting.CraftingHelper;
/*     */ import com.rwtema.extrautils2.entity.EntityBoomerang;
/*     */ import com.rwtema.extrautils2.eventhandlers.ProddingStickHandler;
/*     */ import com.rwtema.extrautils2.eventhandlers.RareSeedHandler;
/*     */ import com.rwtema.extrautils2.items.ItemAngelRing;
/*     */ import com.rwtema.extrautils2.items.ItemBagOfHolding;
/*     */ import com.rwtema.extrautils2.items.ItemBlockPlantable;
/*     */ import com.rwtema.extrautils2.items.ItemBook;
/*     */ import com.rwtema.extrautils2.items.ItemBoomerang;
/*     */ import com.rwtema.extrautils2.items.ItemBuildersWand;
/*     */ import com.rwtema.extrautils2.items.ItemContract;
/*     */ import com.rwtema.extrautils2.items.ItemDestructionWand;
/*     */ import com.rwtema.extrautils2.items.ItemFakeCopy;
/*     */ import com.rwtema.extrautils2.items.ItemGlassCutter;
/*     */ import com.rwtema.extrautils2.items.ItemGoldenLasso;
/*     */ import com.rwtema.extrautils2.items.ItemIngredients;
/*     */ import com.rwtema.extrautils2.items.ItemIngredients.Type;
/*     */ import com.rwtema.extrautils2.items.ItemLawSword;
/*     */ import com.rwtema.extrautils2.items.ItemPowerManager;
/*     */ import com.rwtema.extrautils2.items.ItemSunCrystal;
/*     */ import com.rwtema.extrautils2.items.ItemWateringCan;
/*     */ import com.rwtema.extrautils2.items.ItemWrench;
/*     */ import com.rwtema.extrautils2.tile.TilePassiveGenerator;
/*     */ import com.rwtema.extrautils2.tile.TilePlayerChest;
/*     */ import com.rwtema.extrautils2.tile.TilePowerHandCrank;
/*     */ import com.rwtema.extrautils2.tile.TilePowerOverload;
/*     */ import com.rwtema.extrautils2.tile.TileResonator;
/*     */ import com.rwtema.extrautils2.tile.TileSpotlight;
/*     */ import com.rwtema.extrautils2.tile.TileTrashCan;
/*     */ import com.rwtema.extrautils2.transfernodes.BlockIndexer;
/*     */ import com.rwtema.extrautils2.transfernodes.BlockTransferHolder;
/*     */ import com.rwtema.extrautils2.transfernodes.BlockTransferPipe;
/*     */ import com.rwtema.extrautils2.transfernodes.ItemGrocket;
/*     */ import com.rwtema.extrautils2.transfernodes.ItemIndexerRemote;
/*     */ import com.rwtema.extrautils2.utils.helpers.DungeonHelper;
/*     */ import com.rwtema.extrautils2.worldgen.SingleChunkGen;
/*     */ import com.rwtema.extrautils2.worldgen.SingleChunkWorldGenManager;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Random;
/*     */ import java.util.WeakHashMap;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockDispenser;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
/*     */ import net.minecraft.dispenser.IBlockSource;
/*     */ import net.minecraft.dispenser.IPosition;
/*     */ import net.minecraft.entity.monster.EntityGhast;
/*     */ import net.minecraft.entity.passive.EntityBat;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.BlockPos.MutableBlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.RegistryDefaulted;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ import net.minecraft.world.chunk.IChunkProvider;
/*     */ import net.minecraft.world.gen.ChunkProviderEnd;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ 
/*     */ public class XU2Entries
/*     */ {
/*  94 */   public static final IItemStackMaker magical_wood = BlockDecorativeSolidWood.DecorStates.magical_wood;
/*  95 */   public static final IItemStackMaker redstoneCrystal = ItemIngredients.Type.REDSTONE_CRYSTAL;
/*  96 */   public static final IItemStackMaker stoneburnt = BlockDecorativeSolid.DecorStates.stoneburnt;
/*  97 */   public static ItemEntry<ItemWateringCan> wateringCan = new ItemClassEntry(ItemWateringCan.class)
/*     */   {
/*     */     public void addRecipes() {
/* 100 */       addShaped(newStackLowestDamage(), new Object[] { "S  ", "SBS", " S ", Character.valueOf('S'), Blocks.stone, Character.valueOf('B'), Items.bowl });
/*     */     }
/*     */   };
/* 103 */   public static ItemEntry<ItemDestructionWand> destructionWand = new ItemEntry("ItemDestructionWand")
/*     */   {
/*     */     public ItemDestructionWand initValue() {
/* 106 */       return new ItemDestructionWand(this.name.toLowerCase().substring(4), this.name, new float[] { 0.95686275F, 0.9019608F, 0.30588236F }, 9);
/*     */     }
/*     */     
/*     */     public void addAchievements()
/*     */     {
/* 111 */       AchievementHelper.addAchievement("Destruction Wand", "Breaks blocks", this, XU2Entries.buildersWand);
/*     */     }
/*     */     
/*     */ 
/*     */     public void addRecipes()
/*     */     {
/* 117 */       CraftingHelper.addShaped(newStack(), new Object[] { " GG", " WG", "W  ", Character.valueOf('W'), XU2Entries.magical_wood, Character.valueOf('G'), "ingotGold" });
/*     */     }
/*     */   };
/* 120 */   public static ItemEntry<ItemDestructionWand> creativeDestructionWand = new ItemEntry("ItemCreativeDestructionWand")
/*     */   {
/*     */     public ItemDestructionWand initValue() {
/* 123 */       return new ItemDestructionWand(this.name.toLowerCase().substring(4), this.name, new float[] { 0.99215686F, 0.5921569F, 0.15294118F }, 49);
/*     */     }
/*     */   };
/* 126 */   public static ItemEntry<ItemBuildersWand> buildersWand = new ItemEntry("ItemBuildersWand")
/*     */   {
/*     */     public ItemBuildersWand initValue() {
/* 129 */       return new ItemBuildersWand(this.name, 9, this.name.toLowerCase().substring(4), new float[] { 0.95686275F, 0.9019608F, 0.30588236F });
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 134 */       CraftingHelper.addShaped(newStack(), new Object[] { "  G", " W ", "W  ", Character.valueOf('W'), XU2Entries.magical_wood, Character.valueOf('G'), "ingotGold" });
/*     */     }
/*     */     
/*     */     public void addAchievements()
/*     */     {
/* 139 */       AchievementHelper.addAchievement("Builders Wand", "Places blocks on blocks", this, XU2Entries.magical_wood);
/*     */     }
/*     */   };
/* 142 */   public static ItemEntry<ItemBuildersWand> creativeBuildersWand = new ItemEntry("ItemCreativeBuildersWand")
/*     */   {
/*     */     public ItemBuildersWand initValue() {
/* 145 */       return new ItemBuildersWand(this.name, 49, "creativebuilderswand", new float[] { 0.99215686F, 0.5921569F, 0.15294118F });
/*     */     }
/*     */   };
/* 148 */   public static BlockClassEntry<BlockSoundMuffler> soundMuffler = new BlockClassEntry(BlockSoundMuffler.class, new Class[] { com.rwtema.extrautils2.tile.TileSoundMuffler.class })
/*     */   {
/*     */     public void addRecipes() {
/* 151 */       addShapeless((Block)this.value, new Object[] { Blocks.wool, Blocks.noteblock });
/*     */     }
/*     */   };
/* 154 */   public static BlockEntry<BlockEnderLilly> blockEnderLilly = new BlockClassEntry(BlockEnderLilly.class, new Class[0]) {
/* 155 */     final IBlockState target = Blocks.end_stone.getDefaultState();
/*     */     
/*     */     public void postInit()
/*     */     {
/* 159 */       RareSeedHandler.register(newStack(1), 0.0078125D);
/* 160 */       DungeonHelper.addDungeonItem(newStack(5), 1, 3, "dungeonChest", 0.03D);
/* 161 */       SingleChunkWorldGenManager.register(new SingleChunkGen("EnderLillies", 0)
/*     */       {
/*     */         public void genChunk(Chunk chunk, IChunkProvider provider, Random random) {
/* 164 */           if (!(provider instanceof ChunkProviderEnd)) {
/* 165 */             return;
/*     */           }
/* 167 */           BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
/*     */           
/* 169 */           int dx = random.nextInt(16);
/* 170 */           int dz = random.nextInt(16);
/* 171 */           int dy = chunk.getHeightValue(dx, dz) - 1;
/* 172 */           if (dy <= 0) return;
/* 173 */           pos.set(dx, dy, dz);
/* 174 */           IBlockState blockState = chunk.getBlockState(pos);
/* 175 */           if (blockState == XU2Entries.7.this.target) {
/* 176 */             pos.set(dx, dy + 1, dz);
/* 177 */             if (isAir(chunk, pos)) {
/* 178 */               setBlockState(chunk, pos, ((BlockEnderLilly)XU2Entries.7.this.value).FULLY_GROWN_STATE);
/*     */             }
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/* 154 */   }.setItemClass(ItemBlockPlantable.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */   public static BlockEntry<BlockDecorativeSolidWood> decorativeSolidWood = new BlockClassEntry(BlockDecorativeSolidWood.class, new Class[0])
/*     */   {
/*     */     public void addAchievements() {
/* 189 */       AchievementHelper.addAchievement("Magical Wood", "*snicker*", XU2Entries.magical_wood, null);
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 194 */       for (BlockDecorativeSolidWood.DecorStates decorState : ) {
/* 195 */         decorState.addRecipes();
/*     */       }
/*     */     }
/*     */   };
/* 199 */   public static BlockEntry<BlockTrashCan> trashCan = new BlockClassEntry(BlockTrashCan.class, new Class[] { TileTrashCan.class })
/*     */   {
/*     */     public void addRecipes() {
/* 202 */       addShaped((Block)this.value, new Object[] { "SSS", "CcC", "CCC", Character.valueOf('S'), "stone", Character.valueOf('C'), "cobblestone", Character.valueOf('c'), Blocks.chest });
/*     */     }
/*     */   };
/* 205 */   public static BlockEntry<BlockAngelBlock> angelBlock = new BlockEntry("AngelBlock", new Class[0])
/*     */   {
/*     */     public BlockAngelBlock initValue()
/*     */     {
/* 209 */       return new BlockAngelBlock();
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 214 */       addShaped(newStack(1), new Object[] { " G ", "WOW", Character.valueOf('G'), "ingotGold", Character.valueOf('W'), Items.feather, Character.valueOf('O'), Blocks.obsidian });
/*     */     }
/* 205 */   }.setItemClass(com.rwtema.extrautils2.items.ItemAngelBlock.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 217 */   public static BlockEntry<BlockPassiveGenerator> passiveGenerator = new BlockClassEntry(BlockPassiveGenerator.class, new Class[] { TilePassiveGenerator.class, TilePowerHandCrank.class })
/*     */   {
/*     */     public void addRecipes() {
/* 220 */       for (BlockPassiveGenerator.GeneratorTypes generatorTypes : ) {
/* 221 */         generatorTypes.addRecipe();
/*     */       }
/*     */     }
/*     */     
/*     */     public void addAchievements()
/*     */     {
/* 227 */       for (BlockPassiveGenerator.GeneratorTypes generatorTypes : ) {
/* 228 */         generatorTypes.registerAchievements();
/*     */       }
/*     */     }
/*     */   };
/* 232 */   public static BlockClassEntry<BlockCursedEarth> cursedEarth = new BlockClassEntry(BlockCursedEarth.class, new Class[0]);
/* 233 */   public static BlockClassEntry<BlockRedstoneClock> redstoneClock = new BlockClassEntry(BlockRedstoneClock.class, new Class[0])
/*     */   {
/*     */     public void addRecipes() {
/* 236 */       addShaped((Block)this.value, new Object[] { "SRS", "RTR", "SRS", Character.valueOf('S'), "stone", Character.valueOf('T'), Blocks.redstone_torch, Character.valueOf('R'), Items.redstone });
/*     */     }
/*     */   };
/* 239 */   public static ItemClassEntry<ItemGoldenLasso> goldenLasso = new ItemClassEntry(ItemGoldenLasso.class)
/*     */   {
/*     */     public void addAchievements() {
/* 242 */       AchievementHelper.addAchievement("Golden Lasso", "Animal Transport", getOreDicMaker(), XU2Entries.magical_wood);
/* 243 */       AchievementHelper.addAchievement("Cursed Lasso", "Evil Monster Capture", getMetaMaker(1), getOreDicMaker());
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 248 */       addShaped(newStack(1, 0), new Object[] { "gsg", "ses", "gsg", Character.valueOf('s'), Items.string, Character.valueOf('g'), "nuggetGold", Character.valueOf('e'), Items.ender_pearl });
/* 249 */       addShapeless(newStack(1, 1), new Object[] { newStack(1, 0), new ItemStack(Items.skull, 1, 1) });
/*     */     }
/*     */   };
/* 252 */   public static BlockCompressedEntry compressedCobblestone = new BlockCompressedEntry(Blocks.cobblestone, "cobblestone", 8);
/* 253 */   public static BlockCompressedEntry compressedDirt = new BlockCompressedEntry(Blocks.dirt, "dirt", 4);
/* 254 */   public static BlockCompressedEntry compressedSand = new BlockCompressedEntry(Blocks.sand, "sand", 2);
/* 255 */   public static BlockCompressedEntry compressedGravel = new BlockCompressedEntry(Blocks.gravel, "gravel", 2);
/* 256 */   public static BlockCompressedEntry compressedNetherack = new BlockCompressedEntry(Blocks.netherrack, "netherrack", 6);
/* 257 */   public static BlockEntry<BlockSpotlight> blockSpotlight = new BlockClassEntry(BlockSpotlight.class, new Class[] { TileSpotlight.class })
/*     */   {
/*     */     public void addAchievements() {
/* 260 */       AchievementHelper.addAchievement("Spotlight", "Shine light across the world", this, XU2Entries.sunCrystal);
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 265 */       CraftingHelper.addShaped(newStack(8), new Object[] { Boolean.valueOf(true), "BBB", "GRB", "BBB", Character.valueOf('G'), XU2Entries.sunCrystal.newStack(1), Character.valueOf('R'), XU2Entries.redstoneCrystal.newStack(), Character.valueOf('B'), XU2Entries.stoneburnt });
/*     */     }
/*     */   };
/* 268 */   public static ItemClassEntry<ItemFakeCopy> itemFakeCopy = new ItemClassEntry(ItemFakeCopy.class);
/* 269 */   public static ItemClassEntry<ItemGlassCutter> itemGlassCutter = new ItemClassEntry(ItemGlassCutter.class)
/*     */   {
/*     */     public void addRecipes() {
/* 272 */       addShaped((Item)this.value, new Object[] { "  i", " si", "i  ", Character.valueOf('s'), "stickWood", Character.valueOf('i'), "ingotIron" });
/*     */     }
/*     */   };
/* 275 */   public static ItemEnderShardEntry itemEnderShard = new ItemEnderShardEntry();
/* 276 */   public static BlockEntry<BlockRedOrchid> blockRedOrchid = new BlockClassEntry(BlockRedOrchid.class, new Class[0])
/*     */   {
/*     */     public void postInit() {
/* 279 */       SingleChunkWorldGenManager.register(new SingleChunkGen("RedOrchid", 0)
/*     */       {
/*     */         public void genChunk(Chunk chunk, IChunkProvider provider, Random random) {
/* 282 */           BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
/*     */           
/* 284 */           for (int i = 0; i < 256; i++) {
/* 285 */             int dx = random.nextInt(16);
/* 286 */             int dz = random.nextInt(16);
/* 287 */             int dy = 1 + random.nextInt(32);
/*     */             
/* 289 */             pos.set(dx, dy, dz);
/*     */             
/* 291 */             Block block = chunk.getBlockState(pos).getBlock();
/* 292 */             if ((block == Blocks.redstone_ore) || (block == Blocks.lit_redstone_ore)) {
/* 293 */               for (int j = 1; j < 3; j++)
/*     */               {
/* 295 */                 pos.set(dx, dy + j, dz);
/* 296 */                 block = chunk.getBlockState(pos).getBlock();
/* 297 */                 if (block == Blocks.air) {
/* 298 */                   report(chunk, dx, dy, dz);
/*     */                   
/* 300 */                   setBlockState(chunk, pos, ((BlockRedOrchid)XU2Entries.16.this.value).FULLY_GROWN_STATE);
/*     */                 } else {
/* 302 */                   if ((block != Blocks.redstone_ore) && (block != Blocks.lit_redstone_ore))
/*     */                     break;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 309 */       });
/* 310 */       RareSeedHandler.register(newStack(1), 0.015625D);
/* 311 */       DungeonHelper.addDungeonItem(newStack(5), 2, 5, "dungeonChest", 0.05D);
/*     */     }
/* 276 */   }.setItemClass(ItemBlockPlantable.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 314 */   public static VoidEntry additionalVanillaRecipes = new VoidEntry("additionalVanillaRecipes")
/*     */   {
/*     */     public void addRecipes() {
/* 317 */       CraftingHelper.addRecipe(new AlwaysLast.XUShapedRecipeAlwaysLast(new ItemStack(Blocks.chest, 4), new Object[] { "WWW", "W W", "WWW", Character.valueOf('W'), "logWood" }));
/* 318 */       CraftingHelper.addRecipe(new AlwaysLast.XUShapedRecipeAlwaysLast(new ItemStack(Items.stick, 16), new Object[] { "W", "W", Character.valueOf('W'), "logWood" }));
/*     */     }
/*     */   };
/* 321 */   public static ItemClassEntry<ItemLawSword> lawSword = new ItemClassEntry(ItemLawSword.class) {};
/*     */   
/*     */ 
/* 324 */   public static ItemEntrySickle[] sickles = { new ItemEntrySickle(0), new ItemEntrySickle(1), new ItemEntrySickle(2), new ItemEntrySickle(3), new ItemEntrySickle(4) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 331 */   public static ItemEntry<ItemAngelRing> angelRing = new ItemClassEntry(ItemAngelRing.class)
/*     */   {
/*     */     public void addRecipes() {
/* 334 */       Object[] leftWing = { "blockGlass", Items.feather, "dyePurple", Items.leather, "nuggetGold", new ItemStack(Items.coal, 1, 0) };
/* 335 */       Object[] rightWing = { "blockGlass", Items.feather, "dyePink", Items.leather, "nuggetGold", new ItemStack(Items.coal, 1, 1) };
/*     */       
/* 337 */       for (int i = 0; i < leftWing.length; i++) {
/* 338 */         addShaped(newStack(1, i), new Object[] { Boolean.valueOf(!com.google.common.base.Objects.equal(leftWing[i], rightWing[i]) ? 1 : false), "LGR", "GrG", "BGH", Character.valueOf('L'), leftWing[i], Character.valueOf('R'), rightWing[i], Character.valueOf('B'), ItemGoldenLasso.newCraftingStack(EntityBat.class), Character.valueOf('G'), "ingotGold", Character.valueOf('r'), XU2Entries.redstoneCrystal, Character.valueOf('H'), ItemGoldenLasso.newCraftingStack(EntityGhast.class) });
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 344 */         addShapeless(newStack(1, i), new Object[] { leftWing[i], newWildcardStack(), rightWing[i] });
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/* 350 */   public static BlockClassEntry<BlockScreen> blockScreen = new BlockClassEntry(BlockScreen.class, new Class[] { com.rwtema.extrautils2.tile.TileScreen.class })
/*     */   {
/*     */     public void loadAdditionalConfig(Configuration config) {
/* 353 */       BlockScreen.maxSize = 262144;
/*     */     }
/*     */     
/*     */     public void addAchievements()
/*     */     {
/* 358 */       AchievementHelper.addAchievement("Screen", "For you viewing pleasure", this, XU2Entries.stoneburnt);
/*     */     }
/*     */     
/*     */ 
/*     */     public void addRecipes()
/*     */     {
/* 364 */       CraftingHelper.addShaped(newStack(1), new Object[] { Boolean.valueOf(true), "BBB", "ERE", Character.valueOf('G'), XU2Entries.sunCrystal.newStack(), Character.valueOf('R'), XU2Entries.redstoneCrystal, Character.valueOf('B'), XU2Entries.stoneburnt, Character.valueOf('E'), XU2Entries.itemEnderShard.newStack() });
/*     */     }
/*     */   };
/* 367 */   public static BlockClassEntry<BlockPowerOverload> overload = new BlockClassEntry(BlockPowerOverload.class, new Class[] { TilePowerOverload.class });
/* 368 */   public static BlockClassEntry<BlockResonator> resonator = new BlockClassEntry(BlockResonator.class, new Class[] { TileResonator.class })
/*     */   {
/*     */     public void addAchievements() {
/* 371 */       AchievementHelper.addAchievement("Power Resonator", "Imbue energy to objects", this, BlockPassiveGenerator.GeneratorTypes.Solar);
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 376 */       addShaped(newStack(1), new Object[] { "RCR", "IcI", "III", Character.valueOf('I'), "ingotIron", Character.valueOf('R'), "dustRedstone", Character.valueOf('C'), "blockCoal", Character.valueOf('c'), XU2Entries.redstoneCrystal });
/*     */     }
/*     */   };
/* 379 */   public static ItemEntry<ItemSunCrystal> sunCrystal = new ItemClassEntry(ItemSunCrystal.class) {
/* 380 */     IItemStackMaker EMPTY_GEM = new IItemStackMaker()
/*     */     {
/*     */       public ItemStack newStack() {
/* 383 */         return XU2Entries.22.this.newStackLowestDamage();
/*     */       }
/*     */     };
/*     */     
/*     */     public void addAchievements()
/*     */     {
/* 389 */       AchievementHelper.addAchievement("Luminescent Potential", "Collect the suns rays", this.EMPTY_GEM, XU2Entries.resonator);
/* 390 */       AchievementHelper.addAchievement("Sun Crystal", "Light through walls", this, this.EMPTY_GEM);
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 395 */       addShapeless(newStackLowestDamage(), new Object[] { "gemDiamond", "dustGlowstone", "dustGlowstone", "dustGlowstone", "dustGlowstone" });
/*     */     }
/*     */   };
/* 398 */   public static BlockEntry<BlockDecorativeSolid> decorativeSolid = new BlockClassEntry(BlockDecorativeSolid.class, new Class[0])
/*     */   {
/*     */     public void addAchievements() {
/* 401 */       AchievementHelper.addAchievement("Powered Stone", "Stone that conducts intense amounts of energy", XU2Entries.stoneburnt, XU2Entries.resonator);
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 406 */       for (BlockDecorativeSolid.DecorStates decorState : ) {
/* 407 */         decorState.addRecipes();
/*     */       }
/*     */     }
/*     */     
/*     */     public void postInit()
/*     */     {
/* 413 */       if (XU2Entries.blockEnderLilly.enabled) {
/* 414 */         BlockEnderLilly.end_stone_states.add(((BlockDecorativeSolid)this.value).getDefaultState().withProperty(BlockDecorativeSolid.decor, BlockDecorativeSolid.DecorStates.endstone));
/*     */       }
/*     */     }
/*     */   };
/* 418 */   public static ItemClassEntry<ItemIngredients> itemIngredients = new ItemClassEntry(ItemIngredients.class)
/*     */   {
/*     */     public void addAchievements() {
/* 421 */       for (ItemIngredients.Type type : ) {
/* 422 */         type.addAchievement();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void addRecipes()
/*     */     {
/* 431 */       for (ItemIngredients.Type type : ) {
/* 432 */         type.addRecipes();
/*     */       }
/*     */     }
/*     */   };
/* 436 */   public static ItemClassEntry<ItemPowerManager> powerManager = new ItemClassEntry(ItemPowerManager.class)
/*     */   {
/*     */     public void addRecipes() {
/* 439 */       addShaped(newStack(1), new Object[] { " c", "ss", "ss", Character.valueOf('s'), "stone", Character.valueOf('c'), XU2Entries.redstoneCrystal });
/*     */     }
/*     */   };
/* 442 */   public static ItemClassEntry<ItemBagOfHolding> bagOfHolding = new ItemClassEntry(ItemBagOfHolding.class)
/*     */   {
/*     */     public void addRecipes() {
/* 445 */       addShaped(newStack(), new Object[] { "ggg", "cBc", "ggg", Character.valueOf('g'), "ingotGold", Character.valueOf('c'), Blocks.chest, Character.valueOf('B'), XU2Entries.magical_wood });
/*     */     }
/*     */   };
/* 448 */   public static BlockClassEntry<BlockDecorativeGlass> decorativeGlass = new BlockClassEntry(BlockDecorativeGlass.class, new Class[0])
/*     */   {
/*     */     public void addAchievements() {
/* 451 */       AchievementHelper.addAchievement("Powered Glass", "Glass that gives off energy", BlockDecorativeGlass.DecorStates.glass_redstone, XU2Entries.resonator);
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 456 */       for (BlockDecorativeGlass.DecorStates decorState : ) {
/* 457 */         decorState.addRecipes();
/*     */       }
/*     */     }
/*     */   };
/* 461 */   public static VoidEntry proddingStick = new VoidEntry("WoodenStickPoke")
/*     */   {
/*     */     public void postInit() {}
/*     */   };
/*     */   
/*     */ 
/* 467 */   public static BlockClassEntry<BlockMoonStone> moonStone = (BlockClassEntry)new BlockClassEntry(BlockMoonStone.class, new Class[0])
/*     */   {
/*     */     public void postInit() {
/* 470 */       SingleChunkWorldGenManager.register(new SingleChunkGen("MoonStone", 0) {
/* 471 */         public IBlockState defaultState = ((BlockMoonStone)XU2Entries.29.this.value).getDefaultState();
/*     */         
/*     */         public void genChunk(Chunk chunk, IChunkProvider provider, Random random)
/*     */         {
/* 475 */           for (int i = 0; i < 4; i++) {
/* 476 */             int dx = 1 + random.nextInt(14);
/* 477 */             int dy = 1 + random.nextInt(64);
/* 478 */             int dz = 1 + random.nextInt(14);
/*     */             
/* 480 */             BlockPos pos = new BlockPos(dx, dy, dz);
/*     */             
/* 482 */             if (chunk.getBlockState(pos) == BlockMoonStone.mimicState) {
/* 483 */               for (EnumFacing facing : EnumFacing.values()) {
/* 484 */                 if (isAir(chunk, pos, facing)) {
/* 485 */                   setBlockState(chunk, pos, this.defaultState);
/* 486 */                   return;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/* 467 */   }.setItemClass(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 497 */   public static MultiBlockEntry<BlockTransferPipe> pipe = new MultiBlockEntry(BlockTransferPipe.stateBuilder, "pipe")
/*     */   {
/*     */     public void addAchievements() {
/* 500 */       AchievementHelper.addAchievement("Pipes!", "Point to Point Transport", this, XU2Entries.resonator);
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 505 */       addShaped(newStack(64), new Object[] { "SSS", "GRG", "SSS", Character.valueOf('S'), new ItemStack(Blocks.stone_slab), Character.valueOf('G'), "blockGlass", Character.valueOf('R'), "dustRedstone" });
/*     */     }
/* 497 */   }.setItemBlockClass(com.rwtema.extrautils2.transfernodes.ItemBlockPipe.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 512 */   public static BlockEntry<BlockTransferHolder> holder = new BlockClassEntry(BlockTransferHolder.class, new Class[] { com.rwtema.extrautils2.transfernodes.TileTransferHolder.class })
/*     */   {
/*     */     public String getConfigLabel() {
/* 515 */       return XU2Entries.pipe.getConfigLabel();
/*     */     }
/* 512 */   }.setItemClass(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 518 */   public static ItemClassEntry<ItemGrocket> grocket = new ItemClassEntry(ItemGrocket.class)
/*     */   {
/*     */     public void addRecipes() {
/* 521 */       CraftingHelper.addShaped(newStack(1, 0), new Object[] { "RPR", "SCS", Character.valueOf('P'), XU2Entries.pipe, Character.valueOf('R'), "dustRedstone", Character.valueOf('S'), "stone", Character.valueOf('C'), XU2Entries.redstoneCrystal });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void addAchievements()
/*     */     {
/* 532 */       AchievementHelper.addAchievement("Transfer Nodes", "Simple Item Management", (IItemStackMaker)this.metaCache.getUnchecked(Integer.valueOf(0)), XU2Entries.pipe);
/*     */     }
/*     */     
/*     */     public String getConfigLabel()
/*     */     {
/* 537 */       return XU2Entries.pipe.getConfigLabel();
/*     */     }
/*     */   };
/* 540 */   public static BlockClassEntry<BlockPlayerChest> playerChest = new BlockClassEntry(BlockPlayerChest.class, new Class[] { TilePlayerChest.class })
/*     */   {
/*     */     public void addRecipes() {
/* 543 */       addShaped((Block)this.value, new Object[] { "SSS", "SCS", "ScS", Character.valueOf('S'), XU2Entries.stoneburnt, Character.valueOf('C'), Blocks.ender_chest, Character.valueOf('c'), XU2Entries.redstoneCrystal });
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 550 */   public static ItemClassEntry<ItemWrench> wrench = new ItemClassEntry(ItemWrench.class)
/*     */   {
/*     */     public void addAchievements() {
/* 553 */       AchievementHelper.addAchievement("Wrench", "Wrench it!", this, null);
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 558 */       addShaped(newStack(1), new Object[] { " RS", " Sr", "S  ", Character.valueOf('S'), "ingotIron", Character.valueOf('R'), "dyeRed", Character.valueOf('r'), "dustRedstone" });
/*     */     }
/*     */   };
/* 561 */   public static ItemClassEntry<ItemBoomerang> boomerang = new ItemClassEntry(ItemBoomerang.class)
/*     */   {
/*     */     public void addAchievements() {
/* 564 */       AchievementHelper.addAchievement("Boomerang", "It returns", this, XU2Entries.magical_wood);
/*     */     }
/*     */     
/*     */     public void addRecipes()
/*     */     {
/* 569 */       addShaped(newStack(1), new Object[] { " W ", "W W", Character.valueOf('W'), XU2Entries.magical_wood });
/*     */     }
/*     */     
/*     */     public void postInit()
/*     */     {
/* 574 */       BlockDispenser.dispenseBehaviorRegistry.putObject(this.value, new BehaviorDefaultDispenseItem()
/*     */       {
/*     */         public ItemStack dispenseStack(IBlockSource source, ItemStack stack) {
/* 577 */           World world = source.getWorld();
/* 578 */           TileEntity tile = source.getBlockTileEntity();
/* 579 */           if (tile == null) { return stack;
/*     */           }
/* 581 */           WeakReference<EntityBoomerang> reference = (WeakReference)EntityBoomerang.getBoomerangOwners(world).get(tile);
/*     */           EntityBoomerang t;
/* 583 */           if ((reference != null) && ((t = (EntityBoomerang)reference.get()) != null) && (!t.isDead)) { return stack;
/*     */           }
/* 585 */           IPosition position = BlockDispenser.getDispensePosition(source);
/* 586 */           EnumFacing direction = BlockDispenser.getFacing(source.getBlockMetadata());
/*     */           
/* 588 */           EntityBoomerang boomerang = new EntityBoomerang(world, position.getX(), position.getY(), position.getZ(), tile);
/* 589 */           boomerang.setThrowableHeading(direction.getFrontOffsetX(), direction.getFrontOffsetY(), direction.getFrontOffsetZ(), 0.75F, 4.0F);
/*     */           
/* 591 */           world.spawnEntityInWorld(boomerang);
/*     */           
/* 593 */           return stack;
/*     */         }
/*     */         
/*     */         protected void playDispenseSound(IBlockSource source) {
/* 597 */           source.getWorld().playAuxSFX(1002, source.getBlockPos(), 0);
/*     */         }
/*     */       });
/*     */     }
/*     */   };
/* 602 */   public static ItemClassEntry<ItemBook> book = new ItemClassEntry(ItemBook.class)
/*     */   {
/*     */     public void addRecipes() {
/* 605 */       CraftingHelper.addShapeless(newStack(1), new Object[] { com.google.common.collect.ImmutableList.of(Items.book, Items.writable_book, Items.written_book), "ingotGold", Blocks.obsidian });
/*     */     }
/*     */   };
/* 608 */   public static BlockClassEntry<BlockIndexer> indexer = new BlockClassEntry(BlockIndexer.class, new Class[] { com.rwtema.extrautils2.transfernodes.TileIndexer.class })
/*     */   {
/*     */     public void addRecipes() {
/* 611 */       addShaped((Block)this.value, new Object[] { "SCS", "SsS", "SCS", Character.valueOf('S'), XU2Entries.stoneburnt, Character.valueOf('C'), ItemIngredients.Type.EYE_REDSTONE, Character.valueOf('s'), XU2Entries.blockScreen });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void addAchievements()
/*     */     {
/* 620 */       AchievementHelper.addAchievement("Indexer", "Item Retrieval", this, XU2Entries.grocket.getMetaMaker(0));
/*     */     }
/*     */   };
/* 623 */   public static ItemClassEntry<ItemIndexerRemote> indexerRemote = new ItemClassEntry(ItemIndexerRemote.class)
/*     */   {
/*     */     public void addRecipes() {
/* 626 */       addShaped((Item)this.value, new Object[] { "SCS", "SsS", "SCS", Character.valueOf('S'), "stone", Character.valueOf('C'), XU2Entries.redstoneCrystal, Character.valueOf('s'), XU2Entries.blockScreen.newStack() });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void addAchievements()
/*     */     {
/* 635 */       AchievementHelper.addAchievement("Remote Indexing", "Item Retrieval at distance", this, XU2Entries.indexer);
/*     */     }
/*     */   };
/* 638 */   public static VoidEntry throwEnderPearlsInCreative = new VoidEntry("throwEnderPearlsInCreative")
/*     */   {
/*     */     public void postInit() {}
/*     */   };
/*     */   
/*     */ 
/* 644 */   public static ItemClassEntry<ItemContract> contract = new ItemClassEntry(ItemContract.class)
/*     */   {
/*     */     public void addRecipes() {
/* 647 */       CraftingHelper.addShapeless(newStack(1), new Object[] { Items.feather, Items.paper, Items.glass_bottle, "dyeBlack" });
/*     */     }
/*     */     
/*     */     public void addAchievements()
/*     */     {
/* 652 */       AchievementHelper.addAchievement("Villager Contract", "Head of Villager Soul Resources", this, XU2Entries.goldenLasso.getOreDicMaker());
/*     */     }
/*     */   };
/* 655 */   public static BlockClassEntry<BlockWardChunkLoader> ward_chunkloader = new BlockClassEntry("ChunkLoader", BlockWardChunkLoader.class, new Class[] { com.rwtema.extrautils2.tile.TileChunkLoader.class })
/*     */   {
/*     */     public void addRecipes() {
/* 658 */       CraftingHelper.addShaped(newStack(1), new Object[] { "SES", "SLS", " S ", Character.valueOf('S'), "stickWood", Character.valueOf('E'), ItemIngredients.Type.EYE_REDSTONE.newStack(1), Character.valueOf('L'), ItemGoldenLasso.newCraftingVillagerStack(true, null) });
/*     */     }
/*     */     
/*     */     public void addAchievements()
/*     */     {
/* 663 */       AchievementHelper.addAchievement("Chunk Loader", "Persistence", this, XU2Entries.contract);
/*     */     }
/*     */   };
/*     */   
/*     */   public static void init() {}
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\XU2Entries.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */