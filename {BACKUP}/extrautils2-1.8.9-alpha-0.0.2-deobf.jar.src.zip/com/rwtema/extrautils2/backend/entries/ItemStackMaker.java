/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import com.google.common.cache.CacheBuilder;
/*    */ import com.google.common.cache.LoadingCache;
/*    */ import com.rwtema.extrautils2.utils.datastructures.ItemRef;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemStackMaker
/*    */ {
/* 11 */   private final LoadingCache<ItemRef, IItemStackMaker> cache = CacheBuilder.newBuilder().build(new com.google.common.cache.CacheLoader()
/*    */   {
/*    */     public IItemStackMaker load(@Nonnull final ItemRef key) throws Exception {
/* 14 */       new IItemStackMaker()
/*    */       {
/*    */         public ItemStack newStack() {
/* 17 */           return key.createItemStack(1);
/*    */         }
/*    */       };
/*    */     }
/* 11 */   });
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IItemStackMaker of(ItemStack stack)
/*    */   {
/* 24 */     return (IItemStackMaker)this.cache.getUnchecked(ItemRef.wrap(stack));
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\ItemStackMaker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */