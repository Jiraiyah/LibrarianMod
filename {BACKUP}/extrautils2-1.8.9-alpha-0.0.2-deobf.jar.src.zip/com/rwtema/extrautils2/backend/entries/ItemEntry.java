/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.IXUItem;
/*    */ import com.rwtema.extrautils2.backend.XUItem;
/*    */ import java.util.List;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*    */ 
/*    */ public abstract class ItemEntry<T extends Item> extends Entry<T> implements IItemStackMaker
/*    */ {
/*    */   public ItemEntry(String name)
/*    */   {
/* 14 */     super(name);
/*    */   }
/*    */   
/*    */   public void preInitRegister()
/*    */   {
/* 19 */     if ("item.null".equals(((Item)this.value).getUnlocalizedName()))
/* 20 */       ((Item)this.value).setUnlocalizedName("ExtraUtils2:" + this.name);
/* 21 */     if ((this.value instanceof XUItem)) {
/* 22 */       ((XUItem)this.value).entry = this;
/*    */     }
/* 24 */     else if ((this.value instanceof IXUItem)) {
/* 25 */       XUItem.items.add((IXUItem)this.value);
/*    */     }
/*    */     
/* 28 */     GameRegistry.registerItem((Item)this.value, this.name);
/*    */   }
/*    */   
/*    */   public ItemStack newStack(int amount, int meta)
/*    */   {
/* 33 */     if (this.value == null) return null;
/* 34 */     return new ItemStack((Item)this.value, amount, meta);
/*    */   }
/*    */   
/*    */   public ItemStack newStackLowestDamage() {
/* 38 */     return newStack(1, ((Item)this.value).getMaxDamage());
/*    */   }
/*    */   
/*    */   public ItemStack newWildcardStack() {
/* 42 */     return newStack(1, 32767);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\ItemEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */