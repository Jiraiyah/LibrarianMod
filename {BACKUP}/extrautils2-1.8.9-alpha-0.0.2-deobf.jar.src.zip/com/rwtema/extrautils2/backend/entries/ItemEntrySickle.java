/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import com.rwtema.extrautils2.items.ItemSickle;
/*    */ 
/*    */ public class ItemEntrySickle extends ItemEntry<ItemSickle> {
/*  6 */   public static final Object[] MATERIALS = { "plankWood", "cobblestone", "ingotIron", "ingotGold", "gemDiamond" };
/*    */   
/*    */ 
/*    */ 
/*    */   private final int type;
/*    */   
/*    */ 
/*    */ 
/*    */   public ItemEntrySickle(int type)
/*    */   {
/* 16 */     super(ItemSickle.TYPE_NAMES[type]);
/* 17 */     this.type = type;
/*    */   }
/*    */   
/*    */   public ItemSickle initValue()
/*    */   {
/* 22 */     return new ItemSickle(this.type);
/*    */   }
/*    */   
/*    */   public void addRecipes()
/*    */   {
/* 27 */     addShaped(newStack(1), new Object[] { " GG", "  G", "SGG", Character.valueOf('G'), MATERIALS[this.type], Character.valueOf('S'), "stickWood" });
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\ItemEntrySickle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */