/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import com.rwtema.extrautils2.backend.XUBlock;
/*    */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*    */ import com.rwtema.extrautils2.tile.tesr.ITESRHook;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*    */ 
/*    */ public abstract class BlockEntry<T extends XUBlock> extends Entry<T> implements IItemStackMaker
/*    */ {
/*    */   public Class<? extends TileEntity>[] teClazzes;
/* 17 */   public Class<? extends ItemBlock> itemClass = com.rwtema.extrautils2.backend.XUItemBlock.class;
/*    */   
/*    */   public BlockEntry(String name, Class<? extends TileEntity>... teClazzes) {
/* 20 */     super(name);
/* 21 */     this.teClazzes = teClazzes;
/*    */   }
/*    */   
/*    */   public <K extends BlockEntry<T>> K setItemClass(Class<? extends ItemBlock> clazz) {
/* 25 */     this.itemClass = clazz;
/* 26 */     return this;
/*    */   }
/*    */   
/*    */   public void preInitRegister()
/*    */   {
/* 31 */     ((XUBlock)this.value).setBlockName("ExtraUtils2:" + this.name);
/*    */     
/* 33 */     GameRegistry.registerBlock((Block)this.value, this.itemClass, this.name);
/* 34 */     for (Class<? extends TileEntity> teClazz : this.teClazzes) {
/* 35 */       registerTile(teClazz);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void registerTile(Class<? extends TileEntity> teClazz)
/*    */   {
/* 41 */     if (ITESRHook.class.isAssignableFrom(teClazz)) {
/* 42 */       ExtraUtils2.proxy.registerTESR(teClazz);
/*    */     }
/* 44 */     GameRegistry.registerTileEntity(teClazz, "XU2:" + teClazz.getSimpleName());
/*    */   }
/*    */   
/*    */   public ItemStack newStack(int amount, int meta)
/*    */   {
/* 49 */     if ((this.value == null) || (this.itemClass == null)) { return null;
/*    */     }
/* 51 */     return new ItemStack((Block)this.value, amount, meta);
/*    */   }
/*    */   
/*    */   public ItemStack newStack(int amount, IBlockState state) {
/* 55 */     if ((this.value == null) || (this.itemClass == null)) return null;
/* 56 */     return newStack(amount, ((XUBlock)this.value).xuBlockState.getDropMetaFromState(state));
/*    */   }
/*    */   
/*    */   public ItemStack newStack(int amount, Object... properties) {
/* 60 */     if ((this.value == null) || (this.itemClass == null)) return null;
/* 61 */     IBlockState state = ((XUBlock)this.value).getDefaultState();
/* 62 */     for (int i = 0; i < properties.length; i += 2) {
/* 63 */       state = state.withProperty((net.minecraft.block.properties.IProperty)properties[i], (Comparable)properties[(i + 1)]);
/*    */     }
/* 65 */     return newStack(amount, state);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\BlockEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */