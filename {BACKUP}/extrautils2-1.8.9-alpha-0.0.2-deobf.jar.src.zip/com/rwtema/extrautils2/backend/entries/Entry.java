/*     */ package com.rwtema.extrautils2.backend.entries;
/*     */ 
/*     */ import com.google.common.cache.CacheBuilder;
/*     */ import com.google.common.cache.CacheLoader;
/*     */ import com.google.common.cache.LoadingCache;
/*     */ import com.rwtema.extrautils2.crafting.CraftingHelper;
/*     */ import com.rwtema.extrautils2.crafting.XUShapedRecipe;
/*     */ import com.rwtema.extrautils2.crafting.XUShapelessRecipe;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ 
/*     */ public abstract class Entry<T>
/*     */   implements IItemStackMaker
/*     */ {
/*     */   public final String name;
/*  22 */   public final LoadingCache<Integer, IItemStackMaker> metaCache = CacheBuilder.newBuilder().initialCapacity(1).build(new CacheLoader()
/*     */   {
/*     */     public IItemStackMaker load(@Nonnull final Integer key) throws Exception {
/*  25 */       if (key.intValue() == 0) { return Entry.this;
/*     */       }
/*  27 */       new IItemStackMaker()
/*     */       {
/*     */         public ItemStack newStack() {
/*  30 */           return Entry.this.newStack(1, key.intValue());
/*     */         }
/*     */       };
/*     */     }
/*  22 */   });
/*     */   
/*     */ 
/*     */   public T value;
/*     */   
/*     */ 
/*     */   public String[] dependencies;
/*     */   
/*     */ 
/*     */   public boolean enabled;
/*     */   
/*     */ 
/*     */ 
/*     */   public IItemStackMaker getMetaMaker(int meta)
/*     */   {
/*  37 */     return (IItemStackMaker)this.metaCache.getUnchecked(Integer.valueOf(meta));
/*     */   }
/*     */   
/*     */   public IItemStackMaker getOreDicMaker() {
/*  41 */     return (IItemStackMaker)this.metaCache.getUnchecked(Integer.valueOf(32767));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  47 */   public List<IRecipe> recipes = new ArrayList();
/*     */   
/*     */   public Entry(String name) {
/*  50 */     this.name = name;
/*  51 */     EntryHandler.entries.add(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public abstract T initValue();
/*     */   
/*     */   public void loadAdditionalConfig(Configuration config) {}
/*     */   
/*     */   public void preInitLoad()
/*     */   {
/*  61 */     this.value = initValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public void preInitRegister() {}
/*     */   
/*     */ 
/*     */   public void addRecipes() {}
/*     */   
/*     */ 
/*     */   public boolean isActive()
/*     */   {
/*  73 */     return this.enabled;
/*     */   }
/*     */   
/*     */ 
/*     */   public void registerOres() {}
/*     */   
/*     */   public void addShapeless(ItemStack stack, Object... recipe)
/*     */   {
/*  81 */     CraftingHelper.addRecipe(new XUShapelessRecipe(stack, recipe));
/*     */   }
/*     */   
/*     */   public void addShaped(ItemStack stack, Object... recipe) {
/*  85 */     CraftingHelper.addRecipe(new XUShapedRecipe(stack, recipe));
/*     */   }
/*     */   
/*     */   public void addShapeless(Item stack, Object... recipe) {
/*  89 */     CraftingHelper.addRecipe(new XUShapelessRecipe(stack, recipe));
/*     */   }
/*     */   
/*     */   public void addShaped(Item stack, Object... recipe) {
/*  93 */     CraftingHelper.addRecipe(new XUShapedRecipe(stack, recipe));
/*     */   }
/*     */   
/*     */   public void addShapeless(Block stack, Object... recipe) {
/*  97 */     CraftingHelper.addRecipe(new XUShapelessRecipe(stack, recipe));
/*     */   }
/*     */   
/*     */   public void addShaped(Block stack, Object... recipe) {
/* 101 */     CraftingHelper.addRecipe(new XUShapedRecipe(stack, recipe));
/*     */   }
/*     */   
/*     */ 
/*     */   public void postInit() {}
/*     */   
/*     */   public final ItemStack newStack()
/*     */   {
/* 109 */     return newStack(1);
/*     */   }
/*     */   
/*     */   public final ItemStack newStack(int amount) {
/* 113 */     return newStack(amount, 0);
/*     */   }
/*     */   
/*     */   public ItemStack newStack(int amount, int meta) {
/* 117 */     return null;
/*     */   }
/*     */   
/*     */   public String getConfigLabel() {
/* 121 */     return this.name;
/*     */   }
/*     */   
/*     */   public void addAchievements() {}
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\Entry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */