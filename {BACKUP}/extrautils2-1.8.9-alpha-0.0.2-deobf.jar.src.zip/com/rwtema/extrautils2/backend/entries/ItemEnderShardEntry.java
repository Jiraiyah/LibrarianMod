/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import com.rwtema.extrautils2.items.ItemEnderShard;
/*    */ import com.rwtema.extrautils2.utils.Lang;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ public class ItemEnderShardEntry extends ItemClassEntry<ItemEnderShard>
/*    */ {
/*    */   public ItemEnderShardEntry()
/*    */   {
/* 14 */     super(ItemEnderShard.class);
/*    */   }
/*    */   
/*    */   public void addRecipes()
/*    */   {
/* 19 */     addShapeless(newStack(8), new Object[] { Items.ender_pearl, XU2Entries.itemGlassCutter.newWildcardStack() });
/*    */   }
/*    */   
/*    */   public java.util.List<ItemStack> anySizeStack() {
/* 23 */     ItemStack[] stack = new ItemStack[8];
/* 24 */     for (int i = 0; i < 8; i++) {
/* 25 */       stack[i] = newStack(i + 1);
/* 26 */       if (i != 0) {
/* 27 */         NBTTagCompound tags = new NBTTagCompound();
/* 28 */         tags.setInteger("I", i);
/* 29 */         stack[i].setTagCompound(tags);
/* 30 */         com.rwtema.extrautils2.utils.helpers.ItemStackHelper.addLore(stack[i], new String[] { Lang.translatePrefix("(Any size stack can be used.)") });
/*    */       }
/*    */     }
/*    */     
/* 34 */     return ImmutableList.copyOf(stack);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\ItemEnderShardEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */