/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemClassEntry<T extends Item> extends ItemEntry<T>
/*    */ {
/*    */   Class<T> clazz;
/*    */   
/*    */   public ItemClassEntry(Class<T> clazz) {
/* 10 */     super(com.rwtema.extrautils2.utils.helpers.StringHelper.erasePrefix(clazz.getSimpleName(), "Item"));
/* 11 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */   public T initValue()
/*    */   {
/*    */     try {
/* 17 */       return (Item)this.clazz.newInstance();
/*    */     } catch (Throwable throwable) {
/* 19 */       throw new RuntimeException("Could not init " + this.clazz, throwable);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\ItemClassEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */