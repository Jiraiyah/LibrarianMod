/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.google.common.collect.Maps;
/*    */ import com.rwtema.extrautils2.achievements.AchievementHelper;
/*    */ import com.rwtema.extrautils2.crafting.CraftingHelper;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import net.minecraftforge.common.config.Configuration;
/*    */ 
/*    */ public class EntryHandler
/*    */ {
/* 13 */   public static List<Entry> entries = ;
/* 14 */   public static List<Entry> activeEntries = Lists.newArrayList();
/* 15 */   public static HashMap<String, Entry> entryHashMap = new HashMap();
/*    */   
/*    */   public static void loadConfig(Configuration config) {
/* 18 */     HashMap<String, Boolean> configEntries = Maps.newHashMap();
/* 19 */     for (Entry entry : entries) {
/* 20 */       entryHashMap.put(entry.name.toLowerCase(), entry);
/* 21 */       configEntries.put(entry.name, Boolean.valueOf(config.get("Enabled", entry.getConfigLabel(), true).getBoolean()));
/* 22 */       entry.loadAdditionalConfig(config);
/*    */     }
/*    */     
/* 25 */     for (Entry entry : entries) {
/* 26 */       entry.enabled = ((Boolean)configEntries.get(entry.name)).booleanValue();
/* 27 */       if ((entry.dependencies != null) && (entry.enabled)) {
/* 28 */         for (String dependency : entry.dependencies) {
/* 29 */           if (!((Boolean)configEntries.get(dependency)).booleanValue()) {
/* 30 */             entry.enabled = false;
/* 31 */             break;
/*    */           }
/*    */         }
/*    */       }
/*    */       
/* 36 */       if (entry.enabled)
/* 37 */         activeEntries.add(entry);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void preInit() {
/* 42 */     for (Entry entry : activeEntries) {
/* 43 */       entry.preInitLoad();
/*    */     }
/*    */     
/* 46 */     for (Entry entry : activeEntries) {
/* 47 */       entry.preInitRegister();
/*    */     }
/*    */     
/* 50 */     for (Entry entry : entries) {
/* 51 */       entry.addAchievements();
/*    */     }
/*    */     
/* 54 */     for (Entry entry : activeEntries) {
/* 55 */       entry.registerOres();
/*    */     }
/*    */     
/* 58 */     for (Entry entry : activeEntries) {
/* 59 */       CraftingHelper.recipeCallback.set(entry.recipes);
/* 60 */       entry.addRecipes();
/* 61 */       CraftingHelper.recipeCallback.set(null);
/*    */     }
/*    */     
/* 64 */     AchievementHelper.bake();
/*    */   }
/*    */   
/*    */ 
/*    */   public static void init() {}
/*    */   
/*    */ 
/*    */   public static void postInit()
/*    */   {
/* 73 */     for (Entry entry : activeEntries) {
/* 74 */       entry.postInit();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\EntryHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */