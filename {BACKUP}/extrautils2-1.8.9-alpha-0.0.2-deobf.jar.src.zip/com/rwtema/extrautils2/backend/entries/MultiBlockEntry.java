/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.MultiBlockStateBuilder;
/*    */ import com.rwtema.extrautils2.backend.XUBlock;
/*    */ import com.rwtema.extrautils2.backend.XUItemBlock;
/*    */ import java.util.List;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.common.registry.GameData;
/*    */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*    */ 
/*    */ public class MultiBlockEntry<T extends XUBlock> extends Entry<List<T>>
/*    */ {
/* 13 */   public Class<? extends XUItemBlock> xuItemBlockClass = XUItemBlock.class;
/*    */   MultiBlockStateBuilder<T> builder;
/*    */   T mainBlock;
/*    */   XUItemBlock mainItem;
/*    */   
/*    */   public MultiBlockEntry(MultiBlockStateBuilder<T> builder, String name) {
/* 19 */     super(name);
/* 20 */     this.builder = builder;
/*    */   }
/*    */   
/*    */   public <S extends MultiBlockEntry<T>> S setItemBlockClass(Class<? extends XUItemBlock> xuItemBlockClass) {
/* 24 */     this.xuItemBlockClass = xuItemBlockClass;
/* 25 */     return this;
/*    */   }
/*    */   
/*    */   public List<T> initValue()
/*    */   {
/* 30 */     return this.builder.createBlocks(null);
/*    */   }
/*    */   
/*    */   public void preInitRegister()
/*    */   {
/* 35 */     for (int i = 0; i < ((List)this.value).size(); i++) {
/* 36 */       T t = (XUBlock)((List)this.value).get(i);
/* 37 */       if (i == 0) {
/* 38 */         t.setBlockName("ExtraUtils2:" + this.name);
/* 39 */         GameRegistry.registerBlock(t, this.xuItemBlockClass, this.name);
/* 40 */         this.mainBlock = t;
/* 41 */         this.mainItem = ((XUItemBlock)GameData.getBlockItemMap().get(this.mainBlock));
/*    */       } else {
/* 43 */         t.setBlockName("ExtraUtils2:" + this.name + "." + i);
/* 44 */         this.xuItemBlockClass = XUItemBlock.class;
/* 45 */         GameRegistry.registerBlock(t, null, this.name + "_" + i);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public ItemStack newStack(int amount, int meta)
/*    */   {
/* 52 */     return new ItemStack(this.mainItem, amount, meta);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\MultiBlockEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */