/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public class BlockClassEntry<T extends com.rwtema.extrautils2.backend.XUBlock> extends BlockEntry<T>
/*    */ {
/*    */   Class<T> clazz;
/*    */   
/*    */   public BlockClassEntry(String name, Class<T> clazz, Class<? extends TileEntity>... teClazzes)
/*    */   {
/* 11 */     super(name, teClazzes);
/* 12 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */ 
/*    */   public BlockClassEntry(Class<T> clazz, Class<? extends TileEntity>... teClazzes)
/*    */   {
/* 18 */     this(com.rwtema.extrautils2.utils.helpers.StringHelper.erasePrefix(clazz.getSimpleName(), "Block"), clazz, teClazzes);
/*    */   }
/*    */   
/*    */   public T initValue()
/*    */   {
/*    */     try {
/* 24 */       return (com.rwtema.extrautils2.backend.XUBlock)this.clazz.newInstance();
/*    */     } catch (Throwable throwable) {
/* 26 */       throw new RuntimeException("Could not init " + this.clazz, throwable);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\BlockClassEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */