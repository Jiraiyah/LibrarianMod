/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ import com.rwtema.extrautils2.blocks.BlockCompressed;
/*    */ import com.rwtema.extrautils2.crafting.CraftingHelper;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.oredict.ShapedOreRecipe;
/*    */ 
/*    */ public class BlockCompressedEntry extends BlockEntry<BlockCompressed>
/*    */ {
/*    */   private final IBlockState blockState;
/*    */   private final String texture;
/*    */   private final int max;
/*    */   
/*    */   public BlockCompressedEntry(Block block, String texture, int max)
/*    */   {
/* 18 */     this(block.getDefaultState(), texture, max);
/*    */   }
/*    */   
/*    */   public BlockCompressedEntry(IBlockState blockState, String texture, int max) {
/* 22 */     super("Compressed" + com.rwtema.extrautils2.utils.helpers.StringHelper.capFirst(texture, true), new Class[0]);
/* 23 */     this.blockState = blockState;
/* 24 */     this.texture = texture;
/* 25 */     this.max = max;
/*    */   }
/*    */   
/*    */   public BlockCompressed initValue()
/*    */   {
/* 30 */     return new BlockCompressed(this.blockState, this.texture, this.max);
/*    */   }
/*    */   
/*    */   public void addRecipes()
/*    */   {
/* 35 */     ItemStack base = new ItemStack(this.blockState.getBlock());
/* 36 */     CraftingHelper.addRecipe(new ShapedOreRecipe(newStack(1, 0), new Object[] { "BBB", "BBB", "BBB", Character.valueOf('B'), base }));
/* 37 */     CraftingHelper.addShapeless(new ItemStack(this.blockState.getBlock(), 9), new Object[] { newStack(1, 0) });
/* 38 */     for (int i = 0; i < this.max - 1; i++) {
/* 39 */       CraftingHelper.addRecipe(new ShapedOreRecipe(newStack(1, i + 1), new Object[] { "BBB", "BBB", "BBB", Character.valueOf('B'), newStack(1, i) }));
/* 40 */       CraftingHelper.addRecipe(new net.minecraftforge.oredict.ShapelessOreRecipe(newStack(9, i), new Object[] { newStack(1, i + 1) }));
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\BlockCompressedEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */