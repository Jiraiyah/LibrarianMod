/*    */ package com.rwtema.extrautils2.backend.entries;
/*    */ 
/*    */ public class VoidEntry extends Entry<Void> {
/*    */   public VoidEntry(String name) {
/*  5 */     super(name);
/*    */   }
/*    */   
/*    */   public Void initValue()
/*    */   {
/* 10 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\entries\VoidEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */