/*    */ package com.rwtema.extrautils2.backend;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import net.minecraft.block.properties.PropertyHelper;
/*    */ 
/*    */ public class PropertyEnumSimple<T extends Enum<T>> extends PropertyHelper<T>
/*    */ {
/* 11 */   java.util.List<T> allowedValues = new ArrayList();
/*    */   
/*    */   public PropertyEnumSimple(Class<T> valueClass) {
/* 14 */     super(valueClass.getSimpleName(), valueClass);
/* 15 */     this.allowedValues = Lists.newArrayList(valueClass.getEnumConstants());
/* 16 */     Collections.sort(this.allowedValues);
/*    */   }
/*    */   
/*    */   public Collection<T> getAllowedValues()
/*    */   {
/* 21 */     return this.allowedValues;
/*    */   }
/*    */   
/*    */   public String getName(T value)
/*    */   {
/* 26 */     return value.toString();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\PropertyEnumSimple.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */