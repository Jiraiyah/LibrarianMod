/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import com.google.common.collect.ImmutableMap;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ import net.minecraft.block.state.BlockState.StateImplementation;
/*    */ import net.minecraft.util.StringUtils;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class XUBlockState extends BlockState.StateImplementation
/*    */ {
/*    */   @SideOnly(Side.CLIENT)
/*    */   public ThreadLocal<MutableModel> result;
/*    */   public int metadata;
/*    */   public int dropMeta;
/*    */   public String dropName;
/*    */   public String unlocalizedName;
/*    */   
/*    */   public XUBlockState(Block blockIn, ImmutableMap<IProperty, Comparable> propertiesIn)
/*    */   {
/* 22 */     super(blockIn, propertiesIn);
/*    */   }
/*    */   
/*    */   public String getUnlocalizedName() {
/* 26 */     if (this.unlocalizedName == null) {
/* 27 */       if (StringUtils.isNullOrEmpty(this.dropName)) {
/* 28 */         this.unlocalizedName = (getBlock().getUnlocalizedName() + ".name");
/*    */       } else
/* 30 */         this.unlocalizedName = (getBlock().getUnlocalizedName() + "." + this.dropName + ".name");
/*    */     }
/* 32 */     return this.unlocalizedName;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void load(BoxModel model) {
/* 37 */     if (this.result == null) {
/* 38 */       this.result = new ThreadLocal()
/*    */       {
/*    */         protected MutableModel initialValue() {
/* 41 */           return new MutableModel(Transforms.blockTransforms);
/*    */         }
/*    */       };
/*    */     }
/*    */     
/* 46 */     model.loadIntoMutable((MutableModel)this.result.get(), net.minecraftforge.client.MinecraftForgeClient.getRenderLayer());
/*    */   }
/*    */   
/*    */   public void clearPropertyTable() {
/* 50 */     this.propertyValueTable = null;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\XUBlockState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */