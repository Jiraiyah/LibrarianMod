/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import com.rwtema.extrautils2.utils.helpers.QuadHelper;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public class BoxSingleQuad extends Box
/*    */ {
/*    */   private final UV[] vecs;
/* 12 */   public boolean addShading = true;
/* 13 */   boolean doubleSided = true;
/*    */   
/*    */   public BoxSingleQuad(UV... vecs) {
/* 16 */     super(getBB(vecs, 0), getBB(vecs, 1), getBB(vecs, 2), getBB(vecs, 3), getBB(vecs, 4), getBB(vecs, 5));
/* 17 */     this.vecs = vecs;
/*    */   }
/*    */   
/*    */   public Box copy()
/*    */   {
/* 22 */     UV[] v = new UV[this.vecs.length];
/* 23 */     for (int i = 0; i < this.vecs.length; i++) {
/* 24 */       v[i] = this.vecs[i].copy();
/*    */     }
/*    */     
/* 27 */     BoxSingleQuad box = new BoxSingleQuad(v);
/* 28 */     box.doubleSided = this.doubleSided;
/* 29 */     box.addShading = this.addShading;
/* 30 */     return box;
/*    */   }
/*    */   
/*    */   public static float getBB(UV[] vecs, int i) {
/* 34 */     float k = i >= 3 ? Float.MIN_VALUE : Float.MAX_VALUE;
/* 35 */     for (UV vec : vecs) {
/*    */       float t;
/* 37 */       switch (i) {
/*    */       case 0: 
/*    */       case 3: 
/* 40 */         t = vec.x;
/* 41 */         break;
/*    */       case 1: 
/*    */       case 4: 
/* 44 */         t = vec.y;
/* 45 */         break;
/*    */       case 2: 
/*    */       case 5: 
/* 48 */         t = vec.z;
/* 49 */         break;
/*    */       default: 
/* 51 */         throw new IllegalArgumentException("Wrong Arg: " + i);
/*    */       }
/*    */       
/* 54 */       k = i >= 3 ? Math.max(k, t) : Math.min(k, t);
/*    */     }
/* 56 */     return k;
/*    */   }
/*    */   
/*    */   public Box rotateY(int numRotations)
/*    */   {
/* 61 */     return super.rotateY(numRotations);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void clearCache() {}
/*    */   
/*    */ 
/*    */   public List<net.minecraft.client.renderer.block.model.BakedQuad> makeQuads(@Nullable EnumFacing side)
/*    */   {
/* 71 */     if (side != null) { return ImmutableList.of();
/*    */     }
/* 73 */     if (this.doubleSided) {
/* 74 */       UV[] v2 = new UV[this.vecs.length];
/* 75 */       for (int i = 0; i < v2.length; i++) {
/* 76 */         v2[i] = this.vecs[(this.vecs.length - 1 - i)];
/*    */       }
/*    */       
/* 79 */       return ImmutableList.of(QuadHelper.createBakedQuad(this.vecs, this.texture, this.addShading, this.tint), QuadHelper.createBakedQuad(v2, this.texture, this.addShading, this.tint));
/*    */     }
/* 81 */     return ImmutableList.of(QuadHelper.createBakedQuad(this.vecs, this.texture, this.addShading, this.tint));
/*    */   }
/*    */   
/*    */   public Box setDoubleSided(boolean doubleSided)
/*    */   {
/* 86 */     this.doubleSided = doubleSided;
/* 87 */     return this;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\BoxSingleQuad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */