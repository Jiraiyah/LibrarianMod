/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import org.lwjgl.util.vector.Vector3f;
/*    */ 
/*    */ public class UV
/*    */ {
/*  9 */   private static final float[] cornerUs = { 0.0F, 0.0F, 1.0F, 1.0F };
/* 10 */   private static final float[] cornerVs = { 0.0F, 1.0F, 1.0F, 0.0F };
/*    */   public float x;
/*    */   public float y;
/*    */   public float z;
/*    */   public float u;
/*    */   public float v;
/*    */   
/*    */   public UV(float x, float y, float z, float u, float v)
/*    */   {
/* 19 */     this.x = x;
/* 20 */     this.y = y;
/* 21 */     this.z = z;
/*    */     
/* 23 */     this.u = u;
/* 24 */     this.v = v;
/*    */   }
/*    */   
/*    */   public UV(float x, float y, float z, int corner) {
/* 28 */     this(x, y, z, cornerUs[corner], cornerVs[corner]);
/*    */   }
/*    */   
/*    */   public UV(float x, float y, float z, int corner, float u1, float u2, float v1, float v2) {
/* 32 */     this(x, y, z, Math.min(u1, u2) + Math.abs(u2 - u1) * cornerUs[corner], Math.min(v1, v2) + Math.abs(v2 - v1) * cornerVs[corner]);
/*    */   }
/*    */   
/*    */   public void setUVTextureBounds(float u1, float u2, float v1, float v2, int corner) {
/* 36 */     this.u = (u1 + (u2 - u1) * cornerUs[corner]);
/* 37 */     this.v = (v1 + (v2 - v1) * cornerVs[corner]);
/*    */   }
/*    */   
/*    */   public UV add(float d, EnumFacing side) {
/* 41 */     return new UV(this.x + side.getFrontOffsetX() * d, this.y + side.getFrontOffsetY() * d, this.z + side.getFrontOffsetZ() * d, this.u, this.v);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public Vector3f toVector3f()
/*    */   {
/* 50 */     return new Vector3f(this.x, this.y, this.z);
/*    */   }
/*    */   
/*    */   public void offset(float dx, float dy, float dz) {
/* 54 */     this.x += dx;
/* 55 */     this.y += dy;
/* 56 */     this.z += dz;
/*    */   }
/*    */   
/*    */   public UV copy() {
/* 60 */     return new UV(this.x, this.y, this.z, this.u, this.v);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\UV.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */