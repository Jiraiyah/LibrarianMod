/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ public class FlatSpriteModel extends BoxModel {
/*    */   Box box;
/*    */   
/*    */   public FlatSpriteModel() {
/*  7 */     this.box = addBox(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  8 */     for (int i = 1; i < this.box.invisible.length; i++) {
/*  9 */       this.box.invisible[i] = true;
/*    */     }
/* 11 */     this.box.setTexture("[Missing]");
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\FlatSpriteModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */