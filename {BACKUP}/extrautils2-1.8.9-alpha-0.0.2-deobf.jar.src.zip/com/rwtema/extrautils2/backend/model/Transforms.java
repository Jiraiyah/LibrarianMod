/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import java.util.EnumMap;
/*    */ import javax.vecmath.Matrix4f;
/*    */ import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
/*    */ import net.minecraftforge.client.model.IFlexibleBakedModel;
/*    */ import org.apache.commons.lang3.tuple.Pair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Transforms
/*    */ {
/*    */   public static EnumMap<ItemCameraTransforms.TransformType, Matrix4f> itemTransforms;
/*    */   public static EnumMap<ItemCameraTransforms.TransformType, Matrix4f> itemToolsTransforms;
/* 18 */   public static EnumMap<ItemCameraTransforms.TransformType, Matrix4f> blockTransforms = new EnumMap(ItemCameraTransforms.TransformType.class);
/* 19 */   static { itemTransforms = new EnumMap(ItemCameraTransforms.TransformType.class);
/* 20 */     itemToolsTransforms = new EnumMap(ItemCameraTransforms.TransformType.class);
/* 21 */     zeroTransforms = new EnumMap(ItemCameraTransforms.TransformType.class);
/*    */     
/* 23 */     blockTransforms.put(ItemCameraTransforms.TransformType.THIRD_PERSON, makeMatrix(new double[] { -0.26913232D, -6.995704E-4D, -0.2611366D, -2.9802322E-8D, 0.06412882D, -0.3636924D, -0.06511806D, 0.09375003D, -0.2531409D, -0.09139135D, 0.2611366D, -0.171875D, 0.0D, 0.0D, 0.0D, 1.0D }));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 29 */     itemTransforms.put(ItemCameraTransforms.TransformType.FIRST_PERSON, makeMatrix(new double[] { -1.0894558D, 0.5080216D, -1.2020816D, 5.9604645E-8D, 0.7184511D, 1.5407232D, 2.5331975E-8D, 0.25D, 1.0894558D, -0.5080216D, -1.2020814D, 0.125D, 0.0D, 0.0D, 0.0D, 1.0D }));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 35 */     itemTransforms.put(ItemCameraTransforms.TransformType.THIRD_PERSON, makeMatrix(new double[] { 0.55D, 0.0D, 0.0D, 0.0D, 0.0D, 3.2782555E-8D, 0.54999995D, 0.0625D, 0.0D, -0.54999995D, 3.2782555E-8D, -0.18749997D, 0.0D, 0.0D, 0.0D, 1.0D }));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 41 */     itemToolsTransforms.put(ItemCameraTransforms.TransformType.FIRST_PERSON, makeMatrix(new double[] { -1.0894558D, 0.5080216D, -1.2020816D, 5.9604645E-8D, 0.7184511D, 1.5407232D, 2.5331975E-8D, 0.25D, 1.0894558D, -0.5080216D, -1.2020814D, 0.125D, 0.0D, 0.0D, 0.0D, 1.0D }));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 47 */     itemToolsTransforms.put(ItemCameraTransforms.TransformType.THIRD_PERSON, makeMatrix(new double[] { 2.5331975E-8D, 0.0D, 0.85D, 0.0D, -0.48753995D, 0.69627935D, 0.0D, 0.078125D, -0.6962792D, -0.48753995D, 5.066395E-8D, -0.21875D, 0.0D, 0.0D, 0.0D, 1.0D }));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 53 */     identity = new Matrix4f();
/* 54 */     identity.setIdentity(); }
/*    */   
/*    */   public static EnumMap<ItemCameraTransforms.TransformType, Matrix4f> zeroTransforms;
/*    */   static Matrix4f identity;
/* 58 */   public static EnumMap<ItemCameraTransforms.TransformType, Pair<IFlexibleBakedModel, Matrix4f>> createMap(IFlexibleBakedModel model, EnumMap<ItemCameraTransforms.TransformType, Matrix4f> type) { Pair<IFlexibleBakedModel, Matrix4f> base = Pair.of(model, null);
/* 59 */     EnumMap<ItemCameraTransforms.TransformType, Pair<IFlexibleBakedModel, Matrix4f>> map = new EnumMap(ItemCameraTransforms.TransformType.class);
/* 60 */     for (ItemCameraTransforms.TransformType transformType : ItemCameraTransforms.TransformType.values()) {
/* 61 */       Matrix4f matrix4f = (Matrix4f)type.get(transformType);
/* 62 */       if (matrix4f != null) {
/* 63 */         map.put(transformType, Pair.of(model, matrix4f));
/*    */       } else {
/* 65 */         map.put(transformType, base);
/*    */       }
/*    */     }
/* 68 */     return map;
/*    */   }
/*    */   
/*    */   static Matrix4f makeMatrix(double... values) {
/* 72 */     float[] v = new float[values.length];
/* 73 */     for (int i = 0; i < v.length; i++) {
/* 74 */       v[i] = ((float)values[i]);
/*    */     }
/* 76 */     return new Matrix4f(v);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\Transforms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */