/*     */ package com.rwtema.extrautils2.backend.model;
/*     */ 
/*     */ import com.google.common.base.Optional;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.ImmutableList.Builder;
/*     */ import com.rwtema.extrautils2.backend.IXUItem;
/*     */ import com.rwtema.extrautils2.utils.client.BakedQuadTint;
/*     */ import com.rwtema.extrautils2.utils.helpers.QuadHelper;
/*     */ import gnu.trove.map.hash.TIntObjectHashMap;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumMap;
/*     */ import java.util.List;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.vecmath.Matrix4f;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.client.resources.model.IBakedModel;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraftforge.client.model.ISmartItemModel;
/*     */ import net.minecraftforge.client.model.ItemLayerModel;
/*     */ import net.minecraftforge.client.model.TRSRTransformation;
/*     */ import org.apache.commons.lang3.tuple.Pair;
/*     */ 
/*     */ public class PassthruModelItem extends NullModel implements ISmartItemModel
/*     */ {
/*  29 */   public static WeakHashMap<TextureAtlasSprite, ImmutableList<BakedQuad>> quads2dcache = new WeakHashMap()
/*     */   {
/*     */     public ImmutableList<BakedQuad> get(Object key) {
/*  32 */       ImmutableList<BakedQuad> bakedQuads = (ImmutableList)super.get(key);
/*  33 */       if (bakedQuads == null) {
/*  34 */         TextureAtlasSprite sprite = (TextureAtlasSprite)key;
/*     */         
/*  36 */         ImmutableList.Builder<BakedQuad> builder = ImmutableList.builder();
/*     */         
/*  38 */         builder.add(QuadHelper.buildQuad(DefaultVertexFormats.ITEM, TRSRTransformation.identity(), EnumFacing.SOUTH, -1, 0.0F, 0.0F, 0.5F, sprite.getMinU(), sprite.getMaxV(), 0.0F, 1.0F, 0.5F, sprite.getMinU(), sprite.getMinV(), 1.0F, 1.0F, 0.5F, sprite.getMaxU(), sprite.getMinV(), 1.0F, 0.0F, 0.5F, sprite.getMaxU(), sprite.getMaxV()));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  45 */         builder.add(QuadHelper.buildQuad(DefaultVertexFormats.ITEM, TRSRTransformation.identity(), EnumFacing.NORTH, -1, 0.0F, 0.0F, 0.5F, sprite.getMinU(), sprite.getMaxV(), 1.0F, 0.0F, 0.5F, sprite.getMaxU(), sprite.getMaxV(), 1.0F, 1.0F, 0.5F, sprite.getMaxU(), sprite.getMinV(), 0.0F, 1.0F, 0.5F, sprite.getMinU(), sprite.getMinV()));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */         bakedQuads = builder.build();
/*     */         
/*  53 */         put(sprite, bakedQuads);
/*     */       }
/*  55 */       return bakedQuads;
/*     */     }
/*     */   };
/*     */   
/*  59 */   public static WeakHashMap<TextureAtlasSprite, ImmutableList<BakedQuad>> pseudoQuads2dCache = new WeakHashMap()
/*     */   {
/*     */     public ImmutableList<BakedQuad> get(Object key) {
/*  62 */       ImmutableList<BakedQuad> bakedQuads = (ImmutableList)super.get(key);
/*  63 */       if (bakedQuads == null) {
/*  64 */         TextureAtlasSprite sprite = (TextureAtlasSprite)key;
/*     */         
/*  66 */         ImmutableList.Builder<BakedQuad> builder = ImmutableList.builder();
/*     */         
/*  68 */         builder.add(QuadHelper.buildQuad(DefaultVertexFormats.ITEM, TRSRTransformation.identity(), EnumFacing.SOUTH, -1, 0.0F, 0.0F, 0.46875F, sprite.getMinU(), sprite.getMaxV(), 0.0F, 1.0F, 0.46875F, sprite.getMinU(), sprite.getMinV(), 1.0F, 1.0F, 0.46875F, sprite.getMaxU(), sprite.getMinV(), 1.0F, 0.0F, 0.46875F, sprite.getMaxU(), sprite.getMaxV()));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */         builder.add(QuadHelper.buildQuad(DefaultVertexFormats.ITEM, TRSRTransformation.identity(), EnumFacing.NORTH, -1, 0.0F, 0.0F, 0.53125F, sprite.getMinU(), sprite.getMaxV(), 1.0F, 0.0F, 0.53125F, sprite.getMaxU(), sprite.getMaxV(), 1.0F, 1.0F, 0.53125F, sprite.getMaxU(), sprite.getMinV(), 0.0F, 1.0F, 0.53125F, sprite.getMinU(), sprite.getMinV()));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */         bakedQuads = builder.build();
/*     */         
/*  83 */         put(sprite, bakedQuads);
/*     */       }
/*  85 */       return bakedQuads;
/*     */     }
/*     */   };
/*     */   
/*  89 */   public static WeakHashMap<TextureAtlasSprite, ImmutableList<BakedQuad>> quads3dcache = new WeakHashMap()
/*     */   {
/*     */     public ImmutableList<BakedQuad> get(Object key) {
/*  92 */       ImmutableList<BakedQuad> bakedQuads = (ImmutableList)super.get(key);
/*  93 */       if (bakedQuads == null) {
/*  94 */         TextureAtlasSprite sprite = (TextureAtlasSprite)key;
/*  95 */         bakedQuads = ItemLayerModel.instance.getQuadsForSprite(-1, sprite, DefaultVertexFormats.ITEM, Optional.of(TRSRTransformation.identity()));
/*  96 */         put(sprite, bakedQuads);
/*     */       }
/*  98 */       return bakedQuads;
/*     */     }
/*     */   };
/* 101 */   public static TIntObjectHashMap<WeakHashMap<BakedQuad, BakedQuadTint>> tintedQuads = new TIntObjectHashMap()
/*     */   {
/*     */     public WeakHashMap<BakedQuad, BakedQuadTint> get(final int key) {
/* 104 */       WeakHashMap<BakedQuad, BakedQuadTint> weakHashMap = (WeakHashMap)super.get(key);
/* 105 */       if (weakHashMap != null)
/* 106 */         return weakHashMap;
/* 107 */       weakHashMap = new WeakHashMap()
/*     */       {
/*     */         public BakedQuadTint get(Object quadKey) {
/* 110 */           BakedQuadTint quadTint = (BakedQuadTint)super.get(quadKey);
/* 111 */           if (quadTint != null) {
/* 112 */             return quadTint;
/*     */           }
/* 114 */           BakedQuad quad = (BakedQuad)quadKey;
/* 115 */           quadTint = new BakedQuadTint(quad, key);
/* 116 */           put(quad, quadTint);
/* 117 */           return quadTint;
/*     */         }
/* 119 */       };
/* 120 */       put(key, weakHashMap);
/* 121 */       return weakHashMap;
/*     */     }
/*     */   };
/*     */   private final IXUItem item;
/*     */   ModelLayer model;
/*     */   
/*     */   public PassthruModelItem(IXUItem item) {
/* 128 */     this(item, item.renderAsTool() ? Transforms.itemToolsTransforms : Transforms.itemTransforms);
/*     */   }
/*     */   
/*     */   public PassthruModelItem(IXUItem item, EnumMap<ItemCameraTransforms.TransformType, Matrix4f> transforms) {
/* 132 */     this(item, new ModelLayer(transforms));
/*     */   }
/*     */   
/*     */   public PassthruModelItem(IXUItem item, ModelLayer model) {
/* 136 */     this.item = item;
/* 137 */     this.model = model;
/*     */   }
/*     */   
/*     */   public TextureAtlasSprite getParticleTexture()
/*     */   {
/* 142 */     return this.item.getBaseTexture();
/*     */   }
/*     */   
/*     */   public IBakedModel handleItemState(ItemStack stack)
/*     */   {
/* 147 */     this.model.clear();
/* 148 */     this.item.addQuads(this.model, stack);
/* 149 */     return this.model;
/*     */   }
/*     */   
/*     */   public static class ModelLayer extends MutableModel {
/* 153 */     static ItemCameraTransforms.TransformType[] types = { ItemCameraTransforms.TransformType.GUI, ItemCameraTransforms.TransformType.NONE };
/*     */     
/*     */     public MutableModel lowPolyVersion;
/*     */     
/*     */ 
/*     */     public ModelLayer(EnumMap<ItemCameraTransforms.TransformType, Matrix4f> itemTransforms)
/*     */     {
/* 160 */       super();
/* 161 */       this.isGui3D = false;
/* 162 */       this.ambientOcclusion = false;
/* 163 */       this.lowPolyVersion = new MutableModel(itemTransforms);
/* 164 */       for (ItemCameraTransforms.TransformType type : types) {
/* 165 */         this.transformMap.put(type, Pair.of(this.lowPolyVersion, ((Pair)this.transformMap.get(type)).getRight()));
/*     */       }
/*     */     }
/*     */     
/*     */     public void addBoxModel(BoxModel boxModel) {
/* 170 */       for (Box box : boxModel) {
/* 171 */         for (EnumFacing facing : EnumFacing.values()) {
/* 172 */           List<BakedQuad> quads = box.getQuads(facing);
/* 173 */           if (quads != null) addAllQuads(quads);
/*     */         }
/* 175 */         List<BakedQuad> quads = box.getQuads(null);
/* 176 */         if (quads != null) addAllQuads(quads);
/*     */       }
/*     */     }
/*     */     
/*     */     public void clear()
/*     */     {
/* 182 */       super.clear();
/* 183 */       this.lowPolyVersion.clear();
/*     */     }
/*     */     
/*     */     public void addSprite(TextureAtlasSprite sprite) {
/* 187 */       this.generalQuads.addAll((Collection)PassthruModelItem.quads3dcache.get(sprite));
/* 188 */       this.lowPolyVersion.generalQuads.addAll((Collection)PassthruModelItem.quads2dcache.get(sprite));
/*     */     }
/*     */     
/*     */     public void addSprite(TextureAtlasSprite sprite, boolean draw3d) {
/* 192 */       this.generalQuads.addAll((Collection)(draw3d ? PassthruModelItem.quads3dcache : PassthruModelItem.quads2dcache).get(sprite));
/* 193 */       this.lowPolyVersion.generalQuads.addAll((Collection)PassthruModelItem.quads2dcache.get(sprite));
/*     */     }
/*     */     
/*     */     public void addTintedSprite(TextureAtlasSprite sprite, boolean draw3d, int tint) {
/* 197 */       if (tint == -1) {
/* 198 */         addSprite(sprite, draw3d);
/*     */       } else {
/* 200 */         for (BakedQuad bakedQuad : (ImmutableList)(draw3d ? PassthruModelItem.quads3dcache : PassthruModelItem.quads2dcache).get(sprite)) {
/* 201 */           this.generalQuads.add(((WeakHashMap)PassthruModelItem.tintedQuads.get(tint)).get(bakedQuad));
/*     */         }
/* 203 */         for (BakedQuad bakedQuad : (ImmutableList)PassthruModelItem.quads2dcache.get(sprite)) {
/* 204 */           this.lowPolyVersion.generalQuads.add(((WeakHashMap)PassthruModelItem.tintedQuads.get(tint)).get(bakedQuad));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public void addQuad(BakedQuad quad) {
/* 210 */       this.generalQuads.add(quad);
/* 211 */       this.lowPolyVersion.generalQuads.add(quad);
/*     */     }
/*     */     
/*     */     public void addAllQuads(Collection<BakedQuad> quads) {
/* 215 */       this.generalQuads.addAll(quads);
/* 216 */       this.lowPolyVersion.generalQuads.addAll(quads);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\PassthruModelItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */