/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.helpers.QuadHelper;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public class BoxFullCross extends Box
/*    */ {
/* 11 */   private static final UV[][] stdUVs = { { new UV(0.0F, 0.0F, 0.0F, 0.0F, 0.0F), new UV(1.0F, 0.0F, 1.0F, 1.0F, 0.0F), new UV(1.0F, 1.0F, 1.0F, 1.0F, 1.0F), new UV(0.0F, 1.0F, 0.0F, 0.0F, 1.0F) }, { new UV(0.0F, 0.0F, 1.0F, 0.0F, 0.0F), new UV(1.0F, 0.0F, 0.0F, 1.0F, 0.0F), new UV(1.0F, 1.0F, 0.0F, 1.0F, 1.0F), new UV(0.0F, 1.0F, 1.0F, 0.0F, 1.0F) }, { new UV(0.0F, 1.0F, 0.0F, 0.0F, 1.0F), new UV(1.0F, 1.0F, 1.0F, 1.0F, 1.0F), new UV(1.0F, 0.0F, 1.0F, 1.0F, 0.0F), new UV(0.0F, 0.0F, 0.0F, 0.0F, 0.0F) }, { new UV(0.0F, 1.0F, 1.0F, 0.0F, 1.0F), new UV(1.0F, 1.0F, 0.0F, 1.0F, 1.0F), new UV(1.0F, 0.0F, 0.0F, 1.0F, 0.0F), new UV(0.0F, 0.0F, 1.0F, 0.0F, 0.0F) } };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BoxFullCross()
/*    */   {
/* 39 */     super(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*    */   }
/*    */   
/*    */   public List<BakedQuad> makeQuads(@Nullable EnumFacing side)
/*    */   {
/* 44 */     if (side != null) return null;
/* 45 */     List<BakedQuad> list = new java.util.ArrayList(4);
/* 46 */     for (UV[] stdUV : stdUVs) {
/* 47 */       list.add(QuadHelper.createBakedQuad(stdUV, this.texture, true, this.tint));
/*    */     }
/* 49 */     return list;
/*    */   }
/*    */   
/*    */ 
/*    */   public Box copy()
/*    */   {
/* 55 */     Box box = new BoxFullCross();
/* 56 */     copyBaseProperties(box);
/* 57 */     return box;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\BoxFullCross.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */