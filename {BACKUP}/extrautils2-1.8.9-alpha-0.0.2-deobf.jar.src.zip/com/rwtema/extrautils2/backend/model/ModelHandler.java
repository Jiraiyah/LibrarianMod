/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ 
/*    */ public class ModelHandler
/*    */ {
/*  7 */   public static ModelHandler instance = new ModelHandler();
/*    */   
/*    */   public static void init() {
/* 10 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(instance);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\ModelHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */