/*     */ package com.rwtema.extrautils2.backend.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BoxModel extends ArrayList<Box> implements IClientClearCache
/*     */ {
/*     */   public static final float OVERLAP = 0.0F;
/*     */   public boolean renderAsNormalBlock;
/*     */   @SideOnly(Side.CLIENT)
/*     */   public TextureAtlasSprite sprite;
/*     */   public Box overrideBounds;
/*     */   private byte passableFlag;
/*     */   
/*     */   public BoxModel() {}
/*     */   
/*     */   public BoxModel(Box newBox)
/*     */   {
/*  27 */     super(1);
/*  28 */     add(newBox);
/*     */   }
/*     */   
/*     */   public BoxModel(float par1, float par3, float par5, float par7, float par9, float par11) {
/*  32 */     super(1);
/*  33 */     add(new Box(par1, par3, par5, par7, par9, par11));
/*     */   }
/*     */   
/*     */   public static BoxModel newStandardBlock() {
/*  37 */     Box t = new Box(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  38 */     BoxModel boxes = new BoxModel(t);
/*  39 */     boxes.renderAsNormalBlock = true;
/*  40 */     return boxes;
/*     */   }
/*     */   
/*     */   public static BoxModel newStandardBlock(boolean dummy) {
/*  44 */     BoxModel boxes = new BoxModel();
/*  45 */     boxes.renderAsNormalBlock = true;
/*  46 */     return boxes;
/*     */   }
/*     */   
/*     */   public static BoxModel newStandardBlock(String texture) {
/*  50 */     Box t = new Box(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  51 */     t.texture = texture;
/*  52 */     BoxModel boxes = new BoxModel(t);
/*  53 */     boxes.renderAsNormalBlock = true;
/*  54 */     return boxes;
/*     */   }
/*     */   
/*     */   public static BoxModel hollowBox(float minX, float minY, float minZ, float holeMinX, float holeMinZ, float holeMaxX, float holeMaxZ, float maxX, float maxY, float maxZ) {
/*  58 */     BoxModel t = new BoxModel();
/*  59 */     t.add(new Box(minX, minY, minZ, holeMinX, maxY, maxZ));
/*  60 */     t.add(new Box(holeMinX, minY, minZ, holeMaxX, maxY, holeMinZ));
/*  61 */     t.add(new Box(holeMinX, minY, holeMaxZ, holeMaxX, maxY, maxZ));
/*  62 */     t.add(new Box(holeMaxX, minY, minZ, maxX, maxY, maxZ));
/*  63 */     return t;
/*     */   }
/*     */   
/*     */   public static Box boundingBox(BoxModel models, boolean collideOnly) {
/*  67 */     if (models == null) {
/*  68 */       return null;
/*     */     }
/*     */     
/*  71 */     if (models.overrideBounds != null) {
/*  72 */       if (collideOnly) {
/*  73 */         for (Box box : models) {
/*  74 */           if (!box.noCollide)
/*  75 */             return models.overrideBounds;
/*     */         }
/*  77 */         return null;
/*     */       }
/*  79 */       return models.overrideBounds;
/*     */     }
/*     */     
/*  82 */     if (models.isEmpty()) {
/*  83 */       return null;
/*     */     }
/*     */     
/*     */ 
/*  87 */     Box bounds = null;
/*  88 */     for (Box box : models) {
/*  89 */       if ((!collideOnly) || (!box.noCollide)) {
/*  90 */         if (bounds != null) {
/*  91 */           bounds.increaseBounds(box);
/*     */         } else {
/*  93 */           bounds = new Box(box);
/*     */         }
/*     */       }
/*     */     }
/*  97 */     return bounds;
/*     */   }
/*     */   
/*     */   public static BoxModel crossBoxModel() {
/* 101 */     float size = 0.2F;
/* 102 */     BoxModel model = new BoxModel();
/* 103 */     BoxRotatable box1 = new BoxRotatable(0.5F, 0.0F, -size, 0.5F, 1.0F, 1.0F + size);
/* 104 */     box1.setInvisible(15);
/* 105 */     box1.rotate(1.0F, 1.0F, 0.5F, 0.5F, 0.5F, 0.0F, 1.0F, 0.0F);
/* 106 */     box1.setTextureBounds(new float[][] { null, null, null, null, { 0.0F, 0.0F, 16.0F, 16.0F }, { 0.0F, 0.0F, 16.0F, 16.0F } });
/* 107 */     model.add(box1);
/*     */     
/* 109 */     BoxRotatable box2 = new BoxRotatable(0.5F, 0.0F, -size, 0.5F, 1.0F, 1.0F + size);
/* 110 */     box2.setInvisible(15);
/* 111 */     box2.setTextureBounds(new float[][] { null, null, null, null, { 0.0F, 0.0F, 16.0F, 16.0F }, { 0.0F, 0.0F, 16.0F, 16.0F } });
/* 112 */     box2.rotate(1.0F, -1.0F, 0.5F, 0.5F, 0.5F, 0.0F, 1.0F, 0.0F);
/* 113 */     model.add(box2);
/* 114 */     return model;
/*     */   }
/*     */   
/*     */   public AxisAlignedBB getAABB(boolean collideOnly) {
/* 118 */     Box box = boundingBox(this, collideOnly);
/* 119 */     return box != null ? new AxisAlignedBB(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ) : null;
/*     */   }
/*     */   
/*     */   public Box addBoxOverlay(float h) {
/* 123 */     return addBox(-h, -h, -h, 1.0F + h, 1.0F + h, 1.0F + h);
/*     */   }
/*     */   
/*     */   public Box addBoxI(int par1, int par3, int par5, int par7, int par9, int par11) {
/* 127 */     return addBox(par1 / 16.0F - 0.0F, par3 / 16.0F - 0.0F, par5 / 16.0F - 0.0F, par7 / 16.0F + 0.0F, par9 / 16.0F + 0.0F, par11 / 16.0F + 0.0F);
/*     */   }
/*     */   
/*     */   public Box addBoxI(int par1, int par3, int par5, int par7, int par9, int par11, String texture) {
/* 131 */     return addBox(par1 / 16.0F - 0.0F, par3 / 16.0F - 0.0F, par5 / 16.0F - 0.0F, par7 / 16.0F + 0.0F, par9 / 16.0F + 0.0F, par11 / 16.0F + 0.0F).setTexture(texture);
/*     */   }
/*     */   
/*     */   public Box addBox(float par1, float par3, float par5, float par7, float par9, float par11) {
/* 135 */     Box b = new Box(par1, par3, par5, par7, par9, par11);
/* 136 */     add(b);
/* 137 */     return b;
/*     */   }
/*     */   
/*     */   public BoxModel rotateToSide(EnumFacing dir) {
/* 141 */     for (Box box : this) {
/* 142 */       box.rotateToSide(dir);
/*     */     }
/*     */     
/* 145 */     return this;
/*     */   }
/*     */   
/*     */   public BoxModel rotateY(EnumFacing side) {
/* 149 */     switch (side) {
/*     */     case EAST: 
/* 151 */       rotateY(1);
/* 152 */       break;
/*     */     case SOUTH: 
/* 154 */       rotateY(2);
/* 155 */       break;
/*     */     case WEST: 
/* 157 */       rotateY(3);
/*     */     }
/*     */     
/* 160 */     return this;
/*     */   }
/*     */   
/*     */   public BoxModel rotateY(int numRotations) {
/* 164 */     for (Box box : this) {
/* 165 */       box.rotateY(numRotations);
/*     */     }
/*     */     
/* 168 */     return this;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public MutableModel loadIntoMutable(MutableModel result, EnumWorldBlockLayer layer) {
/* 173 */     result.clear();
/*     */     
/* 175 */     result.ambientOcclusion = true;
/* 176 */     result.isGui3D = true;
/* 177 */     for (Box box : this) {
/* 178 */       if (result.tex == null) {
/* 179 */         result.tex = box.getTex();
/*     */       }
/*     */       
/* 182 */       if ((layer == null) || (box.layer == layer))
/*     */       {
/*     */ 
/*     */ 
/* 186 */         for (EnumFacing facing : EnumFacing.values()) {
/* 187 */           List<BakedQuad> bakedQuads = box.getQuads(facing);
/* 188 */           if (bakedQuads != null) {
/* 189 */             if (box.isFlush(facing)) {
/* 190 */               ((List)result.sidedQuads.get(facing.getIndex())).addAll(bakedQuads);
/*     */             } else
/* 192 */               result.generalQuads.addAll(bakedQuads);
/*     */           }
/*     */         }
/* 195 */         List<BakedQuad> bakedQuads = box.getQuads(null);
/* 196 */         if (bakedQuads != null)
/* 197 */           result.generalQuads.addAll(bakedQuads);
/*     */       } }
/* 199 */     return result;
/*     */   }
/*     */   
/*     */   public BoxModel setTextures(Object... objects) {
/* 203 */     for (Box box : this) {
/* 204 */       box.setTextureSides(objects);
/*     */     }
/* 206 */     return this;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public TextureAtlasSprite getTex() {
/* 211 */     if (this.sprite != null) { return this.sprite;
/*     */     }
/* 213 */     for (Box box : this) {
/* 214 */       if ((this.sprite = box.getTex()) != null) {
/* 215 */         CachedRenderers.register(this);
/* 216 */         return this.sprite;
/*     */       }
/*     */     }
/* 219 */     return Textures.MISSING_SPRITE;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void clientClear()
/*     */   {
/* 225 */     this.sprite = null;
/*     */   }
/*     */   
/*     */   public boolean isFullCube() {
/* 229 */     return this.renderAsNormalBlock;
/*     */   }
/*     */   
/*     */   public BoxModel setTexture(String s) {
/* 233 */     for (Box box : this) {
/* 234 */       box.setTexture(s);
/*     */     }
/* 236 */     return this;
/*     */   }
/*     */   
/*     */   public BoxModel setLayer(EnumWorldBlockLayer layer) {
/* 240 */     for (Box box : this) {
/* 241 */       box.setLayer(layer);
/*     */     }
/* 243 */     return this;
/*     */   }
/*     */   
/*     */   public AxisAlignedBB getAABB(BlockPos pos, boolean collideOnly) {
/* 247 */     AxisAlignedBB aabb = getAABB(collideOnly);
/* 248 */     if (aabb == null) return null;
/* 249 */     return aabb.offset(pos.getX(), pos.getY(), pos.getZ());
/*     */   }
/*     */   
/*     */   public boolean getPassable() {
/* 253 */     if (this.passableFlag == 0) {
/* 254 */       this.passableFlag = 2;
/* 255 */       for (Box box : this) {
/* 256 */         if (!box.noCollide) {
/* 257 */           if (box.maxY > 0.5D) {
/* 258 */             this.passableFlag = 1;
/* 259 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 264 */     return this.passableFlag == 2;
/*     */   }
/*     */   
/*     */   public BoxModel copy() {
/* 268 */     BoxModel model = new BoxModel();
/* 269 */     model.renderAsNormalBlock = this.renderAsNormalBlock;
/* 270 */     model.overrideBounds = this.overrideBounds;
/* 271 */     model.passableFlag = this.passableFlag;
/* 272 */     for (Box box : this) {
/* 273 */       model.add(box.copy());
/*     */     }
/* 275 */     return model;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures() {
/* 280 */     for (Box box : this) {
/* 281 */       Textures.register(new String[] { box.texture });
/* 282 */       Textures.register(box.textureSide);
/*     */     }
/*     */   }
/*     */   
/*     */   public void moveToCenterForInventoryRendering() {
/* 287 */     Box bounds = boundingBox(this, false);
/* 288 */     float dx = 0.5F - (bounds.maxX + bounds.minX) / 2.0F;
/* 289 */     float dy = 0.0F - bounds.minY;
/* 290 */     float dz = 0.5F - (bounds.maxZ + bounds.minZ) / 2.0F;
/* 291 */     if ((dx != 0.0F) || (dz != 0.0F) || (dy != 0.0F)) {
/* 292 */       for (Box box : this) {
/* 293 */         box.setRenderOffset(dx, dy, dz);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\BoxModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */