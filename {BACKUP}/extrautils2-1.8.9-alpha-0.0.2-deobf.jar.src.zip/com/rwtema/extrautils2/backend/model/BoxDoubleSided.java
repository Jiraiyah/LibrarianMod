/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public class BoxDoubleSided extends Box
/*    */ {
/*    */   public BoxDoubleSided(int x0, int y0, int z0, int x1, int y1, int z1, boolean dummy)
/*    */   {
/* 10 */     super(x0, y0, z0, x1, y1, z1, dummy);
/*    */   }
/*    */   
/*    */   public BoxDoubleSided(Box box) {
/* 14 */     super(box);
/*    */   }
/*    */   
/*    */   public BoxDoubleSided(float x0, float y0, float z0, float x1, float y1, float z1) {
/* 18 */     super(x0, y0, z0, x1, y1, z1);
/*    */   }
/*    */   
/*    */ 
/*    */   public java.util.List<net.minecraft.client.renderer.block.model.BakedQuad> makeQuads(@Nullable EnumFacing side)
/*    */   {
/* 24 */     return addReverseQuads(super.makeQuads(side));
/*    */   }
/*    */   
/*    */   public Box copy()
/*    */   {
/* 29 */     Box box = new BoxDoubleSided(this);
/* 30 */     copyBaseProperties(box);
/* 31 */     return box;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\BoxDoubleSided.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */