/*     */ package com.rwtema.extrautils2.backend.model;
/*     */ 
/*     */ import com.google.common.collect.Maps;
/*     */ import com.rwtema.extrautils2.backend.IXUItem;
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStatic;
/*     */ import com.rwtema.extrautils2.backend.XUItem;
/*     */ import com.rwtema.extrautils2.backend.XUItemBlock;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.renderer.ItemMeshDefinition;
/*     */ import net.minecraft.client.renderer.block.statemap.DefaultStateMapper;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.client.resources.model.IBakedModel;
/*     */ import net.minecraft.client.resources.model.ModelResourceLocation;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IRegistry;
/*     */ import net.minecraft.util.RegistryNamespaced;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.client.event.ModelBakeEvent;
/*     */ import net.minecraftforge.client.event.TextureStitchEvent.Pre;
/*     */ import net.minecraftforge.client.model.ModelLoader;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*     */ public class Textures
/*     */ {
/*  35 */   public static final HashMap<String, TextureAtlasSprite> textureNames = ;
/*  36 */   private static final HashMap<Item, ModelResourceLocation> locations = new HashMap();
/*     */   public static HashMap<String, TextureAtlasSprite> sprites;
/*     */   public static TextureAtlasSprite MISSING_SPRITE;
/*     */   
/*     */   static {
/*  41 */     MinecraftForge.EVENT_BUS.register(new Textures());
/*     */   }
/*     */   
/*     */   public static ModelResourceLocation getModelResourceLocation(Item item) {
/*  45 */     ModelResourceLocation location = (ModelResourceLocation)locations.get(item);
/*  46 */     if (location != null) return location;
/*  47 */     location = new ModelResourceLocation((ResourceLocation)Item.itemRegistry.getNameForObject(item), "inventory");
/*  48 */     locations.put(item, location);
/*  49 */     return location;
/*     */   }
/*     */   
/*     */   public static ModelResourceLocation getModelResourceLocation(Item item, int metadata) {
/*  53 */     if (metadata == 32767) return getModelResourceLocation(item);
/*  54 */     ModelResourceLocation location = (ModelResourceLocation)locations.get(item);
/*  55 */     if (location != null) return location;
/*  56 */     location = new ModelResourceLocation(Item.itemRegistry.getNameForObject(item) + "_" + metadata, "inventory");
/*  57 */     locations.put(item, location);
/*  58 */     return location;
/*     */   }
/*     */   
/*     */   public static void register(String... textures) {
/*  62 */     for (String texture : textures) {
/*  63 */       if (texture != null)
/*  64 */         textureNames.put(texture, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public static ResourceLocation completeTextureResourceLocation(ResourceLocation location) {
/*  69 */     return new ResourceLocation(location.getResourceDomain(), String.format("%s/%s%s", new Object[] { "textures", location.getResourcePath(), ".png" }));
/*     */   }
/*     */   
/*     */   public static TextureAtlasSprite getSprite(String textureName) {
/*  73 */     TextureAtlasSprite sprite = (TextureAtlasSprite)sprites.get(textureName);
/*  74 */     return sprite != null ? sprite : MISSING_SPRITE;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void loadTextures(TextureStitchEvent.Pre event) {
/*  79 */     MISSING_SPRITE = event.map.getMissingSprite();
/*     */     IXUItem item;
/*  81 */     for (Iterator i$ = XUItem.items.iterator(); i$.hasNext(); item.clearCaches()) item = (IXUItem)i$.next();
/*  82 */     XUItemBlock item; for (Iterator i$ = XUItemBlock.itemBlocks.iterator(); i$.hasNext(); item.clearCaches()) item = (XUItemBlock)i$.next();
/*  83 */     XUBlock block; for (Iterator i$ = XUBlock.blocks.iterator(); i$.hasNext(); block.clearCaches()) block = (XUBlock)i$.next();
/*     */     IXUItem item;
/*  85 */     for (Iterator i$ = XUItem.items.iterator(); i$.hasNext(); item.registerTextures()) item = (IXUItem)i$.next();
/*  86 */     XUItemBlock item; for (Iterator i$ = XUItemBlock.itemBlocks.iterator(); i$.hasNext(); item.registerTextures()) item = (XUItemBlock)i$.next();
/*  87 */     XUBlock block; for (Iterator i$ = XUBlock.blocks.iterator(); i$.hasNext(); block.registerTextures()) { block = (XUBlock)i$.next();
/*     */     }
/*     */     
/*  90 */     sprites = new HashMap(16, 0.25F);
/*  91 */     TextureMap map = event.map;
/*  92 */     sprites.put("[Missing]", MISSING_SPRITE);
/*  93 */     for (Map.Entry<String, TextureAtlasSprite> entry : textureNames.entrySet()) {
/*  94 */       String texture = (String)entry.getKey();
/*  95 */       String name = texture.indexOf(':') == -1 ? "extrautils2:" + texture : texture;
/*  96 */       TextureAtlasSprite value = (TextureAtlasSprite)entry.getValue();
/*  97 */       if (value != null) {
/*  98 */         map.setTextureEntry(value.getIconName(), value);
/*  99 */         sprites.put(texture, value);
/*     */       } else {
/* 101 */         sprites.put(texture, map.registerSprite(new ResourceLocation(name)));
/*     */       }
/*     */     }
/*     */     IXUItem item;
/* 105 */     for (Iterator i$ = XUItem.items.iterator(); i$.hasNext(); item.postTextureRegister()) item = (IXUItem)i$.next();
/* 106 */     XUItemBlock item; for (Iterator i$ = XUItemBlock.itemBlocks.iterator(); i$.hasNext(); item.postTextureRegister()) item = (XUItemBlock)i$.next();
/* 107 */     XUBlock block; for (Iterator i$ = XUBlock.blocks.iterator(); i$.hasNext(); block.postTextureRegister()) { block = (XUBlock)i$.next();
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void registerModels(ModelBakeEvent event)
/*     */   {
/* 114 */     IRegistry<ModelResourceLocation, IBakedModel> modelRegistry = event.modelRegistry;
/*     */     
/* 116 */     for (IXUItem xuItems : XUItem.items) {
/* 117 */       Item item = (Item)xuItems;
/* 118 */       int maxMetadata = xuItems.getMaxMetadata();
/* 119 */       if (maxMetadata == 0) {
/* 120 */         ModelLoader.setCustomMeshDefinition(item, ItemMesher.INSTANCE);
/* 121 */         ModelResourceLocation modelResourceLocation = getModelResourceLocation(item);
/* 122 */         ModelLoader.setCustomModelResourceLocation(item, 0, modelResourceLocation);
/* 123 */         if ((!xuItems.allowOverride()) || (modelRegistry.getObject(modelResourceLocation) == null))
/* 124 */           modelRegistry.putObject(modelResourceLocation, xuItems.createModel(0));
/*     */       } else {
/* 126 */         ModelLoader.setCustomMeshDefinition(item, ItemMesher.INSTANCE);
/* 127 */         ModelResourceLocation genericLocation = getModelResourceLocation(item);
/* 128 */         modelRegistry.putObject(genericLocation, xuItems.createModel(0));
/*     */         
/*     */ 
/* 131 */         for (int i = 0; i < maxMetadata; i++) {
/* 132 */           ModelLoader.setCustomMeshDefinition(item, new ItemMesherItem(xuItems));
/* 133 */           ModelResourceLocation modelResourceLocation = getModelResourceLocation(item, i);
/* 134 */           ModelLoader.setCustomModelResourceLocation(item, i, modelResourceLocation);
/*     */           
/* 136 */           if ((!xuItems.allowOverride()) || (modelRegistry.getObject(modelResourceLocation) == null)) {
/* 137 */             modelRegistry.putObject(modelResourceLocation, xuItems.createModel(i));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 142 */     for (XUItemBlock item : XUItemBlock.itemBlocks) {
/* 143 */       ModelLoader.setCustomMeshDefinition(item, ItemMesher.INSTANCE);
/* 144 */       final ModelResourceLocation location = getModelResourceLocation(item);
/* 145 */       ModelLoader.setCustomStateMapper(item.block, new net.minecraft.client.renderer.block.statemap.StateMapperBase()
/*     */       {
/*     */         protected ModelResourceLocation getModelResourceLocation(IBlockState state) {
/* 148 */           return location;
/*     */         }
/*     */       });
/*     */       
/* 152 */       if ((!(item.block instanceof XUBlockStatic)) || (modelRegistry.getObject(location) == null)) {
/* 153 */         modelRegistry.putObject(location, new PassthruModelItemBlock(item));
/*     */       }
/*     */     }
/*     */     
/* 157 */     for (Iterator i$ = XUBlock.blocks.iterator(); i$.hasNext();) { block = (XUBlock)i$.next();
/* 158 */       DefaultStateMapper defaultStateMapper = new DefaultStateMapper();
/* 159 */       for (Map.Entry<IBlockState, ModelResourceLocation> entry : defaultStateMapper.putStateModelLocations(block).entrySet()) {
/* 160 */         ModelResourceLocation location = (ModelResourceLocation)entry.getValue();
/* 161 */         if ((!(block instanceof XUBlockStatic)) || (modelRegistry.getObject(location) == null)) {
/* 162 */           modelRegistry.putObject(location, new PassthruModelBlock(block, (IBlockState)entry.getKey(), location));
/*     */         }
/*     */       }
/*     */     }
/*     */     XUBlock block;
/*     */   }
/*     */   
/*     */   public static class ItemMesher implements ItemMeshDefinition {
/* 170 */     public static final ItemMesher INSTANCE = new ItemMesher();
/*     */     
/*     */     public ModelResourceLocation getModelLocation(ItemStack stack)
/*     */     {
/* 174 */       return Textures.getModelResourceLocation(stack.getItem());
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ItemMesherItem implements ItemMeshDefinition {
/*     */     final IXUItem item;
/*     */     
/*     */     public ItemMesherItem(IXUItem item) {
/* 182 */       this.item = item;
/*     */     }
/*     */     
/*     */     public ModelResourceLocation getModelLocation(ItemStack stack)
/*     */     {
/* 187 */       int meta = stack.getItemDamage();
/* 188 */       if (meta < 0) {
/* 189 */         meta = 0;
/* 190 */       } else if (meta > this.item.getMaxMetadata())
/* 191 */         meta = this.item.getMaxMetadata();
/* 192 */       return Textures.getModelResourceLocation(stack.getItem(), meta);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\Textures.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */