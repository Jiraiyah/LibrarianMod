/*     */ package com.rwtema.extrautils2.backend.model;
/*     */ 
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.utils.helpers.ColorHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.QuadHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraftforge.client.ForgeHooksClient;
/*     */ import net.minecraftforge.client.model.IColoredBakedQuad.ColoredBakedQuad;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class Box implements IClientClearCache
/*     */ {
/*     */   public static final String MISSING_TEXTURE = "[Missing]";
/*  23 */   public static final Box fullBox = new Box(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  24 */   public static int[] rotAdd = { 0, 1, 2, 3 };
/*  25 */   static int BOTTOM = 0;
/*  26 */   static int TOP = 1;
/*  27 */   static int NORTH = 2;
/*  28 */   static int SOUTH = 3;
/*  29 */   static int WEST = 4;
/*  30 */   static int EAST = 5;
/*  31 */   static int[][][] sidesVertex = { { { 1, 2, 4 }, { 1, 2, 5 }, { 0, 2, 5 }, { 0, 2, 4 } }, { { 0, 3, 4 }, { 0, 3, 5 }, { 1, 3, 5 }, { 1, 3, 4 } }, { { 0, 2, 4 }, { 0, 3, 4 }, { 1, 3, 4 }, { 1, 2, 4 } }, { { 1, 2, 5 }, { 1, 3, 5 }, { 0, 3, 5 }, { 0, 2, 5 } }, { { 0, 2, 4 }, { 0, 2, 5 }, { 0, 3, 5 }, { 0, 3, 4 } }, { { 1, 3, 4 }, { 1, 3, 5 }, { 1, 2, 5 }, { 1, 2, 4 } } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */   static int[][][] uv = { { { 1, 5 }, { 1, 4 }, { 0, 4 }, { 0, 5 } }, { { 0, 5 }, { 0, 4 }, { 1, 4 }, { 1, 5 } }, { { 1, 2 }, { 1, 3 }, { 0, 3 }, { 0, 2 } }, { { 1, 2 }, { 1, 3 }, { 0, 3 }, { 0, 2 } }, { { 4, 2 }, { 5, 2 }, { 5, 3 }, { 4, 3 } }, { { 5, 3 }, { 4, 3 }, { 4, 2 }, { 5, 2 } } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */   static int[] colShade = { -8355712, -1, -3355444, -3355444, -6710887, -6710887 };
/*  48 */   static float[] colShadeMult = { 0.5F, 1.0F, 0.8F, 0.8F, 0.6F, 0.6F };
/*     */   
/*  50 */   public final int[] rotate = new int[6];
/*  51 */   public final String[] textureSide = new String[6];
/*  52 */   public final boolean[] invisible = new boolean[6];
/*  53 */   public float[][] textureBounds = (float[][])null;
/*     */   public float minX;
/*     */   public float minY;
/*     */   public float minZ;
/*     */   public float maxX;
/*     */   public float maxY;
/*     */   public float maxZ;
/*     */   public String texture;
/*  61 */   public int color = -1;
/*     */   public boolean noCollide;
/*     */   @SideOnly(Side.CLIENT)
/*     */   public List<BakedQuad>[] cachedQuads;
/*  65 */   public EnumWorldBlockLayer layer = EnumWorldBlockLayer.SOLID;
/*  66 */   public boolean[] flipU = null;
/*  67 */   public boolean[] flipV = null;
/*  68 */   public int tint = -1;
/*  69 */   public float[] renderOffset = null;
/*     */   @SideOnly(Side.CLIENT)
/*     */   TextureAtlasSprite sprite;
/*     */   
/*     */   public Box(float x0, float y0, float z0, float x1, float y1, float z1)
/*     */   {
/*  75 */     setBounds(x0, y0, z0, x1, y1, z1);
/*     */   }
/*     */   
/*     */   public Box(int x0, int y0, int z0, int x1, int y1, int z1, boolean dummy) {
/*  79 */     setBounds(x0 / 16.0F, y0 / 16.0F, z0 / 16.0F, x1 / 16.0F, y1 / 16.0F, z1 / 16.0F);
/*     */   }
/*     */   
/*     */   public Box(Box box) {
/*  83 */     this(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private static List<BakedQuad> makeFlatSideBakedQuad(Box box, @javax.annotation.Nonnull EnumFacing side, TextureAtlasSprite textureAtlasSprite, int tint, int color) {
/*  88 */     int index = side.getIndex();
/*  89 */     int[] vertex = new int[28];
/*     */     
/*  91 */     int rot = box.rotate[side.ordinal()] & 0x3;
/*  92 */     for (int i = 0; i < 4; i++)
/*     */     {
/*  94 */       vertex[(i * 7 + 0)] = Float.floatToRawIntBits(box.getPos(sidesVertex[index][i][0]));
/*  95 */       vertex[(i * 7 + 1)] = Float.floatToRawIntBits(box.getPos(sidesVertex[index][i][1]));
/*  96 */       vertex[(i * 7 + 2)] = Float.floatToRawIntBits(box.getPos(sidesVertex[index][i][2]));
/*     */     }
/*     */     
/*  99 */     if (color == -1) {
/* 100 */       for (int i = 0; i < 4; i++) {
/* 101 */         vertex[(i * 7 + 3)] = colShade[index];
/*     */       }
/*     */     } else {
/* 104 */       for (int i = 0; i < 4; i++) {
/* 105 */         vertex[(i * 7 + 3)] = ColorHelper.multShade(color, colShadeMult[index]);
/*     */       }
/*     */     }
/*     */     
/* 109 */     loadTextureUV(box, textureAtlasSprite, index, vertex, rot, box.textureBounds, box.flipU, box.flipV);
/*     */     
/* 111 */     ForgeHooksClient.fillNormal(vertex, side);
/*     */     
/* 113 */     BakedQuad quad = color == -1 ? new BakedQuad(vertex, tint, side) : new IColoredBakedQuad.ColoredBakedQuad(vertex, tint, side);
/* 114 */     return com.google.common.collect.Lists.newArrayList(new BakedQuad[] { quad });
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static void loadTextureUV(Box box, TextureAtlasSprite sprite, int index, int[] vertex, int rot, @Nullable float[][] textureBounds, @Nullable boolean[] flipU, @Nullable boolean[] flipV) {
/* 119 */     for (int i = 0; i < 4; i++)
/*     */     {
/*     */ 
/* 122 */       float[] textureBound = null;
/* 123 */       float dv; float du; float dv; if ((textureBounds != null) && ((textureBound = textureBounds[index]) != null)) {
/* 124 */         float du = 16.0F * fullBox.getPos(uv[index][i][0]);
/* 125 */         dv = 16.0F * fullBox.getPos(uv[index][i][1]);
/*     */       } else {
/* 127 */         du = 16.0F * box.getPos(uv[index][i][0]);
/* 128 */         dv = 16.0F - 16.0F * box.getPos(uv[index][i][1]);
/*     */       }
/*     */       
/* 131 */       if ((flipU != null) && (flipU[index] != 0)) {
/* 132 */         du = 16.0F - du;
/*     */       }
/*     */       
/* 135 */       if ((flipV != null) && (flipV[index] != 0)) {
/* 136 */         dv = 16.0F - dv;
/*     */       }
/*     */       
/* 139 */       if (textureBound != null) {
/* 140 */         du = textureBound[0] + (textureBound[2] - textureBound[0]) * du / 16.0F;
/* 141 */         dv = textureBound[1] + (textureBound[3] - textureBound[1]) * dv / 16.0F;
/*     */       }
/*     */       float v;
/* 144 */       if (rot == 0) {
/* 145 */         float u = du;
/* 146 */         v = dv; } else { float v;
/* 147 */         if (rot == 1) {
/* 148 */           float u = 16.0F - dv;
/* 149 */           v = du; } else { float v;
/* 150 */           if (rot == 2) {
/* 151 */             float u = 16.0F - du;
/* 152 */             v = 16.0F - dv;
/*     */           } else {
/* 154 */             u = dv;
/* 155 */             v = 16.0F - du;
/*     */           }
/*     */         } }
/* 158 */       float u = clamp(u);
/* 159 */       float v = clamp(v);
/*     */       
/* 161 */       vertex[(i * 7 + 4)] = Float.floatToRawIntBits(MathHelper.clamp_float(sprite.getInterpolatedU(u), sprite.getMinU(), sprite.getMaxU()));
/* 162 */       vertex[(i * 7 + 5)] = Float.floatToRawIntBits(MathHelper.clamp_float(sprite.getInterpolatedV(v), sprite.getMinV(), sprite.getMaxV()));
/*     */     }
/*     */   }
/*     */   
/*     */   public static float clamp(float f) {
/* 167 */     return f;
/*     */   }
/*     */   
/*     */   public static List<BakedQuad> offsetQuadList(List<BakedQuad> quads, float[] offsets) {
/* 171 */     if ((offsets == null) || (quads == null)) return quads;
/* 172 */     for (BakedQuad quad : quads) {
/* 173 */       offsetQuad(quad, offsets);
/*     */     }
/* 175 */     return quads;
/*     */   }
/*     */   
/*     */   public static void offsetQuad(BakedQuad quad, float[] offsets) {
/* 179 */     int[] vertex = quad.getVertexData();
/* 180 */     for (int i = 0; i < 4; i++) {
/* 181 */       for (int j = 0; j < 3; j++) {
/* 182 */         vertex[(i * 7 + j)] = Float.floatToRawIntBits(Float.intBitsToFloat(vertex[(i * 7 + j)]) + offsets[j]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Box setTint(int tint) {
/* 188 */     this.tint = tint;
/* 189 */     return this;
/*     */   }
/*     */   
/*     */   public Box setLayer(EnumWorldBlockLayer layer) {
/* 193 */     this.layer = layer;
/* 194 */     return this;
/*     */   }
/*     */   
/*     */   public Box setBounds(float x0, float y0, float z0, float x1, float y1, float z1) {
/* 198 */     this.minX = Math.min(x0, x1);
/* 199 */     this.minY = Math.min(y0, y1);
/* 200 */     this.minZ = Math.min(z0, z1);
/* 201 */     this.maxX = Math.max(x0, x1);
/* 202 */     this.maxY = Math.max(y0, y1);
/* 203 */     this.maxZ = Math.max(z0, z1);
/* 204 */     return this;
/*     */   }
/*     */   
/*     */   public Box increaseBounds(Box other) {
/* 208 */     if (other.minX < this.minX) this.minX = other.minX;
/* 209 */     if (other.minY < this.minY) this.minY = other.minY;
/* 210 */     if (other.minZ < this.minZ) this.minZ = other.minZ;
/* 211 */     if (other.maxX > this.maxX) this.maxX = other.maxX;
/* 212 */     if (other.maxY > this.maxY) this.maxY = other.maxY;
/* 213 */     if (other.maxZ > this.maxZ) this.maxZ = other.maxZ;
/* 214 */     return this;
/*     */   }
/*     */   
/*     */   public Box copy() {
/* 218 */     Box box = new Box(this.minX, this.minY, this.minZ, this.maxX, this.maxY, this.maxZ);
/* 219 */     copyBaseProperties(box);
/* 220 */     return box;
/*     */   }
/*     */   
/*     */   protected void copyBaseProperties(Box box) {
/* 224 */     box.color = this.color;
/* 225 */     System.arraycopy(this.rotate, 0, box.rotate, 0, 6);
/* 226 */     System.arraycopy(this.invisible, 0, box.invisible, 0, 6);
/* 227 */     System.arraycopy(this.textureSide, 0, box.textureSide, 0, 6);
/* 228 */     box.texture = this.texture;
/* 229 */     box.noCollide = this.noCollide;
/* 230 */     box.layer = this.layer;
/* 231 */     if (this.flipU != null) box.flipU = ((boolean[])this.flipU.clone());
/* 232 */     if (this.flipV != null) box.flipV = ((boolean[])this.flipV.clone());
/* 233 */     box.tint = this.tint;
/* 234 */     if (this.renderOffset != null)
/* 235 */       box.renderOffset = ((float[])this.renderOffset.clone());
/*     */   }
/*     */   
/*     */   public Box rotateY(int numRotations) {
/* 239 */     if (numRotations == 0) {
/* 240 */       return this;
/*     */     }
/*     */     
/* 243 */     if (numRotations < 0) {
/* 244 */       numRotations += 4;
/*     */     }
/*     */     
/* 247 */     numRotations &= 0x3;
/*     */     
/* 249 */     for (int i = 0; i < numRotations; i++) {
/* 250 */       Box prev = copy();
/* 251 */       this.minZ = prev.minX;
/* 252 */       this.maxZ = prev.maxX;
/* 253 */       this.minX = (1.0F - prev.maxZ);
/* 254 */       this.maxX = (1.0F - prev.minZ);
/*     */       
/* 256 */       String temp = this.textureSide[2];
/* 257 */       this.textureSide[2] = this.textureSide[4];
/* 258 */       this.textureSide[4] = this.textureSide[3];
/* 259 */       this.textureSide[3] = this.textureSide[5];
/* 260 */       this.textureSide[5] = temp;
/*     */       
/* 262 */       boolean t = this.invisible[2];
/* 263 */       this.invisible[2] = this.invisible[4];
/* 264 */       this.invisible[4] = this.invisible[3];
/* 265 */       this.invisible[3] = this.invisible[5];
/* 266 */       this.invisible[5] = t;
/*     */       
/* 268 */       if (this.flipU != null) {
/* 269 */         t = this.flipU[2];
/* 270 */         this.flipU[2] = this.flipU[4];
/* 271 */         this.flipU[4] = this.flipU[3];
/* 272 */         this.flipU[3] = this.flipU[5];
/* 273 */         this.flipU[5] = t;
/*     */       }
/*     */       
/* 276 */       if (this.flipV != null) {
/* 277 */         t = this.flipV[2];
/* 278 */         this.flipV[2] = this.flipV[4];
/* 279 */         this.flipV[4] = this.flipV[3];
/* 280 */         this.flipV[3] = this.flipV[5];
/* 281 */         this.flipV[5] = t;
/*     */       }
/*     */     }
/*     */     
/* 285 */     this.rotate[TOP] = (this.rotate[TOP] + rotAdd[numRotations] & 0x3);
/* 286 */     this.rotate[BOTTOM] = (this.rotate[BOTTOM] + rotAdd[numRotations] & 0x3);
/* 287 */     clearCache();
/* 288 */     return this;
/*     */   }
/*     */   
/*     */   public Box swapIcons(int a, int b) {
/* 292 */     boolean t2 = this.invisible[a];
/* 293 */     this.invisible[a] = this.invisible[b];
/* 294 */     this.invisible[b] = t2;
/*     */     
/* 296 */     String temp = this.textureSide[a];
/* 297 */     this.textureSide[a] = this.textureSide[b];
/* 298 */     this.textureSide[b] = temp;
/*     */     
/* 300 */     if (this.flipU != null) {
/* 301 */       boolean t = this.flipU[b];
/* 302 */       this.flipU[b] = this.flipU[a];
/* 303 */       this.flipU[a] = t;
/*     */     }
/*     */     
/* 306 */     if (this.flipV != null) {
/* 307 */       boolean t = this.flipV[b];
/* 308 */       this.flipV[b] = this.flipV[a];
/* 309 */       this.flipV[a] = t;
/*     */     }
/*     */     
/* 312 */     return this;
/*     */   }
/*     */   
/*     */   public Box rotateToSideTex(EnumFacing dir) {
/* 316 */     switch (dir) {
/*     */     case DOWN: 
/*     */       break;
/*     */     case UP: 
/* 320 */       swapIcons(0, 1);
/* 321 */       this.rotate[EAST] = 3;
/* 322 */       this.rotate[WEST] = 3;
/* 323 */       this.rotate[SOUTH] = 3;
/* 324 */       this.rotate[NORTH] = 3;
/* 325 */       break;
/*     */     case NORTH: 
/* 327 */       swapIcons(1, 3);
/* 328 */       swapIcons(0, 2);
/* 329 */       this.rotate[SOUTH] = 2;
/* 330 */       this.rotate[NORTH] = 1;
/* 331 */       this.rotate[TOP] = 3;
/* 332 */       this.rotate[BOTTOM] = 3;
/* 333 */       break;
/*     */     case SOUTH: 
/* 335 */       swapIcons(1, 2);
/* 336 */       swapIcons(0, 3);
/* 337 */       this.rotate[SOUTH] = 1;
/* 338 */       this.rotate[NORTH] = 2;
/* 339 */       break;
/*     */     case WEST: 
/* 341 */       swapIcons(1, 5);
/* 342 */       swapIcons(0, 4);
/* 343 */       this.rotate[EAST] = 2;
/* 344 */       this.rotate[WEST] = 1;
/* 345 */       this.rotate[TOP] = 1;
/* 346 */       this.rotate[BOTTOM] = 2;
/* 347 */       break;
/*     */     case EAST: 
/* 349 */       swapIcons(1, 4);
/* 350 */       swapIcons(0, 5);
/* 351 */       this.rotate[EAST] = 1;
/* 352 */       this.rotate[WEST] = 2;
/* 353 */       this.rotate[TOP] = 2;
/* 354 */       this.rotate[BOTTOM] = 1;
/* 355 */       break;
/*     */     }
/*     */     
/*     */     
/* 359 */     return this;
/*     */   }
/*     */   
/*     */   public Box rotateToSide(EnumFacing dir)
/*     */   {
/* 364 */     Box prev = copy();
/* 365 */     clearCache();
/* 366 */     rotateToSideTex(dir);
/* 367 */     switch (dir)
/*     */     {
/*     */     case DOWN: 
/*     */       break;
/*     */     case UP: 
/* 372 */       this.minY = (1.0F - prev.maxY);
/* 373 */       this.maxY = (1.0F - prev.minY);
/* 374 */       break;
/*     */     
/*     */     case NORTH: 
/* 377 */       this.minZ = prev.minY;
/* 378 */       this.maxZ = prev.maxY;
/* 379 */       this.minY = prev.minX;
/* 380 */       this.maxY = prev.maxX;
/* 381 */       this.minX = prev.minZ;
/* 382 */       this.maxX = prev.maxZ;
/* 383 */       break;
/*     */     
/*     */     case SOUTH: 
/* 386 */       this.minZ = (1.0F - prev.maxY);
/* 387 */       this.maxZ = (1.0F - prev.minY);
/* 388 */       this.minY = prev.minX;
/* 389 */       this.maxY = prev.maxX;
/* 390 */       this.minX = (1.0F - prev.maxZ);
/* 391 */       this.maxX = (1.0F - prev.minZ);
/* 392 */       break;
/*     */     
/*     */     case WEST: 
/* 395 */       this.minX = prev.minY;
/* 396 */       this.maxX = prev.maxY;
/* 397 */       this.minY = prev.minX;
/* 398 */       this.maxY = prev.maxX;
/* 399 */       this.minZ = (1.0F - prev.maxZ);
/* 400 */       this.maxZ = (1.0F - prev.minZ);
/* 401 */       break;
/*     */     
/*     */     case EAST: 
/* 404 */       this.minX = (1.0F - prev.maxY);
/* 405 */       this.maxX = (1.0F - prev.minY);
/* 406 */       this.minY = prev.minX;
/* 407 */       this.maxY = prev.maxX;
/* 408 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/* 414 */     return this;
/*     */   }
/*     */   
/*     */   public Box setTexture(String tex) {
/* 418 */     this.texture = tex;
/* 419 */     return this;
/*     */   }
/*     */   
/*     */   public Box setTextureSides(Object... tex) {
/* 423 */     int s = -1;
/*     */     
/* 425 */     for (Object aTex : tex) {
/* 426 */       if ((aTex instanceof Integer)) {
/* 427 */         s = ((Integer)aTex).intValue();
/*     */       }
/* 429 */       if ((aTex instanceof EnumFacing)) {
/* 430 */         s = ((EnumFacing)aTex).getIndex();
/* 431 */       } else if ((aTex instanceof String)) {
/* 432 */         if (s == -1) {
/* 433 */           this.texture = ((String)aTex);
/* 434 */         } else if ((s >= 0) && (s < 6)) {
/* 435 */           this.textureSide[s] = ((String)aTex);
/* 436 */           s++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 441 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isFlush(EnumFacing side) {
/* 445 */     switch (side) {
/*     */     case DOWN: 
/* 447 */       return this.minY <= 0.0F;
/*     */     case UP: 
/* 449 */       return this.maxY >= 1.0F;
/*     */     case NORTH: 
/* 451 */       return this.minZ <= 0.0F;
/*     */     case SOUTH: 
/* 453 */       return this.maxZ >= 1.0F;
/*     */     case WEST: 
/* 455 */       return this.minX <= 0.0F;
/*     */     case EAST: 
/* 457 */       return this.maxX >= 1.0F;
/*     */     }
/* 459 */     return false;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public TextureAtlasSprite getTex() {
/* 464 */     if (this.sprite != null) { return this.sprite;
/*     */     }
/* 466 */     if ((this.texture != null) && ((this.sprite = (TextureAtlasSprite)Textures.sprites.get(this.texture)) != null)) {
/* 467 */       CachedRenderers.register(this);
/* 468 */       return this.sprite;
/*     */     }
/* 470 */     for (int i = 0; i < 6; i++) {
/* 471 */       if ((this.sprite = getTextureSide(i)) != null) {
/* 472 */         CachedRenderers.register(this);
/* 473 */         return this.sprite;
/*     */       }
/*     */     }
/*     */     
/* 477 */     return null;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public List<BakedQuad> getQuads(@Nullable EnumFacing side)
/*     */   {
/* 483 */     if ((side != null) && (this.invisible[side.ordinal()] != 0)) { return null;
/*     */     }
/* 485 */     List<BakedQuad>[] cache = this.cachedQuads;
/* 486 */     if (cache == null) {
/* 487 */       cache = new List[7];
/* 488 */       for (EnumFacing face : EnumFacing.values()) {
/* 489 */         cache[face.getIndex()] = offsetQuadList(makeQuads(face), this.renderOffset);
/*     */       }
/* 491 */       cache[6] = offsetQuadList(makeQuads(null), this.renderOffset);
/* 492 */       this.cachedQuads = cache;
/*     */     }
/* 494 */     int i = side == null ? 6 : side.getIndex();
/* 495 */     return cache[i];
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public List<BakedQuad> makeQuads(@Nullable EnumFacing side) {
/* 500 */     if (side == null) return null;
/* 501 */     int index = side.getIndex();
/*     */     
/* 503 */     switch (index) {
/*     */     case 0: 
/*     */     case 1: 
/* 506 */       if (this.minX == this.maxX) return null;
/* 507 */       if (this.minZ == this.maxZ) return null;
/*     */       break;
/*     */     case 2: 
/*     */     case 3: 
/* 511 */       if (this.minX == this.maxX) return null;
/* 512 */       if (this.minY == this.maxY) return null;
/*     */       break;
/*     */     case 4: 
/*     */     case 5: 
/* 516 */       if (this.minY == this.maxY) return null;
/* 517 */       if (this.minZ == this.maxZ) { return null;
/*     */       }
/*     */       break;
/*     */     }
/* 521 */     TextureAtlasSprite textureAtlasSprite = getTextureSide(index);
/* 522 */     if (textureAtlasSprite == null) { textureAtlasSprite = Textures.MISSING_SPRITE;
/*     */     }
/* 524 */     return makeFlatSideBakedQuad(this, side, textureAtlasSprite, this.tint, this.color);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public TextureAtlasSprite getTextureSide(int index) {
/* 529 */     String tex = this.textureSide[index];
/* 530 */     if (tex == null) tex = this.texture;
/* 531 */     if (tex == null) { return null;
/*     */     }
/* 533 */     TextureAtlasSprite textureAtlasSprite = (TextureAtlasSprite)Textures.sprites.get(tex);
/* 534 */     if (textureAtlasSprite == null) return null;
/* 535 */     return textureAtlasSprite;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private float getPos(int i) {
/* 540 */     switch (i) {
/*     */     case 0: 
/* 542 */       return this.minX;
/*     */     case 1: 
/* 544 */       return this.maxX;
/*     */     case 2: 
/* 546 */       return this.minY;
/*     */     case 3: 
/* 548 */       return this.maxY;
/*     */     case 4: 
/* 550 */       return this.minZ;
/*     */     case 5: 
/* 552 */       return this.maxZ;
/*     */     }
/* 554 */     throw new RuntimeException(i + " is not valid side");
/*     */   }
/*     */   
/*     */   public void clearCache() {
/* 558 */     ExtraUtils2.proxy.clearClientCache(this);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void clientClear()
/*     */   {
/* 564 */     this.sprite = null;
/* 565 */     this.cachedQuads = null;
/*     */   }
/*     */   
/*     */   public Box setInvisible(boolean... sides) {
/* 569 */     System.arraycopy(sides, 0, this.invisible, 0, sides.length);
/* 570 */     return this;
/*     */   }
/*     */   
/*     */   public Box setInvisible(int mask) {
/* 574 */     for (int i = 0; i < this.invisible.length; i++) {
/* 575 */       this.invisible[i] = ((mask & 1 << i) != 0 ? 1 : false);
/*     */     }
/* 577 */     return this;
/*     */   }
/*     */   
/*     */   public List<BakedQuad> addReverseQuads(List<BakedQuad> bakedQuads) {
/* 581 */     if ((bakedQuads == null) || (bakedQuads.isEmpty())) { return bakedQuads;
/*     */     }
/* 583 */     List<BakedQuad> rev = new ArrayList(bakedQuads.size() * 2);
/* 584 */     rev.addAll(bakedQuads);
/* 585 */     for (BakedQuad bakedQuad : bakedQuads) {
/* 586 */       rev.add(QuadHelper.reverse(bakedQuad));
/*     */     }
/*     */     
/* 589 */     return rev;
/*     */   }
/*     */   
/*     */   public Box setTextureBounds(float[][] floats) {
/* 593 */     this.textureBounds = floats;
/* 594 */     return this;
/*     */   }
/*     */   
/*     */   public Box setFlipU(int... sides) {
/* 598 */     this.flipU = new boolean[6];
/* 599 */     for (int side : sides) {
/* 600 */       this.flipU[side] = true;
/*     */     }
/* 602 */     return this;
/*     */   }
/*     */   
/*     */   public Box setFlipV(int... sides) {
/* 606 */     this.flipV = new boolean[6];
/* 607 */     for (int side : sides) {
/* 608 */       this.flipV[side] = true;
/*     */     }
/* 610 */     return this;
/*     */   }
/*     */   
/*     */   public void setRenderOffset(float dx, float dy, float dz) {
/* 614 */     this.renderOffset = new float[] { dx, dy, dz };
/*     */   }
/*     */   
/*     */   public void setInvisible(EnumFacing... facing) {
/* 618 */     for (EnumFacing enumFacing : facing) {
/* 619 */       this.invisible[enumFacing.ordinal()] = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\Box.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */