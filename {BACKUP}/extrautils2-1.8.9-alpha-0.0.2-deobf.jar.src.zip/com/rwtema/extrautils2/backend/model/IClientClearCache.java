package com.rwtema.extrautils2.backend.model;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public abstract interface IClientClearCache
{
  @SideOnly(Side.CLIENT)
  public abstract void clientClear();
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\IClientClearCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */