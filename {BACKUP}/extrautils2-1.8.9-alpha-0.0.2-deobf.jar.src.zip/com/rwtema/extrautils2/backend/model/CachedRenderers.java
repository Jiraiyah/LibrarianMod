/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import com.rwtema.extrautils2.utils.datastructures.WeakSet;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.resources.IReloadableResourceManager;
/*    */ import net.minecraft.client.resources.IResourceManager;
/*    */ import net.minecraft.client.resources.IResourceManagerReloadListener;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class CachedRenderers
/*    */ {
/* 14 */   private static final WeakSet<IClientClearCache> cachedRenderers = new WeakSet();
/*    */   
/*    */   static {
/* 17 */     ExtraUtils2.proxy.run(new com.rwtema.extrautils2.backend.ClientCallable()
/*    */     {
/*    */       @SideOnly(Side.CLIENT)
/*    */       public void runClient() {
/* 21 */         ((IReloadableResourceManager)Minecraft.getMinecraft().getResourceManager()).registerReloadListener(new IResourceManagerReloadListener()
/*    */         {
/*    */           public void onResourceManagerReload(IResourceManager resourceManager) {
/* 24 */             for (IClientClearCache cachedRenderer : CachedRenderers.cachedRenderers) {
/* 25 */               cachedRenderer.clientClear();
/*    */             }
/*    */           }
/*    */         });
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */ 
/*    */   public static void register(IClientClearCache clientClearCache)
/*    */   {
/* 36 */     synchronized (cachedRenderers) {
/* 37 */       cachedRenderers.add(clientClearCache);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\CachedRenderers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */