/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import com.google.common.base.Throwables;
/*    */ import com.rwtema.extrautils2.backend.ClientCallable;
/*    */ import com.rwtema.extrautils2.utils.blockaccess.BlockAccessEmpty;
/*    */ import com.rwtema.extrautils2.utils.blockaccess.BlockAccessMimic;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*    */ import net.minecraft.client.resources.model.IBakedModel;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BoxMimic extends Box
/*    */ {
/* 22 */   public static ThreadLocal<BlockAccessMimic> blockAccessMimicThreadLocal = new ThreadLocal()
/*    */   {
/*    */     protected BlockAccessMimic initialValue() {
/* 25 */       return new BlockAccessMimic();
/*    */     }
/*    */   };
/*    */   
/*    */   IBlockAccess world;
/*    */   BlockPos pos;
/*    */   IBlockState mimicState;
/*    */   
/*    */   public BoxMimic(IBlockState mimicState)
/*    */   {
/* 35 */     this(BlockAccessEmpty.INSTANCE, com.rwtema.extrautils2.utils.PositionPool.MID_HEIGHT, mimicState);
/*    */   }
/*    */   
/*    */   public BoxMimic(IBlockAccess world, BlockPos pos, IBlockState mimicState) {
/* 39 */     super(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 40 */     this.world = world;
/* 41 */     this.pos = pos;
/* 42 */     this.mimicState = mimicState;
/* 43 */     com.rwtema.extrautils2.ExtraUtils2.proxy.run(new ClientCallable()
/*    */     {
/*    */       @SideOnly(Side.CLIENT)
/*    */       public void runClient() {
/* 47 */         BoxMimic.this.layer = BoxMimic.this.mimicState.getBlock().getBlockLayer();
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   public Box copy()
/*    */   {
/* 54 */     return new BoxMimic(this.world, this.pos, this.mimicState);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public List<BakedQuad> makeQuads(@Nullable EnumFacing side)
/*    */   {
/* 60 */     BlockAccessMimic blockAccessMimic = (BlockAccessMimic)blockAccessMimicThreadLocal.get();
/*    */     try {
/* 62 */       blockAccessMimic.base = this.world;
/* 63 */       blockAccessMimic.state = this.mimicState;
/* 64 */       blockAccessMimic.myPos = this.pos;
/* 65 */       IBakedModel modelFromBlockState = Minecraft.getMinecraft().getBlockRendererDispatcher().func_175022_a(this.mimicState, blockAccessMimic, this.pos);
/* 66 */       List<BakedQuad> array = side == null ? modelFromBlockState.func_177550_a() : modelFromBlockState.func_177551_a(side);
/* 67 */       blockAccessMimic.base = null;
/* 68 */       return array;
/*    */     } catch (Throwable throwable) {
/* 70 */       blockAccessMimic.base = null;
/* 71 */       throw Throwables.propagate(throwable);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\BoxMimic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */