/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlock;
/*    */ import com.rwtema.extrautils2.backend.XUItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class PassthruModelItemBlock extends NullModel implements net.minecraftforge.client.model.ISmartItemModel
/*    */ {
/*    */   private final XUItemBlock item;
/*    */   MutableModel result;
/*    */   
/*    */   public PassthruModelItemBlock(XUItemBlock item)
/*    */   {
/* 14 */     this.item = item;
/* 15 */     this.result = item.block.createInventoryMutableModel();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public net.minecraft.client.resources.model.IBakedModel handleItemState(ItemStack stack)
/*    */   {
/* 22 */     this.result.clear();
/* 23 */     this.item.block.addInventoryQuads(this.result, stack);
/* 24 */     return this.result;
/*    */   }
/*    */   
/*    */   public net.minecraft.client.renderer.texture.TextureAtlasSprite getParticleTexture()
/*    */   {
/* 29 */     return this.item.block.getInventoryModel(null).getTex();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\PassthruModelItemBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */