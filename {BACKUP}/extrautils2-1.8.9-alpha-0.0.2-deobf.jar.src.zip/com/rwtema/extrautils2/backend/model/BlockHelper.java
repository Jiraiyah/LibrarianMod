/*   */ package com.rwtema.extrautils2.backend.model;
/*   */ 
/*   */ import java.util.HashMap;
/*   */ 
/*   */ public class BlockHelper
/*   */ {
/* 7 */   public static HashMap<String, net.minecraft.client.renderer.texture.TextureAtlasSprite> map = new HashMap(16, 0.25F);
/*   */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\BlockHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */