/*     */ package com.rwtema.extrautils2.backend.model;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.Iterables;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.rwtema.extrautils2.utils.client.GLState;
/*     */ import java.util.ArrayList;
/*     */ import java.util.EnumMap;
/*     */ import java.util.List;
/*     */ import javax.vecmath.Matrix4f;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
/*     */ import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.client.renderer.vertex.VertexFormat;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraftforge.client.model.IFlexibleBakedModel;
/*     */ import net.minecraftforge.client.model.IPerspectiveAwareModel;
/*     */ import org.apache.commons.lang3.tuple.Pair;
/*     */ 
/*     */ public class MutableModel implements IPerspectiveAwareModel
/*     */ {
/*  25 */   public final List<BakedQuad> generalQuads = Lists.newArrayList();
/*  26 */   public final List<List<BakedQuad>> sidedQuads = ImmutableList.of(Lists.newArrayList(), Lists.newArrayList(), Lists.newArrayList(), Lists.newArrayList(), Lists.newArrayList(), Lists.newArrayList());
/*     */   public final EnumMap<ItemCameraTransforms.TransformType, Pair<IFlexibleBakedModel, Matrix4f>> transformMap;
/*     */   public boolean ambientOcclusion;
/*     */   public TextureAtlasSprite tex;
/*     */   public boolean isGui3D;
/*     */   private List<GLState<?>> states;
/*     */   
/*     */   public MutableModel(EnumMap<ItemCameraTransforms.TransformType, Matrix4f> type) {
/*  34 */     this.transformMap = Transforms.createMap(this, type);
/*     */   }
/*     */   
/*     */   public void clear() {
/*  38 */     this.tex = null;
/*  39 */     this.states = null;
/*  40 */     this.generalQuads.clear();
/*  41 */     for (List<BakedQuad> sidedQuad : this.sidedQuads) {
/*  42 */       sidedQuad.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public List<BakedQuad> func_177551_a(EnumFacing side)
/*     */   {
/*  48 */     return (List)this.sidedQuads.get(side.getIndex());
/*     */   }
/*     */   
/*     */   public List<BakedQuad> func_177550_a()
/*     */   {
/*  53 */     return this.generalQuads;
/*     */   }
/*     */   
/*     */   public boolean isAmbientOcclusion()
/*     */   {
/*  58 */     return this.ambientOcclusion;
/*     */   }
/*     */   
/*     */   public void addGLState(GLState<?> state) {
/*  62 */     if (this.states == null) this.states = new ArrayList();
/*  63 */     this.states.add(state);
/*     */   }
/*     */   
/*     */   public boolean isGui3d()
/*     */   {
/*  68 */     return this.isGui3D;
/*     */   }
/*     */   
/*     */   public boolean func_177553_d()
/*     */   {
/*  73 */     return false;
/*     */   }
/*     */   
/*     */   public TextureAtlasSprite getParticleTexture()
/*     */   {
/*  78 */     TextureAtlasSprite tex = this.tex;
/*  79 */     return tex == null ? Textures.MISSING_SPRITE : tex;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemCameraTransforms getItemCameraTransforms()
/*     */   {
/*  85 */     return ItemCameraTransforms.DEFAULT;
/*     */   }
/*     */   
/*     */ 
/*     */   public Pair<IFlexibleBakedModel, Matrix4f> handlePerspective(ItemCameraTransforms.TransformType cameraTransformType)
/*     */   {
/*  91 */     handleGLStates();
/*  92 */     return (Pair)this.transformMap.get(cameraTransformType);
/*     */   }
/*     */   
/*     */   public void handleGLStates() {
/*  96 */     if ((this.states != null) && ("Client thread".equals(Thread.currentThread().getName()))) {
/*  97 */       for (GLState<?> state : this.states) {
/*  98 */         state.setValue();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public VertexFormat getFormat()
/*     */   {
/* 105 */     return DefaultVertexFormats.BLOCK;
/*     */   }
/*     */   
/*     */   public Iterable<BakedQuad> getAllQuads() {
/* 109 */     return Iterables.concat(this.generalQuads, Iterables.concat(this.sidedQuads));
/*     */   }
/*     */   
/*     */   public void rotateY(float x, float z, float t) {
/* 113 */     float c = MathHelper.cos(t);
/* 114 */     float s = MathHelper.sin(t);
/*     */     
/* 116 */     for (BakedQuad quad : getAllQuads()) {
/* 117 */       int[] data = quad.getVertexData();
/* 118 */       for (int i = 0; i < 28; i += 7) {
/* 119 */         float ax = Float.intBitsToFloat(data[i]) - x;
/* 120 */         float az = Float.intBitsToFloat(data[(i + 2)]) - z;
/*     */         
/* 122 */         data[i] = Float.floatToRawIntBits(x + ax * c - az * s);
/* 123 */         data[(i + 2)] = Float.floatToRawIntBits(z + ax * s + az * c);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\MutableModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */