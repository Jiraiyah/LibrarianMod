/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlock;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.client.resources.model.IBakedModel;
/*    */ import net.minecraft.client.resources.model.ModelResourceLocation;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class PassthruModelBlock extends NullModel implements net.minecraftforge.client.model.ISmartBlockModel
/*    */ {
/*    */   protected final XUBlock block;
/*    */   protected final XUBlockState xuBlockState;
/*    */   protected final ModelResourceLocation modelResourceLocation;
/*    */   
/*    */   public PassthruModelBlock(XUBlock block, IBlockState key, ModelResourceLocation modelResourceLocation)
/*    */   {
/* 20 */     this.block = block;
/* 21 */     this.xuBlockState = ((XUBlockState)key);
/* 22 */     this.modelResourceLocation = modelResourceLocation;
/*    */   }
/*    */   
/*    */   public TextureAtlasSprite getParticleTexture()
/*    */   {
/* 27 */     return this.block.getInventoryModel(null).getTex();
/*    */   }
/*    */   
/*    */   public IBakedModel handleBlockState(IBlockState state)
/*    */   {
/* 32 */     return (IBakedModel)((XUBlockState)state).result.get();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\PassthruModelBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */