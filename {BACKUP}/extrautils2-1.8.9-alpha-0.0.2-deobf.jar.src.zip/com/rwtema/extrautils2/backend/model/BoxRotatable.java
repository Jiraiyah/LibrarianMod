/*     */ package com.rwtema.extrautils2.backend.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ 
/*     */ public class BoxRotatable extends Box
/*     */ {
/*     */   public UV[][] faceVecs;
/*     */   
/*     */   public BoxRotatable(UV[][] faceVecs)
/*     */   {
/*  15 */     super(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  16 */     this.faceVecs = faceVecs;
/*  17 */     rebuildBounds();
/*     */   }
/*     */   
/*     */   public BoxRotatable(float x0, float y0, float z0, float x1, float y1, float z1) {
/*  21 */     super(x0, y0, z0, x1, y1, z1);
/*  22 */     this.faceVecs = new UV[][] { { new UV(x1, y0, z0, 0), new UV(x1, y0, z1, 1), new UV(x0, y0, z1, 2), new UV(x0, y0, z0, 3) }, { new UV(x0, y1, z0, 0), new UV(x0, y1, z1, 1), new UV(x1, y1, z1, 2), new UV(x1, y1, z0, 3) }, { new UV(x0, y0, z0, 0), new UV(x0, y1, z0, 1), new UV(x1, y1, z0, 2), new UV(x1, y0, z0, 3) }, { new UV(x1, y0, z1, 0), new UV(x1, y1, z1, 1), new UV(x0, y1, z1, 2), new UV(x0, y0, z1, 3) }, { new UV(x0, y0, z1, 0), new UV(x0, y1, z1, 1), new UV(x0, y1, z0, 2), new UV(x0, y0, z0, 3) }, { new UV(x1, y0, z0, 0), new UV(x1, y1, z0, 1), new UV(x1, y1, z1, 2), new UV(x1, y0, z1, 3) } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */     rebuildBounds();
/*     */   }
/*     */   
/*     */   public Box setBounds(float x0, float y0, float z0, float x1, float y1, float z1)
/*     */   {
/*  68 */     if (this.faceVecs == null) {
/*  69 */       return super.setBounds(x0, y0, z0, x1, y1, z1);
/*     */     }
/*  71 */     rebuildBounds();
/*     */     
/*  73 */     return this;
/*     */   }
/*     */   
/*     */   protected void rebuildBounds() {
/*  77 */     this.minX = Float.MAX_VALUE;
/*  78 */     this.minY = Float.MAX_VALUE;
/*  79 */     this.minZ = Float.MAX_VALUE;
/*  80 */     this.maxX = Float.MIN_VALUE;
/*  81 */     this.maxY = Float.MIN_VALUE;
/*  82 */     this.maxZ = Float.MIN_VALUE;
/*  83 */     for (UV[] faceVec : this.faceVecs) {
/*  84 */       for (UV uv : faceVec) {
/*  85 */         this.minX = Math.min(uv.x, this.minX);
/*  86 */         this.maxX = Math.max(uv.x, this.maxX);
/*  87 */         this.minY = Math.min(uv.y, this.minY);
/*  88 */         this.maxY = Math.max(uv.y, this.maxY);
/*  89 */         this.minZ = Math.min(uv.z, this.minZ);
/*  90 */         this.maxZ = Math.max(uv.z, this.maxZ);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public BoxRotatable rotate(float theta, float rx, float ry, float rz, float ux, float uy, float uz) {
/*  96 */     float c = MathHelper.cos(theta * 0.017453292F);
/*  97 */     float s = MathHelper.sin(theta * 0.017453292F);
/*  98 */     return rotate(c, s, rz, ux, uy, uz, rx, ry);
/*     */   }
/*     */   
/*     */   public BoxRotatable rotate(float c, float s, float rx, float ry, float rz, float ux, float uy, float uz) {
/* 102 */     float d = c * c + s * s;
/* 103 */     if (d < 1.0E-6D) return this;
/* 104 */     if (Math.abs(d - 1.0F) > 1.0E-6D) {
/* 105 */       d = MathHelper.sqrt_float(d);
/* 106 */       c /= d;
/* 107 */       s /= d;
/*     */     }
/*     */     
/* 110 */     float c2 = 1.0F - c;
/* 111 */     float uxy = ux * uy * c2;
/* 112 */     float uxz = ux * uz * c2;
/* 113 */     float uyz = uy * uz * c2;
/* 114 */     for (UV[] faceVec : this.faceVecs) {
/* 115 */       for (UV uv : faceVec) {
/* 116 */         float px = uv.x - rx;float py = uv.y - ry;float pz = uv.z - rz;
/*     */         
/* 118 */         uv.x = (rx + px * (c + ux * ux * c2) + py * (uxy - uz * s) + pz * (uxz + uy * s));
/*     */         
/*     */ 
/*     */ 
/* 122 */         uv.y = (ry + px * (uxy + uz * s) + py * (c + uy * uy * c2) + pz * (uyz - ux * s));
/*     */         
/*     */ 
/*     */ 
/* 126 */         uv.z = (rz + px * (uxz - uy * s) + py * (uyz + ux * s) + pz * (c + uz * uz * c2));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 132 */     rebuildBounds();
/* 133 */     clearCache();
/* 134 */     return this;
/*     */   }
/*     */   
/*     */   public java.util.List<BakedQuad> makeQuads(@Nullable EnumFacing side)
/*     */   {
/* 139 */     if (side != null) { return null;
/*     */     }
/* 141 */     ArrayList<BakedQuad> quads = new ArrayList(6);
/* 142 */     for (int i = 0; i < this.faceVecs.length; i++) {
/* 143 */       UV[] faceVec = this.faceVecs[i];
/* 144 */       if (this.invisible[i] == 0) {
/* 145 */         quads.add(com.rwtema.extrautils2.utils.helpers.QuadHelper.createBakedQuad(faceVec, this.texture, true, this.tint));
/*     */       }
/*     */     }
/* 148 */     return quads;
/*     */   }
/*     */   
/*     */   public Box setTextureBounds(float[][] bounds)
/*     */   {
/* 153 */     for (int i = 0; i < this.faceVecs.length; i++) {
/* 154 */       float[] bound = bounds[i];
/* 155 */       if (bound != null)
/* 156 */         for (int j = 0; j < 4; j++) {
/* 157 */           UV uv = this.faceVecs[i][j];
/* 158 */           uv.setUVTextureBounds(bound[0] / 16.0F, bound[2] / 16.0F, bound[1] / 16.0F, bound[3] / 16.0F, j);
/*     */         }
/*     */     }
/* 161 */     return this;
/*     */   }
/*     */   
/*     */   public Box copy()
/*     */   {
/* 166 */     UV[][] newVecs = new UV[this.faceVecs.length][4];
/* 167 */     for (int i = 0; i < this.faceVecs.length; i++) {
/* 168 */       for (int j = 0; j < 4; j++) {
/* 169 */         newVecs[i][j] = this.faceVecs[i][j].copy();
/*     */       }
/*     */     }
/* 172 */     return new BoxRotatable(newVecs);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\BoxRotatable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */