/*    */ package com.rwtema.extrautils2.backend.model;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.client.resources.model.SimpleBakedModel;
/*    */ 
/*    */ public abstract class NullModel extends SimpleBakedModel
/*    */ {
/* 11 */   protected static final List<BakedQuad> EMPTY_QUADS = ;
/*    */   protected static final boolean EMPTY_AMBIENTOCCLUSION = false;
/*    */   protected static final boolean EMPTY_GUI3D = false;
/* 14 */   protected static final TextureAtlasSprite EMPTY_TEXTURE = null;
/* 15 */   protected static final net.minecraft.client.renderer.block.model.ItemCameraTransforms EMPTY_CAMERATRANSFORMS = net.minecraft.client.renderer.block.model.ItemCameraTransforms.DEFAULT;
/* 16 */   protected static final List<List<BakedQuad>> EMPTY_FACE_QUADS = ImmutableList.of(ImmutableList.of(), ImmutableList.of(), ImmutableList.of(), ImmutableList.of(), ImmutableList.of(), ImmutableList.of());
/*    */   
/*    */   public NullModel() {
/* 19 */     super(EMPTY_QUADS, EMPTY_FACE_QUADS, false, false, Textures.MISSING_SPRITE, EMPTY_CAMERATRANSFORMS);
/*    */   }
/*    */   
/*    */   public abstract TextureAtlasSprite getParticleTexture();
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\model\NullModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */