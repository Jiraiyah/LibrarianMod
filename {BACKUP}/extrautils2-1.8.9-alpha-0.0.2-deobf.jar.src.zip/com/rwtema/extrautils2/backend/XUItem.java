/*    */ package com.rwtema.extrautils2.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import com.rwtema.extrautils2.achievements.AchievementHelper;
/*    */ import com.rwtema.extrautils2.backend.entries.ItemEntry;
/*    */ import com.rwtema.extrautils2.backend.model.PassthruModelItem;
/*    */ import com.rwtema.extrautils2.utils.Lang;
/*    */ import com.rwtema.extrautils2.utils.helpers.StringHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public abstract class XUItem extends Item implements IXUItem
/*    */ {
/* 20 */   public static final List<IXUItem> items = ;
/*    */   public ItemEntry<?> entry;
/*    */   
/*    */   public XUItem() {
/* 24 */     setCreativeTab(ExtraUtils2.creativeTabExtraUtils);
/* 25 */     items.add(this);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public net.minecraft.client.resources.model.IBakedModel createModel(int metadata)
/*    */   {
/* 31 */     return new PassthruModelItem(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void postTextureRegister() {}
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean renderAsTool()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public void clearCaches() {}
/*    */   
/*    */ 
/*    */   public void register(String... textures)
/*    */   {
/* 52 */     ExtraUtils2.proxy.registerTexture(textures);
/*    */   }
/*    */   
/*    */   public boolean allowOverride()
/*    */   {
/* 57 */     return true;
/*    */   }
/*    */   
/*    */   public void openItemGui(EntityPlayer playerIn) {
/* 61 */     playerIn.openGui(ExtraUtils2.instance, -1, playerIn.worldObj, 0, 0, 0);
/*    */   }
/*    */   
/*    */   public void openItemGui(EntityPlayer playerIn, int x, int y, int z) {
/* 65 */     playerIn.openGui(ExtraUtils2.instance, -1, playerIn.worldObj, x, y, z);
/*    */   }
/*    */   
/*    */   public void onCreated(ItemStack stack, World worldIn, EntityPlayer playerIn)
/*    */   {
/* 70 */     AchievementHelper.checkForPotentialAwards(playerIn, stack);
/*    */   }
/*    */   
/*    */ 
/*    */   public String getItemStackDisplayName(ItemStack stack)
/*    */   {
/* 76 */     if (!ExtraUtils2.deobf_folder) {
/* 77 */       return super.getItemStackDisplayName(stack);
/*    */     }
/* 79 */     String key = getUnlocalizedNameInefficiently(stack) + ".name";
/* 80 */     String item = StringHelper.sepWords(((ResourceLocation)Item.itemRegistry.getNameForObject(this)).getResourcePath().replace("Item", ""));
/*    */     
/* 82 */     if ((!this.hasSubtypes) || (getUnlocalizedName().equals(getUnlocalizedName(stack)))) {
/* 83 */       return Lang.translate(key, item);
/*    */     }
/* 85 */     return Lang.translate(key, item + " " + stack.getItemDamage());
/*    */   }
/*    */   
/*    */ 
/*    */   public final String getUnlocalizedNameInefficiently(ItemStack stack)
/*    */   {
/* 91 */     return super.getUnlocalizedNameInefficiently(stack);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */