/*    */ package com.rwtema.extrautils2.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public abstract class XUBlockStaticRotation extends XUBlockStatic
/*    */ {
/*    */   public XUBlockStaticRotation(net.minecraft.block.material.Material materialIn)
/*    */   {
/* 13 */     super(materialIn);
/*    */   }
/*    */   
/*    */   protected XUBlockStateCreator createBlockState()
/*    */   {
/* 18 */     return new XUBlockStateCreator.Builder(this).addWorldPropertyWithDefault(XUBlockStateCreator.ROTATION_HORIZONTAL, EnumFacing.SOUTH).build();
/*    */   }
/*    */   
/*    */   public BoxModel getModel(IBlockState state)
/*    */   {
/* 23 */     BoxModel model = createBaseModel(state.withProperty(XUBlockStateCreator.ROTATION_HORIZONTAL, EnumFacing.NORTH));
/* 24 */     model.rotateY((EnumFacing)state.getValue(XUBlockStateCreator.ROTATION_HORIZONTAL));
/* 25 */     return model;
/*    */   }
/*    */   
/*    */   protected abstract BoxModel createBaseModel(IBlockState paramIBlockState);
/*    */   
/*    */   public IBlockState onBlockPlaced(net.minecraft.world.World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer)
/*    */   {
/* 32 */     return this.xuBlockState.getStateFromDropMeta(meta).withProperty(XUBlockStateCreator.ROTATION_HORIZONTAL, placer.getHorizontalFacing());
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUBlockStaticRotation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */