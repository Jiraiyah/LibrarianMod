/*     */ package com.rwtema.extrautils2.backend;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.textures.ISolidWorldTexture;
/*     */ import java.util.HashMap;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public abstract class XUBlockConnectedTextureBase extends XUBlock
/*     */ {
/*  23 */   public final ThreadLocal<BoxModel> worldModel = new ThreadLocal()
/*     */   {
/*     */     protected BoxModel initialValue() {
/*  26 */       return BoxModel.newStandardBlock();
/*     */     }
/*     */   };
/*     */   
/*  30 */   public HashMap<IBlockState, BoxModel> invModels = new HashMap();
/*     */   
/*     */   public XUBlockConnectedTextureBase(Material materialIn) {
/*  33 */     super(materialIn);
/*     */   }
/*     */   
/*     */   public void clearCaches()
/*     */   {
/*  38 */     this.invModels.clear();
/*     */   }
/*     */   
/*     */ 
/*     */   public abstract boolean isOpaqueCube();
/*     */   
/*     */   public boolean shouldSideBeRendered(IBlockAccess worldIn, BlockPos pos, EnumFacing side)
/*     */   {
/*  46 */     Block block = worldIn.getBlockState(pos).getBlock();
/*  47 */     return (block != this) && (!block.isOpaqueCube());
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public abstract ISolidWorldTexture getConnectedTexture(IBlockState paramIBlockState, EnumFacing paramEnumFacing);
/*     */   
/*     */   @Nonnull
/*     */   public BoxModel getWorldModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/*  56 */     return (BoxModel)this.worldModel.get();
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BoxModel getInventoryModel(@Nullable ItemStack item)
/*     */   {
/*  63 */     IBlockState state = this.xuBlockState.getStateFromItemStack(item);
/*     */     
/*  65 */     BoxModel model = (BoxModel)this.invModels.get(state);
/*  66 */     if (model != null) {}
/*  67 */     model = BoxModel.newStandardBlock();
/*  68 */     for (EnumFacing facing : EnumFacing.values()) {
/*  69 */       ((Box)model.get(0)).setTextureSides(new Object[] { facing, getConnectedTexture(state, facing).getItemTexture(facing) });
/*     */     }
/*  71 */     this.invModels.put(state, model);
/*     */     
/*  73 */     return model;
/*     */   }
/*     */   
/*     */   public EnumWorldBlockLayer renderLayer(IBlockState state) {
/*  77 */     return getBlockLayer();
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BoxModel getRenderModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/*  83 */     IBlockState state1 = state == null ? world.getBlockState(pos) : state;
/*  84 */     BoxModel boxes = BoxModel.newStandardBlock();
/*  85 */     Box worldBox = (Box)boxes.get(0);
/*  86 */     worldBox.layer = renderLayer(state);
/*  87 */     for (EnumFacing side : EnumFacing.values()) {
/*  88 */       boolean renderSide = shouldSideBeRendered(world, pos.offset(side), side);
/*  89 */       worldBox.invisible[side.ordinal()] = (!renderSide ? 1 : false);
/*  90 */       if (renderSide) {
/*  91 */         net.minecraft.client.renderer.texture.TextureAtlasSprite worldIcon = getConnectedTexture(state1, side).getWorldIcon(world, pos, side);
/*  92 */         BakedQuad bakedQuad = (BakedQuad)worldBox.getQuads(side).get(0);
/*  93 */         Box.loadTextureUV(worldBox, worldIcon, side.getIndex(), bakedQuad.getVertexData(), 0, worldBox.textureBounds, null, null);
/*     */       }
/*     */     }
/*     */     
/*  97 */     return boxes;
/*     */   }
/*     */   
/*     */   public boolean isNormalCube(IBlockAccess world, BlockPos pos)
/*     */   {
/* 102 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUBlockConnectedTextureBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */