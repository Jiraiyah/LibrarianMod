/*    */ package com.rwtema.extrautils2.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.model.Box;
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public abstract class XUBlockFull extends XUBlockStatic
/*    */ {
/*    */   boolean rotates;
/*    */   
/*    */   public XUBlockFull(Material materialIn)
/*    */   {
/* 15 */     super(materialIn);
/*    */   }
/*    */   
/*    */ 
/*    */   public void setBlockState(XUBlockStateCreator creator)
/*    */   {
/* 21 */     super.setBlockState(creator);
/* 22 */     this.rotates = creator.getProperties().contains(XUBlockStateCreator.ROTATION_HORIZONTAL);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isOpaqueCube()
/*    */   {
/* 29 */     return true;
/*    */   }
/*    */   
/*    */   public BoxModel getModel(IBlockState state)
/*    */   {
/* 34 */     BoxModel boxes = BoxModel.newStandardBlock();
/* 35 */     Box box = (Box)boxes.get(0);
/* 36 */     for (EnumFacing side : EnumFacing.values()) {
/* 37 */       box.textureSide[side.getIndex()] = getTexture(state, side);
/*    */     }
/*    */     
/* 40 */     if (this.rotates) {
/* 41 */       boxes.rotateY((EnumFacing)state.getValue(XUBlockStateCreator.ROTATION_HORIZONTAL));
/*    */     }
/*    */     
/* 44 */     return boxes;
/*    */   }
/*    */   
/*    */   public abstract String getTexture(IBlockState paramIBlockState, EnumFacing paramEnumFacing);
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUBlockFull.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */