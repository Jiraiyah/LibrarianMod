/*    */ package com.rwtema.extrautils2.backend;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import net.minecraft.client.resources.IResourcePack;
/*    */ import net.minecraft.client.resources.data.IMetadataSection;
/*    */ import net.minecraft.client.resources.data.IMetadataSerializer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.fml.client.FMLClientHandler;
/*    */ import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
/*    */ 
/*    */ public class RedirectResourcePack implements IResourcePack
/*    */ {
/*    */   public static List<IResourcePack> packs;
/*    */   protected final String name;
/*    */   IResourcePack xuPack;
/*    */   public final HashSet<String> domains;
/*    */   public String prefix;
/*    */   
/*    */   public RedirectResourcePack(String name, HashSet<String> domains, String folderPrefix)
/*    */   {
/* 26 */     this.name = name.toLowerCase();
/* 27 */     this.xuPack = FMLClientHandler.instance().getResourcePackFor("ExtraUtils2");
/* 28 */     this.domains = domains;
/* 29 */     this.prefix = folderPrefix;
/*    */   }
/*    */   
/*    */   public InputStream getInputStream(ResourceLocation location)
/*    */     throws IOException
/*    */   {
/* 35 */     return this.xuPack.getInputStream(new ResourceLocation("extrautils2", location.getResourcePath()));
/*    */   }
/*    */   
/*    */   public boolean resourceExists(ResourceLocation location)
/*    */   {
/* 40 */     String resourcePath = location.getResourcePath();
/* 41 */     return (resourcePath.startsWith(this.prefix)) && (this.xuPack.resourceExists(new ResourceLocation("extrautils2", resourcePath)));
/*    */   }
/*    */   
/*    */ 
/*    */   public Set<String> getResourceDomains()
/*    */   {
/* 47 */     return this.domains;
/*    */   }
/*    */   
/*    */   public <T extends IMetadataSection> T getPackMetadata(IMetadataSerializer p_135058_1_, String p_135058_2_) throws IOException
/*    */   {
/* 52 */     return null;
/*    */   }
/*    */   
/*    */   public BufferedImage getPackImage() throws IOException
/*    */   {
/* 57 */     throw new IOException();
/*    */   }
/*    */   
/*    */   public String getPackName()
/*    */   {
/* 62 */     return "ExtraUtils2_Additional";
/*    */   }
/*    */   
/*    */   public void register()
/*    */   {
/* 67 */     List<IResourcePack> packs = getiResourcePacks();
/* 68 */     packs.add(this);
/*    */   }
/*    */   
/*    */   public List<IResourcePack> getiResourcePacks() {
/* 72 */     List<IResourcePack> packs1 = packs;
/* 73 */     if (packs1 == null)
/* 74 */       packs1 = (List)ObfuscationReflectionHelper.getPrivateValue(FMLClientHandler.class, FMLClientHandler.instance(), new String[] { "resourcePackList" });
/* 75 */     return packs1;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\RedirectResourcePack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */