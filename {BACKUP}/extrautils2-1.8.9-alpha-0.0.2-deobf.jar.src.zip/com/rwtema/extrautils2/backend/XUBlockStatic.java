/*     */ package com.rwtema.extrautils2.backend;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public abstract class XUBlockStatic extends XUBlock
/*     */ {
/*  20 */   public HashMap<IBlockState, BoxModel> cachedModels = new HashMap()
/*     */   {
/*     */     public BoxModel get(Object key) {
/*  23 */       BoxModel boxes = (BoxModel)super.get(key);
/*  24 */       if ((boxes == null) || (XUBlockStatic.recalc_models())) {
/*  25 */         IBlockState state = key != null ? (IBlockState)key : XUBlockStatic.this.getDefaultState();
/*  26 */         boxes = XUBlockStatic.this.getModel(state);
/*  27 */         super.put(state, boxes);
/*     */       }
/*  29 */       return boxes;
/*     */     }
/*     */   };
/*  32 */   public HashMap<IBlockState, BoxModel> cachedInvModels = new HashMap()
/*     */   {
/*     */     public BoxModel get(Object key) {
/*  35 */       BoxModel boxes = (BoxModel)super.get(key);
/*  36 */       if ((boxes == null) || (XUBlockStatic.recalc_models())) {
/*  37 */         IBlockState state = key != null ? (IBlockState)key : XUBlockStatic.this.getDefaultState();
/*  38 */         boxes = XUBlockStatic.this.getModelInv(state);
/*  39 */         boxes.moveToCenterForInventoryRendering();
/*     */         
/*     */ 
/*  42 */         super.put(state, boxes);
/*     */       }
/*  44 */       return boxes;
/*     */     }
/*     */   };
/*     */   public EnumSet<EnumWorldBlockLayer> set;
/*     */   
/*     */   public XUBlockStatic(Material materialIn)
/*     */   {
/*  51 */     super(materialIn);
/*     */   }
/*     */   
/*     */   public static boolean recalc_models() {
/*  55 */     return false;
/*     */   }
/*     */   
/*     */   public void registerTextures()
/*     */   {
/*  60 */     for (IBlockState iBlockState : this.xuBlockState.getValidStates()) {
/*  61 */       ((BoxModel)this.cachedModels.get(iBlockState)).registerTextures();
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearCaches()
/*     */   {
/*  67 */     this.cachedModels.clear();
/*  68 */     this.cachedInvModels.clear();
/*  69 */     this.set = null;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public BoxModel getWorldModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/*  75 */     return (BoxModel)this.cachedModels.get(state == null ? world.getBlockState(pos) : state);
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public BoxModel getInventoryModel(@Nullable ItemStack item)
/*     */   {
/*  81 */     return (BoxModel)this.cachedInvModels.get(this.xuBlockState.getStateFromItemStack(item));
/*     */   }
/*     */   
/*     */   public BoxModel getModelInv(IBlockState state) {
/*  85 */     return getModel(state);
/*     */   }
/*     */   
/*     */   public abstract BoxModel getModel(IBlockState paramIBlockState);
/*     */   
/*     */   public boolean canRenderInLayer(EnumWorldBlockLayer layer)
/*     */   {
/*  92 */     EnumSet<EnumWorldBlockLayer> set = this.set;
/*  93 */     if (set == null) {
/*  94 */       set = EnumSet.noneOf(EnumWorldBlockLayer.class);
/*  95 */       for (IBlockState iBlockState : this.xuBlockState.getValidStates()) {
/*  96 */         for (Box box : (BoxModel)this.cachedModels.get(iBlockState)) {
/*  97 */           set.add(box.layer);
/*     */         }
/*     */       }
/* 100 */       this.set = set;
/*     */     }
/* 102 */     return set.contains(layer);
/*     */   }
/*     */   
/*     */   public AxisAlignedBB getSelectedBoundingBox(World worldIn, BlockPos pos, IBlockState state)
/*     */   {
/* 107 */     return ((BoxModel)this.cachedModels.get(state)).getAABB(pos, true);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\XUBlockStatic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */