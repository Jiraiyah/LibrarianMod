/*    */ package com.rwtema.extrautils2.backend.multiblockstate;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlock;
/*    */ import com.rwtema.extrautils2.backend.model.XUBlockState;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ 
/*    */ public class XUBlockStateMulti extends XUBlockState
/*    */ {
/*    */   public final XUBlock mainBlock;
/*    */   
/*    */   public XUBlockStateMulti(net.minecraft.block.Block blockIn, com.google.common.collect.ImmutableMap<IProperty, Comparable> propertiesIn, XUBlock mainBlock)
/*    */   {
/* 13 */     super(blockIn, propertiesIn);
/* 14 */     this.mainBlock = mainBlock;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\multiblockstate\XUBlockStateMulti.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */