/*    */ package com.rwtema.extrautils2.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.XUProxy;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public abstract interface ISidedFunction<F, T>
/*    */ {
/*    */   @SideOnly(Side.SERVER)
/*    */   public abstract T applyServer(F paramF);
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public abstract T applyClient(F paramF);
/*    */   
/*    */   public static class SidedCallabe<V> implements java.util.concurrent.Callable<V>
/*    */   {
/*    */     final ISidedFunction<Void, V> function;
/*    */     
/*    */     public SidedCallabe(ISidedFunction<Void, V> function)
/*    */     {
/* 21 */       this.function = function;
/*    */     }
/*    */     
/*    */     public V call() throws Exception
/*    */     {
/* 26 */       return (V)com.rwtema.extrautils2.ExtraUtils2.proxy.apply(this.function, null);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\ISidedFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */