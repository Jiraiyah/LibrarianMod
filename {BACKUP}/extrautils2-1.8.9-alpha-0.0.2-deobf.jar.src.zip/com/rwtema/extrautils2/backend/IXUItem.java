package com.rwtema.extrautils2.backend;

import com.rwtema.extrautils2.backend.model.PassthruModelItem.ModelLayer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public abstract interface IXUItem
{
  @SideOnly(Side.CLIENT)
  public abstract void registerTextures();
  
  @SideOnly(Side.CLIENT)
  public abstract IBakedModel createModel(int paramInt);
  
  @SideOnly(Side.CLIENT)
  public abstract TextureAtlasSprite getBaseTexture();
  
  @SideOnly(Side.CLIENT)
  public abstract void addQuads(PassthruModelItem.ModelLayer paramModelLayer, ItemStack paramItemStack);
  
  @SideOnly(Side.CLIENT)
  public abstract void postTextureRegister();
  
  @SideOnly(Side.CLIENT)
  public abstract boolean renderAsTool();
  
  @SideOnly(Side.CLIENT)
  public abstract void clearCaches();
  
  @SideOnly(Side.CLIENT)
  public abstract boolean allowOverride();
  
  @SideOnly(Side.CLIENT)
  public abstract int getMaxMetadata();
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\IXUItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */