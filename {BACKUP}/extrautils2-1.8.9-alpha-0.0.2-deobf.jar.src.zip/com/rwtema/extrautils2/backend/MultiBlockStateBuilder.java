/*     */ package com.rwtema.extrautils2.backend;
/*     */ 
/*     */ import com.google.common.base.Optional;
/*     */ import com.google.common.base.Throwables;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import com.rwtema.extrautils2.backend.model.XUBlockState;
/*     */ import com.rwtema.extrautils2.backend.multiblockstate.XUBlockStateMulti;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.util.MapPopulator;
/*     */ import net.minecraftforge.common.property.IUnlistedProperty;
/*     */ 
/*     */ public class MultiBlockStateBuilder<T extends XUBlock>
/*     */ {
/*     */   public final Class<T> clazz;
/*  30 */   private final List<IProperty<? extends Comparable>> worldProperties = Lists.newArrayList();
/*  31 */   private final List<IProperty<? extends Comparable>> dropProperties = Lists.newArrayList();
/*  32 */   private final HashMap<IProperty, Comparable> defaultValues = Maps.newHashMap();
/*     */   private final Constructor<T> constructor;
/*     */   private final Object[] parameters;
/*     */   public IBlockState[] meta2states;
/*     */   public TObjectIntHashMap<IBlockState> states2meta;
/*  37 */   public HashSet<IBlockState> genericPipeStates = new HashSet();
/*     */   public HashMap<Map<IProperty, Comparable>, XUBlockState> propertyStateBlockStatesMap;
/*  39 */   public boolean initialized = false;
/*     */   public XUBlockStateMulti defaultState;
/*     */   public T mainBlock;
/*     */   
/*     */   public MultiBlockStateBuilder(Class<T> clazz, Object... parameters) {
/*  44 */     this.clazz = clazz;
/*  45 */     this.parameters = parameters;
/*  46 */     Class<?>[] parameClazzes = new Class[parameters.length];
/*  47 */     for (int i = 0; i < parameters.length; i++) {
/*  48 */       if (parameters[i] == null) {
/*  49 */         parameClazzes[i] = Integer.TYPE;
/*     */       } else {
/*  51 */         parameClazzes[i] = parameters[i].getClass();
/*     */       }
/*     */     }
/*     */     try {
/*  55 */       this.constructor = clazz.getConstructor(parameClazzes);
/*     */     } catch (NoSuchMethodException e) {
/*  57 */       throw Throwables.propagate(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public MultiBlockStateBuilder<T> addWorldProperties(Collection<IProperty<?>> properties) {
/*  62 */     this.worldProperties.addAll(properties);
/*  63 */     return this;
/*     */   }
/*     */   
/*     */   public MultiBlockStateBuilder<T> addDropProperties(Collection<IProperty<?>> properties) {
/*  67 */     this.dropProperties.addAll(properties);
/*  68 */     return this;
/*     */   }
/*     */   
/*     */   public MultiBlockStateBuilder<T> addWorldProperties(IProperty<?>... properties) {
/*  72 */     Collections.addAll(this.worldProperties, properties);
/*  73 */     return this;
/*     */   }
/*     */   
/*     */   public MultiBlockStateBuilder<T> addDropProperties(IProperty<?>... properties) {
/*  77 */     Collections.addAll(this.dropProperties, properties);
/*  78 */     return this;
/*     */   }
/*     */   
/*     */   public <K extends Comparable<K>> MultiBlockStateBuilder<T> setDefaultValue(IProperty<K> property, K value) {
/*  82 */     this.defaultValues.put(property, value);
/*  83 */     return this;
/*     */   }
/*     */   
/*     */   public List<T> createBlocks(T firstBlock) {
/*  87 */     IProperty<?>[] worldProperties = (IProperty[])this.worldProperties.toArray(new IProperty[this.worldProperties.size()]);
/*  88 */     IProperty<?>[] dropProperties = (IProperty[])this.dropProperties.toArray(new IProperty[this.dropProperties.size()]);
/*  89 */     IProperty[] properties = XUBlockStateCreator.joinProperties(worldProperties, dropProperties);
/*  90 */     Arrays.sort(properties, XUBlockStateCreator.property_sorter);
/*     */     
/*  92 */     List<Collection<? extends Comparable>> allowedValues = Lists.newArrayList();
/*     */     
/*  94 */     for (IProperty<?> property : properties) {
/*  95 */       allowedValues.add(property.getAllowedValues());
/*     */     }
/*     */     
/*  98 */     List<List<Comparable>> propertyStates = Lists.newArrayList(net.minecraft.util.Cartesian.cartesianProduct(allowedValues));
/*     */     
/* 100 */     if (propertyStates.size() < 16) {
/* 101 */       throw new RuntimeException("No of iblockstates = " + propertyStates.size() + " - Dont be silly");
/*     */     }
/* 103 */     int numBlocks = (int)Math.ceil(propertyStates.size() / 16.0D);
/*     */     
/* 105 */     List<T> blocks = Lists.newArrayListWithCapacity(numBlocks);
/*     */     
/* 107 */     if (firstBlock != null) { blocks.add(firstBlock);
/*     */     }
/* 109 */     while (blocks.size() < numBlocks) {
/*     */       try {
/* 111 */         Object[] par = new Object[this.parameters.length];
/* 112 */         for (int i = 0; i < par.length; i++) {
/* 113 */           if (this.parameters[i] == null) {
/* 114 */             par[i] = Integer.valueOf(blocks.size());
/*     */           } else {
/* 116 */             par[i] = this.parameters[i];
/*     */           }
/*     */         }
/* 119 */         blocks.add(this.constructor.newInstance(par));
/*     */       } catch (Exception err) {
/* 121 */         throw new RuntimeException(err);
/*     */       }
/*     */     }
/*     */     
/* 125 */     this.mainBlock = ((XUBlock)blocks.get(0));
/*     */     
/* 127 */     final HashMap<Map<IProperty, Comparable>, T> propertyStateBlockMap = new HashMap();
/* 128 */     this.propertyStateBlockStatesMap = new HashMap();
/* 129 */     for (int i = 0; i < propertyStates.size(); i++) {
/* 130 */       List<Comparable> propertState = (List)propertyStates.get(i);
/* 131 */       Map<IProperty, Comparable> map1 = MapPopulator.createMap(Arrays.asList(properties), propertState);
/* 132 */       T t = (XUBlock)blocks.get(i / 16);
/* 133 */       propertyStateBlockMap.put(map1, t);
/*     */     }
/*     */     
/* 136 */     this.meta2states = new IBlockState[propertyStates.size()];
/*     */     
/* 138 */     HashMap<T, XUBlockStateCreator> map = new HashMap();
/*     */     
/* 140 */     for (int i = 0; i < blocks.size(); i++) {
/* 141 */       final T curBlock = (XUBlock)blocks.get(i);
/* 142 */       final List<IBlockState> myStates = Lists.newArrayList();
/* 143 */       XUBlockStateCreator creator = new XUBlockStateCreator(curBlock, worldProperties, dropProperties, this.defaultValues)
/*     */       {
/*     */         private ImmutableList<IBlockState> validStates;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         protected net.minecraft.block.state.BlockState.StateImplementation createState(Block block, ImmutableMap<IProperty, Comparable> properties, ImmutableMap<IUnlistedProperty<?>, Optional<?>> unlistedProperties)
/*     */         {
/* 153 */           if (MultiBlockStateBuilder.this.propertyStateBlockStatesMap.containsKey(properties)) {
/* 154 */             XUBlockState xuBlockState = (XUBlockState)MultiBlockStateBuilder.this.propertyStateBlockStatesMap.get(properties);
/* 155 */             xuBlockState.clearPropertyTable();
/* 156 */             if (xuBlockState.getBlock() == curBlock) {
/* 157 */               myStates.add(xuBlockState);
/*     */             }
/* 159 */             return xuBlockState;
/*     */           }
/* 161 */           T blockIn = (XUBlock)propertyStateBlockMap.get(properties);
/* 162 */           XUBlockState state = MultiBlockStateBuilder.this.createXUBlockStateMulti(blockIn, properties, MultiBlockStateBuilder.this.mainBlock);
/* 163 */           if (blockIn == curBlock) {
/* 164 */             myStates.add(state);
/*     */           }
/* 166 */           MultiBlockStateBuilder.this.propertyStateBlockStatesMap.put(properties, state);
/* 167 */           return state;
/*     */         }
/*     */         
/*     */ 
/*     */         public ImmutableList<IBlockState> getValidStates()
/*     */         {
/* 173 */           return ImmutableList.copyOf(myStates);
/*     */         }
/*     */         
/*     */         protected IBlockState[] createBlockStateArray(ImmutableList<IBlockState> validStates)
/*     */         {
/* 178 */           return (IBlockState[])myStates.toArray(new IBlockState[myStates.size()]);
/*     */         }
/*     */         
/* 181 */       };
/* 182 */       System.arraycopy(creator.meta2state, 0, this.meta2states, i * 16, creator.meta2state.length);
/* 183 */       this.genericPipeStates.addAll(myStates);
/* 184 */       map.put(curBlock, creator);
/*     */     }
/*     */     
/* 187 */     this.states2meta = new TObjectIntHashMap();
/* 188 */     for (int i = 0; i < this.meta2states.length; i++) {
/* 189 */       this.states2meta.put(this.meta2states[i], i);
/*     */     }
/*     */     
/* 192 */     this.defaultState = ((XUBlockStateMulti)((XUBlockStateCreator)map.get(this.mainBlock)).defaultState);
/*     */     
/* 194 */     this.initialized = true;
/*     */     
/* 196 */     for (Map.Entry<T, XUBlockStateCreator> entry : map.entrySet()) {
/* 197 */       ((XUBlock)entry.getKey()).setBlockState((XUBlockStateCreator)entry.getValue());
/*     */     }
/*     */     
/* 200 */     return blocks;
/*     */   }
/*     */   
/*     */   @javax.annotation.Nonnull
/*     */   protected XUBlockStateMulti createXUBlockStateMulti(T blockIn, ImmutableMap<IProperty, Comparable> properties, T mainBlock) {
/* 205 */     return new XUBlockStateMulti(blockIn, properties, mainBlock);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\MultiBlockStateBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */