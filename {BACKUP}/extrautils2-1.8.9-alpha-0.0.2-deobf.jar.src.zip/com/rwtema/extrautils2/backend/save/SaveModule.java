/*    */ package com.rwtema.extrautils2.backend.save;
/*    */ 
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ public abstract class SaveModule {
/*    */   String name;
/*    */   
/*    */   public SaveModule(String name) {
/*  9 */     this.name = name;
/*    */   }
/*    */   
/*    */   public abstract void readFromNBT(NBTTagCompound paramNBTTagCompound);
/*    */   
/*    */   public abstract void writeToNBT(NBTTagCompound paramNBTTagCompound);
/*    */   
/*    */   public void markDirty() {
/* 17 */     if (SaveManager.manager != null) {
/* 18 */       SaveManager.manager.markDirty();
/*    */     }
/*    */   }
/*    */   
/*    */   public abstract void reset();
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\save\SaveModule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */