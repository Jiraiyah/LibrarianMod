/*    */ package com.rwtema.extrautils2.backend.save;
/*    */ 
/*    */ import com.rwtema.extrautils2.chunkloading.ChunkLoaderLoginTimes;
/*    */ import com.rwtema.extrautils2.power.PowerSettings;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.world.WorldSavedData;
/*    */ import net.minecraft.world.WorldServer;
/*    */ import net.minecraftforge.common.DimensionManager;
/*    */ 
/*    */ public class SaveManager extends WorldSavedData
/*    */ {
/*    */   public static final String SAVE_DATA_NAME = "XU2SaveData";
/*    */   public static SaveManager manager;
/* 14 */   public static SaveModule[] saveModules = { PowerSettings.instance, ChunkLoaderLoginTimes.instance };
/*    */   
/*    */ 
/*    */ 
/*    */   public SaveManager(String name)
/*    */   {
/* 20 */     super(name);
/*    */   }
/*    */   
/*    */   public static void init() {
/* 24 */     WorldServer worldServer = DimensionManager.getWorld(0);
/* 25 */     manager = (SaveManager)worldServer.loadItemData(SaveManager.class, "XU2SaveData");
/* 26 */     if (manager == null) {
/* 27 */       manager = new SaveManager("XU2SaveData");
/* 28 */       worldServer.setItemData("XU2SaveData", manager);
/* 29 */       manager.markDirty();
/*    */     }
/*    */   }
/*    */   
/*    */   public void readFromNBT(NBTTagCompound nbt)
/*    */   {
/* 35 */     for (SaveModule saveModule : saveModules) {
/* 36 */       saveModule.reset();
/* 37 */       if (nbt.hasKey(saveModule.name, 10)) {
/*    */         try {
/* 39 */           saveModule.readFromNBT(nbt.getCompoundTag(saveModule.name));
/*    */         } catch (Exception e) {
/* 41 */           e.printStackTrace();
/* 42 */           saveModule.reset();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void writeToNBT(NBTTagCompound nbt)
/*    */   {
/* 50 */     for (SaveModule saveModule : saveModules) {
/*    */       try {
/* 52 */         NBTTagCompound tag = new NBTTagCompound();
/* 53 */         saveModule.writeToNBT(tag);
/* 54 */         nbt.setTag(saveModule.name, tag);
/*    */       } catch (Exception e) {
/* 56 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\backend\save\SaveManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */