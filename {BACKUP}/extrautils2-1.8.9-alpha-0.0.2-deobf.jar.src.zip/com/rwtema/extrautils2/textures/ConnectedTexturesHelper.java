/*    */ package com.rwtema.extrautils2.textures;
/*    */ 
/*    */ public class ConnectedTexturesHelper {
/*  4 */   public static int[] textureFromArrangement = new int['Ā'];
/*  5 */   public static boolean[] isAdvancedArrangement = new boolean[16];
/*  6 */   public static int[] textureIds = new int[47];
/*    */   
/*    */   static
/*    */   {
/* 10 */     textureIds = new int[47];
/* 11 */     int j = 0;
/*    */     
/* 13 */     int[] sideA = { 1, 4, 4, 1 };
/* 14 */     int[] sideB = { 2, 2, 8, 8 };
/* 15 */     int[] corner = { 16, 32, 64, 128 };
/*    */     
/* 17 */     boolean[] validTexture = new boolean['ɱ'];
/* 18 */     int[] revTextureIds = new int['ɱ'];
/* 19 */     int[] k = { 1, 5, 25, 125 };
/*    */     
/* 21 */     for (int ar = 0; ar < 256; ar++) {
/* 22 */       int texId = 0;
/*    */       
/* 24 */       for (int i = 0; i < 4; i++) {
/* 25 */         boolean sA = (ar & sideA[i]) != 0;
/* 26 */         boolean sB = (ar & sideB[i]) != 0;
/* 27 */         boolean c = (ar & corner[i]) != 0;
/* 28 */         texId += getTex(sA, sB, c) * k[i];
/* 29 */         if ((!sA) && (!sB)) {
/* 30 */           isAdvancedArrangement[(ar & 0xF)] = true;
/*    */         }
/*    */       }
/* 33 */       if (validTexture[texId] == 0) {
/* 34 */         textureIds[j] = texId;
/* 35 */         revTextureIds[texId] = j;
/* 36 */         validTexture[texId] = true;
/* 37 */         j++;
/*    */       }
/*    */       
/* 40 */       textureFromArrangement[ar] = revTextureIds[texId];
/*    */     }
/*    */   }
/*    */   
/*    */   private static int getTex(boolean sideA, boolean sideB, boolean corner)
/*    */   {
/* 46 */     return corner ? 3 : sideB ? 2 : sideA ? 1 : sideB ? 0 : 4;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\ConnectedTexturesHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */