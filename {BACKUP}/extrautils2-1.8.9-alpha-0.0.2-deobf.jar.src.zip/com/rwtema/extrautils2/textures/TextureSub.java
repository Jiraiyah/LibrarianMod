/*    */ package com.rwtema.extrautils2.textures;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import javax.imageio.ImageIO;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.client.resources.IResource;
/*    */ import net.minecraft.client.resources.IResourceManager;
/*    */ import net.minecraft.client.resources.data.AnimationMetadataSection;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class TextureSub extends TextureAtlasSprite
/*    */ {
/*    */   String name;
/*    */   int x;
/*    */   int y;
/*    */   int size;
/*    */   int image_width;
/*    */   int image_height;
/*    */   
/*    */   public TextureSub(String spriteName, int x, int y, int image_width, int image_height, int size)
/*    */   {
/* 27 */     super(spriteName);
/* 28 */     this.x = x;
/* 29 */     this.y = y;
/* 30 */     this.size = size;
/* 31 */     this.image_width = image_width;
/* 32 */     this.image_height = image_height;
/* 33 */     this.name = (spriteName + "_" + x + "_" + y + "_" + image_width + "_" + image_height + "_" + size);
/*    */   }
/*    */   
/*    */   public String getIconName() {
/* 37 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean hasCustomLoader(IResourceManager manager, ResourceLocation location)
/*    */   {
/* 43 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean load(IResourceManager par1ResourceManager, ResourceLocation location)
/*    */   {
/* 49 */     ResourceLocation resourcelocation = new ResourceLocation("ExtraUtils2:connected/" + super.getIconName());
/* 50 */     ResourceLocation resourcelocation1 = com.rwtema.extrautils2.backend.model.Textures.completeTextureResourceLocation(resourcelocation);
/*    */     try
/*    */     {
/* 53 */       IResource iresource = par1ResourceManager.getResource(resourcelocation1);
/* 54 */       BufferedImage[] abufferedimage = new BufferedImage[1 + Minecraft.getMinecraft().gameSettings.mipmapLevels];
/* 55 */       abufferedimage[0] = ImageIO.read(iresource.getInputStream());
/* 56 */       func_180598_a(abufferedimage, null);
/*    */     } catch (IOException ioexception1) {
/* 58 */       com.rwtema.extrautils2.utils.LogHelper.logger.error("Using missing texture, unable to load " + resourcelocation1, ioexception1);
/* 59 */       return true;
/*    */     }
/*    */     
/* 62 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_180598_a(BufferedImage[] p_147964_1_, AnimationMetadataSection p_147964_2_)
/*    */   {
/* 68 */     setFramesTextureData(com.google.common.collect.Lists.newArrayList());
/* 69 */     int w = p_147964_1_[0].getWidth();
/* 70 */     int h = p_147964_1_[0].getHeight();
/*    */     
/* 72 */     if (w % this.image_width != 0) {
/* 73 */       throw new RuntimeException("Wrong width (must be divisible by " + this.image_width + ")");
/*    */     }
/* 75 */     if (h % this.image_height != 0) {
/* 76 */       throw new RuntimeException("Wrong height (must be divisible by " + this.image_height + ")");
/*    */     }
/* 78 */     int scale = w / this.image_width;
/* 79 */     if (this.image_height * scale != h) {
/* 80 */       throw new RuntimeException("Wrong aspect ratio (must be " + this.image_width + "x" + this.image_height + ")");
/*    */     }
/* 82 */     int s = this.size * scale;
/*    */     
/* 84 */     this.width = s;
/* 85 */     this.height = s;
/*    */     
/* 87 */     int[][] aint = new int[p_147964_1_.length][];
/*    */     
/* 89 */     BufferedImage bufferedimage = p_147964_1_[0];
/*    */     
/* 91 */     aint[0] = new int[s * s];
/*    */     
/* 93 */     bufferedimage.getRGB(this.x * scale, this.y * scale, s, s, aint[0], 0, w);
/*    */     
/* 95 */     this.framesTextureData.clear();
/* 96 */     this.framesTextureData.add(aint);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\TextureSub.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */