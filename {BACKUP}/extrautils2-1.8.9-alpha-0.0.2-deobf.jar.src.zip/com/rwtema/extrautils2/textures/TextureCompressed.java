/*    */ package com.rwtema.extrautils2.textures;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.helpers.ColorHelper;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageTypeSpecifier;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.client.resources.IResource;
/*    */ import net.minecraft.client.resources.IResourceManager;
/*    */ import net.minecraft.client.resources.data.AnimationMetadataSection;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class TextureCompressed extends TextureAtlasSprite
/*    */ {
/*    */   private final String textureBase;
/*    */   private final int n;
/*    */   private final float max_n;
/*    */   private final ResourceLocation textureLocation;
/*    */   
/*    */   public TextureCompressed(String textureBase, int n, float max_n)
/*    */   {
/* 25 */     super("extrautils2:compressed/" + textureBase + "_" + n);
/* 26 */     this.textureBase = textureBase;
/* 27 */     this.n = n;
/* 28 */     this.max_n = max_n;
/* 29 */     this.textureLocation = new ResourceLocation("minecraft", "textures/blocks/" + textureBase + ".png");
/*    */   }
/*    */   
/*    */   public boolean hasCustomLoader(IResourceManager manager, ResourceLocation location)
/*    */   {
/*    */     try {
/* 35 */       manager.getResource(location);
/* 36 */       return false;
/*    */     } catch (IOException e) {}
/* 38 */     return true;
/*    */   }
/*    */   
/*    */   public boolean load(IResourceManager manager, ResourceLocation location)
/*    */   {
/*    */     try
/*    */     {
/* 45 */       IResource iresource = manager.getResource(this.textureLocation);
/* 46 */       BufferedImage[] abufferedimage = new BufferedImage[1 + Minecraft.getMinecraft().gameSettings.mipmapLevels];
/*    */       
/* 48 */       AnimationMetadataSection animationmetadatasection = (AnimationMetadataSection)iresource.getMetadata("animation");
/*    */       
/* 50 */       BufferedImage image = javax.imageio.ImageIO.read(iresource.getInputStream());
/*    */       
/* 52 */       int w = image.getWidth();
/* 53 */       int h = image.getHeight();
/* 54 */       BufferedImage newImage = ImageTypeSpecifier.createFromBufferedImageType(2).createBufferedImage(w, h);
/*    */       
/* 56 */       float border = (2.0F + this.n / this.max_n / 2.0F) / 32.0F;
/*    */       
/* 58 */       for (int px = 0; px < w; px++) {
/* 59 */         for (int py = 0; py < h; py++) {
/* 60 */           float x = px / (w - 1);
/* 61 */           float y = py % w / (w - 1);
/* 62 */           int col = image.getRGB(px, py);
/* 63 */           float d = MathHelper.sqrt_float((x - 0.5F) * (x - 0.5F) + (y - 0.5F) * (y - 0.5F));
/*    */           
/* 65 */           float br = 1.0F - this.n / this.max_n + (0.5F - d) / 2.0F;
/* 66 */           if (br > 1.0F) { br = 1.0F;
/*    */           }
/* 68 */           if ((x <= border) || (y < border) || (1.0F - x <= border) || (1.0F - y <= border)) {
/* 69 */             br *= 0.5F;
/*    */           }
/*    */           
/* 72 */           int a = ColorHelper.getA(col);
/* 73 */           int r = MathHelper.clamp_int(Math.round(ColorHelper.getR(col) * br), 0, 255);
/* 74 */           int g = MathHelper.clamp_int(Math.round(ColorHelper.getG(col) * br), 0, 255);
/* 75 */           int b = MathHelper.clamp_int(Math.round(ColorHelper.getB(col) * br), 0, 255);
/*    */           
/* 77 */           newImage.setRGB(px, py, ColorHelper.color(r, g, b, a));
/*    */         }
/*    */       }
/*    */       
/*    */ 
/* 82 */       abufferedimage[0] = newImage;
/*    */       
/* 84 */       func_180598_a(abufferedimage, animationmetadatasection);
/*    */     } catch (IOException ioexception1) {
/* 86 */       com.rwtema.extrautils2.utils.LogHelper.logger.error("Using missing texture, unable to load " + this.textureLocation, ioexception1);
/* 87 */       return true;
/*    */     }
/*    */     
/* 90 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\TextureCompressed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */