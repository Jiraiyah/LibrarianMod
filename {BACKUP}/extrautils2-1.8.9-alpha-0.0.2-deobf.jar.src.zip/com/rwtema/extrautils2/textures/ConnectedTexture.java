/*     */ package com.rwtema.extrautils2.textures;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.XUBlockConnectedTextureBase;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.resources.IResource;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ 
/*     */ public class ConnectedTexture implements ISolidWorldTexture
/*     */ {
/*  20 */   public static EnumFacing[] up = { EnumFacing.NORTH, EnumFacing.NORTH, EnumFacing.UP, EnumFacing.UP, EnumFacing.UP, EnumFacing.UP };
/*  21 */   public static EnumFacing[] left = { EnumFacing.WEST, EnumFacing.WEST, EnumFacing.EAST, EnumFacing.WEST, EnumFacing.NORTH, EnumFacing.SOUTH };
/*     */   public final String baseTextureName;
/*     */   final XUBlock base;
/*     */   final IBlockState state;
/*     */   public String texture;
/*  26 */   TextureAtlasSprite[] icons = new TextureAtlasSprite[47];
/*  27 */   boolean hasConnectedTextures = false;
/*     */   
/*     */   public ConnectedTexture(String texture, IBlockState state, XUBlockConnectedTextureBase base) {
/*  30 */     this.texture = texture;
/*  31 */     this.state = state;
/*  32 */     this.base = base;
/*     */     try
/*     */     {
/*  35 */       ResourceLocation resourcelocation = new ResourceLocation("ExtraUtils2:connected/" + texture);
/*  36 */       ResourceLocation resourcelocation1 = Textures.completeTextureResourceLocation(resourcelocation);
/*  37 */       IResource iresource = Minecraft.getMinecraft().getResourceManager().getResource(resourcelocation1);
/*  38 */       BufferedImage read = javax.imageio.ImageIO.read(iresource.getInputStream());
/*  39 */       this.hasConnectedTextures = (read.getHeight() == read.getWidth() * 5);
/*     */     } catch (IOException e) {
/*  41 */       this.hasConnectedTextures = false;
/*     */     }
/*     */     
/*     */ 
/*  45 */     this.baseTextureName = ("connected/" + texture);
/*  46 */     if (this.hasConnectedTextures) {
/*  47 */       for (int i = 0; i < 47; i++) {
/*  48 */         Textures.textureNames.put(getTexKey(i), this.icons[i] = new TextureConnectedTextures(texture, i));
/*     */       }
/*     */     } else {
/*  51 */       Textures.register(new String[] { this.baseTextureName });
/*     */     }
/*     */   }
/*     */   
/*     */   private static BlockPos multiOffset(BlockPos base, EnumFacing... sides) {
/*  56 */     for (EnumFacing side : sides) {
/*  57 */       if (side != null)
/*  58 */         base = base.offset(side);
/*     */     }
/*  60 */     return base;
/*     */   }
/*     */   
/*     */   public String getTexKey(int i) {
/*  64 */     if (this.hasConnectedTextures) {
/*  65 */       return this.baseTextureName + "#" + i;
/*     */     }
/*  67 */     return this.baseTextureName;
/*     */   }
/*     */   
/*     */   private boolean matches(IBlockAccess world, BlockPos pos, EnumFacing side) {
/*  71 */     IBlockState b = world.getBlockState(pos);
/*  72 */     return (b == this.state) && (this.base.shouldSideBeRendered(world, pos.offset(side), side));
/*     */   }
/*     */   
/*     */   public TextureAtlasSprite getWorldIcon(IBlockAccess world, BlockPos blockPos, EnumFacing side)
/*     */   {
/*  77 */     if (side == null) {
/*  78 */       return null;
/*     */     }
/*  80 */     if (!this.hasConnectedTextures) {
/*  81 */       return getBaseTexture();
/*     */     }
/*  83 */     EnumFacing u = up[side.getIndex()];
/*  84 */     EnumFacing l = left[side.getIndex()];
/*  85 */     EnumFacing r = l.getOpposite();
/*  86 */     EnumFacing d = u.getOpposite();
/*     */     
/*  88 */     int ar = 0;
/*  89 */     ar += matches(world, blockPos, side, new EnumFacing[] { u });
/*  90 */     ar += matches(world, blockPos, side, new EnumFacing[] { r }) * 2;
/*  91 */     ar += matches(world, blockPos, side, new EnumFacing[] { d }) * 4;
/*  92 */     ar += matches(world, blockPos, side, new EnumFacing[] { l }) * 8;
/*     */     
/*  94 */     if (ConnectedTexturesHelper.isAdvancedArrangement[ar] == 0) {
/*  95 */       return this.icons[ConnectedTexturesHelper.textureFromArrangement[ar]];
/*     */     }
/*     */     
/*  98 */     ar += matches(world, blockPos, side, new EnumFacing[] { u, r }) * 16;
/*  99 */     ar += matches(world, blockPos, side, new EnumFacing[] { d, r }) * 32;
/* 100 */     ar += matches(world, blockPos, side, new EnumFacing[] { d, l }) * 64;
/* 101 */     ar += matches(world, blockPos, side, new EnumFacing[] { u, l }) * 128;
/*     */     
/* 103 */     return this.icons[ConnectedTexturesHelper.textureFromArrangement[ar]];
/*     */   }
/*     */   
/*     */   public String getItemTexture(EnumFacing side)
/*     */   {
/* 108 */     if (this.hasConnectedTextures) {
/* 109 */       return getTexKey(ConnectedTexturesHelper.textureFromArrangement[15]);
/*     */     }
/* 111 */     return this.baseTextureName;
/*     */   }
/*     */   
/*     */   public TextureAtlasSprite getBaseTexture() {
/* 115 */     return Textures.getSprite(this.baseTextureName);
/*     */   }
/*     */   
/*     */   private int matches(IBlockAccess world, BlockPos pos, EnumFacing side, EnumFacing... dirs) {
/* 119 */     return matches(world, multiOffset(pos, dirs), side) ? 0 : 1;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\ConnectedTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */