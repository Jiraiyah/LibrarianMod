/*    */ package com.rwtema.extrautils2.textures;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ 
/*    */ public class TextureRedstoneClock extends TextureAtlasSprite
/*    */ {
/*    */   public TextureRedstoneClock(String spriteName)
/*    */   {
/* 10 */     super(spriteName);
/*    */   }
/*    */   
/*    */   public void updateAnimation()
/*    */   {
/* 15 */     this.tickCounter += 1;
/*    */     
/* 17 */     if (this.tickCounter >= 2) {
/* 18 */       this.tickCounter = 0;
/*    */       
/* 20 */       net.minecraft.client.multiplayer.WorldClient theWorld = Minecraft.getMinecraft().theWorld;
/* 21 */       int size = this.framesTextureData.size();
/* 22 */       int t = theWorld != null ? (int)(theWorld.getTotalWorldTime() % (20 * size)) * size / 20 % size : 0;
/*    */       
/* 24 */       int k = this.frameCounter;
/*    */       
/* 26 */       if (t == this.frameCounter) { return;
/*    */       }
/* 28 */       int numSteps = t - this.frameCounter;
/* 29 */       if (numSteps < 0) { numSteps += 20;
/*    */       }
/* 31 */       if (numSteps <= 2) { k += numSteps;
/* 32 */       } else { if (numSteps > size * 3 / 4)
/* 33 */           return;
/* 34 */         k += 4;
/*    */       }
/* 36 */       k %= size;
/*    */       
/* 38 */       if (this.frameCounter != k) {
/* 39 */         net.minecraft.client.renderer.texture.TextureUtil.uploadTextureMipmap((int[][])this.framesTextureData.get(k), this.width, this.height, this.originX, this.originY, false, false);
/* 40 */         this.frameCounter = k;
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\TextureRedstoneClock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */