package com.rwtema.extrautils2.textures;

import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public abstract interface ISolidWorldTexture
{
  @SideOnly(Side.CLIENT)
  public abstract TextureAtlasSprite getWorldIcon(IBlockAccess paramIBlockAccess, BlockPos paramBlockPos, EnumFacing paramEnumFacing);
  
  @SideOnly(Side.CLIENT)
  public abstract String getItemTexture(EnumFacing paramEnumFacing);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\ISolidWorldTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */