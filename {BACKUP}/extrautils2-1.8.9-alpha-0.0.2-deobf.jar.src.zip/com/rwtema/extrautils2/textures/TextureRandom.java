/*    */ package com.rwtema.extrautils2.textures;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ 
/*    */ public class TextureRandom extends TextureLocation
/*    */ {
/*    */   public TextureRandom(String texture)
/*    */   {
/* 12 */     super(texture);
/*    */   }
/*    */   
/*    */   protected void assignBaseTextures()
/*    */   {
/* 17 */     Random random = new Random(12234L);
/* 18 */     for (int i = 0; i < 6; i++) {
/* 19 */       int j = random.nextInt(this.textures.length);
/* 20 */       this.baseTexture[i] = this.textures[(j % this.textures.length)];
/*    */     }
/*    */   }
/*    */   
/*    */   protected int getRandomIndex(IBlockAccess world, BlockPos blockPos, EnumFacing side)
/*    */   {
/* 26 */     long random = net.minecraft.util.MathHelper.getCoordinateRandom(blockPos.getX() + side.ordinal() * 12234533, blockPos.getY(), blockPos.getZ());
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 32 */     int a = (int)(random ^ random >> 32);
/* 33 */     a = Math.abs(a);
/* 34 */     return a;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\TextureRandom.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */