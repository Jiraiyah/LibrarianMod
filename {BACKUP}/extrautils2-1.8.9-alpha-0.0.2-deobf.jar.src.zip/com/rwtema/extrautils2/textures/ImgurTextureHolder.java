/*     */ package com.rwtema.extrautils2.textures;
/*     */ 
/*     */ import com.rwtema.extrautils2.blocks.BlockScreen;
/*     */ import com.rwtema.extrautils2.tile.TileScreen;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.imageio.ImageIO;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.IImageBuffer;
/*     */ import net.minecraft.client.renderer.texture.SimpleTexture;
/*     */ import net.minecraft.client.renderer.texture.TextureUtil;
/*     */ import net.minecraft.client.resources.IResourceManager;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class ImgurTextureHolder
/*     */ {
/*  29 */   public static final ResourceLocation loading_texture = new ResourceLocation("extrautils2", "textures/screen_loading.png");
/*  30 */   public static final ResourceLocation noSignal_texture = new ResourceLocation("extrautils2", "textures/screen_no_signal.png");
/*  31 */   public static final ResourceLocation error_texture = new ResourceLocation("extrautils2", "textures/screen_error.png");
/*  32 */   private static final Pattern patternControlCode = TileScreen.illegalPatternControlCode;
/*  33 */   private static final Logger logger = LogManager.getLogger();
/*  34 */   private static final AtomicInteger threadDownloadCounter = new AtomicInteger(0);
/*  35 */   public static ImgurTextureHolder _default = new ImgurTextureHolder(loading_texture);
/*  36 */   private static HashMap<String, ImgurTextureHolder> holder = new HashMap();
/*     */   public ResourceLocation resourceLocation;
/*     */   public boolean deleteOldTexture;
/*     */   public SimpleTexture img;
/*     */   public BufferedImage image;
/*  41 */   public int width = 32;
/*  42 */   public int height = 32;
/*  43 */   public float u0 = 0.0F; public float u1 = 1.0F; public float v0 = 0.0F; public float v1 = 1.0F;
/*     */   
/*     */   public ImgurTextureHolder(ResourceLocation resourceLocation) {
/*  46 */     this.resourceLocation = resourceLocation;
/*     */   }
/*     */   
/*     */   public ImgurTextureHolder(String key)
/*     */   {
/*  51 */     key = patternControlCode.matcher(key).replaceAll("");
/*  52 */     String url = "https://i.imgur.com/" + key + ".png";
/*     */     
/*  54 */     this.img = new XUDownloadImageData(null, url, loading_texture, new IImageBuffer()
/*     */     {
/*     */       public BufferedImage parseUserSkin(BufferedImage image) {
/*  57 */         if (image == null) return null;
/*  58 */         int w = image.getWidth();
/*  59 */         int h = image.getHeight();
/*  60 */         ImgurTextureHolder.this.width = ImgurTextureHolder.nextPower2(w);
/*  61 */         ImgurTextureHolder.this.height = ImgurTextureHolder.nextPower2(h);
/*  62 */         BufferedImage newImage = new BufferedImage(ImgurTextureHolder.this.width, ImgurTextureHolder.this.height, 2);
/*     */         
/*  64 */         Graphics graphics = newImage.getGraphics();
/*  65 */         int x = (ImgurTextureHolder.this.width - w) / 2;
/*  66 */         int y = (ImgurTextureHolder.this.height - h) / 2;
/*     */         
/*  68 */         ImgurTextureHolder.this.u0 = (x / ImgurTextureHolder.this.width);
/*  69 */         ImgurTextureHolder.this.u1 = ((x + w) / ImgurTextureHolder.this.width);
/*  70 */         ImgurTextureHolder.this.v0 = (y / ImgurTextureHolder.this.height);
/*  71 */         ImgurTextureHolder.this.v1 = ((y + h) / ImgurTextureHolder.this.height);
/*     */         
/*  73 */         graphics.setColor(Color.BLACK);
/*  74 */         graphics.fillRect(0, 0, ImgurTextureHolder.this.width, ImgurTextureHolder.this.height);
/*  75 */         graphics.drawImage(image, x, y, null);
/*  76 */         graphics.dispose();
/*     */         
/*  78 */         ImgurTextureHolder.this.image = newImage;
/*  79 */         return newImage;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       public void skinAvailable() {}
/*  87 */     });
/*  88 */     this.resourceLocation = new ResourceLocation("extrautils2", "texures/imgur/" + key);
/*  89 */     Minecraft.getMinecraft().renderEngine.loadTexture(this.resourceLocation, this.img);
/*     */   }
/*     */   
/*     */   public static ImgurTextureHolder getTex(String tex) {
/*  93 */     if (tex.length() == 0) return _default;
/*  94 */     ImgurTextureHolder imgurTextureHolder = (ImgurTextureHolder)holder.get(tex);
/*  95 */     if (imgurTextureHolder != null) return imgurTextureHolder;
/*  96 */     imgurTextureHolder = new ImgurTextureHolder(tex);
/*  97 */     holder.put(tex, imgurTextureHolder);
/*  98 */     return imgurTextureHolder;
/*     */   }
/*     */   
/*     */   public static int nextPower2(int v) {
/* 102 */     v--;
/* 103 */     v |= v >> 1;
/* 104 */     v |= v >> 2;
/* 105 */     v |= v >> 4;
/* 106 */     v |= v >> 8;
/* 107 */     v |= v >> 16;
/* 108 */     v++;
/* 109 */     return v;
/*     */   }
/*     */   
/*     */   public ResourceLocation getResourceLocationForBinding() {
/* 113 */     if (this.deleteOldTexture) {
/* 114 */       this.img.deleteGlTexture();
/* 115 */       this.deleteOldTexture = false;
/*     */     }
/* 117 */     return this.resourceLocation;
/*     */   }
/*     */   
/*     */   public class XUDownloadImageData extends SimpleTexture {
/*     */     private final File cacheFile;
/*     */     private final String imageUrl;
/*     */     private final IImageBuffer imageBuffer;
/*     */     private BufferedImage bufferedImage;
/*     */     private Thread imageThread;
/*     */     private boolean textureUploaded;
/*     */     
/*     */     public XUDownloadImageData(File cacheFileIn, String imageUrlIn, ResourceLocation textureResourceLocation, IImageBuffer imageBufferIn) {
/* 129 */       super();
/* 130 */       this.cacheFile = cacheFileIn;
/* 131 */       this.imageUrl = imageUrlIn;
/* 132 */       this.imageBuffer = imageBufferIn;
/*     */     }
/*     */     
/*     */     private void checkTextureUploaded() {
/* 136 */       if ((!this.textureUploaded) && 
/* 137 */         (this.bufferedImage != null)) {
/* 138 */         if (this.textureLocation != null) {
/* 139 */           deleteGlTexture();
/*     */         }
/*     */         
/* 142 */         TextureUtil.uploadTextureImage(super.getGlTextureId(), this.bufferedImage);
/* 143 */         this.textureUploaded = true;
/*     */       }
/*     */     }
/*     */     
/*     */     public int getGlTextureId()
/*     */     {
/* 149 */       checkTextureUploaded();
/* 150 */       return super.getGlTextureId();
/*     */     }
/*     */     
/*     */     public void setBufferedImage(BufferedImage bufferedImageIn) {
/* 154 */       this.bufferedImage = bufferedImageIn;
/*     */       
/* 156 */       if (this.imageBuffer != null) {
/* 157 */         this.imageBuffer.skinAvailable();
/*     */       }
/*     */     }
/*     */     
/*     */     public void loadTexture(IResourceManager resourceManager) throws IOException {
/* 162 */       if ((this.bufferedImage == null) && (this.textureLocation != null)) {
/* 163 */         super.loadTexture(resourceManager);
/*     */       }
/*     */       
/* 166 */       if (this.imageThread == null) {
/* 167 */         if ((this.cacheFile != null) && (this.cacheFile.isFile())) {
/* 168 */           ImgurTextureHolder.logger.debug("Loading http texture from local cache ({})", new Object[] { this.cacheFile });
/*     */           try
/*     */           {
/* 171 */             this.bufferedImage = ImageIO.read(this.cacheFile);
/*     */             
/* 173 */             if (this.imageBuffer != null) {
/* 174 */               setBufferedImage(this.imageBuffer.parseUserSkin(this.bufferedImage));
/*     */             }
/*     */           } catch (IOException ioexception) {
/* 177 */             ImgurTextureHolder.logger.error("Couldn't load texture " + this.cacheFile, ioexception);
/* 178 */             loadTextureFromServer();
/*     */           }
/*     */         } else {
/* 181 */           loadTextureFromServer();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     protected void loadTextureFromServer() {
/* 187 */       this.imageThread = new Thread("XU Texture Downloader #" + ImgurTextureHolder.threadDownloadCounter.incrementAndGet()) {
/*     */         public void run() {
/* 189 */           HttpURLConnection httpurlconnection = null;
/* 190 */           ImgurTextureHolder.logger.debug("Downloading http texture from {} to {}", new Object[] { ImgurTextureHolder.XUDownloadImageData.this.imageUrl, ImgurTextureHolder.XUDownloadImageData.this.cacheFile });
/*     */           try
/*     */           {
/* 193 */             httpurlconnection = (HttpURLConnection)new URL(ImgurTextureHolder.XUDownloadImageData.this.imageUrl).openConnection(Minecraft.getMinecraft().getProxy());
/* 194 */             httpurlconnection.setDoInput(true);
/* 195 */             httpurlconnection.setDoOutput(false);
/* 196 */             httpurlconnection.connect();
/*     */             
/* 198 */             if (httpurlconnection.getResponseCode() / 100 == 2) {
/* 199 */               int contentLength = httpurlconnection.getContentLength();
/* 200 */               if ((BlockScreen.maxSize > 0) && (contentLength > BlockScreen.maxSize)) {
/* 201 */                 ImgurTextureHolder.logger.debug(contentLength + " is larger than " + BlockScreen.maxSize);
/* 202 */                 ImgurTextureHolder.this.resourceLocation = ImgurTextureHolder.error_texture;
/* 203 */                 ImgurTextureHolder.this.deleteOldTexture = true;
/*     */               } else {
/*     */                 BufferedImage bufferedimage;
/*     */                 BufferedImage bufferedimage;
/* 207 */                 if (ImgurTextureHolder.XUDownloadImageData.this.cacheFile != null) {
/* 208 */                   FileUtils.copyInputStreamToFile(httpurlconnection.getInputStream(), ImgurTextureHolder.XUDownloadImageData.this.cacheFile);
/* 209 */                   bufferedimage = ImageIO.read(ImgurTextureHolder.XUDownloadImageData.this.cacheFile);
/*     */                 } else {
/* 211 */                   bufferedimage = TextureUtil.readBufferedImage(httpurlconnection.getInputStream());
/*     */                 }
/*     */                 
/* 214 */                 if (ImgurTextureHolder.XUDownloadImageData.this.imageBuffer != null) {
/* 215 */                   bufferedimage = ImgurTextureHolder.XUDownloadImageData.this.imageBuffer.parseUserSkin(bufferedimage);
/*     */                 }
/*     */                 
/* 218 */                 ImgurTextureHolder.XUDownloadImageData.this.setBufferedImage(bufferedimage);
/*     */               }
/*     */             } else {
/* 221 */               ImgurTextureHolder.this.resourceLocation = ImgurTextureHolder.noSignal_texture;
/* 222 */               ImgurTextureHolder.this.deleteOldTexture = true;
/*     */             }
/*     */           } catch (Exception exception) {
/* 225 */             ImgurTextureHolder.logger.error("Couldn't download http texture", exception);
/* 226 */             ImgurTextureHolder.this.resourceLocation = ImgurTextureHolder.error_texture;
/* 227 */             ImgurTextureHolder.this.deleteOldTexture = true;
/*     */           }
/*     */           finally {
/* 230 */             if (httpurlconnection != null) {
/* 231 */               httpurlconnection.disconnect();
/*     */             }
/*     */           }
/*     */         }
/* 235 */       };
/* 236 */       this.imageThread.setDaemon(true);
/* 237 */       this.imageThread.start();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\ImgurTextureHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */