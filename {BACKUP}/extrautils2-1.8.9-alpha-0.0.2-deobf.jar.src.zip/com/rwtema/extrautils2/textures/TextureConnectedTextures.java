/*     */ package com.rwtema.extrautils2.textures;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.resources.IResource;
/*     */ import net.minecraft.client.resources.IResourceManager;
/*     */ import net.minecraft.client.resources.data.AnimationMetadataSection;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class TextureConnectedTextures extends TextureAtlasSprite
/*     */ {
/*     */   private final int texID;
/*     */   private static final String basePath = "textures";
/*     */   
/*     */   protected TextureConnectedTextures(String spriteName, int texID)
/*     */   {
/*  22 */     super(spriteName);
/*  23 */     this.texID = texID;
/*     */   }
/*     */   
/*     */   public static String iconName(String name, int offset) {
/*  27 */     return name + "_" + offset;
/*     */   }
/*     */   
/*     */   public String getIconName() {
/*  31 */     return iconName(super.getIconName(), this.texID);
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_180598_a(BufferedImage[] p_147964_1_, AnimationMetadataSection p_147964_2_)
/*     */   {
/*  37 */     setFramesTextureData(com.google.common.collect.Lists.newArrayList());
/*  38 */     int width = p_147964_1_[0].getWidth();
/*  39 */     int h = p_147964_1_[0].getHeight();
/*  40 */     this.width = width;
/*     */     
/*  42 */     this.height = width;
/*     */     
/*     */ 
/*  45 */     if (width % 2 != 0) {
/*  46 */       throw new RuntimeException("Wrong width (must be divisible by 2)");
/*     */     }
/*  48 */     if (h != width * 5) {
/*  49 */       throw new RuntimeException("Wrong aspect ratio (must be 1x5)");
/*     */     }
/*  51 */     int[][] aint = new int[p_147964_1_.length][];
/*     */     
/*     */ 
/*  54 */     BufferedImage bufferedimage = p_147964_1_[0];
/*     */     
/*  56 */     aint[0] = new int[width * width];
/*     */     
/*  58 */     int textureIndexMask = ConnectedTexturesHelper.textureIds[this.texID];
/*     */     
/*  60 */     int half_width = width / 2;
/*     */     
/*     */ 
/*     */ 
/*  64 */     int subImageIndex = textureIndexMask / 125;
/*  65 */     bufferedimage.getRGB(0, subImageIndex * width, half_width, half_width, aint[0], 0, width);
/*  66 */     textureIndexMask -= subImageIndex * 125;
/*     */     
/*  68 */     subImageIndex = textureIndexMask / 25;
/*  69 */     bufferedimage.getRGB(0, subImageIndex * width + half_width, half_width, half_width, aint[0], half_width * width, width);
/*  70 */     textureIndexMask -= subImageIndex * 25;
/*     */     
/*  72 */     subImageIndex = textureIndexMask / 5;
/*  73 */     bufferedimage.getRGB(half_width, subImageIndex * width + half_width, half_width, half_width, aint[0], half_width * (width + 1), width);
/*  74 */     textureIndexMask -= subImageIndex * 5;
/*     */     
/*  76 */     subImageIndex = textureIndexMask;
/*  77 */     bufferedimage.getRGB(half_width, subImageIndex * width, half_width, half_width, aint[0], half_width, width);
/*     */     
/*  79 */     this.framesTextureData.clear();
/*  80 */     this.framesTextureData.add(aint);
/*     */   }
/*     */   
/*     */   public boolean hasCustomLoader(IResourceManager manager, ResourceLocation location)
/*     */   {
/*  85 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean load(IResourceManager par1ResourceManager, ResourceLocation location)
/*     */   {
/*  91 */     ResourceLocation resourcelocation = new ResourceLocation("ExtraUtils2:connected/" + super.getIconName());
/*  92 */     ResourceLocation resourcelocation1 = com.rwtema.extrautils2.backend.model.Textures.completeTextureResourceLocation(resourcelocation);
/*     */     try
/*     */     {
/*  95 */       IResource iresource = par1ResourceManager.getResource(resourcelocation1);
/*  96 */       BufferedImage[] abufferedimage = new BufferedImage[1 + Minecraft.getMinecraft().gameSettings.mipmapLevels];
/*  97 */       abufferedimage[0] = javax.imageio.ImageIO.read(iresource.getInputStream());
/*  98 */       func_180598_a(abufferedimage, null);
/*     */     } catch (IOException ioexception1) {
/* 100 */       com.rwtema.extrautils2.utils.LogHelper.logger.error("Using missing texture, unable to load " + resourcelocation1, ioexception1);
/* 101 */       return true;
/*     */     }
/*     */     
/* 104 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\TextureConnectedTextures.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */