/*    */ package com.rwtema.extrautils2.textures;
/*    */ 
/*    */ import com.google.common.base.Throwables;
/*    */ import com.rwtema.extrautils2.backend.model.Textures;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import javax.imageio.ImageIO;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.resources.IResource;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public abstract class TextureLocation implements ISolidWorldTexture
/*    */ {
/*    */   protected final String[] textures;
/* 21 */   protected final String[] baseTexture = new String[6];
/*    */   
/*    */   public TextureLocation(String texture)
/*    */   {
/*    */     try {
/* 26 */       ResourceLocation resourcelocation = new ResourceLocation("ExtraUtils2:connected/" + texture);
/* 27 */       ResourceLocation resourcelocation1 = Textures.completeTextureResourceLocation(resourcelocation);
/* 28 */       IResource iresource = Minecraft.getMinecraft().getResourceManager().getResource(resourcelocation1);
/* 29 */       BufferedImage read = ImageIO.read(iresource.getInputStream());
/* 30 */       int w = read.getWidth();
/* 31 */       int h = read.getHeight();
/* 32 */       if (h % w != 0) throw new RuntimeException("Height must be a multiple of the width.");
/* 33 */       int n = h / w;
/*    */       
/* 35 */       this.textures = new String[n];
/* 36 */       for (int i = 0; i < n; i++) {
/* 37 */         String key = texture + "#" + i;
/* 38 */         this.textures[i] = key;
/* 39 */         Textures.textureNames.put(key, new TextureSub(texture, 0, i, 1, n, 1));
/*    */       }
/*    */       
/* 42 */       assignBaseTextures();
/*    */     } catch (IOException e) {
/* 44 */       throw Throwables.propagate(e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void assignBaseTextures();
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public net.minecraft.client.renderer.texture.TextureAtlasSprite getWorldIcon(IBlockAccess world, BlockPos blockPos, EnumFacing side)
/*    */   {
/* 53 */     int a = getRandomIndex(world, blockPos, side);
/* 54 */     int l = a % this.textures.length;
/*    */     
/* 56 */     return Textures.getSprite(this.textures[l]);
/*    */   }
/*    */   
/*    */   protected abstract int getRandomIndex(IBlockAccess paramIBlockAccess, BlockPos paramBlockPos, EnumFacing paramEnumFacing);
/*    */   
/*    */   public String getItemTexture(EnumFacing side)
/*    */   {
/* 63 */     return this.baseTexture[side.ordinal()];
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\textures\TextureLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */