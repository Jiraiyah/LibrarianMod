/*    */ package com.rwtema.extrautils2.crafting;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.LogHelper;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.crafting.IRecipe;
/*    */ import net.minecraft.item.crafting.ShapedRecipes;
/*    */ import net.minecraft.item.crafting.ShapelessRecipes;
/*    */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*    */ import net.minecraftforge.oredict.RecipeSorter;
/*    */ import net.minecraftforge.oredict.RecipeSorter.Category;
/*    */ import net.minecraftforge.oredict.ShapedOreRecipe;
/*    */ import net.minecraftforge.oredict.ShapelessOreRecipe;
/*    */ 
/*    */ public class CraftingHelper
/*    */ {
/* 21 */   private static final Set<Class<? extends IRecipe>> registeredRecipes = new HashSet();
/*    */   
/* 23 */   public static final ThreadLocal<Collection<? super IRecipe>> recipeCallback = new ThreadLocal();
/*    */   
/*    */   static {
/* 26 */     registeredRecipes.add(AlwaysLast.XUShapedRecipeAlwaysLast.class);
/* 27 */     RecipeSorter.register("extrautils2:alwaysLastShaped", AlwaysLast.XUShapedRecipeAlwaysLast.class, RecipeSorter.Category.SHAPELESS, "after:minecraft:shaped after:minecraft:shapeless after:forge:shapedore after:forge:shapelessore after:minecraft:repair after:minecraft:pattern_add after:minecraft:mapextending after:minecraft:armordyes after:minecraft:fireworks after:minecraft:bookcloning");
/* 28 */     registeredRecipes.add(AlwaysLast.XUShapelessRecipeAlwaysLast.class);
/* 29 */     RecipeSorter.register("extrautils2:alwaysLastShapeless", AlwaysLast.XUShapedRecipeAlwaysLast.class, RecipeSorter.Category.SHAPELESS, "after:minecraft:shaped after:minecraft:shapeless after:forge:shapedore after:forge:shapelessore after:minecraft:repair after:minecraft:pattern_add after:minecraft:mapextending after:minecraft:armordyes after:minecraft:fireworks after:minecraft:bookcloning");
/*    */   }
/*    */   
/*    */   public static void addRecipe(IRecipe recipe) {
/* 33 */     Collection<? super IRecipe> objects = (Collection)recipeCallback.get();
/* 34 */     if (objects != null) objects.add(recipe);
/* 35 */     registerRecipe(recipe.getClass());
/* 36 */     GameRegistry.addRecipe(recipe);
/*    */   }
/*    */   
/*    */   public static void addShapeless(ItemStack stack, Object... recipe) {
/* 40 */     addRecipe(new XUShapelessRecipe(stack, recipe));
/*    */   }
/*    */   
/*    */   public static void addShaped(ItemStack stack, Object... recipe) {
/* 44 */     addRecipe(new XUShapedRecipe(stack, recipe));
/*    */   }
/*    */   
/*    */   public static void addShapeless(Item stack, Object... recipe) {
/* 48 */     addRecipe(new XUShapelessRecipe(stack, recipe));
/*    */   }
/*    */   
/*    */   public static void addShaped(Item stack, Object... recipe) {
/* 52 */     addRecipe(new XUShapedRecipe(stack, recipe));
/*    */   }
/*    */   
/*    */   public static void addShapeless(Block stack, Object... recipe) {
/* 56 */     addRecipe(new XUShapelessRecipe(stack, recipe));
/*    */   }
/*    */   
/*    */   public static void addShaped(Block stack, Object... recipe) {
/* 60 */     addRecipe(new XUShapedRecipe(stack, recipe));
/*    */   }
/*    */   
/*    */   public static void registerRecipe(Class<? extends IRecipe> recipe) {
/* 64 */     if (registeredRecipes.contains(recipe)) {
/* 65 */       return;
/*    */     }
/* 67 */     if (!recipe.getName().startsWith("com.rwtema.")) {
/* 68 */       return;
/*    */     }
/* 70 */     registeredRecipes.add(recipe);
/* 71 */     LogHelper.fine("Registering " + recipe.getSimpleName() + " to RecipeSorter", new Object[0]);
/* 72 */     if (ShapedOreRecipe.class.isAssignableFrom(recipe)) {
/* 73 */       RecipeSorter.register("extrautils2:" + recipe.getSimpleName(), recipe, RecipeSorter.Category.SHAPED, "after:forge:shapedore");
/* 74 */     } else if (ShapelessOreRecipe.class.isAssignableFrom(recipe)) {
/* 75 */       RecipeSorter.register("extrautils2:" + recipe.getSimpleName(), recipe, RecipeSorter.Category.SHAPELESS, "after:forge:shapelessore before:extrautils2:alwaysLastShapeless");
/* 76 */     } else if (ShapedRecipes.class.isAssignableFrom(recipe)) {
/* 77 */       RecipeSorter.register("extrautils2:" + recipe.getSimpleName(), recipe, RecipeSorter.Category.SHAPED, "after:minecraft:shaped before:minecraft:shapeless");
/* 78 */     } else if (ShapelessRecipes.class.isAssignableFrom(recipe)) {
/* 79 */       RecipeSorter.register("extrautils2:" + recipe.getSimpleName(), recipe, RecipeSorter.Category.SHAPELESS, "after:minecraft:shapeless before:minecraft:bookcloning before:extrautils2:alwaysLastShapeless");
/*    */     } else
/* 81 */       RecipeSorter.register("extrautils2:" + recipe.getSimpleName(), recipe, RecipeSorter.Category.SHAPELESS, "after:forge:shapelessore before:extrautils2:alwaysLastShapeless");
/*    */   }
/*    */   
/*    */   public static void registerRecipe(Class<? extends IRecipe> recipe, RecipeSorter.Category cat, String s) {
/* 85 */     if (registeredRecipes.contains(recipe)) {
/* 86 */       return;
/*    */     }
/* 88 */     registeredRecipes.add(recipe);
/* 89 */     RecipeSorter.register("extrautils2:" + recipe.getSimpleName(), recipe, cat, s);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\CraftingHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */