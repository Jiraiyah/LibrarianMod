/*    */ package com.rwtema.extrautils2.crafting;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class AlwaysLast
/*    */ {
/*    */   public static class XUShapelessRecipeAlwaysLast extends XUShapelessRecipe
/*    */   {
/*    */     public XUShapelessRecipeAlwaysLast(Block result, Object... recipe)
/*    */     {
/* 12 */       super(recipe);
/*    */     }
/*    */     
/*    */     public XUShapelessRecipeAlwaysLast(net.minecraft.item.Item result, Object... recipe) {
/* 16 */       super(recipe);
/*    */     }
/*    */     
/*    */     public XUShapelessRecipeAlwaysLast(ItemStack result, Object... recipe) {
/* 20 */       super(recipe);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class XUShapedRecipeAlwaysLast extends XUShapedRecipe
/*    */   {
/*    */     public XUShapedRecipeAlwaysLast(Block result, Object... recipe)
/*    */     {
/* 28 */       super(recipe);
/*    */     }
/*    */     
/*    */     public XUShapedRecipeAlwaysLast(net.minecraft.item.Item result, Object... recipe) {
/* 32 */       super(recipe);
/*    */     }
/*    */     
/*    */     public XUShapedRecipeAlwaysLast(ItemStack result, Object... recipe) {
/* 36 */       super(recipe);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\AlwaysLast.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */