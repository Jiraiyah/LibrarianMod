package com.rwtema.extrautils2.crafting;

import net.minecraft.item.crafting.IRecipe;

public abstract interface IRecipePassThru
  extends IRecipe
{
  public abstract IRecipe getOriginalRecipe();
  
  public abstract String info();
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\IRecipePassThru.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */