/*    */ package com.rwtema.extrautils2.crafting;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.entries.ItemClassEntry;
/*    */ import com.rwtema.extrautils2.backend.entries.XU2Entries;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.inventory.InventoryCrafting;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class RecipeClearGoldenLasso extends XUShapelessRecipe
/*    */ {
/* 12 */   private final ArrayList<Object> recipeItemList = new ArrayList();
/*    */   
/*    */   public RecipeClearGoldenLasso(int meta, List<ItemStack> recipeItemList) {
/* 15 */     super(XU2Entries.goldenLasso.newStack(1, meta), new Object[] { XU2Entries.goldenLasso.newStack(1, meta) });
/* 16 */     this.recipeItemList.add(recipeItemList);
/*    */   }
/*    */   
/*    */   public ArrayList<Object> getInput()
/*    */   {
/* 21 */     return this.recipeItemList;
/*    */   }
/*    */   
/*    */   public ItemStack[] getRemainingItems(InventoryCrafting inv)
/*    */   {
/* 26 */     return new ItemStack[inv.getSizeInventory()];
/*    */   }
/*    */   
/*    */   public boolean itemsMatch(ItemStack slot, @javax.annotation.Nonnull ItemStack target)
/*    */   {
/* 31 */     return net.minecraftforge.oredict.OreDictionary.itemMatches(target, slot, false);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\RecipeClearGoldenLasso.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */