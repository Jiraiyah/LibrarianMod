/*     */ package com.rwtema.extrautils2.crafting;
/*     */ 
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.ItemStackHelper;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.InventoryCrafting;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.network.NetHandlerPlayServer;
/*     */ import net.minecraft.network.play.server.S1FPacketSetExperience;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.management.ServerConfigurationManager;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.entity.player.ItemTooltipEvent;
/*     */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemCraftedEvent;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class EnchantRecipe implements IRecipe, IRecipePassThru
/*     */ {
/*     */   public final IRecipe recipe;
/*     */   public final IItemMatcher matcher;
/*     */   private final int enchantLevel;
/*     */   
/*     */   public EnchantRecipe(IRecipe recipe, int enchantLevel)
/*     */   {
/*  34 */     this.recipe = recipe;
/*  35 */     this.matcher = ((recipe instanceof IItemMatcher) ? (IItemMatcher)recipe : IItemMatcher.CRAFTING);
/*  36 */     this.enchantLevel = enchantLevel;
/*     */     
/*  38 */     MinecraftForge.EVENT_BUS.register(new EventHandler(null));
/*     */   }
/*     */   
/*     */   public int getRecipeSize()
/*     */   {
/*  43 */     return this.recipe.getRecipeSize();
/*     */   }
/*     */   
/*     */   public ItemStack getRecipeOutput()
/*     */   {
/*  48 */     return this.recipe.getRecipeOutput();
/*     */   }
/*     */   
/*     */   public ItemStack[] getRemainingItems(InventoryCrafting inv)
/*     */   {
/*  53 */     return this.recipe.getRemainingItems(inv);
/*     */   }
/*     */   
/*     */   public ItemStack getCraftingResult(InventoryCrafting var1)
/*     */   {
/*  58 */     if (!isGoodForCrafting(var1)) {
/*  59 */       return null;
/*     */     }
/*     */     
/*  62 */     return this.recipe.getCraftingResult(var1);
/*     */   }
/*     */   
/*     */   public boolean matches(InventoryCrafting inv, World world)
/*     */   {
/*  67 */     return this.recipe.matches(inv, world);
/*     */   }
/*     */   
/*     */   public boolean isGoodForCrafting(InventoryCrafting inv)
/*     */   {
/*  72 */     if (FMLCommonHandler.instance().getEffectiveSide() == Side.CLIENT) {
/*  73 */       return ((Boolean)com.rwtema.extrautils2.ExtraUtils2.proxy.apply(new ClientIsGoodForCrafting(inv), (Void)null)).booleanValue();
/*     */     }
/*     */     
/*  76 */     MinecraftServer server = MinecraftServer.func_71276_C();
/*  77 */     if (server != null) {
/*  78 */       ServerConfigurationManager manager = server.func_71203_ab();
/*  79 */       if (manager != null) {
/*  80 */         Container container = inv.eventHandler;
/*  81 */         if (container == null) { return false;
/*     */         }
/*  83 */         EntityPlayerMP foundPlayer = null;
/*     */         
/*  85 */         for (EntityPlayerMP entityPlayerMP : manager.playerEntityList) {
/*  86 */           if ((entityPlayerMP.openContainer == container) && (container.canInteractWith(entityPlayerMP)) && (container.getCanCraft(entityPlayerMP))) {
/*  87 */             if (foundPlayer != null) return false;
/*  88 */             foundPlayer = entityPlayerMP;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*  93 */         if (foundPlayer != null) {
/*  94 */           foundPlayer.playerNetServerHandler.sendPacket(new S1FPacketSetExperience(foundPlayer.experience, foundPlayer.experienceTotal, foundPlayer.experienceLevel));
/*  95 */           return foundPlayer.experienceLevel >= this.enchantLevel;
/*     */         }
/*     */       }
/*     */     }
/*  99 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public IRecipe getOriginalRecipe()
/*     */   {
/* 105 */     return this.recipe;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 110 */   public String info() { return Lang.translateArgs("%s XP", new Object[] { Integer.valueOf(this.enchantLevel) }); }
/*     */   
/*     */   private class EventHandler {
/*     */     private EventHandler() {}
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     @SubscribeEvent
/* 117 */     public void tooltip(ItemTooltipEvent event) { if (event.itemStack != EnchantRecipe.this.recipe.getRecipeOutput()) { return;
/*     */       }
/* 119 */       if (EnchantRecipe.this.enchantLevel == 1) {
/* 120 */         ItemStackHelper.addInfoWidth(event.toolTip, event.itemStack, Lang.translate("Requires 1 enchantment level to craft"));
/*     */       } else
/* 122 */         ItemStackHelper.addInfoWidth(event.toolTip, event.itemStack, Lang.translateArgs("Requires %s enchantment levels to craft", new Object[] { Integer.valueOf(EnchantRecipe.this.enchantLevel) }));
/*     */     }
/*     */     
/*     */     @SubscribeEvent
/*     */     public void onCraft(PlayerEvent.ItemCraftedEvent event) {
/* 127 */       EntityPlayer player = event.player;
/* 128 */       if (player == null) {
/* 129 */         return;
/*     */       }
/*     */       
/* 132 */       ItemStack crafting = event.crafting;
/* 133 */       if ((crafting == null) || (!EnchantRecipe.this.matcher.itemsMatch(crafting, EnchantRecipe.this.recipe.getRecipeOutput()))) {
/* 134 */         return;
/*     */       }
/*     */       
/* 137 */       player.removeExperienceLevel(EnchantRecipe.this.enchantLevel);
/*     */     }
/*     */   }
/*     */   
/*     */   private class ClientIsGoodForCrafting implements com.rwtema.extrautils2.backend.ISidedFunction<Void, Boolean>
/*     */   {
/*     */     private final InventoryCrafting inv;
/*     */     
/*     */     public ClientIsGoodForCrafting(InventoryCrafting inv) {
/* 146 */       this.inv = inv;
/*     */     }
/*     */     
/*     */     @SideOnly(Side.SERVER)
/*     */     public Boolean applyServer(Void input)
/*     */     {
/* 152 */       return Boolean.valueOf(false);
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public Boolean applyClient(Void input)
/*     */     {
/* 158 */       EntityPlayerSP player = Minecraft.getMinecraft().thePlayer;
/* 159 */       return Boolean.valueOf((player != null) && (player.experienceLevel >= EnchantRecipe.this.enchantLevel) && (player.openContainer == this.inv.eventHandler));
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\EnchantRecipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */