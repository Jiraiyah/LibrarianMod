package com.rwtema.extrautils2.crafting;

import javax.annotation.Nonnull;
import net.minecraft.item.ItemStack;

public abstract interface ICustomMatching
{
  public abstract boolean itemsMatch(ItemStack paramItemStack1, @Nonnull ItemStack paramItemStack2);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\ICustomMatching.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */