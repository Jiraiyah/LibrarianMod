/*    */ package com.rwtema.extrautils2.crafting;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.items.ItemHandlerHelper;
/*    */ 
/*    */ public abstract interface IItemMatcher
/*    */ {
/*  9 */   public static final IItemMatcher CRAFTING = new IItemMatcher()
/*    */   {
/*    */     public boolean itemsMatch(ItemStack slot, @Nonnull ItemStack target) {
/* 12 */       return net.minecraftforge.oredict.OreDictionary.itemMatches(target, slot, false);
/*    */     }
/*    */   };
/* 15 */   public static final IItemMatcher EXACT = new IItemMatcher()
/*    */   {
/*    */     public boolean itemsMatch(ItemStack slot, @Nonnull ItemStack target) {
/* 18 */       return (slot != null) && (ItemHandlerHelper.canItemStacksStack(slot, target));
/*    */     }
/*    */   };
/*    */   
/*    */   public abstract boolean itemsMatch(ItemStack paramItemStack1, @Nonnull ItemStack paramItemStack2);
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\IItemMatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */