/*     */ package com.rwtema.extrautils2.crafting.jei;
/*     */ 
/*     */ import com.rwtema.extrautils2.crafting.IRecipePassThru;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import mezz.jei.api.recipe.IRecipeHandler;
/*     */ import mezz.jei.api.recipe.IRecipeWrapper;
/*     */ import mezz.jei.api.recipe.wrapper.ICraftingRecipeWrapper;
/*     */ import mezz.jei.api.recipe.wrapper.IShapedCraftingRecipeWrapper;
/*     */ import mezz.jei.plugins.vanilla.crafting.ShapedOreRecipeHandler;
/*     */ import mezz.jei.plugins.vanilla.crafting.ShapedRecipesHandler;
/*     */ import mezz.jei.plugins.vanilla.crafting.ShapelessOreRecipeHandler;
/*     */ import mezz.jei.plugins.vanilla.crafting.ShapelessRecipesHandler;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.item.crafting.ShapedRecipes;
/*     */ import net.minecraft.item.crafting.ShapelessRecipes;
/*     */ import net.minecraftforge.fluids.FluidStack;
/*     */ import net.minecraftforge.oredict.ShapedOreRecipe;
/*     */ import net.minecraftforge.oredict.ShapelessOreRecipe;
/*     */ 
/*     */ 
/*     */ public class JEIVanillaCraftingRecipeHandler<T extends IRecipePassThru>
/*     */   implements IRecipeHandler<T>
/*     */ {
/*  31 */   public static HashMap<Class, IRecipeHandler<?>> handlers = new HashMap();
/*  32 */   static { handlers.put(ShapedOreRecipe.class, new ShapedOreRecipeHandler());
/*  33 */     handlers.put(ShapedRecipes.class, new ShapedRecipesHandler());
/*  34 */     handlers.put(ShapelessOreRecipe.class, new ShapelessOreRecipeHandler());
/*  35 */     handlers.put(ShapelessRecipes.class, new ShapelessRecipesHandler());
/*     */   }
/*     */   
/*     */   final Class<T> clazz;
/*     */   public JEIVanillaCraftingRecipeHandler(Class<T> clazz)
/*     */   {
/*  41 */     this.clazz = clazz;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static IRecipeHandler getHandler(IRecipe recipe) {
/*  46 */     IRecipeHandler recipeHandler = null;
/*  47 */     Class<?> clazz = recipe.getClass();
/*  48 */     while (!clazz.equals(Object.class)) {
/*  49 */       recipeHandler = (IRecipeHandler)handlers.get(clazz);
/*  50 */       if (recipeHandler != null)
/*     */         break;
/*  52 */       clazz = clazz.getSuperclass();
/*     */     }
/*     */     
/*  55 */     return recipeHandler;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public Class<T> getRecipeClass()
/*     */   {
/*  61 */     return this.clazz;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public String getRecipeCategoryUid()
/*     */   {
/*  67 */     return "minecraft.crafting";
/*     */   }
/*     */   
/*     */ 
/*     */   @Nonnull
/*     */   public IRecipeWrapper getRecipeWrapper(@Nonnull T recipe)
/*     */   {
/*  74 */     IRecipe originalRecipe = recipe.getOriginalRecipe();
/*  75 */     IRecipeHandler recipeHandler = getHandler(originalRecipe);
/*  76 */     if (recipeHandler == null) throw new RuntimeException("Recipe Handler not found, it should have been.");
/*  77 */     return wrapRecipe(recipe, recipeHandler.getRecipeWrapper(originalRecipe));
/*     */   }
/*     */   
/*     */   public IRecipeWrapper wrapRecipe(T recipe, IRecipeWrapper wrapper) {
/*  81 */     if (recipe.info() == null) { return wrapper;
/*     */     }
/*  83 */     if ((wrapper instanceof IShapedCraftingRecipeWrapper)) {
/*  84 */       IShapedCraftingRecipeWrapper w = (IShapedCraftingRecipeWrapper)wrapper;
/*  85 */       return new MyIShapedCraftingRecipeWrapper(w, recipe);
/*     */     }
/*     */     
/*     */ 
/*  89 */     if ((wrapper instanceof ICraftingRecipeWrapper)) {
/*  90 */       ICraftingRecipeWrapper w = (ICraftingRecipeWrapper)wrapper;
/*  91 */       return new MyICraftingRecipeWrapper(w, recipe);
/*     */     }
/*  93 */     return wrapper;
/*     */   }
/*     */   
/*     */   public void drawInfo(T recipe, ICraftingRecipeWrapper iCraftingRecipeWrapper, Minecraft minecraft, int recipeWidth, int recipeHeight, int mouseX, int mouseY) {
/*  97 */     String info = recipe.info();
/*  98 */     if (info != null) { minecraft.fontRendererObj.drawString(info, 60, 10, Color.black.getRGB());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isRecipeValid(@Nonnull T recipe)
/*     */   {
/* 105 */     IRecipe originalRecipe = recipe.getOriginalRecipe();
/* 106 */     if (originalRecipe == null) return false;
/* 107 */     IRecipeHandler handler = getHandler(originalRecipe);
/* 108 */     return (handler != null) && (handler.isRecipeValid(originalRecipe));
/*     */   }
/*     */   
/*     */   private class MyIShapedCraftingRecipeWrapper extends JEIVanillaCraftingRecipeHandler<T>.MyICraftingRecipeWrapper implements IShapedCraftingRecipeWrapper {
/*     */     private final IShapedCraftingRecipeWrapper w;
/*     */     
/*     */     public MyIShapedCraftingRecipeWrapper(T w) {
/* 115 */       super(w, recipe);
/* 116 */       this.w = w;
/*     */     }
/*     */     
/*     */     public int getWidth() {
/* 120 */       return this.w.getWidth();
/*     */     }
/*     */     
/*     */     public int getHeight() {
/* 124 */       return this.w.getHeight();
/*     */     }
/*     */   }
/*     */   
/*     */   private class MyICraftingRecipeWrapper implements ICraftingRecipeWrapper {
/*     */     protected final ICraftingRecipeWrapper w;
/*     */     protected final T recipe;
/*     */     
/*     */     public MyICraftingRecipeWrapper(T w) {
/* 133 */       this.w = w;
/* 134 */       this.recipe = recipe;
/*     */     }
/*     */     
/*     */     public List getInputs() {
/* 138 */       return this.w.getInputs();
/*     */     }
/*     */     
/*     */     public List<ItemStack> getOutputs() {
/* 142 */       return this.w.getOutputs();
/*     */     }
/*     */     
/*     */     public void drawInfo(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight) {
/* 146 */       this.w.drawInfo(minecraft, recipeWidth, recipeHeight);
/*     */     }
/*     */     
/*     */     public List<FluidStack> getFluidInputs() {
/* 150 */       return this.w.getFluidInputs();
/*     */     }
/*     */     
/*     */     public List<FluidStack> getFluidOutputs() {
/* 154 */       return this.w.getFluidOutputs();
/*     */     }
/*     */     
/*     */     public void drawInfo(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight, int mouseX, int mouseY) {
/* 158 */       this.w.drawInfo(minecraft, recipeWidth, recipeHeight, mouseX, mouseY);
/* 159 */       JEIVanillaCraftingRecipeHandler.this.drawInfo(this.recipe, this, minecraft, recipeWidth, recipeHeight, mouseX, mouseY);
/*     */     }
/*     */     
/*     */     public void drawAnimations(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight) {
/* 163 */       this.w.drawAnimations(minecraft, recipeWidth, recipeHeight);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public List<String> getTooltipStrings(int mouseX, int mouseY) {
/* 168 */       return this.w.getTooltipStrings(mouseX, mouseY);
/*     */     }
/*     */     
/*     */     public boolean handleClick(@Nonnull Minecraft minecraft, int mouseX, int mouseY, int mouseButton) {
/* 172 */       return this.w.handleClick(minecraft, mouseX, mouseY, mouseButton);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\jei\JEIVanillaCraftingRecipeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */