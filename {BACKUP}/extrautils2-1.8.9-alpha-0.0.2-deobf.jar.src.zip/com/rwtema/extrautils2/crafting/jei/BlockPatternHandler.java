/*    */ package com.rwtema.extrautils2.crafting.jei;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nonnull;
/*    */ import mezz.jei.api.IGuiHelper;
/*    */ import mezz.jei.api.IJeiHelpers;
/*    */ import mezz.jei.api.gui.IDrawable;
/*    */ import mezz.jei.api.gui.IGuiItemStackGroup;
/*    */ import mezz.jei.api.gui.IRecipeLayout;
/*    */ import mezz.jei.api.recipe.IRecipeCategory;
/*    */ import mezz.jei.api.recipe.IRecipeHandler;
/*    */ import mezz.jei.api.recipe.IRecipeWrapper;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fluids.FluidStack;
/*    */ 
/*    */ public class BlockPatternHandler
/*    */ {
/*    */   public static final String uid = "ExtraUtils2.blockPatterns";
/*    */   public IRecipeCategory category;
/*    */   public IRecipeHandler<PatternRecipe> handler;
/*    */   
/*    */   public BlockPatternHandler()
/*    */   {
/* 26 */     this.category = new IRecipeCategory() {
/*    */       public static final int recipeWidth = 160;
/*    */       public static final int recipeHeight = 160;
/*    */       public static final int slotX0 = 71;
/* 30 */       IDrawable slotDrawable = XUJEIPlugin.jeiHelpers.getGuiHelper().getSlotDrawable();
/* 31 */       IDrawable background = XUJEIPlugin.jeiHelpers.getGuiHelper().createBlankDrawable(160, 54);
/*    */       
/*    */       @Nonnull
/*    */       public String getUid()
/*    */       {
/* 36 */         return "ExtraUtils2.blockPatterns";
/*    */       }
/*    */       
/*    */       @Nonnull
/*    */       public String getTitle()
/*    */       {
/* 42 */         return com.rwtema.extrautils2.utils.Lang.translate("Blocks");
/*    */       }
/*    */       
/*    */       @Nonnull
/*    */       public IDrawable getBackground()
/*    */       {
/* 48 */         return this.background;
/*    */       }
/*    */       
/*    */       public void drawExtras(@Nonnull Minecraft minecraft)
/*    */       {
/* 53 */         this.slotDrawable.draw(minecraft, 71, 0);
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */       public void drawAnimations(@Nonnull Minecraft minecraft) {}
/*    */       
/*    */ 
/*    */       public void setRecipe(@Nonnull IRecipeLayout recipeLayout, @Nonnull IRecipeWrapper recipeWrapper)
/*    */       {
/* 63 */         IGuiItemStackGroup guiItemStacks = recipeLayout.getItemStacks();
/*    */         
/* 65 */         guiItemStacks.init(0, true, 71, 0);
/* 66 */         guiItemStacks.setFromRecipe(0, recipeWrapper.getInputs());
/*    */       }
/* 68 */     };
/* 69 */     this.handler = new IRecipeHandler()
/*    */     {
/*    */       @Nonnull
/*    */       public Class<BlockPatternHandler.PatternRecipe> getRecipeClass()
/*    */       {
/* 74 */         return BlockPatternHandler.PatternRecipe.class;
/*    */       }
/*    */       
/*    */       @Nonnull
/*    */       public String getRecipeCategoryUid()
/*    */       {
/* 80 */         return "ExtraUtils2.blockPatterns";
/*    */       }
/*    */       
/*    */       @Nonnull
/*    */       public IRecipeWrapper getRecipeWrapper(@Nonnull final BlockPatternHandler.PatternRecipe recipe)
/*    */       {
/* 86 */         new IRecipeWrapper()
/*    */         {
/*    */           public List getInputs() {
/* 89 */             return Collections.singletonList(recipe.output);
/*    */           }
/*    */           
/*    */           public List getOutputs()
/*    */           {
/* 94 */             return Collections.singletonList(recipe.output);
/*    */           }
/*    */           
/*    */           public List<FluidStack> getFluidInputs()
/*    */           {
/* 99 */             return Collections.emptyList();
/*    */           }
/*    */           
/*    */           public List<FluidStack> getFluidOutputs()
/*    */           {
/* :4 */             return Collections.emptyList();
/*    */           }
/*    */           
/*    */ 
/*    */ 
/*    */ 
/*    */           public void drawInfo(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight) {}
/*    */           
/*    */ 
/*    */ 
/*    */           public void drawInfo(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight, int mouseX, int mouseY) {}
/*    */           
/*    */ 
/*    */ 
/*    */           public void drawAnimations(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight) {}
/*    */           
/*    */ 
/*    */ 
/*    */           @javax.annotation.Nullable
/*    */           public List<String> getTooltipStrings(int mouseX, int mouseY)
/*    */           {
/* <5 */             return Collections.emptyList();
/*    */           }
/*    */           
/*    */           public boolean handleClick(@Nonnull Minecraft minecraft, int mouseX, int mouseY, int mouseButton)
/*    */           {
/* =0 */             return false;
/*    */           }
/*    */         };
/*    */       }
/*    */       
/*    */       public boolean isRecipeValid(@Nonnull BlockPatternHandler.PatternRecipe recipe)
/*    */       {
/* =7 */         return true;
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   public static class PatternRecipe
/*    */   {
/*    */     net.minecraft.block.state.IBlockState[][][] states;
/*    */     ItemStack output;
/*    */     
/*    */     public PatternRecipe(ItemStack output, Object... objects) {}
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\jei\BlockPatternHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */