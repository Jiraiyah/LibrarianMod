/*     */ package com.rwtema.extrautils2.crafting.jei;
/*     */ 
/*     */ import com.rwtema.extrautils2.network.NetworkHandler;
/*     */ import com.rwtema.extrautils2.network.NetworkHandler.XUPacket;
/*     */ import com.rwtema.extrautils2.network.XUPacketClientToServer;
/*     */ import com.rwtema.extrautils2.utils.CapGetter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeSet;
/*     */ import java.util.WeakHashMap;
/*     */ import mezz.jei.api.IItemListOverlay;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ import net.minecraftforge.client.event.GuiScreenEvent.KeyboardInputEvent.Pre;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ public class JEIRadar
/*     */ {
/*     */   @SideOnly(Side.CLIENT)
/*     */   static IItemListOverlay itemListOverlay;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static void register(IItemListOverlay itemListOverlay)
/*     */   {
/*  38 */     itemListOverlay = itemListOverlay;
/*  39 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new JEIRadar());
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void onKeyPress(GuiScreenEvent.KeyboardInputEvent.Pre event) {
/*  45 */     if ((Keyboard.getEventKeyState()) && 
/*  46 */       (Keyboard.getEventKey() == Minecraft.getMinecraft().gameSettings.keyBindChat.getKeyCode()) && 
/*  47 */       ((Minecraft.getMinecraft().currentScreen instanceof GuiContainer))) {
/*  48 */       ItemStack stackUnderMouse = itemListOverlay.getStackUnderMouse();
/*  49 */       if (stackUnderMouse != null) {
/*  50 */         NetworkHandler.sendPacketToServer(new PacketPing(stackUnderMouse));
/*  51 */         event.setCanceled(true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @NetworkHandler.XUPacket
/*     */   public static class PacketPing
/*     */     extends XUPacketClientToServer
/*     */   {
/*     */     static final long TIMEOUT = 10L;
/*     */     static final int RANGE = 16;
/*  62 */     static WeakHashMap<EntityPlayer, Long> timeOutsHandler = new WeakHashMap();
/*     */     
/*     */     ItemStack stack;
/*     */     private EntityPlayer player;
/*     */     
/*     */     public PacketPing() {}
/*     */     
/*     */     public PacketPing(@javax.annotation.Nonnull ItemStack stack)
/*     */     {
/*  71 */       this.stack = stack.copy();
/*  72 */       stack.setTagCompound(null);
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/*  77 */       writeItemStack(this.stack);
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player)
/*     */     {
/*  82 */       this.player = player;
/*  83 */       this.stack = readItemStack();
/*     */     }
/*     */     
/*     */     public Runnable doStuffServer()
/*     */     {
/*  88 */       new Runnable()
/*     */       {
/*     */         public void run() {
/*  91 */           if ((JEIRadar.PacketPing.this.player == null) || (JEIRadar.PacketPing.this.stack == null) || (JEIRadar.PacketPing.this.stack.getItem() == null)) {
/*  92 */             return;
/*     */           }
/*     */           
/*  95 */           World world = JEIRadar.PacketPing.this.player.worldObj;
/*     */           
/*  97 */           long time = world.getTotalWorldTime();
/*  98 */           Long aLong = (Long)JEIRadar.PacketPing.timeOutsHandler.get(JEIRadar.PacketPing.this.player);
/*  99 */           if ((aLong != null) && 
/* 100 */             (time - aLong.longValue() < 10L)) {
/* 101 */             return;
/*     */           }
/*     */           
/* 104 */           JEIRadar.PacketPing.timeOutsHandler.put(JEIRadar.PacketPing.this.player, Long.valueOf(time));
/*     */           
/* 106 */           final int x = (int)Math.round(JEIRadar.PacketPing.this.player.posX);
/* 107 */           final int y = (int)Math.round(JEIRadar.PacketPing.this.player.posY);
/* 108 */           final int z = (int)Math.round(JEIRadar.PacketPing.this.player.posZ);
/*     */           
/* 110 */           Item trueItem = JEIRadar.PacketPing.this.stack.getItem();
/* 111 */           int trueItemDamage = JEIRadar.PacketPing.this.stack.getItemDamage();
/*     */           
/* 113 */           TreeSet<BlockPos> positions = new TreeSet(new java.util.Comparator()
/*     */           {
/*     */             public int compare(BlockPos o1, BlockPos o2) {
/* 116 */               return Double.compare(JEIRadar.PacketPing.this.getRange(x, y, z, o1), JEIRadar.PacketPing.this.getRange(x, y, z, o2));
/*     */             }
/*     */           });
/*     */           
/* 120 */           for (int cx = x - 16; cx <= x + 16; cx += 16) {
/* 121 */             for (int cz = z - 16; cz <= z + 16; cz += 16) {
/* 122 */               BlockPos p = new BlockPos(cx, y, cz);
/* 123 */               if (world.isBlockLoaded(p)) {
/* 124 */                 Chunk chunk = world.getChunkFromBlockCoords(p);
/*     */                 
/* 126 */                 java.util.Set<Map.Entry<BlockPos, TileEntity>> entrySet = chunk.getTileEntityMap().entrySet();
/* 127 */                 for (Map.Entry<BlockPos, TileEntity> entry : entrySet)
/*     */                 {
/* 129 */                   if (JEIRadar.PacketPing.this.inRange(x, y, z, (BlockPos)entry.getKey()))
/*     */                   {
/*     */ 
/* 132 */                     TileEntity tile = (TileEntity)entry.getValue();
/*     */                     
/* 134 */                     IItemHandler handler = (IItemHandler)CapGetter.ItemHandler.getInterface(tile, null);
/* 135 */                     if (handler != null)
/*     */                     {
/* 137 */                       for (int i = 0; i < handler.getSlots(); i++) {
/* 138 */                         ItemStack stack = handler.getStackInSlot(i);
/* 139 */                         if ((stack != null) && (stack.getItem() == trueItem))
/*     */                         {
/* 141 */                           if ((!trueItem.getHasSubtypes()) || (stack.getItemDamage() == trueItemDamage))
/*     */                           {
/*     */ 
/* 144 */                             positions.add(entry.getKey());
/*     */                             
/* 146 */                             if (positions.size() >= 30)
/* 147 */                               positions.pollLast();
/*     */                           } }
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 156 */           if (!positions.isEmpty()) {
/* 157 */             NetworkHandler.sendPacketToPlayer(new JEIRadar.PacketPong(new ArrayList(positions)), JEIRadar.PacketPing.this.player);
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */     
/*     */ 
/*     */     public int getRange(int x, int y, int z, BlockPos pos)
/*     */     {
/* 166 */       return Math.abs(pos.getX() - x) + Math.abs(pos.getY() - y) + Math.abs(pos.getZ() - z);
/*     */     }
/*     */     
/*     */     public boolean inRange(int x, int y, int z, BlockPos pos) {
/* 170 */       return (Math.abs(pos.getX() - x) <= 16) && (Math.abs(pos.getY() - y) <= 16) && (Math.abs(pos.getZ() - z) <= 16);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @NetworkHandler.XUPacket
/*     */   public static class PacketPong
/*     */     extends com.rwtema.extrautils2.network.XUPacketServerToClient
/*     */   {
/*     */     public static final int MAX_SIZE = 30;
/*     */     ArrayList<BlockPos> positions;
/*     */     
/*     */     public PacketPong() {}
/*     */     
/*     */     public PacketPong(ArrayList<BlockPos> positions)
/*     */     {
/* 186 */       this.positions = positions;
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/* 191 */       writeInt(this.positions.size());
/* 192 */       for (BlockPos position : this.positions) {
/* 193 */         writeBlockPos(position);
/*     */       }
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player)
/*     */     {
/* 199 */       int size = readInt();
/* 200 */       this.positions = new ArrayList(size);
/* 201 */       for (int i = 0; i < size; i++) {
/* 202 */         this.positions.add(readBlockPos());
/*     */       }
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public Runnable doStuffClient()
/*     */     {
/* 209 */       new Runnable()
/*     */       {
/*     */         public void run() {
/* 212 */           Minecraft.getMinecraft().thePlayer.closeScreen();
/* 213 */           for (BlockPos position : JEIRadar.PacketPong.this.positions) {
/* 214 */             for (int i = 0; i < 20; i++) {
/* 215 */               Minecraft.getMinecraft().effectRenderer.addEffect(new ParticlePing(Minecraft.getMinecraft().theWorld, position));
/*     */             }
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\jei\JEIRadar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */