/*    */ package com.rwtema.extrautils2.crafting.jei;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.entries.BlockClassEntry;
/*    */ import com.rwtema.extrautils2.backend.entries.BlockEntry;
/*    */ import com.rwtema.extrautils2.backend.entries.ItemClassEntry;
/*    */ import com.rwtema.extrautils2.backend.entries.ItemEntry;
/*    */ import com.rwtema.extrautils2.backend.entries.XU2Entries;
/*    */ import com.rwtema.extrautils2.crafting.EnchantRecipe;
/*    */ import com.rwtema.extrautils2.gui.backend.DynamicContainer;
/*    */ import com.rwtema.extrautils2.gui.backend.DynamicGui;
/*    */ import com.rwtema.extrautils2.gui.backend.DynamicWindow;
/*    */ import com.rwtema.extrautils2.utils.Lang;
/*    */ import java.awt.Rectangle;
/*    */ import java.util.ArrayList;
/*    */ import javax.annotation.Nonnull;
/*    */ import javax.annotation.Nullable;
/*    */ import mezz.jei.api.IItemListOverlay;
/*    */ import mezz.jei.api.IItemRegistry;
/*    */ import mezz.jei.api.IJeiHelpers;
/*    */ import mezz.jei.api.IJeiRuntime;
/*    */ import mezz.jei.api.IModRegistry;
/*    */ import mezz.jei.api.IRecipeRegistry;
/*    */ import mezz.jei.api.gui.IAdvancedGuiHandler;
/*    */ import mezz.jei.api.recipe.IRecipeHandler;
/*    */ 
/*    */ @mezz.jei.api.JEIPlugin
/*    */ public class XUJEIPlugin implements mezz.jei.api.IModPlugin
/*    */ {
/*    */   public static IJeiHelpers jeiHelpers;
/*    */   public static IRecipeRegistry recipeRegistry;
/*    */   
/*    */   public XUJEIPlugin()
/*    */   {
/* 34 */     com.rwtema.extrautils2.utils.LogHelper.info("Extra Utilities 2 JEI Plugin - ACTIVATE!", new Object[0]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void onJeiHelpersAvailable(IJeiHelpers jeiHelpers)
/*    */   {
/* 41 */     jeiHelpers = jeiHelpers;
/*    */   }
/*    */   
/*    */   public void onItemRegistryAvailable(IItemRegistry itemRegistry)
/*    */   {
/* 46 */     if (XU2Entries.itemFakeCopy.isActive()) {
/* 47 */       jeiHelpers.getItemBlacklist().addItemToBlacklist(XU2Entries.itemFakeCopy.newStack(1, 32767));
/*    */     }
/*    */   }
/*    */   
/*    */   public void register(@Nonnull IModRegistry registry)
/*    */   {
/* 53 */     if (XU2Entries.sunCrystal.isActive())
/* 54 */       registry.addDescription(XU2Entries.sunCrystal.newStack(1), new String[] { Lang.translate("Craft an empty Sun Crystal first, then throw the crystal on the ground in direct sunlight.") });
/* 55 */     if (XU2Entries.blockEnderLilly.isActive())
/* 56 */       registry.addDescription(XU2Entries.blockEnderLilly.newStack(1), new String[] { Lang.translate("Found in dungeon chests.") });
/* 57 */     if (XU2Entries.blockRedOrchid.isActive()) {
/* 58 */       registry.addDescription(XU2Entries.blockRedOrchid.newStack(1), new String[] { Lang.translate("Found in dungeon chests.") });
/*    */     }
/* 60 */     if (XU2Entries.resonator.isActive()) {
/* 61 */       ResonatorHandler resonator = new ResonatorHandler();
/* 62 */       registry.addRecipeCategories(new mezz.jei.api.recipe.IRecipeCategory[] { resonator });
/* 63 */       registry.addRecipeHandlers(new IRecipeHandler[] { resonator });
/* 64 */       registry.addRecipes(com.rwtema.extrautils2.tile.TileResonator.resonatorRecipes);
/*    */     }
/*    */     
/* 67 */     registry.addRecipeHandlers(new IRecipeHandler[] { new JEIVanillaCraftingRecipeHandler(EnchantRecipe.class) });
/*    */     
/* 69 */     registry.addAdvancedGuiHandlers(new IAdvancedGuiHandler[] { new IAdvancedGuiHandler()
/*    */     {
/*    */       @Nonnull
/*    */       public Class<DynamicGui> getGuiContainerClass() {
/* 73 */         return DynamicGui.class;
/*    */       }
/*    */       
/*    */       @Nullable
/*    */       public java.util.List<Rectangle> getGuiExtraAreas(DynamicGui gui)
/*    */       {
/* 79 */         ArrayList<Rectangle> rectangles = new ArrayList();
/*    */         
/* 81 */         for (DynamicWindow window : gui.container.getWindows()) {
/* 82 */           rectangles.add(new Rectangle(gui.guiLeft + window.x, gui.guiTop + window.y, window.w, window.h));
/*    */         }
/* 84 */         return rectangles;
/*    */       }
/*    */     } });
/*    */   }
/*    */   
/*    */ 
/*    */   public void onRecipeRegistryAvailable(@Nonnull IRecipeRegistry recipeRegistry)
/*    */   {
/* 92 */     recipeRegistry = recipeRegistry;
/*    */   }
/*    */   
/*    */   public void onRuntimeAvailable(@Nonnull IJeiRuntime jeiRuntime)
/*    */   {
/* 97 */     IItemListOverlay itemListOverlay = jeiRuntime.getItemListOverlay();
/* 98 */     JEIRadar.register(itemListOverlay);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\jei\XUJEIPlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */