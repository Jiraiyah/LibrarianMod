/*     */ package com.rwtema.extrautils2.crafting.jei;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.rwtema.extrautils2.backend.entries.BlockClassEntry;
/*     */ import com.rwtema.extrautils2.tile.TileResonator.ResonatorRecipe;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.StringHelper;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nonnull;
/*     */ import mezz.jei.api.IGuiHelper;
/*     */ import mezz.jei.api.IJeiHelpers;
/*     */ import mezz.jei.api.gui.IDrawable;
/*     */ import mezz.jei.api.gui.IGuiItemStackGroup;
/*     */ import mezz.jei.api.gui.IRecipeLayout;
/*     */ import mezz.jei.api.recipe.IRecipeWrapper;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.fluids.FluidStack;
/*     */ 
/*     */ class ResonatorHandler implements mezz.jei.api.recipe.IRecipeHandler<TileResonator.ResonatorRecipe>, mezz.jei.api.recipe.IRecipeCategory
/*     */ {
/*     */   public static final String uid = "ExtraUtils2.resonator";
/*     */   public static final int recipeWidth = 116;
/*     */   public static final int BETWEEN_DIST = 60;
/*     */   public static final int slotX1 = 79;
/*     */   public static final int slotX0 = 19;
/*  30 */   IDrawable slotDrawable = XUJEIPlugin.jeiHelpers.getGuiHelper().getSlotDrawable();
/*  31 */   IDrawable background = XUJEIPlugin.jeiHelpers.getGuiHelper().createBlankDrawable(116, 54);
/*     */   
/*     */   @Nonnull
/*     */   public Class<TileResonator.ResonatorRecipe> getRecipeClass()
/*     */   {
/*  36 */     return TileResonator.ResonatorRecipe.class;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public String getRecipeCategoryUid()
/*     */   {
/*  42 */     return "ExtraUtils2.resonator";
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public IRecipeWrapper getRecipeWrapper(@Nonnull TileResonator.ResonatorRecipe recipe)
/*     */   {
/*  48 */     final TileResonator.ResonatorRecipe resonatorRecipe = recipe;
/*  49 */     new IRecipeWrapper() {
/*  50 */       String energyString = Lang.translateArgs("%s GP", new Object[] { StringHelper.niceFormat(resonatorRecipe.energy / 100.0D) });
/*     */       
/*     */       public List getInputs()
/*     */       {
/*  54 */         return Lists.newArrayList(new ItemStack[] { resonatorRecipe.input });
/*     */       }
/*     */       
/*     */       public List getOutputs()
/*     */       {
/*  59 */         return Lists.newArrayList(new ItemStack[] { resonatorRecipe.output });
/*     */       }
/*     */       
/*     */       public List<FluidStack> getFluidInputs()
/*     */       {
/*  64 */         return null;
/*     */       }
/*     */       
/*     */       public List<FluidStack> getFluidOutputs()
/*     */       {
/*  69 */         return null;
/*     */       }
/*     */       
/*     */       public void drawInfo(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight)
/*     */       {
/*  74 */         int stringWidth = minecraft.fontRendererObj.getStringWidth(this.energyString);
/*  75 */         minecraft.fontRendererObj.drawSplitString(this.energyString, Math.max(19, (recipeWidth - stringWidth) / 2), 4, 60, Color.gray.getRGB());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void drawInfo(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight, int mouseX, int mouseY) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void drawAnimations(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight) {}
/*     */       
/*     */ 
/*     */ 
/*     */       @javax.annotation.Nullable
/*     */       public List<String> getTooltipStrings(int mouseX, int mouseY)
/*     */       {
/*  91 */         return null;
/*     */       }
/*     */       
/*     */       public boolean handleClick(@Nonnull Minecraft minecraft, int mouseX, int mouseY, int mouseButton)
/*     */       {
/*  96 */         return false;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public boolean isRecipeValid(@Nonnull TileResonator.ResonatorRecipe recipe)
/*     */   {
/* 103 */     return true;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public String getUid()
/*     */   {
/* 109 */     return "ExtraUtils2.resonator";
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public String getTitle()
/*     */   {
/* 115 */     return Lang.getItemName((Block)com.rwtema.extrautils2.backend.entries.XU2Entries.resonator.value);
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public IDrawable getBackground()
/*     */   {
/* 121 */     return this.background;
/*     */   }
/*     */   
/*     */   public void drawExtras(@Nonnull Minecraft minecraft)
/*     */   {
/* 126 */     this.slotDrawable.draw(minecraft, 19, 0);
/* 127 */     this.slotDrawable.draw(minecraft, 79, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void drawAnimations(@Nonnull Minecraft minecraft) {}
/*     */   
/*     */ 
/*     */   public void setRecipe(@Nonnull IRecipeLayout recipeLayout, @Nonnull IRecipeWrapper recipeWrapper)
/*     */   {
/* 137 */     IGuiItemStackGroup guiItemStacks = recipeLayout.getItemStacks();
/*     */     
/* 139 */     guiItemStacks.init(0, true, 19, 0);
/* 140 */     guiItemStacks.setFromRecipe(0, recipeWrapper.getInputs());
/*     */     
/* 142 */     guiItemStacks.init(1, false, 79, 0);
/* 143 */     guiItemStacks.setFromRecipe(1, recipeWrapper.getOutputs());
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\jei\ResonatorHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */