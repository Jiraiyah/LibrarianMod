/*    */ package com.rwtema.extrautils2.crafting.jei;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.client.particle.EntityReddustFX;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ParticlePing extends EntityReddustFX
/*    */ {
/* 16 */   public static final Random RANDOM = com.rwtema.extrautils2.utils.XURandom.rand;
/*    */   public static final float r = 1.0F;
/*    */   public static final float g = 1.0F;
/*    */   public static final float b = 1.0F;
/*    */   
/*    */   public ParticlePing(World world, int x, int y, int z) {
/* 22 */     super(world, x + randOffset(), y + randOffset(), z + randOffset(), 1.0F, 1.0F, 1.0F);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 27 */     this.noClip = true;
/* 28 */     this.particleMaxAge *= 10;
/* 29 */     this.motionX *= 0.1D;
/* 30 */     this.motionY *= 0.1D;
/* 31 */     this.motionZ *= 0.1D;
/* 32 */     this.particleScale *= 2.0F;
/*    */   }
/*    */   
/*    */   public ParticlePing(WorldClient theWorld, BlockPos p) {
/* 36 */     this(theWorld, p.getX(), p.getY(), p.getZ());
/*    */   }
/*    */   
/*    */   public static double randOffset() {
/* 40 */     return 0.5D + (RANDOM.nextDouble() - 0.5D) * RANDOM.nextDouble();
/*    */   }
/*    */   
/*    */   public void renderParticle(WorldRenderer worldRenderer, Entity entityIn, float partialTicks, float p_180434_4_, float p_180434_5_, float p_180434_6_, float p_180434_7_, float p_180434_8_)
/*    */   {
/* 45 */     if (GlStateManager.depthState.depthTest.currentState) {
/* 46 */       super.renderParticle(worldRenderer, entityIn, partialTicks, p_180434_4_, p_180434_5_, p_180434_6_, p_180434_7_, p_180434_8_);
/* 47 */       Tessellator tessellator = Tessellator.getInstance();
/* 48 */       tessellator.draw();
/*    */       
/* 50 */       GlStateManager.disableDepth();
/* 51 */       worldRenderer.begin(7, DefaultVertexFormats.PARTICLE_POSITION_TEX_COLOR_LMAP);
/* 52 */       super.renderParticle(worldRenderer, entityIn, partialTicks, p_180434_4_, p_180434_5_, p_180434_6_, p_180434_7_, p_180434_8_);
/* 53 */       tessellator.draw();
/* 54 */       GlStateManager.enableDepth();
/*    */       
/* 56 */       worldRenderer.begin(7, DefaultVertexFormats.PARTICLE_POSITION_TEX_COLOR_LMAP);
/*    */     } else {
/* 58 */       super.renderParticle(worldRenderer, entityIn, partialTicks, p_180434_4_, p_180434_5_, p_180434_6_, p_180434_7_, p_180434_8_);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\jei\ParticlePing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */