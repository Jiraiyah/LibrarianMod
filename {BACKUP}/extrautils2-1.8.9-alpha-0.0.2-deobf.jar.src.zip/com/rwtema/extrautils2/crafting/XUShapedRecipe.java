/*     */ package com.rwtema.extrautils2.crafting;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.entries.IItemStackMaker;
/*     */ import com.rwtema.extrautils2.utils.datastructures.ConcatList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.InventoryCrafting;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ 
/*     */ public class XUShapedRecipe extends net.minecraftforge.oredict.ShapedOreRecipe implements IItemMatcher
/*     */ {
/*     */   public XUShapedRecipe(Block result, Object... recipe)
/*     */   {
/*  21 */     this(new ItemStack(result), recipe);
/*     */   }
/*     */   
/*     */   public XUShapedRecipe(Item result, Object... recipe) {
/*  25 */     this(new ItemStack(result), recipe);
/*     */   }
/*     */   
/*     */   public XUShapedRecipe(ItemStack result, Object... recipe) {
/*  29 */     super(new ItemStack(Items.stick), new Object[] { "S", Character.valueOf('S'), Items.stick });
/*  30 */     this.output = result.copy();
/*  31 */     this.width = 0;
/*  32 */     this.height = 0;
/*     */     
/*  34 */     String shape = "";
/*  35 */     int idx = 0;
/*     */     
/*  37 */     if ((recipe[idx] instanceof Boolean)) {
/*  38 */       this.mirrored = ((Boolean)recipe[idx]).booleanValue();
/*  39 */       if ((recipe[(idx + 1)] instanceof Object[])) {
/*  40 */         recipe = (Object[])recipe[(idx + 1)];
/*     */       } else {
/*  42 */         idx = 1;
/*     */       }
/*     */     }
/*     */     
/*  46 */     if ((recipe[idx] instanceof String[])) {
/*  47 */       String[] parts = (String[])recipe[(idx++)];
/*     */       
/*  49 */       for (String s : parts) {
/*  50 */         this.width = s.length();
/*  51 */         shape = shape + s;
/*     */       }
/*     */       
/*  54 */       this.height = parts.length;
/*     */     } else {
/*  56 */       while ((recipe[idx] instanceof String)) {
/*  57 */         String s = (String)recipe[(idx++)];
/*  58 */         shape = shape + s;
/*  59 */         this.width = s.length();
/*  60 */         this.height += 1;
/*     */       }
/*     */     }
/*     */     
/*  64 */     if (this.width * this.height != shape.length()) {
/*  65 */       String ret = "Invalid shaped ore recipe: ";
/*  66 */       for (Object tmp : recipe) {
/*  67 */         ret = ret + tmp + ", ";
/*     */       }
/*  69 */       ret = ret + this.output;
/*  70 */       throw new RuntimeException(ret);
/*     */     }
/*     */     
/*  73 */     HashMap<Character, Object> itemMap = new HashMap();
/*  75 */     for (; 
/*  75 */         idx < recipe.length; idx += 2) {
/*  76 */       Character chr = (Character)recipe[idx];
/*  77 */       Object in = recipe[(idx + 1)];
/*     */       
/*  79 */       itemMap.put(chr, getRecipeObject(in));
/*     */     }
/*     */     
/*  82 */     this.input = new Object[this.width * this.height];
/*  83 */     int x = 0;
/*  84 */     for (char chr : shape.toCharArray()) {
/*  85 */       this.input[(x++)] = itemMap.get(Character.valueOf(chr));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void handleListInput(List<ItemStack> list, Object in) {
/*  90 */     if ((in instanceof ItemStack)) {
/*  91 */       list.add(((ItemStack)in).copy());
/*  92 */     } else if ((in instanceof Item)) {
/*  93 */       list.add(new ItemStack((Item)in));
/*  94 */     } else if ((in instanceof Block)) {
/*  95 */       list.add(new ItemStack((Block)in, 1, 32767));
/*  96 */     } else if ((in instanceof String)) {
/*  97 */       list.addAll(OreDictionary.getOres((String)in));
/*  98 */     } else if ((in instanceof IItemStackMaker)) {
/*  99 */       list.add(((IItemStackMaker)in).newStack());
/* 100 */     } else if ((in instanceof IBlockState)) {
/* 101 */       IBlockState state = (IBlockState)in;
/* 102 */       Block block = state.getBlock();
/* 103 */       Item itemDropped = block.getItemDropped(state, null, 0);
/* 104 */       if (itemDropped != null)
/* 105 */         new ItemStack(itemDropped, 1, block.damageDropped(state));
/* 106 */     } else if ((in instanceof Collection)) {
/* 107 */       if ((in instanceof List)) {
/* 108 */         boolean allStacks = true;
/* 109 */         for (Object o : (List)in) {
/* 110 */           if (!(o instanceof ItemStack)) {
/* 111 */             allStacks = false;
/* 112 */             break;
/*     */           }
/*     */         }
/*     */         
/* 116 */         if (allStacks) {
/* 117 */           list.addAll((List)in);
/* 118 */           return;
/*     */         }
/*     */       }
/*     */       
/* 122 */       for (Object o : (Collection)in) {
/* 123 */         handleListInput(list, o);
/*     */       }
/*     */     } else {
/* 126 */       String ret = "Invalid shaped ore input: ";
/* 127 */       ret = ret + in;
/* 128 */       throw new RuntimeException(ret);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Object getRecipeObject(Object in) {
/* 133 */     ConcatList<ItemStack> list = new ConcatList();
/* 134 */     handleListInput(list, in);
/*     */     Object out;
/*     */     Object out;
/* 137 */     if (list.lists.size() == 1) { Object out;
/* 138 */       if (list.size() == 1) {
/* 139 */         out = list.modifiableList.get(0);
/*     */       } else
/* 141 */         out = list.modifiableList;
/*     */     } else {
/*     */       Object out;
/* 144 */       if ((list.lists.size() == 2) && (list.modifiableList.isEmpty())) {
/* 145 */         out = list.lists.get(1);
/*     */       } else
/* 147 */         out = list;
/*     */     }
/* 149 */     return out;
/*     */   }
/*     */   
/*     */   protected boolean checkMatch(InventoryCrafting inv, int startX, int startY, boolean mirror)
/*     */   {
/* 154 */     for (int x = 0; x < 3; x++) {
/* 155 */       for (int y = 0; y < 3; y++) {
/* 156 */         int subX = x - startX;
/* 157 */         int subY = y - startY;
/* 158 */         Object target = null;
/*     */         
/* 160 */         if ((subX >= 0) && (subY >= 0) && (subX < this.width) && (subY < this.height)) {
/* 161 */           if (mirror) {
/* 162 */             target = this.input[(this.width - subX - 1 + subY * this.width)];
/*     */           } else {
/* 164 */             target = this.input[(subX + subY * this.width)];
/*     */           }
/*     */         }
/*     */         
/* 168 */         ItemStack slot = inv.getStackInRowAndColumn(x, y);
/*     */         
/* 170 */         if ((target instanceof ItemStack)) {
/* 171 */           if (!itemsMatch(slot, (ItemStack)target)) {
/* 172 */             return false;
/*     */           }
/* 174 */         } else if ((target instanceof List)) {
/* 175 */           boolean matched = false;
/*     */           
/* 177 */           Iterator<ItemStack> itr = ((List)target).iterator();
/* 178 */           while ((itr.hasNext()) && (!matched)) {
/* 179 */             matched = itemsMatch(slot, (ItemStack)itr.next());
/*     */           }
/*     */           
/* 182 */           if (!matched) {
/* 183 */             return false;
/*     */           }
/* 185 */         } else if ((target == null) && (slot != null)) {
/* 186 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 191 */     return true;
/*     */   }
/*     */   
/*     */   public boolean itemsMatch(ItemStack slot, @javax.annotation.Nonnull ItemStack target) {
/* 195 */     Item item = target.getItem();
/* 196 */     if ((item instanceof ICustomMatching)) {
/* 197 */       return ((ICustomMatching)item).itemsMatch(slot, target);
/*     */     }
/* 199 */     return OreDictionary.itemMatches(target, slot, false);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\XUShapedRecipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */