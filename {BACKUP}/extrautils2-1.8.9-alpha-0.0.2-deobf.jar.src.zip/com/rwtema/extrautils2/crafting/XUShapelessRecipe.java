/*    */ package com.rwtema.extrautils2.crafting;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.inventory.InventoryCrafting;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.oredict.OreDictionary;
/*    */ import net.minecraftforge.oredict.ShapelessOreRecipe;
/*    */ 
/*    */ public class XUShapelessRecipe extends ShapelessOreRecipe implements IItemMatcher
/*    */ {
/*    */   public XUShapelessRecipe(Block result, Object... recipe)
/*    */   {
/* 18 */     this(new ItemStack(result), recipe);
/*    */   }
/*    */   
/*    */   public XUShapelessRecipe(Item result, Object... recipe) {
/* 22 */     this(new ItemStack(result), recipe);
/*    */   }
/*    */   
/*    */   public XUShapelessRecipe(ItemStack result, Object... recipe) {
/* 26 */     super(new ItemStack(net.minecraft.init.Items.stick), new Object[0]);
/*    */     
/* 28 */     this.output = result.copy();
/* 29 */     for (Object in : recipe) {
/* 30 */       Object out = XUShapedRecipe.getRecipeObject(in);
/*    */       
/* 32 */       this.input.add(out);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean matches(InventoryCrafting var1, World world)
/*    */   {
/* 39 */     ArrayList<Object> required = new ArrayList(this.input);
/*    */     
/* 41 */     for (int x = 0; x < var1.getSizeInventory(); x++) {
/* 42 */       ItemStack slot = var1.getStackInSlot(x);
/*    */       
/* 44 */       if (slot != null) {
/* 45 */         boolean inRecipe = false;
/*    */         
/* 47 */         for (Object target : required) {
/* 48 */           boolean match = false;
/*    */           
/* 50 */           if ((target instanceof ItemStack)) {
/* 51 */             match = itemsMatch(slot, (ItemStack)target);
/* 52 */           } else if ((target instanceof List)) {
/* 53 */             Iterator<ItemStack> itr = ((List)target).iterator();
/* 54 */             while ((itr.hasNext()) && (!match)) {
/* 55 */               match = itemsMatch(slot, (ItemStack)itr.next());
/*    */             }
/*    */           }
/*    */           
/* 59 */           if (match) {
/* 60 */             inRecipe = true;
/* 61 */             required.remove(target);
/* 62 */             break;
/*    */           }
/*    */         }
/*    */         
/* 66 */         if (!inRecipe) {
/* 67 */           return false;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 72 */     return required.isEmpty();
/*    */   }
/*    */   
/*    */   public boolean itemsMatch(ItemStack slot, @javax.annotation.Nonnull ItemStack target) {
/* 76 */     Item item = target.getItem();
/* 77 */     if ((item instanceof ICustomMatching)) {
/* 78 */       return ((ICustomMatching)item).itemsMatch(slot, target);
/*    */     }
/* 80 */     return OreDictionary.itemMatches(target, slot, false);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\crafting\XUShapelessRecipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */