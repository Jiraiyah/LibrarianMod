/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import com.rwtema.extrautils2.fluids.FluidTankSerial;
/*    */ import com.rwtema.extrautils2.fluids.IFluidInterface;
/*    */ import com.rwtema.extrautils2.utils.CapGetter;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ 
/*    */ public class TransferNodeFluid extends TransferNodeBase<IFluidInterface>
/*    */ {
/* 12 */   FluidTankSerial tank = (FluidTankSerial)registerNBT("Buffer", new FluidTankSerial(1000));
/*    */   
/*    */   protected boolean shouldAdvance()
/*    */   {
/* 16 */     return !this.tank.isEmpty();
/*    */   }
/*    */   
/*    */   public int getDrainAmount() {
/* 20 */     return getUpgradeLevel(Upgrade.STACK_SIZE) > 0 ? 1000 : 200;
/*    */   }
/*    */   
/*    */   protected void processBuffer(@Nullable IFluidInterface attached)
/*    */   {
/* 25 */     if (attached != null) {}
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected boolean processPosition(BlockPos pingPos, IFluidInterface attached, IPipe pipe)
/*    */   {
/* 32 */     return false;
/*    */   }
/*    */   
/*    */   public IFluidInterface getHandler(TileEntity tile)
/*    */   {
/* 37 */     return (IFluidInterface)CapGetter.fluids.getInterface(tile, this.side.getOpposite());
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\TransferNodeFluid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */