/*     */ package com.rwtema.extrautils2.transfernodes;
/*     */ 
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainerTile;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetSlotItemHandler;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetTextData;
/*     */ import com.rwtema.extrautils2.itemhandler.InventoryHelper;
/*     */ import com.rwtema.extrautils2.itemhandler.SingleStackHandler;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.utils.CapGetter;
/*     */ import com.rwtema.extrautils2.utils.helpers.BlockStates;
/*     */ import java.util.EnumSet;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import net.minecraftforge.items.ItemStackHandler;
/*     */ 
/*     */ public class TransferNodeItem extends TransferNodeBase<IItemHandler> implements com.rwtema.extrautils2.gui.backend.IDynamicHandler
/*     */ {
/*     */   SingleStackHandler stack;
/*     */   
/*     */   public TransferNodeItem()
/*     */   {
/*  28 */     this.stack = ((SingleStackHandler)registerNBT("Buffer", new SingleStackHandler()
/*     */     {
/*     */       protected int getStackLimit(ItemStack stack) {
/*  31 */         return stack.getMaxStackSize();
/*     */       }
/*     */       
/*     */       protected void onContentsChanged()
/*     */       {
/*  36 */         TransferNodeItem.this.holder.markDirty();
/*     */       }
/*     */     }));
/*     */   }
/*     */   
/*     */   protected boolean shouldAdvance() {
/*  42 */     return !this.stack.isEmpty();
/*     */   }
/*     */   
/*     */   protected void processBuffer(IItemHandler attached)
/*     */   {
/*  47 */     if (attached == null) {
/*  48 */       int upgradeLevel = getUpgradeLevel(Upgrade.MINING);
/*  49 */       if (upgradeLevel > 0) {
/*  50 */         if (this.stack.isFull()) {
/*  51 */           return;
/*     */         }
/*     */         
/*  54 */         ItemStack b = new ItemStack(net.minecraft.init.Blocks.cobblestone, upgradeLevel);
/*  55 */         if ((!this.stack.isEmpty()) && (!net.minecraftforge.items.ItemHandlerHelper.canItemStacksStack(this.stack.getStack(), b))) {
/*  56 */           return;
/*     */         }
/*     */         
/*     */ 
/*  60 */         World world = this.holder.getWorld();
/*  61 */         BlockPos offset = this.holder.getPos().offset(this.side);
/*  62 */         IBlockState state = world.getBlockState(offset);
/*  63 */         if (state == BlockStates.cobblestone) {
/*  64 */           boolean lava = false;
/*  65 */           boolean water = false;
/*     */           
/*  67 */           EnumSet<EnumFacing> enumFacings = (EnumSet)FacingHelper.horizontalOrthogonal.get(this.side);
/*  68 */           for (EnumFacing facing : enumFacings) {
/*  69 */             IBlockState blockState = world.getBlockState(offset.offset(facing));
/*  70 */             if (blockState == BlockStates.lava_level_0) {
/*  71 */               lava = true;
/*  72 */             } else if (blockState == BlockStates.water_level_0) {
/*  73 */               water = true;
/*     */             }
/*     */           }
/*     */           
/*  77 */           if ((water) && (lava)) {
/*  78 */             this.stack.insertItem(0, b, false);
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/*  83 */       for (int i = 0; (i < attached.getSlots()) && (!this.stack.isFull()); i++) {
/*  84 */         InventoryHelper.transferSlotAtoSlotB(attached, i, this.stack, 0, getMaxTransfer());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getMaxTransfer() {
/*  90 */     return getUpgradeLevel(Upgrade.STACK_SIZE) > 0 ? 64 : 1;
/*     */   }
/*     */   
/*     */   protected boolean processPosition(BlockPos pingPos, IItemHandler attached, IPipe pipe)
/*     */   {
/*  95 */     if (pipe == null) {
/*  96 */       return true;
/*     */     }
/*     */     
/*  99 */     int maxTransfer = this.stack.getStackLevel();
/*     */     
/* 101 */     for (EnumFacing facing : FacingHelper.getRandomFaceOrderPooled()) {
/* 102 */       IItemHandler capability = (IItemHandler)pipe.getCapability(this.holder.getWorld(), pingPos, facing, CapGetter.ItemHandler);
/* 103 */       if (capability != null) {
/* 104 */         maxTransfer -= InventoryHelper.transfer(this.stack, 0, capability, maxTransfer, true);
/* 105 */         if (maxTransfer == 0) break;
/*     */       }
/*     */     }
/* 108 */     if (this.stack.isEmpty()) {
/* 109 */       this.ping.resetPosition();
/* 110 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 114 */     return true;
/*     */   }
/*     */   
/*     */   public boolean onActivated(EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/* 119 */     if (this.holder.getWorld().isRemote) {
/* 120 */       return true;
/*     */     }
/* 122 */     this.holder.openGui(playerIn, this);
/* 123 */     return true;
/*     */   }
/*     */   
/*     */   public IItemHandler getHandler(TileEntity tile)
/*     */   {
/* 128 */     return (IItemHandler)CapGetter.ItemHandler.getInterface(tile, this.side.getOpposite());
/*     */   }
/*     */   
/*     */   public com.rwtema.extrautils2.gui.backend.DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/* 133 */     return new TransferNodeContainer(player);
/*     */   }
/*     */   
/*     */   public <T> T getInterface(TileEntity tileEntity, CapGetter<T> capability)
/*     */   {
/* 138 */     if (capability == CapGetter.ItemHandler) {
/* 139 */       IItemHandler handler = (IItemHandler)CapGetter.ItemHandler.getInterface(tileEntity, this.side.getOpposite());
/* 140 */       if (handler != null) {
/* 141 */         return new com.rwtema.extrautils2.itemhandler.PublicWrapper.Extract(handler);
/*     */       }
/*     */     }
/* 144 */     return (T)super.getInterface(tileEntity, capability);
/*     */   }
/*     */   
/*     */   public class TransferNodeContainer extends DynamicContainerTile {
/*     */     public TransferNodeContainer(EntityPlayer player) {
/* 149 */       super(9, 64);
/* 150 */       addTitle("Transfer Node");
/*     */       
/* 152 */       int numUpgradeSlots = TransferNodeItem.this.upgradeHandler.getSlots();
/* 153 */       for (int i = 0; i < numUpgradeSlots; i++) {
/* 154 */         addWidget(new WidgetSlotItemHandler(TransferNodeItem.this.upgradeHandler, i, 85 + i * 18 - 9 * numUpgradeSlots, 80));
/*     */       }
/*     */       
/* 157 */       addWidget(new WidgetSlotItemHandler(TransferNodeItem.this.stack, 0, 76, 31));
/* 158 */       addWidget(new WidgetTextData(4, 68, 154)
/*     */       {
/*     */         public void addToDescription(PacketBuffer packet) {
/* 161 */           packet.writeBlockPos(TransferNodeItem.this.ping.getPos());
/*     */         }
/*     */         
/*     */         protected String constructText(PacketBuffer packet)
/*     */         {
/* 166 */           BlockPos pos = packet.readBlockPos();
/* 167 */           pos = pos.subtract(TransferNodeItem.this.holder.getPos());
/* 168 */           return com.rwtema.extrautils2.utils.Lang.translateArgs("x = %s, y = %s, z = %s", new Object[] { Integer.valueOf(pos.getX()), Integer.valueOf(pos.getY()), Integer.valueOf(pos.getZ()) }); } }.setAlign(0));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */       cropAndAddPlayerSlots(player.inventory);
/* 175 */       validate();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\TransferNodeItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */