/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import com.rwtema.extrautils2.utils.CapGetter;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map.Entry;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTBase;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.ITickable;
/*    */ import net.minecraftforge.common.util.INBTSerializable;
/*    */ 
/*    */ public abstract class Grocket implements ITickable
/*    */ {
/*    */   public TileTransferHolder holder;
/*    */   public EnumFacing side;
/*    */   @javax.annotation.Nullable
/*    */   private HashMap<String, INBTSerializable> nbtHandlers;
/*    */   
/*    */   @javax.annotation.Nonnull
/*    */   public BoxModel getWorldModel(EnumFacing facing)
/*    */   {
/* 26 */     GrocketType type = getType();
/* 27 */     BoxModel model = type.cache[facing.ordinal()];
/* 28 */     if (model == null) {
/* 29 */       model = type.createBaseModel(facing);
/* 30 */       type.cache[facing.ordinal()] = model;
/*    */     }
/* 32 */     return model;
/*    */   }
/*    */   
/*    */   public abstract GrocketType getType();
/*    */   
/*    */   public boolean onActivated(EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 38 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public void validate() {}
/*    */   
/*    */ 
/*    */   public void invalidate() {}
/*    */   
/*    */ 
/*    */   public java.util.List<ItemStack> getDrops()
/*    */   {
/* 50 */     return com.google.common.collect.ImmutableList.of(new ItemStack(ItemGrocket.instance, 1, getType().ordinal()));
/*    */   }
/*    */   
/*    */   public <T> T getInterface(TileEntity tileEntity, CapGetter<T> capability)
/*    */   {
/* 55 */     return (T)capability.getInterface(tileEntity, this.side.getOpposite());
/*    */   }
/*    */   
/*    */   public <T> boolean hasInterface(TileEntity tileEntity, CapGetter<T> capability) {
/* 59 */     return (tileEntity != null) && (capability.hasInterface(tileEntity, this.side.getOpposite()));
/*    */   }
/*    */   
/*    */   public void writeToNBT(NBTTagCompound tag) {
/* 63 */     if (this.nbtHandlers != null) {
/* 64 */       for (Map.Entry<String, INBTSerializable> entry : this.nbtHandlers.entrySet()) {
/* 65 */         tag.setTag((String)entry.getKey(), ((INBTSerializable)entry.getValue()).serializeNBT());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void readFromNBT(NBTTagCompound tag) {
/* 71 */     if (this.nbtHandlers != null) {
/* 72 */       for (Map.Entry<String, INBTSerializable> entry : this.nbtHandlers.entrySet()) {
/* 73 */         NBTBase subTag = tag.getTag((String)entry.getKey());
/* 74 */         if (subTag != null) {
/* 75 */           ((INBTSerializable)entry.getValue()).deserializeNBT(subTag);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void onPlaced(EntityPlayer player) {}
/*    */   
/*    */ 
/*    */   protected <T extends INBTSerializable> T registerNBT(String key, T t)
/*    */   {
/* 88 */     if (this.nbtHandlers == null) {
/* 89 */       this.nbtHandlers = new HashMap();
/*    */     }
/* 91 */     this.nbtHandlers.put(key, t);
/* 92 */     return t;
/*    */   }
/*    */   
/*    */   public void markDirty() {
/* 96 */     if (this.holder != null) {
/* 97 */       this.holder.markDirty();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\Grocket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */