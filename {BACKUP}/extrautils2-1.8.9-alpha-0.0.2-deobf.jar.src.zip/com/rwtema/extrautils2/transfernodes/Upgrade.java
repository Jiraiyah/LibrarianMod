/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public enum Upgrade
/*    */ {
/*  8 */   STACK_SIZE(1), 
/*  9 */   SPEED(20), 
/* 10 */   MINING(1);
/*    */   
/*    */   public final int maxLevel;
/*    */   
/* 14 */   private Upgrade(int maxLevel) { this.maxLevel = maxLevel; }
/*    */   
/*    */   public static void addTooltip(List<String> tooltip, ItemStack stack)
/*    */   {
/* 18 */     addTooltip(tooltip, ((IUpgradeProvider)stack.getItem()).getUpgrades(stack));
/*    */   }
/*    */   
/*    */   protected static void addTooltip(List<String> tooltip, Upgrade upgrade) {
/* 22 */     tooltip.add(com.rwtema.extrautils2.utils.Lang.translateArgs("Max Upgrades: %s", new Object[] { Integer.valueOf(upgrade.maxLevel) }));
/*    */   }
/*    */   
/*    */   public int getModifierLevel(int level) {
/* 26 */     return level;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\Upgrade.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */