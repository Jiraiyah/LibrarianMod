/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import java.util.AbstractSet;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ 
/*    */ public class FacingSet
/*    */   extends AbstractSet<EnumFacing>
/*    */   implements Set<EnumFacing>
/*    */ {
/* 17 */   private static Collection<EnumFacing>[] facings = new Collection[64];
/* 18 */   static { for (int i = 0; i < 64; i++) {
/* 19 */       ArrayList<EnumFacing> list = new ArrayList();
/* 20 */       for (EnumFacing facing : EnumFacing.values()) {
/* 21 */         if ((i & 1 << facing.ordinal()) != 0) {
/* 22 */           list.add(facing);
/*    */         }
/*    */       }
/* 25 */       facings[i] = ImmutableList.copyOf(list);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   int mask;
/*    */   public int size()
/*    */   {
/* 33 */     return facings[this.mask].size();
/*    */   }
/*    */   
/*    */   public boolean isEmpty()
/*    */   {
/* 38 */     return this.mask == 0;
/*    */   }
/*    */   
/*    */   public boolean contains(Object o)
/*    */   {
/* 43 */     EnumFacing facing = (EnumFacing)o;
/* 44 */     return (this.mask & 1 << facing.ordinal()) != 0;
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public Iterator<EnumFacing> iterator()
/*    */   {
/* 50 */     return facings[this.mask].iterator();
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public Object[] toArray()
/*    */   {
/* 56 */     return facings[this.mask].toArray();
/*    */   }
/*    */   
/*    */ 
/*    */   @Nonnull
/*    */   public <T> T[] toArray(@Nonnull T[] a)
/*    */   {
/* 63 */     return facings[this.mask].toArray(a);
/*    */   }
/*    */   
/*    */   public boolean add(EnumFacing facing)
/*    */   {
/* 68 */     if ((this.mask & 1 << facing.ordinal()) == 0) {
/* 69 */       this.mask |= 1 << facing.ordinal();
/* 70 */       return true;
/*    */     }
/*    */     
/* 73 */     return false;
/*    */   }
/*    */   
/*    */   public boolean remove(Object o)
/*    */   {
/* 78 */     EnumFacing facing = (EnumFacing)o;
/*    */     
/* 80 */     if ((this.mask & 1 << facing.ordinal()) != 0) {
/* 81 */       this.mask &= (1 << facing.ordinal() ^ 0xFFFFFFFF);
/* 82 */       return true;
/*    */     }
/*    */     
/* 85 */     return false;
/*    */   }
/*    */   
/*    */   public void clear()
/*    */   {
/* 90 */     this.mask = 0;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\FacingSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */