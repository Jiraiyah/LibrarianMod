/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import net.minecraft.nbt.NBTTagIntArray;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ 
/*    */ public class Ping implements net.minecraftforge.common.util.INBTSerializable<NBTTagIntArray>
/*    */ {
/*    */   private IBlockAccess world;
/* 11 */   private BlockPos pos = null;
/*    */   private EnumFacing direction;
/*    */   private BlockPos home;
/*    */   private EnumFacing homeDirection;
/*    */   
/*    */   public boolean needsInit()
/*    */   {
/* 18 */     return (this.world == null) || (this.home == null) || (this.homeDirection == null);
/*    */   }
/*    */   
/*    */   public void init(IBlockAccess world, BlockPos home, EnumFacing homeDirection) {
/* 22 */     this.world = world;
/* 23 */     this.home = home;
/* 24 */     this.homeDirection = homeDirection;
/*    */   }
/*    */   
/*    */   public BlockPos getPos() {
/* 28 */     if (this.pos == null) {
/* 29 */       resetPosition();
/*    */     }
/* 31 */     return this.pos;
/*    */   }
/*    */   
/*    */   public EnumFacing getDirection() {
/* 35 */     if (this.direction == null) {
/* 36 */       resetPosition();
/*    */     }
/* 38 */     return this.direction;
/*    */   }
/*    */   
/*    */   public void resetPosition() {
/* 42 */     this.pos = getDefaultPos();
/* 43 */     this.direction = getDefaultSide();
/*    */   }
/*    */   
/*    */   protected EnumFacing getDefaultSide() {
/* 47 */     return this.homeDirection;
/*    */   }
/*    */   
/*    */   protected BlockPos getDefaultPos() {
/* 51 */     return this.home;
/*    */   }
/*    */   
/*    */ 
/*    */   public void advanceSearch(IPipe pipe)
/*    */   {
/* 57 */     if (pipe == null) {
/* 58 */       resetPosition();
/* 59 */       return;
/*    */     }
/*    */     
/* 62 */     for (EnumFacing facing : FacingHelper.getRandomFaceOrderPooled()) {
/* 63 */       if (facing != this.direction.getOpposite())
/*    */       {
/*    */ 
/* 66 */         if (pipe.canOutput(this.world, this.pos, facing)) {
/* 67 */           BlockPos offset = this.pos.offset(facing);
/* 68 */           if (TransferHelper.isInputtingPipe(this.world, offset, facing.getOpposite())) {
/* 69 */             this.pos = offset;
/* 70 */             this.direction = facing;
/* 71 */             return;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 76 */     resetPosition();
/*    */   }
/*    */   
/*    */   public NBTTagIntArray serializeNBT()
/*    */   {
/* 81 */     if ((this.pos == null) || (this.direction == null))
/* 82 */       return new NBTTagIntArray(new int[] { 0, 0, 0, 0 });
/* 83 */     return new NBTTagIntArray(new int[] { this.pos.getX(), this.pos.getY(), this.pos.getZ(), this.direction.ordinal() });
/*    */   }
/*    */   
/*    */   public void deserializeNBT(NBTTagIntArray nbt)
/*    */   {
/* 88 */     int[] ints = nbt.getIntArray();
/* 89 */     if (ints.length != 4) { return;
/*    */     }
/* 91 */     int i = ints[3];
/* 92 */     if ((i < 0) || (i >= 6)) {
/* 93 */       return;
/*    */     }
/*    */     
/* 96 */     this.direction = EnumFacing.values()[i];
/*    */     
/* 98 */     this.pos = new BlockPos(ints[0], ints[1], ints[2]);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\Ping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */