/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.minecraftforge.common.capabilities.Capability;
/*    */ 
/*    */ public class CapabilityHandlers
/*    */ {
/*  8 */   public static final ArrayList<Capability<?>> capabilities = new ArrayList();
/*    */   
/*    */   static {
/* 11 */     capabilities.add(net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\CapabilityHandlers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */