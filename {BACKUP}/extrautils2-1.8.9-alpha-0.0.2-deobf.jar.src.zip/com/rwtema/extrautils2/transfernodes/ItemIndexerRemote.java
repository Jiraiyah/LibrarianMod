/*     */ package com.rwtema.extrautils2.transfernodes;
/*     */ 
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.backend.XUItemFlatMetadata;
/*     */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraftforge.common.DimensionManager;
/*     */ 
/*     */ public class ItemIndexerRemote extends XUItemFlatMetadata implements IDynamicHandler
/*     */ {
/*     */   public ItemIndexerRemote()
/*     */   {
/*  22 */     super(new String[] { "indexer_remote" });
/*  23 */     setMaxStackSize(1);
/*     */   }
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer playerIn, World worldIn, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*  28 */     if ((stack.hasTagCompound()) && (stack.getTagCompound().hasKey("BlockPos", 10))) {
/*  29 */       return false;
/*     */     }
/*     */     
/*  32 */     if (worldIn.isRemote) {
/*  33 */       return worldIn.getTileEntity(pos) instanceof TileIndexer;
/*     */     }
/*  35 */     TileEntity entity = worldIn.getTileEntity(pos);
/*  36 */     if (!(entity instanceof TileIndexer)) return false;
/*  37 */     TileIndexer indexer = (TileIndexer)entity;
/*  38 */     if (!indexer.isValidPlayer(playerIn)) {
/*  39 */       return true;
/*     */     }
/*     */     
/*  42 */     NBTTagCompound nbt = NBTHelper.getOrInitTagCompound(stack);
/*  43 */     nbt.setInteger("Dimension", worldIn.provider.func_177502_q());
/*  44 */     nbt.setTag("BlockPos", NBTHelper.blockPosToNBT(pos));
/*  45 */     return true;
/*     */   }
/*     */   
/*     */   public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn)
/*     */   {
/*  50 */     if (worldIn.isRemote) return itemStackIn;
/*  51 */     if (!itemStackIn.hasTagCompound()) { return itemStackIn;
/*     */     }
/*  53 */     NBTTagCompound nbt = itemStackIn.getTagCompound();
/*     */     
/*  55 */     int dimension = nbt.getInteger("Dimension");
/*  56 */     WorldServer world = DimensionManager.getWorld(dimension);
/*  57 */     if (world == null) {
/*  58 */       playerIn.addChatComponentMessage(Lang.chat("Unable to contact indexer", new Object[0]));
/*  59 */       return itemStackIn;
/*     */     }
/*     */     
/*  62 */     BlockPos blockPos = NBTHelper.nbtToBlockPos(nbt.getCompoundTag("BlockPos"));
/*  63 */     if (!world.isBlockLoaded(blockPos)) {
/*  64 */       playerIn.addChatComponentMessage(Lang.chat("Unable to contact indexer", new Object[0]));
/*  65 */       return itemStackIn;
/*     */     }
/*     */     
/*  68 */     TileEntity tile = world.getTileEntity(blockPos);
/*  69 */     if (!(tile instanceof TileIndexer)) {
/*  70 */       playerIn.addChatComponentMessage(Lang.chat("Unable to contact indexer", new Object[0]));
/*  71 */       return itemStackIn;
/*     */     }
/*     */     
/*  74 */     if (((TileIndexer)tile).isValidPlayer(playerIn)) {
/*  75 */       playerIn.openGui(ExtraUtils2.instance, -1, world, blockPos.getX(), blockPos.getY(), blockPos.getZ());
/*     */     }
/*  77 */     return itemStackIn;
/*     */   }
/*     */   
/*     */ 
/*     */   public com.rwtema.extrautils2.gui.backend.DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/*  83 */     BlockPos pos = new BlockPos(x, y, z);
/*  84 */     TileIndexer indexer; if (world.isRemote) {
/*  85 */       TileIndexer indexer = new TileIndexer();
/*  86 */       indexer.setWorldObj(world);
/*  87 */       indexer.setPos(pos);
/*     */     } else {
/*  89 */       if (!world.isBlockLoaded(pos)) {
/*  90 */         return null;
/*     */       }
/*     */       
/*  93 */       TileEntity tile = world.getTileEntity(pos);
/*  94 */       if (!(tile instanceof TileIndexer)) {
/*  95 */         return null;
/*     */       }
/*     */       
/*  98 */       indexer = (TileIndexer)tile;
/*     */       
/* 100 */       indexer.positionsHash = 0L;
/* 101 */       indexer.reload();
/*     */     }
/*     */     
/* 104 */     return new TileIndexer.ContainerIndexer(indexer, player);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\ItemIndexerRemote.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */