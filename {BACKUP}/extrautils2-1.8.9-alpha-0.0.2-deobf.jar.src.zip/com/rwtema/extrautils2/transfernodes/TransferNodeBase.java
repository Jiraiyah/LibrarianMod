/*     */ package com.rwtema.extrautils2.transfernodes;
/*     */ 
/*     */ import com.rwtema.extrautils2.utils.CapGetter;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.ITickable;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.items.ItemHandlerHelper;
/*     */ import net.minecraftforge.items.ItemStackHandler;
/*     */ 
/*     */ public abstract class TransferNodeBase<T> extends Grocket implements ITickable
/*     */ {
/*  16 */   protected final Ping ping = (Ping)registerNBT("ping", new Ping());
/*  17 */   protected int cooldown = 0;
/*     */   TObjectIntHashMap<Upgrade> upgrades;
/*  19 */   public ItemStackHandler upgradeHandler = (ItemStackHandler)registerNBT("upgrades", new ItemStackHandler(6)
/*     */   {
/*     */     protected int getStackLimit(int slot, ItemStack stack) {
/*  22 */       if (!(stack.getItem() instanceof IUpgradeProvider)) {
/*  23 */         return 0;
/*     */       }
/*     */       
/*  26 */       for (int i = 0; i < this.stacks.length; i++) {
/*  27 */         if (i != slot) {
/*  28 */           ItemStack otherStack = this.stacks[i];
/*  29 */           if ((otherStack != null) && (ItemHandlerHelper.canItemStacksStack(stack, otherStack)))
/*  30 */             return 0;
/*     */         }
/*     */       }
/*  33 */       Upgrade upgrade = ((IUpgradeProvider)stack.getItem()).getUpgrades(stack);
/*  34 */       if (upgrade == null) return 0;
/*  35 */       return upgrade.maxLevel;
/*     */     }
/*     */     
/*     */     protected void onContentsChanged(int slot)
/*     */     {
/*  40 */       TransferNodeBase.this.markDirty();
/*  41 */       loadUpgrades();
/*     */     }
/*     */     
/*     */     protected void onLoad()
/*     */     {
/*  46 */       loadUpgrades();
/*     */     }
/*     */     
/*     */     public void loadUpgrades() {
/*  50 */       TObjectIntHashMap<Upgrade> upgradeMap = new TObjectIntHashMap(10, 0.5F, 0);
/*  51 */       for (ItemStack stack : this.stacks) {
/*  52 */         if ((stack != null) && ((stack.getItem() instanceof IUpgradeProvider))) {
/*  53 */           upgradeMap.adjustOrPutValue(((IUpgradeProvider)stack.getItem()).getUpgrades(stack), stack.stackSize, stack.stackSize);
/*     */         }
/*     */       }
/*     */       
/*  57 */       TransferNodeBase.this.upgrades = upgradeMap;
/*     */     }
/*  19 */   });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUpgradeLevel(Upgrade upgrade)
/*     */   {
/*  62 */     TObjectIntHashMap<Upgrade> upgrades = this.upgrades;
/*  63 */     if (upgrades == null) return upgrade.getModifierLevel(0);
/*  64 */     int level = upgrades.get(upgrade);
/*  65 */     if (level < 0) level = 0;
/*  66 */     if (level > upgrade.maxLevel) level = upgrade.maxLevel;
/*  67 */     return upgrade.getModifierLevel(level);
/*     */   }
/*     */   
/*     */   public GrocketType getType()
/*     */   {
/*  72 */     return GrocketType.TRANSFER_NODE_ITEMS;
/*     */   }
/*     */   
/*     */   public void update()
/*     */   {
/*  77 */     if (this.holder == null) { return;
/*     */     }
/*  79 */     World world = this.holder.getWorld();
/*  80 */     if (this.ping.needsInit()) {
/*  81 */       this.ping.init(world, this.holder.getPos(), this.side.getOpposite());
/*  82 */       return;
/*     */     }
/*     */     
/*  85 */     if (this.cooldown > 0) { this.cooldown -= stepCooldown();
/*     */     }
/*  87 */     if (checkRedstone()) {
/*  88 */       this.cooldown = 20;
/*  89 */       return;
/*     */     }
/*     */     
/*  92 */     T attached = getAttached();
/*  93 */     while (this.cooldown <= 0) {
/*  94 */       this.cooldown += 20;
/*     */       
/*     */ 
/*  97 */       processBuffer(attached);
/*     */       
/*  99 */       if (shouldAdvance()) {
/* 100 */         BlockPos pingPos = this.ping.getPos();
/* 101 */         if (pingPos == null) {
/* 102 */           return;
/*     */         }
/* 104 */         if (!world.isBlockLoaded(pingPos)) {
/* 105 */           this.ping.resetPosition();
/* 106 */           return;
/*     */         }
/* 108 */         IPipe pipe = TransferHelper.getPipe(world, pingPos);
/*     */         
/* 110 */         if (processPosition(pingPos, attached, pipe)) {
/* 111 */           this.ping.advanceSearch(pipe);
/*     */         }
/*     */       }
/*     */       else {
/* 115 */         this.ping.resetPosition();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract boolean shouldAdvance();
/*     */   
/*     */ 
/*     */   protected abstract void processBuffer(@javax.annotation.Nullable T paramT);
/*     */   
/*     */   protected abstract boolean processPosition(BlockPos paramBlockPos, T paramT, IPipe paramIPipe);
/*     */   
/*     */   private int stepCooldown()
/*     */   {
/* 130 */     return 1 + getUpgradeLevel(Upgrade.SPEED);
/*     */   }
/*     */   
/*     */   public boolean checkRedstone() {
/* 134 */     return this.holder.getWorld().isBlockPowered(this.holder.getPos());
/*     */   }
/*     */   
/*     */   public T getAttached() {
/* 138 */     TileEntity tile = this.holder.getWorld().getTileEntity(this.holder.getPos().offset(this.side));
/* 139 */     if (tile == null) return null;
/* 140 */     T capability1 = getHandler(tile);
/* 141 */     if (capability1 != null) { return capability1;
/*     */     }
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   public abstract T getHandler(TileEntity paramTileEntity);
/*     */   
/*     */   public void writeToNBT(NBTTagCompound tag)
/*     */   {
/* 150 */     super.writeToNBT(tag);
/* 151 */     tag.setInteger("Cooldown", this.cooldown);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound tag)
/*     */   {
/* 156 */     super.readFromNBT(tag);
/* 157 */     this.cooldown = tag.getInteger("Cooldown");
/*     */   }
/*     */   
/*     */   public <S> boolean hasInterface(TileEntity tileEntity, CapGetter<S> capability)
/*     */   {
/* 162 */     return (capability == CapGetter.PipeConnect) || (super.hasInterface(tileEntity, capability));
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\TransferNodeBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */