/*     */ package com.rwtema.extrautils2.transfernodes;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUItem;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem.ModelLayer;
/*     */ import java.util.EnumMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block.SoundType;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ItemGrocket extends XUItem
/*     */ {
/*     */   public static ItemGrocket instance;
/*     */   private EnumMap<GrocketType, BoxModel> models;
/*     */   @SideOnly(Side.CLIENT)
/*     */   private TextureAtlasSprite sprite;
/*     */   
/*     */   public ItemGrocket()
/*     */   {
/*  29 */     setHasSubtypes(true);
/*  30 */     instance = this;
/*     */   }
/*     */   
/*     */   public void getSubItems(Item itemIn, CreativeTabs tab, List<ItemStack> subItems)
/*     */   {
/*  35 */     for (int i = 0; i < GrocketType.values().length; i++) {
/*  36 */       subItems.add(new ItemStack(itemIn, 1, i));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onItemUse(ItemStack stack, EntityPlayer playerIn, World worldIn, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*  42 */     if ((stack == null) || (stack.stackSize == 0)) {
/*  43 */       return false;
/*     */     }
/*  45 */     if (!playerIn.canPlayerEdit(pos, side, stack)) { return false;
/*     */     }
/*  47 */     if (worldIn.isRemote) { return true;
/*     */     }
/*  49 */     GrocketType type = getGrocketType(stack);
/*     */     
/*  51 */     if ((BlockTransferHolder.placeGrocket(playerIn, worldIn, pos, type.create(), side)) || (BlockTransferHolder.placeGrocket(playerIn, worldIn, pos.offset(side), type.create(), side.getOpposite()))) {
/*  52 */       Block.SoundType stepSound = net.minecraft.block.Block.field_149769_e;
/*  53 */       worldIn.func_72908_a(pos.getX() + 0.5F, pos.getY() + 0.5F, pos.getZ() + 0.5F, stepSound.func_150496_b(), (stepSound.func_150497_c() + 1.0F) / 2.0F, stepSound.func_150494_d() * 0.8F);
/*  54 */       stack.stackSize -= 1;
/*  55 */       return true; }
/*  56 */     return false;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/*  62 */     this.sprite = null;
/*  63 */     GrocketType[] values = GrocketType.values();
/*  64 */     this.models = new EnumMap(GrocketType.class);
/*  65 */     for (GrocketType type : values) {
/*  66 */       BoxModel baseModel = type.createBaseModel();
/*  67 */       baseModel.moveToCenterForInventoryRendering();
/*  68 */       baseModel.registerTextures();
/*  69 */       this.models.put(type, baseModel);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public TextureAtlasSprite getBaseTexture()
/*     */   {
/*  76 */     if (this.sprite == null) {
/*  77 */       for (BoxModel boxes : this.models.values()) {
/*  78 */         this.sprite = boxes.getTex();
/*  79 */         if (this.sprite != null) return this.sprite;
/*     */       }
/*     */     }
/*  82 */     return this.sprite;
/*     */   }
/*     */   
/*     */   public GrocketType getGrocketType(ItemStack stack) {
/*  86 */     GrocketType[] values = GrocketType.values();
/*  87 */     int i = stack.getItemDamage();
/*  88 */     if ((i < 0) || (i >= values.length)) i = 0;
/*  89 */     return values[i];
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public net.minecraft.client.resources.model.IBakedModel createModel(int metadata)
/*     */   {
/*  95 */     return new com.rwtema.extrautils2.backend.model.PassthruModelItem(this, com.rwtema.extrautils2.backend.model.Transforms.itemTransforms);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addQuads(PassthruModelItem.ModelLayer model, ItemStack stack)
/*     */   {
/* 101 */     GrocketType type = getGrocketType(stack);
/* 102 */     BoxModel m = (BoxModel)this.models.get(type);
/* 103 */     model.clear();
/* 104 */     model.isGui3D = true;
/* 105 */     model.tex = m.getTex();
/* 106 */     model.addBoxModel(m);
/*     */   }
/*     */   
/*     */   public int getMaxMetadata()
/*     */   {
/* 111 */     return GrocketType.values().length;
/*     */   }
/*     */   
/*     */   public boolean allowOverride()
/*     */   {
/* 116 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getUnlocalizedName(ItemStack stack)
/*     */   {
/* 122 */     return super.getUnlocalizedName(stack) + "." + stack.getItemDamage();
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\ItemGrocket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */