package com.rwtema.extrautils2.transfernodes;

import net.minecraft.util.EnumFacing;

public abstract interface IPipeConnect
{
  public abstract boolean forceConnect(EnumFacing paramEnumFacing);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\IPipeConnect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */