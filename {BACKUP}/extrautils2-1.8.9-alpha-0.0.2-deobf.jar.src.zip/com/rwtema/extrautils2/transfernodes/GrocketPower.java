/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import com.rwtema.extrautils2.power.Freq;
/*    */ import com.rwtema.extrautils2.power.IPower;
/*    */ import com.rwtema.extrautils2.power.IWorldPowerMultiplier;
/*    */ import com.rwtema.extrautils2.power.PowerManager;
/*    */ import javax.annotation.Nonnull;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public abstract class GrocketPower extends Grocket implements IPower
/*    */ {
/*    */   public static final String NBT_FREQUENCY = "Frequency";
/*    */   public static final String NBT_ACTIVE = "Active";
/*    */   public int frequency;
/*    */   public boolean active;
/*    */   
/*    */   public void writeToNBT(NBTTagCompound compound)
/*    */   {
/* 24 */     super.writeToNBT(compound);
/* 25 */     compound.setInteger("Frequency", this.frequency);
/* 26 */     compound.setBoolean("Active", this.active);
/*    */   }
/*    */   
/*    */   public void readFromNBT(NBTTagCompound tag)
/*    */   {
/* 31 */     super.readFromNBT(tag);
/* 32 */     this.frequency = tag.getInteger("Frequency");
/* 33 */     this.active = tag.getBoolean("Active");
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public String getName()
/*    */   {
/* 39 */     return getType().createStack().getDisplayName();
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public World world()
/*    */   {
/* 45 */     return this.holder.getWorld();
/*    */   }
/*    */   
/*    */   public int frequency()
/*    */   {
/* 50 */     return this.frequency;
/*    */   }
/*    */   
/*    */ 
/*    */   public void powerChanged(boolean powered)
/*    */   {
/* 56 */     if (this.active != powered) {
/* 57 */       this.active = powered;
/* 58 */       this.holder.markDirty();
/* 59 */       onPowerChanged();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public IWorldPowerMultiplier getMultiplier()
/*    */   {
/* 66 */     return IWorldPowerMultiplier.CONSTANT;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void onPowerChanged() {}
/*    */   
/*    */ 
/*    */   public void validate()
/*    */   {
/* 76 */     super.validate();
/* 77 */     if (!this.holder.getWorld().isRemote) {
/* 78 */       PowerManager.instance.addPowerHandler(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public void invalidate()
/*    */   {
/* 84 */     super.invalidate();
/* 85 */     if (!this.holder.getWorld().isRemote) {
/* 86 */       PowerManager.instance.removePowerHandler(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public void onPlaced(EntityPlayer placer) {
/* 91 */     if ((!this.holder.getWorld().isRemote) && ((placer instanceof EntityPlayerMP)))
/* 92 */       this.frequency = Freq.getBasePlayerFreq((EntityPlayerMP)placer);
/*    */   }
/*    */   
/*    */   public boolean isValidPlayer(EntityPlayer playerIn) {
/* 96 */     return PowerManager.canUse(playerIn, this);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\GrocketPower.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */