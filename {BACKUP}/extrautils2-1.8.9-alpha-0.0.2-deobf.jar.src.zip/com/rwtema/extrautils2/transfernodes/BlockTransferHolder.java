/*     */ package com.rwtema.extrautils2.transfernodes;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.MultiBlockStateBuilder;
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.entries.MultiBlockEntry;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import java.util.ArrayList;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockTransferHolder extends XUBlock
/*     */ {
/*     */   private static IBlockState holderState;
/*     */   
/*     */   public BlockTransferHolder()
/*     */   {
/*  24 */     super(net.minecraft.block.material.Material.rock);
/*  25 */     holderState = getDefaultState();
/*     */   }
/*     */   
/*     */   public static boolean placePipe(World world, BlockPos pos) {
/*  29 */     IBlockState blockState = world.getBlockState(pos);
/*     */     
/*  31 */     if (blockState.getBlock().isReplaceable(world, pos)) {
/*  32 */       return world.setBlockState(pos, BlockTransferPipe.stateBuilder.defaultState);
/*     */     }
/*     */     
/*  35 */     if (blockState == holderState) {
/*  36 */       TileEntity tile = world.getTileEntity(pos);
/*     */       
/*  38 */       if (!(tile instanceof TileTransferHolder)) {
/*  39 */         world.removeTileEntity(pos);
/*  40 */         tile = world.getTileEntity(pos);
/*     */       }
/*  42 */       TileTransferHolder holder = (TileTransferHolder)tile;
/*  43 */       if (holder.centerPipe != null) return false;
/*  44 */       holder.centerPipe = BlockTransferPipe.stateBuilder.defaultState;
/*  45 */       world.func_175689_h(pos);
/*  46 */       return true;
/*     */     }
/*     */     
/*  49 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean placeGrocket(EntityPlayer player, World world, BlockPos pos, Grocket grocket, EnumFacing facing) {
/*  53 */     IBlockState blockState = world.getBlockState(pos);
/*  54 */     if (blockState == holderState) {
/*  55 */       TileEntity tile = world.getTileEntity(pos);
/*  56 */       if (!(tile instanceof TileTransferHolder)) {
/*  57 */         world.removeTileEntity(pos);
/*  58 */         tile = world.getTileEntity(pos);
/*     */       }
/*  60 */       TileTransferHolder holder = (TileTransferHolder)tile;
/*  61 */       if (holder.grockets[facing.ordinal()] != null) return false;
/*  62 */       holder.addGrocket(player, grocket, facing);
/*  63 */       world.func_175689_h(pos);
/*  64 */       return true;
/*     */     }
/*     */     
/*  67 */     if (BlockTransferPipe.stateBuilder.genericPipeStates.contains(blockState)) {
/*  68 */       world.setBlockState(pos, holderState);
/*  69 */       world.removeTileEntity(pos);
/*  70 */       TileTransferHolder tileEntity = (TileTransferHolder)world.getTileEntity(pos);
/*  71 */       tileEntity.addGrocket(player, grocket, facing);
/*  72 */       tileEntity.centerPipe = blockState;
/*  73 */       world.func_175689_h(pos);
/*  74 */       return true;
/*     */     }
/*     */     
/*  77 */     if (blockState.getBlock().isReplaceable(world, pos)) {
/*  78 */       world.setBlockState(pos, holderState);
/*  79 */       TileTransferHolder tileEntity = (TileTransferHolder)world.getTileEntity(pos);
/*  80 */       tileEntity.addGrocket(player, grocket, facing);
/*  81 */       world.func_175689_h(pos);
/*  82 */       return true;
/*     */     }
/*     */     
/*  85 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isToolEffective(String type, IBlockState state)
/*     */   {
/*  90 */     return true;
/*     */   }
/*     */   
/*     */   public boolean canHarvestBlock(IBlockAccess world, BlockPos pos, EntityPlayer player)
/*     */   {
/*  95 */     return true;
/*     */   }
/*     */   
/*     */   @javax.annotation.Nonnull
/*     */   public BoxModel getWorldModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/* 101 */     TileEntity tileEntity = world.getTileEntity(pos);
/* 102 */     if ((tileEntity instanceof TileTransferHolder)) {
/* 103 */       TileTransferHolder transferHolder = (TileTransferHolder)tileEntity;
/*     */       
/* 105 */       BoxModel worldModel = transferHolder.worldModel;
/*     */       
/* 107 */       if (worldModel != null) return worldModel;
/* 108 */       worldModel = new BoxModel();
/* 109 */       IBlockState centerPipe = transferHolder.centerPipe;
/* 110 */       if (centerPipe != null) {
/* 111 */         worldModel.addAll(((BlockTransferPipe)BlockTransferPipe.stateBuilder.mainBlock).getWorldModel(world, pos, centerPipe));
/*     */       }
/* 113 */       Grocket[] grockets = transferHolder.grockets;
/* 114 */       for (EnumFacing facing : EnumFacing.values()) {
/* 115 */         Grocket grocket = grockets[facing.ordinal()];
/* 116 */         if (grocket != null) {
/* 117 */           worldModel.addAll(grocket.getWorldModel(facing));
/*     */         }
/*     */       }
/*     */       
/* 121 */       return worldModel;
/*     */     }
/* 123 */     return new BoxModel(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public BoxModel getRenderModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/* 128 */     TileEntity tileEntity = world.getTileEntity(pos);
/* 129 */     if ((tileEntity instanceof TileTransferHolder)) {
/* 130 */       TileTransferHolder transferHolder = (TileTransferHolder)tileEntity;
/*     */       
/* 132 */       BoxModel worldModel = transferHolder.worldModel;
/*     */       
/* 134 */       if (worldModel != null) return worldModel;
/* 135 */       worldModel = new BoxModel();
/* 136 */       IBlockState centerPipe = transferHolder.centerPipe;
/* 137 */       if (centerPipe != null) {
/* 138 */         worldModel.addAll(((BlockTransferPipe)BlockTransferPipe.stateBuilder.mainBlock).getRenderModel(world, pos, centerPipe));
/*     */       }
/* 140 */       Grocket[] grockets = transferHolder.grockets;
/* 141 */       for (EnumFacing facing : EnumFacing.values()) {
/* 142 */         Grocket grocket = grockets[facing.ordinal()];
/* 143 */         if (grocket != null) {
/* 144 */           worldModel.addAll(grocket.getWorldModel(facing));
/*     */         }
/*     */       }
/*     */       
/* 148 */       return worldModel;
/*     */     }
/* 150 */     return new BoxModel(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public boolean hasTileEntity(IBlockState state)
/*     */   {
/* 155 */     return true;
/*     */   }
/*     */   
/*     */   public TileEntity createTileEntity(World world, IBlockState state)
/*     */   {
/* 160 */     return new TileTransferHolder();
/*     */   }
/*     */   
/*     */   @javax.annotation.Nonnull
/*     */   public BoxModel getInventoryModel(@Nullable ItemStack item)
/*     */   {
/* 166 */     return new BoxModel();
/*     */   }
/*     */   
/*     */   public void harvestBlock(World world, EntityPlayer player, BlockPos pos, IBlockState state, TileEntity te) {
/* 170 */     if ((te instanceof TileTransferHolder)) {
/* 171 */       TileTransferHolder holder = (TileTransferHolder)te;
/*     */       
/* 173 */       if (holder.centerPipe != null) {
/* 174 */         spawnAsEntity(world, pos, com.rwtema.extrautils2.backend.entries.XU2Entries.pipe.newStack());
/*     */       }
/* 176 */       for (Grocket grocket : holder.grockets) {
/* 177 */         if (grocket != null) {
/* 178 */           for (ItemStack itemStack : grocket.getDrops())
/* 179 */             spawnAsEntity(world, pos, itemStack);
/*     */         }
/*     */       }
/*     */     } else {
/* 183 */       super.harvestBlock(world, player, pos, state, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public java.util.List<ItemStack> getDrops(IBlockAccess world, BlockPos pos, IBlockState state, int fortune)
/*     */   {
/* 189 */     ArrayList<ItemStack> list = new ArrayList();
/* 190 */     TileEntity tileEntity = world.getTileEntity(pos);
/* 191 */     if ((tileEntity instanceof TileTransferHolder)) {
/* 192 */       TileTransferHolder holder = (TileTransferHolder)tileEntity;
/*     */       
/* 194 */       if (holder.centerPipe != null) {
/* 195 */         list.add(com.rwtema.extrautils2.backend.entries.XU2Entries.pipe.newStack());
/*     */       }
/* 197 */       for (Grocket grocket : holder.grockets) {
/* 198 */         if (grocket != null) {
/* 199 */           list.addAll(grocket.getDrops());
/*     */         }
/*     */       }
/*     */     }
/* 203 */     return list;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\BlockTransferHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */