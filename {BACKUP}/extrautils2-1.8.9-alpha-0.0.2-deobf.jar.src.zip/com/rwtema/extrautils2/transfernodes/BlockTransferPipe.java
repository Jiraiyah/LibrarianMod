/*     */ package com.rwtema.extrautils2.transfernodes;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.MultiBlockStateBuilder;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStatic;
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.utils.CapGetter;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyBool;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockTransferPipe extends XUBlockStatic implements IPipe
/*     */ {
/*  28 */   public static MultiBlockStateBuilder<BlockTransferPipe> stateBuilder = new MultiBlockStateBuilder(BlockTransferPipe.class, new Object[0]).addWorldProperties(XUBlockStateCreator.FACING_BOOLEANS.values());
/*     */   EnumMap<EnumFacing, HashSet<IBlockState>> canOutputPipeStates;
/*     */   IBlockState defaultSimple;
/*     */   IBlockState allSides;
/*     */   
/*     */   public BlockTransferPipe() {
/*  34 */     super(net.minecraft.block.material.Material.rock);
/*     */   }
/*     */   
/*     */   public boolean isToolEffective(String type, IBlockState state)
/*     */   {
/*  39 */     return true;
/*     */   }
/*     */   
/*     */   public boolean canHarvestBlock(IBlockAccess world, BlockPos pos, EntityPlayer player)
/*     */   {
/*  44 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean isUnblocked(@Nonnull IBlockState state, EnumFacing facing) {
/*  48 */     return !((Boolean)state.getValue((IProperty)XUBlockStateCreator.FACING_BOOLEANS.get(facing))).booleanValue();
/*     */   }
/*     */   
/*     */   public void setBlockState(XUBlockStateCreator creator)
/*     */   {
/*  53 */     super.setBlockState(creator);
/*     */     
/*  55 */     if (!stateBuilder.initialized) { return;
/*     */     }
/*  57 */     this.defaultSimple = (this.allSides = stateBuilder.defaultState);
/*     */     
/*  59 */     for (PropertyBool propertyBool : XUBlockStateCreator.FACING_BOOLEANS.values()) {
/*  60 */       this.allSides = this.allSides.withProperty(propertyBool, Boolean.valueOf(true));
/*  61 */       this.defaultSimple = this.defaultSimple.withProperty(propertyBool, Boolean.valueOf(false));
/*     */     }
/*     */     
/*  64 */     this.canOutputPipeStates = new EnumMap(EnumFacing.class);
/*     */     
/*  66 */     for (EnumFacing a : EnumFacing.values()) {
/*  67 */       HashSet<IBlockState> set = new HashSet();
/*  68 */       for (IBlockState allState : stateBuilder.genericPipeStates) {
/*  69 */         if (isUnblocked(allState, a.getOpposite())) {
/*  70 */           set.add(allState);
/*     */         }
/*     */       }
/*  73 */       this.canOutputPipeStates.put(a, set);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*  79 */     if (!com.rwtema.extrautils2.utils.helpers.ItemStackHelper.holdingWrench(playerIn)) return false;
/*  80 */     EnumFacing facing = EnumFacing.getFacingFromVector(hitX - 0.5F, hitY - 0.5F, hitZ - 0.5F);
/*  81 */     BlockPos offset = pos.offset(facing);
/*  82 */     if ((!TransferHelper.isInputtingPipe(worldIn, offset, facing.getOpposite())) && (!TransferHelper.hasValidCapability(worldIn, offset, facing.getOpposite())))
/*  83 */       return false;
/*  84 */     IBlockState newState = state.cycleProperty((IProperty)XUBlockStateCreator.FACING_BOOLEANS.get(facing));
/*  85 */     worldIn.setBlockState(pos, newState);
/*  86 */     return true;
/*     */   }
/*     */   
/*     */   public BoxModel getModel(IBlockState state)
/*     */   {
/*  91 */     BoxModel model = new BoxModel();
/*  92 */     model.addBoxI(6, 6, 6, 10, 10, 10, "transfernodes/pipes");
/*     */     
/*  94 */     for (EnumFacing facing : EnumFacing.values()) {
/*  95 */       if (isUnblocked(state, facing)) {
/*  96 */         model.addBoxI(6, 0, 6, 10, 6, 10, "transfernodes/pipes").rotateToSide(facing).tint = facing.ordinal();
/*     */       }
/*     */     }
/*  99 */     return model;
/*     */   }
/*     */   
/*     */   public void registerTextures()
/*     */   {
/* 104 */     super.registerTextures();
/* 105 */     com.rwtema.extrautils2.backend.model.Textures.register(new String[] { "transfernodes/pipes_oneway", "transfernodes/pipes_nozzle" });
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public BoxModel getWorldModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/* 111 */     if (state == null) state = world.getBlockState(pos);
/* 112 */     IPipe pipe = TransferHelper.getPipe(world, pos);
/* 113 */     if (pipe == null) { return super.getWorldModel(world, pos, state);
/*     */     }
/* 115 */     BoxModel model = new BoxModel();
/* 116 */     Box center_box = model.addBoxI(6, 6, 6, 10, 10, 10, "transfernodes/pipes");
/* 117 */     for (EnumFacing facing : EnumFacing.values()) {
/* 118 */       if (shouldConnectPipe(world, pos, facing, pipe)) {
/* 119 */         boolean value = pipe.canOutput(world, pos, facing);
/*     */         Box box;
/* 121 */         Box box; if (value) {
/* 122 */           box = model.addBoxI(6, 0, 6, 10, 6, 10, "transfernodes/pipes");
/*     */         } else {
/* 124 */           box = model.addBoxI(6, 0, 6, 10, 6, 10, "transfernodes/pipes_oneway");
/*     */         }
/* 126 */         box.setTint(facing.ordinal());
/* 127 */         box.rotateToSide(facing).setInvisible(new EnumFacing[] { facing, facing.getOpposite() });
/* 128 */         center_box.setInvisible(new EnumFacing[] { facing });
/* 129 */       } else if (shouldConnectTile(world, pos, facing, pipe)) {
/* 130 */         model.addBoxI(6, 0, 6, 10, 6, 10, "transfernodes/pipes").rotateToSide(facing).setTint(facing.ordinal()).setInvisible(new EnumFacing[] { facing, facing.getOpposite() });
/* 131 */         model.addBoxI(5, 0, 5, 11, 3, 11, "transfernodes/pipes_nozzle").rotateToSide(facing).setTint(facing.ordinal());
/*     */       }
/*     */     }
/* 134 */     return model;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public BoxModel getInventoryModel(@Nullable ItemStack item)
/*     */   {
/* 140 */     return (BoxModel)this.cachedInvModels.get(this.xuBlockState.getStateFromItemStack(item));
/*     */   }
/*     */   
/*     */   public boolean shouldConnectPipe(IBlockAccess world, BlockPos pos, EnumFacing facing, IPipe pipe)
/*     */   {
/* 145 */     BlockPos offset = pos.offset(facing);
/*     */     
/* 147 */     IPipe otherPipe = TransferHelper.getPipe(world, offset);
/* 148 */     return (otherPipe != null) && (((pipe.canOutput(world, pos, facing)) && (otherPipe.canInput(world, offset, facing.getOpposite()))) || ((pipe.canInput(world, pos, facing)) && (otherPipe.canOutput(world, offset, facing.getOpposite()))));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean shouldConnectTile(IBlockAccess world, BlockPos pos, EnumFacing facing, IPipe pipe)
/*     */   {
/* 154 */     BlockPos offset = pos.offset(facing);
/*     */     
/*     */ 
/* 157 */     if ((pipe.canOutputTile(world, pos, facing)) && (TransferHelper.getPipe(world, offset) == null))
/*     */     {
/* 159 */       for (CapGetter<?> cap : CapGetter.caps) {
/* 160 */         if (pipe.hasCapability(world, pos, facing, cap))
/* 161 */           return true;
/*     */       }
/*     */     }
/* 164 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canInput(IBlockAccess world, BlockPos pos, EnumFacing dir)
/*     */   {
/* 170 */     return true;
/*     */   }
/*     */   
/*     */   public boolean canOutput(IBlockAccess world, BlockPos pos, EnumFacing dir)
/*     */   {
/* 175 */     return isUnblocked(world.getBlockState(pos), dir);
/*     */   }
/*     */   
/*     */   public boolean canOutputTile(IBlockAccess world, BlockPos pos, EnumFacing dir)
/*     */   {
/* 180 */     return isUnblocked(world.getBlockState(pos), dir);
/*     */   }
/*     */   
/*     */   public <T> boolean hasCapability(IBlockAccess world, BlockPos pos, EnumFacing side, CapGetter<T> capability)
/*     */   {
/* 185 */     if (!isUnblocked(world.getBlockState(pos), side)) return false;
/* 186 */     TileEntity tileEntity = world.getTileEntity(pos.offset(side));
/* 187 */     return (tileEntity != null) && (capability.hasInterface(tileEntity, side.getOpposite()));
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> T getCapability(IBlockAccess world, BlockPos pos, EnumFacing side, CapGetter<T> capability)
/*     */   {
/* 193 */     if (!isUnblocked(world.getBlockState(pos), side)) return null;
/* 194 */     TileEntity tileEntity = world.getTileEntity(pos.offset(side));
/* 195 */     if (tileEntity != null) {
/* 196 */       return (T)capability.getInterface(tileEntity, side.getOpposite());
/*     */     }
/* 198 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\BlockTransferPipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */