/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUItemBlock;
/*    */ import net.minecraft.block.Block.SoundType;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemBlockPipe extends XUItemBlock
/*    */ {
/*    */   public ItemBlockPipe(net.minecraft.block.Block block)
/*    */   {
/* 15 */     super(block);
/*    */   }
/*    */   
/*    */   public boolean onItemUse(ItemStack stack, EntityPlayer playerIn, World worldIn, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ)
/*    */   {
/* 20 */     if ((stack == null) || (stack.stackSize == 0)) {
/* 21 */       return false;
/*    */     }
/* 23 */     if (!playerIn.canPlayerEdit(pos, side, stack)) { return false;
/*    */     }
/* 25 */     if (worldIn.isRemote) { return true;
/*    */     }
/* 27 */     if ((BlockTransferHolder.placePipe(worldIn, pos)) || (BlockTransferHolder.placePipe(worldIn, pos.offset(side)))) {
/* 28 */       worldIn.func_72908_a(pos.getX() + 0.5F, pos.getY() + 0.5F, pos.getZ() + 0.5F, this.block.blockSoundType.func_150496_b(), (this.block.blockSoundType.func_150497_c() + 1.0F) / 2.0F, this.block.blockSoundType.func_150494_d() * 0.8F);
/* 29 */       stack.stackSize -= 1;
/* 30 */       return true; }
/* 31 */     return false;
/*    */   }
/*    */   
/*    */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ, net.minecraft.block.state.IBlockState newState)
/*    */   {
/* 36 */     return BlockTransferHolder.placePipe(world, pos);
/*    */   }
/*    */   
/*    */   public boolean canPlaceBlockOnSide(World worldIn, BlockPos pos, EnumFacing side, EntityPlayer player, ItemStack stack)
/*    */   {
/* 41 */     return (super.canPlaceBlockOnSide(worldIn, pos, side, player, stack)) || (checkPos(worldIn, pos)) || (checkPos(worldIn, pos.offset(side)));
/*    */   }
/*    */   
/*    */   public boolean checkPos(World world, BlockPos pos)
/*    */   {
/* 46 */     net.minecraft.tileentity.TileEntity tileEntity = world.getTileEntity(pos);
/* 47 */     return ((tileEntity instanceof TileTransferHolder)) && (((TileTransferHolder)tileEntity).centerPipe == null);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\ItemBlockPipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */