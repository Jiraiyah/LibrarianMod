package com.rwtema.extrautils2.transfernodes;

import com.rwtema.extrautils2.utils.CapGetter;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;

public abstract interface IPipe
{
  public abstract boolean canInput(IBlockAccess paramIBlockAccess, BlockPos paramBlockPos, EnumFacing paramEnumFacing);
  
  public abstract boolean canOutput(IBlockAccess paramIBlockAccess, BlockPos paramBlockPos, EnumFacing paramEnumFacing);
  
  public abstract boolean canOutputTile(IBlockAccess paramIBlockAccess, BlockPos paramBlockPos, EnumFacing paramEnumFacing);
  
  public abstract <T> boolean hasCapability(IBlockAccess paramIBlockAccess, BlockPos paramBlockPos, EnumFacing paramEnumFacing, CapGetter<T> paramCapGetter);
  
  public abstract <T> T getCapability(IBlockAccess paramIBlockAccess, BlockPos paramBlockPos, EnumFacing paramEnumFacing, CapGetter<T> paramCapGetter);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\IPipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */