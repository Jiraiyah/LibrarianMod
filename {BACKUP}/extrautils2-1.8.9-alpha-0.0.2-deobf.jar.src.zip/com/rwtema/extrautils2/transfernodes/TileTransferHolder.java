/*     */ package com.rwtema.extrautils2.transfernodes;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.MultiBlockStateBuilder;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainer;
/*     */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.tile.XUTile;
/*     */ import com.rwtema.extrautils2.utils.CapGetter;
/*     */ import com.rwtema.extrautils2.utils.helpers.ItemStackHelper;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.ITickable;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class TileTransferHolder extends XUTile implements ITickable, IPipe, IDynamicHandler
/*     */ {
/*     */   public BoxModel worldModel;
/*  30 */   IBlockState centerPipe = null;
/*  31 */   Grocket[] grockets = new Grocket[6];
/*     */   
/*     */   @Nullable
/*     */   public static IBlockState getCenterPipeState(byte b) {
/*  35 */     return b == -1 ? null : BlockTransferPipe.stateBuilder.meta2states[b];
/*     */   }
/*     */   
/*     */   public void addGrocket(EntityPlayer player, Grocket grocket, EnumFacing facing) {
/*  39 */     loadGrocket(grocket, facing.ordinal());
/*  40 */     if (player != null) {
/*  41 */       grocket.onPlaced(player);
/*     */     }
/*  43 */     grocket.validate();
/*  44 */     this.worldObj.func_175689_h(this.pos);
/*     */   }
/*     */   
/*     */   public void loadGrocket(Grocket grocket, int ordinal) {
/*  48 */     this.grockets[ordinal] = grocket;
/*  49 */     grocket.holder = this;
/*  50 */     grocket.side = EnumFacing.values()[ordinal];
/*     */   }
/*     */   
/*     */   public void update()
/*     */   {
/*  55 */     if ((this.worldObj == null) || (this.worldObj.isRemote)) {
/*  56 */       return;
/*     */     }
/*  58 */     boolean shouldStay = this.centerPipe != null;
/*  59 */     for (Grocket grocket : this.grockets) {
/*  60 */       if (grocket != null) {
/*  61 */         grocket.update();
/*  62 */         shouldStay = true;
/*     */       }
/*     */     }
/*     */     
/*  66 */     if (!shouldStay) {
/*  67 */       this.worldObj.setBlockToAir(this.pos);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*  73 */     MovingObjectPosition rayTrace = com.rwtema.extrautils2.utils.helpers.PlayerHelper.rayTrace(playerIn);
/*  74 */     if (rayTrace == null) { return false;
/*     */     }
/*  76 */     int subHit = rayTrace.subHit;
/*  77 */     if (subHit < 6)
/*     */     {
/*  79 */       if (!ItemStackHelper.holdingWrench(playerIn)) return false;
/*  80 */       if (subHit < 0) subHit = side.ordinal();
/*  81 */       EnumFacing facing = EnumFacing.values()[subHit];
/*  82 */       BlockPos offset = pos.offset(facing);
/*  83 */       if ((!TransferHelper.isInputtingPipe(worldIn, offset, facing.getOpposite())) && (!TransferHelper.hasValidCapability(worldIn, offset, facing.getOpposite())))
/*  84 */         return false;
/*  85 */       this.centerPipe = this.centerPipe.cycleProperty((IProperty)com.rwtema.extrautils2.backend.XUBlockStateCreator.FACING_BOOLEANS.get(facing));
/*  86 */       worldIn.func_175689_h(pos);
/*  87 */       return true;
/*     */     }
/*     */     
/*  90 */     subHit %= 6;
/*     */     
/*  92 */     Grocket grocket = this.grockets[subHit];
/*  93 */     if (grocket == null) { return false;
/*     */     }
/*  95 */     if ((ItemStackHelper.holdingWrench(playerIn)) && (playerIn.isSneaking()))
/*     */     {
/*  97 */       grocket.invalidate();
/*  98 */       for (ItemStack itemStack : grocket.getDrops()) {
/*  99 */         Block.spawnAsEntity(worldIn, pos, itemStack);
/*     */       }
/* 101 */       this.grockets[subHit] = null;
/*     */       
/* 103 */       for (Grocket g : this.grockets) {
/* 104 */         if (g != null) {
/* 105 */           worldIn.func_175689_h(pos);
/* 106 */           return true;
/*     */         }
/*     */       }
/*     */       
/* 110 */       IBlockState centerPipe = this.centerPipe;
/* 111 */       if (centerPipe == null) centerPipe = net.minecraft.init.Blocks.air.getDefaultState();
/* 112 */       worldIn.setBlockState(pos, centerPipe);
/* 113 */       return true;
/*     */     }
/*     */     
/* 116 */     return grocket.onActivated(playerIn, side, hitX, hitY, hitZ);
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound nbt)
/*     */   {
/* 121 */     super.writeToNBT(nbt);
/* 122 */     nbt.setByte("CenterPipeState", getCenterPipeIndex());
/*     */     
/* 124 */     for (int i = 0; i < 6; i++) {
/* 125 */       Grocket grocket = this.grockets[i];
/* 126 */       NBTTagCompound subTag = new NBTTagCompound();
/* 127 */       if (grocket != null) {
/* 128 */         grocket.writeToNBT(subTag);
/* 129 */         nbt.setInteger("Type", grocket.getType().ordinal());
/* 130 */         nbt.setTag("Grocket_" + i, subTag);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public byte getCenterPipeIndex()
/*     */   {
/* 137 */     return this.centerPipe == null ? -1 : (byte)BlockTransferPipe.stateBuilder.states2meta.get(this.centerPipe);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound nbt)
/*     */   {
/* 142 */     super.readFromNBT(nbt);
/* 143 */     byte b = nbt.getByte("CenterPipeState");
/* 144 */     this.centerPipe = getCenterPipeState(b);
/*     */     
/* 146 */     for (int i = 0; i < 6; i++) {
/* 147 */       String key = "Grocket_" + i;
/* 148 */       if (nbt.hasKey(key, 10)) {
/* 149 */         NBTTagCompound tag = nbt.getCompoundTag(key);
/* 150 */         int type = tag.getInteger("Type");
/* 151 */         Grocket grocket = GrocketType.values()[type].create();
/* 152 */         loadGrocket(grocket, i);
/* 153 */         grocket.readFromNBT(tag);
/*     */       }
/*     */       else {
/* 156 */         this.grockets[i] = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addToDescriptionPacket(PacketBuffer packet)
/*     */   {
/* 163 */     packet.writeByte(getCenterPipeIndex());
/*     */     
/* 165 */     int mask = 0;
/* 166 */     for (int i = 0; i < 6; i++) {
/* 167 */       if (this.grockets[i] != null) {
/* 168 */         mask |= 1 << i;
/*     */       }
/*     */     }
/* 171 */     packet.writeByte(mask);
/*     */     
/* 173 */     for (Grocket grocket : this.grockets) {
/* 174 */       if (grocket != null) {
/* 175 */         packet.writeInt(grocket.getType().ordinal());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void handleDescriptionPacket(PacketBuffer packet)
/*     */   {
/* 182 */     if (!this.worldObj.isRemote)
/* 183 */       return;
/* 184 */     this.centerPipe = getCenterPipeState(packet.readByte());
/* 185 */     int mask = packet.readUnsignedByte();
/* 186 */     for (int i = 0; i < 6; i++) {
/* 187 */       if ((mask & 1 << i) != 0) {
/* 188 */         loadGrocket(GrocketType.values()[packet.readInt()].create(), i);
/*     */       } else {
/* 190 */         this.grockets[i] = null;
/*     */       }
/*     */     }
/* 193 */     this.worldObj.func_175689_h(this.pos);
/*     */   }
/*     */   
/*     */   public boolean canInput(IBlockAccess world, BlockPos pos, EnumFacing dir)
/*     */   {
/* 198 */     return this.centerPipe != null;
/*     */   }
/*     */   
/*     */   public boolean canOutput(IBlockAccess world, BlockPos pos, EnumFacing dir)
/*     */   {
/* 203 */     return (this.centerPipe != null) && (BlockTransferPipe.isUnblocked(this.centerPipe, dir)) && (TransferHelper.isInputtingPipe(world, pos.offset(dir), dir.getOpposite()));
/*     */   }
/*     */   
/*     */   public boolean canOutputTile(IBlockAccess world, BlockPos pos, EnumFacing side)
/*     */   {
/* 208 */     if ((this.centerPipe == null) || (!BlockTransferPipe.isUnblocked(this.centerPipe, side))) {
/* 209 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 213 */     TileEntity tileEntity = world.getTileEntity(pos.offset(side));
/*     */     
/*     */ 
/* 216 */     Grocket grocket = this.grockets[side.ordinal()];
/* 217 */     for (CapGetter<?> cap : CapGetter.caps) {
/* 218 */       if ((grocket != null) && (grocket.hasInterface(tileEntity, cap))) {
/* 219 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 223 */     if (tileEntity == null) return false;
/* 224 */     for (CapGetter<?> cap : CapGetter.caps) {
/* 225 */       if (cap.hasInterface(tileEntity, side.getOpposite())) return true;
/*     */     }
/* 227 */     return false;
/*     */   }
/*     */   
/*     */   public <T> boolean hasCapability(IBlockAccess world, BlockPos pos, EnumFacing side, CapGetter<T> capability)
/*     */   {
/* 232 */     if ((this.centerPipe == null) || (!BlockTransferPipe.isUnblocked(this.centerPipe, side))) { return false;
/*     */     }
/* 234 */     TileEntity tileEntity = world.getTileEntity(pos.offset(side));
/*     */     
/*     */ 
/* 237 */     Grocket grocket = this.grockets[side.ordinal()];
/* 238 */     if (grocket != null) {
/* 239 */       return grocket.hasInterface(tileEntity, capability);
/*     */     }
/*     */     
/* 242 */     return (tileEntity != null) && (capability.hasInterface(tileEntity, side.getOpposite()));
/*     */   }
/*     */   
/*     */   public <T> T getCapability(IBlockAccess world, BlockPos pos, EnumFacing side, CapGetter<T> capability)
/*     */   {
/* 247 */     if ((this.centerPipe == null) || (!BlockTransferPipe.isUnblocked(this.centerPipe, side))) return null;
/* 248 */     TileEntity tileEntity = world.getTileEntity(pos.offset(side));
/* 249 */     if (tileEntity == null) { return null;
/*     */     }
/* 251 */     Grocket grocket = this.grockets[side.ordinal()];
/* 252 */     if (grocket != null) {
/* 253 */       return (T)grocket.getInterface(tileEntity, capability);
/*     */     }
/*     */     
/* 256 */     return (T)capability.getInterface(tileEntity, side.getOpposite());
/*     */   }
/*     */   
/*     */   public void invalidate()
/*     */   {
/* 261 */     super.invalidate();
/* 262 */     for (Grocket grocket : this.grockets) {
/* 263 */       if (grocket != null) grocket.invalidate();
/*     */     }
/*     */   }
/*     */   
/*     */   public void onChunkUnload()
/*     */   {
/* 269 */     super.onChunkUnload();
/* 270 */     for (Grocket grocket : this.grockets) {
/* 271 */       if (grocket != null) grocket.invalidate();
/*     */     }
/*     */   }
/*     */   
/*     */   public void validate()
/*     */   {
/* 277 */     super.validate();
/*     */     
/* 279 */     for (Grocket grocket : this.grockets) {
/* 280 */       if (grocket != null) {
/* 281 */         grocket.validate();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void openGui(EntityPlayer player, Grocket grocket) {
/* 287 */     openGui(player, grocket.side);
/*     */   }
/*     */   
/*     */   public void openGui(EntityPlayer player, EnumFacing side) {
/* 291 */     openGUI(player, side.ordinal());
/*     */   }
/*     */   
/*     */   public DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/* 296 */     if ((ID < 0) || (ID >= 6))
/* 297 */       return null;
/* 298 */     Grocket grocket = this.grockets[ID];
/* 299 */     if ((grocket instanceof IDynamicHandler)) {
/* 300 */       return ((IDynamicHandler)grocket).getDynamicContainer(ID, player, world, x, y, z);
/*     */     }
/* 302 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\TileTransferHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */