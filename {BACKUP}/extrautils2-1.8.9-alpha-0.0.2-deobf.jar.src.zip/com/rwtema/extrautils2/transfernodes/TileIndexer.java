/*     */ package com.rwtema.extrautils2.transfernodes;
/*     */ 
/*     */ import com.google.common.base.Throwables;
/*     */ import com.google.common.collect.HashMultimap;
/*     */ import com.google.common.collect.Interner;
/*     */ import com.google.common.util.concurrent.ListenableFuture;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainerTile;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicGui;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetClickBase;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetRawData;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetScrollBar;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetSlotItemHandler;
/*     */ import com.rwtema.extrautils2.itemhandler.InventoryHelper;
/*     */ import com.rwtema.extrautils2.itemhandler.PublicWrapper.Extract;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.utils.CapGetter;
/*     */ import com.rwtema.extrautils2.utils.PositionPool;
/*     */ import com.rwtema.extrautils2.utils.blockaccess.ThreadSafeBlockAccess;
/*     */ import com.rwtema.extrautils2.utils.client.GLStateAttributes;
/*     */ import com.rwtema.extrautils2.utils.datastructures.ItemRef;
/*     */ import gnu.trove.iterator.TObjectIntIterator;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.TreeSet;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.WorldRenderer;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import net.minecraftforge.items.ItemStackHandler;
/*     */ 
/*     */ public class TileIndexer extends com.rwtema.extrautils2.tile.TilePower implements net.minecraft.util.ITickable, com.rwtema.extrautils2.gui.backend.IDynamicHandler, IPipeConnect
/*     */ {
/*     */   public static final int COUNTDOWN_SINGLE = 10;
/*     */   public HashMultimap<ItemRef, SidedPos> itemRefPosEntryHashMultimap;
/*     */   public List<SidedPos> positions;
/*     */   public TObjectIntHashMap<ItemRef> counts;
/*     */   public TObjectIntHashMap<ItemRef> countDown;
/*     */   public TObjectIntHashMap<ItemRef> orders;
/*     */   public ItemStackHandler stacks;
/*     */   public ItemStackHandler returnStacks;
/*     */   public IItemHandler publicHandler;
/*     */   public long positionsHash;
/*     */   public long itemsHash;
/*     */   public ListenableFuture<Runnable> submit;
/*     */   public boolean dirty;
/*     */   
/*     */   public TileIndexer()
/*     */   {
/*  67 */     this.itemRefPosEntryHashMultimap = HashMultimap.create();
/*  68 */     this.positions = new ArrayList();
/*  69 */     this.counts = new TObjectIntHashMap();
/*  70 */     this.countDown = new TObjectIntHashMap();
/*  71 */     this.orders = new TObjectIntHashMap();
/*  72 */     this.stacks = ((ItemStackHandler)registerNBT("stacks", new ItemStackHandler(9)));
/*  73 */     this.returnStacks = ((ItemStackHandler)registerNBT("return", new ItemStackHandler(9)
/*     */     {
/*     */       protected void onContentsChanged(int slot) {
/*  76 */         TileIndexer.this.markDirty();
/*  77 */         TileIndexer.this.dirty = true;
/*     */       }
/*     */       
/*  80 */     }));
/*  81 */     this.publicHandler = new PublicWrapper.Extract(this.returnStacks);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reload()
/*     */   {
/*  89 */     if (this.worldObj.isRemote) return;
/*  90 */     if ((!this.active) || (this.submit != null)) { return;
/*     */     }
/*  92 */     final PositionPool pool = new PositionPool();
/*  93 */     final HashSet<BlockPos> alreadyChecking = new HashSet();
/*  94 */     final LinkedList<BlockPos> toCheck = new LinkedList();
/*  95 */     BlockPos intern = pool.intern(this.pos);
/*     */     
/*  97 */     boolean adjacentPipe = false;
/*     */     
/*     */ 
/* 100 */     final ArrayList<SidedPos> sides = new ArrayList();
/*     */     
/* 102 */     alreadyChecking.add(intern);
/* 103 */     for (EnumFacing facing : EnumFacing.values()) {
/* 104 */       BlockPos offset = pool.offset(intern, facing);
/* 105 */       adjacentPipe = (adjacentPipe) || (TransferHelper.getPipe(this.worldObj, offset) != null);
/*     */       
/* 107 */       alreadyChecking.add(offset);
/* 108 */       toCheck.add(offset);
/*     */     }
/*     */     
/* 111 */     if (!adjacentPipe) {
/* 112 */       return;
/*     */     }
/*     */     
/* 115 */     final IBlockAccess world = new ThreadSafeBlockAccess((net.minecraft.world.WorldServer)this.worldObj);
/*     */     
/* 117 */     this.submit = net.minecraft.util.HttpUtil.DOWNLOADER_EXECUTOR.submit(new java.util.concurrent.Callable()
/*     */     {
/*     */ 
/*     */       public Runnable call()
/*     */         throws Exception
/*     */       {
/* 123 */         long hash = alreadyChecking.hashCode() * 31 + toCheck.hashCode();
/*     */         BlockPos pos;
/* 125 */         while ((pos = (BlockPos)toCheck.poll()) != null) {
/* 126 */           if ((!TileIndexer.this.active) || (TileIndexer.this.isInvalid())) return null;
/* 127 */           hash = hash * 31L + pos.hashCode() + 1L;
/* 128 */           IPipe pipe = TransferHelper.getPipe(world, pos);
/* 129 */           if (pipe != null)
/*     */           {
/* 131 */             hash = hash * 31L + pipe.hashCode();
/*     */             
/* 133 */             for (EnumFacing facing : EnumFacing.values()) {
/* 134 */               if (pipe.hasCapability(world, pos, facing, CapGetter.ItemHandler)) {
/* 135 */                 sides.add(new TileIndexer.SidedPos(pos, facing));
/* 136 */                 hash = (hash * 31L + pos.hashCode()) * 31L + facing.ordinal();
/*     */               }
/*     */               
/* 139 */               BlockPos offset = pool.offset(pos, facing);
/* 140 */               if (!alreadyChecking.contains(offset))
/*     */               {
/*     */ 
/* 143 */                 hash = hash * 31L + facing.ordinal();
/*     */                 
/* 145 */                 IPipe otherPipe = TransferHelper.getPipe(world, offset);
/*     */                 
/* 147 */                 if ((otherPipe != null) && (((pipe.canOutput(world, pos, facing)) && (otherPipe.canInput(world, offset, facing.getOpposite()))) || ((pipe.canInput(world, pos, facing)) && (otherPipe.canOutput(world, offset, facing.getOpposite())))))
/*     */                 {
/*     */ 
/* 150 */                   hash = hash * 31L + offset.hashCode();
/* 151 */                   alreadyChecking.add(offset);
/* 152 */                   toCheck.add(offset);
/*     */                 }
/*     */               }
/*     */             }
/*     */           } }
/* 157 */         final long finalHash = hash;
/*     */         
/* 159 */         new Runnable()
/*     */         {
/*     */           public void run() {
/* 162 */             TileIndexer.this.process(TileIndexer.2.this.val$sides, finalHash);
/*     */           }
/*     */           
/*     */         };
/*     */       }
/* 167 */     });
/* 168 */     com.google.common.util.concurrent.Futures.addCallback(this.submit, new com.google.common.util.concurrent.FutureCallback()
/*     */     {
/*     */       public void onSuccess(Runnable result) {
/* 171 */         if (result != null)
/* 172 */           MinecraftServer.func_71276_C().addScheduledTask(result);
/* 173 */         TileIndexer.this.submit = null;
/*     */       }
/*     */       
/*     */       public void onFailure(@Nonnull final Throwable t)
/*     */       {
/* 178 */         MinecraftServer.func_71276_C().addScheduledTask(new Runnable()
/*     */         {
/*     */           public void run() {
/* 181 */             throw Throwables.propagate(t);
/*     */           }
/* 183 */         });
/* 184 */         TileIndexer.this.submit = null;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void process(List<SidedPos> sidedPositions, long finalHash) {
/* 190 */     if (this.positionsHash == finalHash) return;
/* 191 */     this.positionsHash = finalHash;
/*     */     
/* 193 */     process(sidedPositions);
/*     */   }
/*     */   
/*     */   private void process(List<SidedPos> sidedPositions) {
/* 197 */     long h = 0L;
/*     */     
/* 199 */     if ((!isLoaded()) || (this.worldObj.isRemote)) { return;
/*     */     }
/* 201 */     HashMultimap<ItemRef, SidedPos> itemRefPosEntryHashMultimap = HashMultimap.create();
/* 202 */     TObjectIntHashMap<ItemRef> counts = new TObjectIntHashMap();
/*     */     
/* 204 */     Interner<ItemRef> interner = com.google.common.collect.Interners.newStrongInterner();
/* 205 */     for (ItemRef itemRef : this.counts.keySet()) {
/* 206 */       interner.intern(itemRef);
/*     */     }
/*     */     
/* 209 */     HashSet<IItemHandler> processedHandlers = new HashSet();
/*     */     
/* 211 */     for (SidedPos sidedPos : sidedPositions) {
/* 212 */       IPipe pipe = TransferHelper.getPipe(this.worldObj, sidedPos.pos);
/* 213 */       if (pipe != null)
/*     */       {
/* 215 */         IItemHandler handler = (IItemHandler)pipe.getCapability(this.worldObj, sidedPos.pos, sidedPos.side, CapGetter.ItemHandler);
/* 216 */         if ((handler != null) && (!processedHandlers.contains(handler)))
/*     */         {
/* 218 */           processedHandlers.add(handler);
/*     */           
/* 220 */           h = h * 31L + sidedPos.hashCode();
/* 221 */           h = h * 31L + handler.getSlots();
/*     */           
/* 223 */           for (int i = 0; i < handler.getSlots(); i++) {
/* 224 */             ItemStack stack = handler.extractItem(i, 64, true);
/* 225 */             if (stack != null)
/*     */             {
/* 227 */               ItemRef itemRef = (ItemRef)interner.intern(ItemRef.wrap(stack));
/* 228 */               if (itemRef != ItemRef.NULL)
/*     */               {
/*     */ 
/* 231 */                 itemRefPosEntryHashMultimap.put(itemRef, sidedPos);
/* 232 */                 counts.adjustOrPutValue(itemRef, stack.stackSize, stack.stackSize);
/*     */                 
/* 234 */                 h = h * 31L + i;
/* 235 */                 h = h * 31L + itemRef.hashCode();
/* 236 */                 h = h * 31L + stack.stackSize;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       } }
/* 242 */     this.positions = sidedPositions;
/* 243 */     this.itemRefPosEntryHashMultimap = itemRefPosEntryHashMultimap;
/* 244 */     this.counts = counts;
/* 245 */     this.itemsHash = h;
/*     */   }
/*     */   
/*     */   public void onPowerChanged()
/*     */   {
/* 250 */     if ((!this.active) && 
/* 251 */       (this.submit != null)) {
/* 252 */       this.submit.cancel(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public IItemHandler getItemHandler(EnumFacing facing)
/*     */   {
/* 259 */     return this.publicHandler;
/*     */   }
/*     */   
/*     */   public float getPower()
/*     */   {
/* 264 */     return 8.0F;
/*     */   }
/*     */   
/*     */   public void update()
/*     */   {
/* 269 */     if ((this.itemRefPosEntryHashMultimap == null) || (this.worldObj.getTotalWorldTime() % 200L == 0L)) {
/* 270 */       reload();
/*     */     }
/*     */     
/* 273 */     if (!this.countDown.isEmpty()) {
/* 274 */       TObjectIntIterator<ItemRef> iterator = this.countDown.iterator();
/* 275 */       while (iterator.hasNext()) {
/* 276 */         iterator.advance();
/* 277 */         int value = iterator.value();
/* 278 */         value--;
/* 279 */         if (value == 0) {
/* 280 */           ItemRef key = (ItemRef)iterator.key();
/* 281 */           int i = this.orders.get(key);
/* 282 */           if (i <= 0) {
/* 283 */             iterator.remove();
/* 284 */             this.orders.remove(key);
/* 285 */           } else if (i == 1) {
/* 286 */             iterator.remove();
/* 287 */             this.orders.remove(key);
/* 288 */             retrieve(key, 1);
/* 289 */             this.dirty = true;
/* 290 */           } else if (i > 1) {
/* 291 */             if (retrieve(key, 1)) {
/* 292 */               iterator.setValue(10);
/* 293 */               this.orders.put(key, i - 1);
/*     */             } else {
/* 295 */               iterator.remove();
/* 296 */               this.orders.remove(key);
/*     */             }
/* 298 */             this.dirty = true;
/*     */           }
/*     */         }
/*     */         else {
/* 302 */           iterator.setValue(value);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 309 */     if (this.dirty) {
/* 310 */       process();
/* 311 */       reload();
/*     */     }
/*     */   }
/*     */   
/*     */   public void process() {
/* 316 */     process(this.positions);
/*     */   }
/*     */   
/*     */   private boolean retrieve(ItemRef key, int order) {
/* 320 */     HashMultimap<ItemRef, SidedPos> itemRefPosEntryHashMultimap = this.itemRefPosEntryHashMultimap;
/* 321 */     java.util.Set<SidedPos> sidedPositions = itemRefPosEntryHashMultimap.get(key);
/*     */     
/*     */ 
/* 324 */     order = InventoryHelper.getMaxInsert(this.stacks, key.createItemStack(order));
/*     */     
/*     */ 
/* 327 */     if (order <= 0) { return false;
/*     */     }
/* 329 */     boolean inserted = false;
/*     */     
/* 331 */     HashSet<IItemHandler> processedHandlers = new HashSet();
/*     */     
/* 333 */     for (SidedPos sidedPos : sidedPositions) {
/*     */       IItemHandler handler;
/* 335 */       if (sidedPos.pos.equals(this.pos)) {
/* 336 */         net.minecraft.tileentity.TileEntity tileEntity = this.worldObj.getTileEntity(this.pos.offset(sidedPos.side));
/* 337 */         if (tileEntity == null)
/*     */           continue;
/* 339 */         IItemHandler handler = (IItemHandler)CapGetter.ItemHandler.getInterface(tileEntity, sidedPos.side.getOpposite());
/*     */       } else {
/* 341 */         IPipe pipe = TransferHelper.getPipe(this.worldObj, sidedPos.pos);
/* 342 */         if (pipe == null)
/*     */           continue;
/* 344 */         handler = (IItemHandler)pipe.getCapability(this.worldObj, sidedPos.pos, sidedPos.side, CapGetter.ItemHandler);
/*     */       }
/*     */       
/* 347 */       if ((handler != null) && (processedHandlers.add(handler)))
/*     */       {
/* 349 */         for (int i = 0; i < handler.getSlots(); i++) {
/* 350 */           ItemStack stack = handler.extractItem(i, order, true);
/* 351 */           if ((stack != null) && 
/* 352 */             (key.equalsItemStack(stack))) {
/* 353 */             int toOrder = InventoryHelper.getMaxInsert(this.stacks, stack);
/* 354 */             if (toOrder == 0) return inserted;
/* 355 */             inserted = true;
/* 356 */             ItemStack extracted = handler.extractItem(i, toOrder, false);
/* 357 */             InventoryHelper.insert(this.stacks, extracted, false);
/* 358 */             order -= toOrder;
/*     */             
/* 360 */             if (order <= 0) return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 365 */     return inserted;
/*     */   }
/*     */   
/*     */   public void order(ItemRef ref, boolean b)
/*     */   {
/* 370 */     if (this.orders.containsKey(ref))
/*     */       return;
/*     */     int order;
/*     */     int order;
/* 374 */     if (b) {
/* 375 */       order = ref.getMaxStackSize();
/*     */     } else {
/* 377 */       order = 1;
/*     */     }
/* 379 */     this.orders.put(ref, order);
/* 380 */     this.countDown.put(ref, 10);
/*     */   }
/*     */   
/*     */   public com.rwtema.extrautils2.gui.backend.DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/* 385 */     this.positionsHash = 0L;
/* 386 */     process();
/* 387 */     reload();
/* 388 */     return new ContainerIndexer(this, player);
/*     */   }
/*     */   
/*     */   public boolean forceConnect(EnumFacing side)
/*     */   {
/* 393 */     return true;
/*     */   }
/*     */   
/*     */   public static class SidedPos
/*     */   {
/*     */     @Nonnull
/*     */     public final EnumFacing side;
/*     */     @Nonnull
/*     */     public final BlockPos pos;
/*     */     
/*     */     public SidedPos(@Nonnull BlockPos pos, @Nonnull EnumFacing side) {
/* 404 */       this.pos = pos;
/* 405 */       this.side = side;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 410 */       if (this == o) return true;
/* 411 */       if ((o == null) || (getClass() != o.getClass())) { return false;
/*     */       }
/* 413 */       SidedPos sidedPos = (SidedPos)o;
/*     */       
/* 415 */       return (this.side == sidedPos.side) && (this.pos.equals(sidedPos.pos));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 420 */       return 31 * this.side.hashCode() + this.pos.hashCode();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ContainerIndexer extends DynamicContainerTile {
/*     */     static final int HORIZONTAL_SLOTS = 9;
/*     */     static final int VERTICAL_SLOTS = 4;
/*     */     private final EntityPlayer player;
/* 428 */     public ArrayList<ItemRef> list = new ArrayList();
/*     */     WidgetScrollBar scrollBar;
/*     */     private TileIndexer tileIndexer;
/*     */     
/*     */     public ContainerIndexer(final TileIndexer tileIndexer, EntityPlayer player) {
/* 433 */       super();
/* 434 */       this.player = player;
/*     */       
/* 436 */       this.scrollBar = new WidgetScrollBar(170, 4, 72, 0, 0);
/* 437 */       addWidget(this.scrollBar);
/*     */       
/* 439 */       addWidget(new WidgetRawData()
/*     */       {
/*     */         public void addToDescription(PacketBuffer packet) {
/* 442 */           packet.writeBoolean(tileIndexer.active);
/*     */         }
/*     */         
/*     */         public void handleDescriptionPacket(PacketBuffer packet)
/*     */         {
/* 447 */           tileIndexer.active = packet.readBoolean();
/*     */         }
/*     */         
/* 450 */       });
/* 451 */       addWidget(new WidgetRawData()
/*     */       {
/*     */         public void addToDescription(final PacketBuffer packet) {
/* 454 */           TObjectIntHashMap<ItemRef> countDown = tileIndexer.countDown;
/* 455 */           packet.writeInt(countDown.size());
/* 456 */           countDown.forEachEntry(new gnu.trove.procedure.TObjectIntProcedure()
/*     */           {
/*     */             public boolean execute(ItemRef a, int b) {
/* 459 */               a.write(packet);
/* 460 */               packet.writeInt(b);
/* 461 */               return true;
/*     */             }
/*     */           });
/*     */         }
/*     */         
/*     */         public void handleDescriptionPacket(PacketBuffer packet)
/*     */         {
/* 468 */           int n = packet.readInt();
/* 469 */           if (n == 0) {
/* 470 */             if (!tileIndexer.countDown.isEmpty())
/* 471 */               tileIndexer.countDown.clear();
/* 472 */             return;
/*     */           }
/*     */           
/* 475 */           TObjectIntHashMap<ItemRef> countDown = new TObjectIntHashMap(n);
/* 476 */           for (int i = 0; i < n; i++) {
/* 477 */             ItemRef ref = ItemRef.read(packet);
/* 478 */             countDown.put(ref, packet.readInt());
/*     */           }
/* 480 */           tileIndexer.countDown = countDown;
/*     */         }
/*     */         
/* 483 */       });
/* 484 */       addWidget(new WidgetRawData() {
/* 485 */         long lastSentHash = 0L;
/*     */         
/*     */         public void addToDescription(PacketBuffer packet)
/*     */         {
/* 489 */           if (tileIndexer.itemsHash == this.lastSentHash) {
/* 490 */             packet.writeBoolean(true);
/* 491 */             return;
/*     */           }
/* 493 */           tileIndexer.itemsHash = this.lastSentHash;
/* 494 */           packet.writeBoolean(false);
/*     */           
/* 496 */           TObjectIntHashMap<ItemRef> counts = tileIndexer.counts;
/* 497 */           packet.writeInt(counts.size());
/* 498 */           TObjectIntIterator<ItemRef> iterator = counts.iterator();
/* 499 */           while (iterator.hasNext()) {
/* 500 */             iterator.advance();
/* 501 */             ((ItemRef)iterator.key()).write(packet);
/* 502 */             packet.writeInt(iterator.value());
/*     */           }
/*     */         }
/*     */         
/*     */         public void handleDescriptionPacket(PacketBuffer packet)
/*     */         {
/* 508 */           if (packet.readBoolean()) return;
/* 509 */           TObjectIntHashMap<ItemRef> items = new TObjectIntHashMap();
/* 510 */           TreeSet<ItemRef> refTreeSet = new TreeSet(com.rwtema.extrautils2.utils.datastructures.ItemRefComparator.names);
/* 511 */           int n = packet.readInt();
/* 512 */           for (int i = 0; i < n; i++) {
/* 513 */             ItemRef itemRef = ItemRef.read(packet);
/* 514 */             refTreeSet.add(itemRef);
/* 515 */             int count = packet.readInt();
/* 516 */             items.put(itemRef, count);
/*     */           }
/*     */           
/* 519 */           tileIndexer.counts = items;
/* 520 */           TileIndexer.ContainerIndexer.this.list = com.google.common.collect.Lists.newArrayList(refTreeSet);
/* 521 */           int size = TileIndexer.ContainerIndexer.this.list.size();
/* 522 */           TileIndexer.ContainerIndexer.this.scrollBar.setValues(0, Math.max(0, size / 9 - 4 + 1));
/*     */         }
/*     */       });
/*     */       
/* 526 */       for (int yi = 0; yi < 4; yi++) {
/* 527 */         for (int xi = 0; xi < 9; xi++) {
/* 528 */           int i = yi * 9 + xi;
/* 529 */           addWidget(new WidgetItemRefButton(i, 4 + xi * 18, 4 + yi * 18));
/*     */         }
/*     */       }
/*     */       
/* 533 */       crop();
/*     */       
/* 535 */       int left = (this.width - 162) / 2;
/*     */       
/* 537 */       for (int xi = 0; xi < 9; xi++) {
/* 538 */         addWidget(new WidgetSlotItemHandler(tileIndexer.stacks, xi, left + xi * 18, this.height)
/*     */         {
/*     */           public boolean isItemValid(ItemStack stack) {
/* 541 */             return false;
/*     */           }
/*     */         });
/*     */       }
/*     */       
/* 546 */       for (int xi = 0; xi < 9; xi++) {
/* 547 */         addWidget(new WidgetSlotItemHandler(tileIndexer.returnStacks, xi, left + xi * 18, this.height + 27)
/*     */         {
/*     */           public boolean canTakeStack(EntityPlayer playerIn) {
/* 550 */             return false;
/*     */           }
/*     */         });
/*     */       }
/*     */       
/* 555 */       cropAndAddPlayerSlots(player.inventory);
/* 556 */       validate();
/* 557 */       this.tileIndexer = tileIndexer;
/*     */     }
/*     */     
/*     */     public class WidgetItemRefButton extends WidgetClickBase implements com.rwtema.extrautils2.gui.backend.IWidgetClientNetwork
/*     */     {
/*     */       private final int i;
/*     */       
/*     */       public WidgetItemRefButton(int i, int x, int y) {
/* 565 */         super(y, 18, 18);
/* 566 */         this.i = i;
/*     */       }
/*     */       
/*     */       public ItemRef getRef() {
/* 570 */         if (!TileIndexer.this.active) return ItemRef.NULL;
/* 571 */         int j = this.i + TileIndexer.ContainerIndexer.this.scrollBar.scrollValue * 9;
/* 572 */         if (j < 0) return ItemRef.NULL;
/* 573 */         ArrayList<ItemRef> list = TileIndexer.ContainerIndexer.this.list;
/* 574 */         if (j < list.size()) {
/* 575 */           return (ItemRef)list.get(j);
/*     */         }
/* 577 */         return ItemRef.NULL;
/*     */       }
/*     */       
/*     */       public void receiveClientPacket(PacketBuffer buffer)
/*     */       {
/* 582 */         ItemRef read = ItemRef.read(buffer);
/* 583 */         if (read == ItemRef.NULL) return;
/* 584 */         boolean b = buffer.readBoolean();
/* 585 */         TileIndexer.this.order(read, b);
/*     */       }
/*     */       
/*     */       @SideOnly(Side.CLIENT)
/*     */       public PacketBuffer getPacketToSend(int mouseButton)
/*     */       {
/* 591 */         PacketBuffer pkt = new PacketBuffer();
/* 592 */         ItemRef ref = getRef();
/* 593 */         if (ref == ItemRef.NULL) return null;
/* 594 */         ref.write(pkt);
/*     */         
/* 596 */         pkt.writeBoolean(GuiContainer.isShiftKeyDown());
/* 597 */         return pkt;
/*     */       }
/*     */       
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */       {
/* 603 */         ItemRef ref = getRef();
/* 604 */         if (ref != ItemRef.NULL)
/*     */         {
/* 606 */           int i = TileIndexer.this.counts.get(ref);
/* 607 */           String s = "" + i;
/*     */           
/*     */ 
/* 610 */           GlStateManager.enableLighting();
/* 611 */           RenderHelper.enableGUIStandardItemLighting();
/* 612 */           gui.renderSmallStackText(ref.createItemStack(1), s, guiLeft + getX() + 1, guiTop + getY() + 1);
/* 613 */           RenderHelper.disableStandardItemLighting();
/* 614 */           GlStateManager.disableLighting();
/*     */         }
/*     */         
/*     */         float t;
/*     */         
/*     */         float t;
/*     */         
/* 621 */         if (TileIndexer.this.active) {
/* 622 */           int i1 = TileIndexer.this.countDown.get(ref);
/*     */           
/* 624 */           if (i1 <= 0) { return;
/*     */           }
/* 626 */           t = i1 / 10.0F % 1.0F;
/*     */         } else {
/* 628 */           t = 1.0F;
/*     */         }
/*     */         
/* 631 */         if (t <= 0.0F) {
/* 632 */           return;
/*     */         }
/*     */         
/* 635 */         GLStateAttributes states = GLStateAttributes.loadStates();
/*     */         
/* 637 */         GlStateManager.pushMatrix();
/*     */         
/* 639 */         GlStateManager.translate(guiLeft + getX(), guiTop + getY(), 300.0F);
/* 640 */         GlStateManager.enableBlend();
/* 641 */         GlStateManager.disableDepth();
/* 642 */         GlStateManager.disableAlpha();
/* 643 */         GlStateManager.disableTexture2D();
/* 644 */         GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/* 645 */         GlStateManager.color(0.0F, 0.0F, 0.0F, 0.5F);
/* 646 */         Tessellator instance = Tessellator.getInstance();
/* 647 */         WorldRenderer tess = instance.getBuffer();
/* 648 */         tess.begin(7, DefaultVertexFormats.POSITION);
/*     */         
/* 650 */         double angle = 1.5707963267948966D + t * 3.141592653589793D * 2.0D;
/* 651 */         float dx = (float)Math.cos(angle);
/* 652 */         float dy = (float)Math.sin(angle);
/*     */         
/* 654 */         float adx = Math.abs(dx);
/* 655 */         float ady = Math.abs(dy);
/*     */         
/* 657 */         if (adx < ady) {
/* 658 */           dx /= ady;
/* 659 */           dy = Math.signum(dy);
/*     */         } else {
/* 661 */           dy /= adx;
/* 662 */           dx = Math.signum(dx);
/*     */         }
/* 664 */         dx = (1.0F + dx) / 2.0F * 18.0F;
/* 665 */         dy = 18.0F - (1.0F + dy) / 2.0F * 18.0F;
/*     */         
/* 667 */         if (t <= 0.125D) {
/* 668 */           tess.pos(9.0D, 0.0D, 0.0D).endVertex();
/* 669 */           tess.pos(dx, dy, 0.0D).endVertex();
/* 670 */           tess.pos(dx, dy, 0.0D).endVertex();
/* 671 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/* 672 */         } else if (t <= 0.375D) {
/* 673 */           tess.pos(dx, dy, 0.0D).endVertex();
/* 674 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/* 675 */           tess.pos(9.0D, 0.0D, 0.0D).endVertex();
/* 676 */           tess.pos(0.0D, 0.0D, 0.0D).endVertex();
/* 677 */         } else if (t <= 0.625D) {
/* 678 */           tess.pos(0.0D, 18.0D, 0.0D).endVertex();
/* 679 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/* 680 */           tess.pos(9.0D, 0.0D, 0.0D).endVertex();
/* 681 */           tess.pos(0.0D, 0.0D, 0.0D).endVertex();
/* 682 */           tess.pos(dx, dy, 0.0D).endVertex();
/* 683 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/* 684 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/* 685 */           tess.pos(0.0D, 18.0D, 0.0D).endVertex();
/* 686 */         } else if (t <= 0.875D) {
/* 687 */           tess.pos(0.0D, 18.0D, 0.0D).endVertex();
/* 688 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/* 689 */           tess.pos(9.0D, 0.0D, 0.0D).endVertex();
/* 690 */           tess.pos(0.0D, 0.0D, 0.0D).endVertex();
/*     */           
/* 692 */           tess.pos(0.0D, 18.0D, 0.0D).endVertex();
/* 693 */           tess.pos(18.0D, 18.0D, 0.0D).endVertex();
/* 694 */           tess.pos(dx, dy, 0.0D).endVertex();
/* 695 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/* 696 */         } else if (t <= 1.0F) {
/* 697 */           tess.pos(0.0D, 18.0D, 0.0D).endVertex();
/* 698 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/* 699 */           tess.pos(9.0D, 0.0D, 0.0D).endVertex();
/* 700 */           tess.pos(0.0D, 0.0D, 0.0D).endVertex();
/*     */           
/* 702 */           tess.pos(0.0D, 18.0D, 0.0D).endVertex();
/* 703 */           tess.pos(18.0D, 18.0D, 0.0D).endVertex();
/* 704 */           tess.pos(18.0D, 0.0D, 0.0D).endVertex();
/* 705 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/*     */           
/* 707 */           tess.pos(18.0D, 0.0D, 0.0D).endVertex();
/* 708 */           tess.pos(dx, dy, 0.0D).endVertex();
/* 709 */           tess.pos(dx, dy, 0.0D).endVertex();
/* 710 */           tess.pos(9.0D, 9.0D, 0.0D).endVertex();
/*     */         } else {
/* 712 */           tess.pos(0.0D, 18.0D, 0.0D).endVertex();
/* 713 */           tess.pos(18.0D, 18.0D, 0.0D).endVertex();
/* 714 */           tess.pos(18.0D, 0.0D, 0.0D).endVertex();
/* 715 */           tess.pos(0.0D, 0.0D, 0.0D).endVertex();
/*     */         }
/*     */         
/* 718 */         instance.draw();
/*     */         
/*     */ 
/* 721 */         GlStateManager.enableTexture2D();
/* 722 */         GlStateManager.enableAlpha();
/* 723 */         GlStateManager.disableBlend();
/*     */         
/* 725 */         GlStateManager.popMatrix();
/* 726 */         states.restore();
/*     */       }
/*     */       
/*     */ 
/*     */       @SideOnly(Side.CLIENT)
/*     */       public List<String> getToolTip()
/*     */       {
/* 733 */         ItemRef ref = getRef();
/* 734 */         if (ref == ItemRef.NULL) return null;
/* 735 */         ItemStack itemStack = ref.createItemStack(1);
/* 736 */         if (itemStack == null) return null;
/* 737 */         return itemStack.getTooltip(TileIndexer.ContainerIndexer.this.player, Minecraft.getMinecraft().gameSettings.advancedItemTooltips);
/*     */       }
/*     */       
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */       {
/* 743 */         gui.drawSlotBackground(guiLeft + getX(), guiTop + getY());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\TileIndexer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */