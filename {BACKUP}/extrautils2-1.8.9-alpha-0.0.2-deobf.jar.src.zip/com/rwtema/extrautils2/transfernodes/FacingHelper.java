/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.datastructures.FunctionABBool;
/*    */ import com.rwtema.extrautils2.utils.helpers.CollectionHelper;
/*    */ import java.util.EnumMap;
/*    */ import java.util.EnumSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Random;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public class FacingHelper
/*    */ {
/* 13 */   public static final EnumMap<EnumFacing, EnumSet<EnumFacing>> orthogonal = CollectionHelper.populateEnumMultiMap(EnumFacing.class, new FunctionABBool()
/*    */   {
/*    */     public boolean apply(EnumFacing facing, EnumFacing facing2) {
/* 16 */       return facing.getAxis() != facing2.getAxis();
/*    */     }
/* 13 */   });
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 22 */   public static final EnumMap<EnumFacing, EnumSet<EnumFacing>> horizontalOrthogonal = CollectionHelper.populateEnumMultiMap(EnumFacing.class, new FunctionABBool()
/*    */   {
/*    */     public boolean apply(EnumFacing facing, EnumFacing facing2) {
/* 25 */       return (facing.getAxis() != facing2.getAxis()) && (facing2.getAxis() != net.minecraft.util.EnumFacing.Axis.Y);
/*    */     }
/* 22 */   });
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 30 */   static final ThreadLocal<FaceIterRandom> pool = new ThreadLocal()
/*    */   {
/*    */     protected FacingHelper.FaceIterRandom initialValue() {
/* 33 */       return new FacingHelper.FaceIterRandom(null);
/*    */     }
/*    */   };
/* 36 */   private static final Random r = new Random();
/* 37 */   private static final EnumFacing[] facingValues = EnumFacing.values();
/*    */   
/*    */   public static Iterable<EnumFacing> getRandomFaceOrder() {
/* 40 */     return new FaceIterRandom(null);
/*    */   }
/*    */   
/*    */   public static Iterable<EnumFacing> getRandomFaceOrderPooled() {
/* 44 */     return (Iterable)pool.get();
/*    */   }
/*    */   
/*    */   private static class FaceIterRandom implements Iterable<EnumFacing>, Iterator<EnumFacing> {
/* 48 */     byte[] b = { 0, 1, 2, 3, 4, 5 };
/* 49 */     byte i = 0;
/*    */     
/*    */     public Iterator<EnumFacing> iterator()
/*    */     {
/* 53 */       this.i = 0;
/* 54 */       return this;
/*    */     }
/*    */     
/*    */     public boolean hasNext()
/*    */     {
/* 59 */       return this.i < 6;
/*    */     }
/*    */     
/*    */     public EnumFacing next()
/*    */     {
/* 64 */       if (this.i == 5) {
/* 65 */         this.i = ((byte)(this.i + 1));
/* 66 */         return FacingHelper.facingValues[this.b[5]];
/*    */       }
/* 68 */       int k = this.i + FacingHelper.r.nextInt(6 - this.i);
/* 69 */       if (k == this.i) {
/* 70 */         this.i = ((byte)(this.i + 1));
/* 71 */         return FacingHelper.facingValues[this.b[k]];
/*    */       }
/*    */       
/* 74 */       byte t = this.b[k];
/* 75 */       this.b[k] = this.b[this.i];
/* 76 */       this.b[this.i] = t;
/* 77 */       this.i = ((byte)(this.i + 1));
/*    */       
/* 79 */       return FacingHelper.facingValues[t];
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */     public void remove()
/*    */     {
/* 86 */       throw new UnsupportedOperationException();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\FacingHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */