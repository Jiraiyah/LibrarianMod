/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.CapGetter;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*    */ 
/*    */ public class TransferHelper
/*    */ {
/*    */   public static boolean isInputtingPipe(IBlockAccess world, BlockPos pos, EnumFacing dir)
/*    */   {
/* 13 */     IPipe pipe = getPipe(world, pos);
/* 14 */     return (pipe != null) && (pipe.canInput(world, pos, dir));
/*    */   }
/*    */   
/*    */   public static IPipe getPipe(IBlockAccess world, BlockPos pos) {
/* 18 */     net.minecraft.tileentity.TileEntity tileEntity = world.getTileEntity(pos);
/* 19 */     if ((tileEntity instanceof IPipe)) {
/* 20 */       return (IPipe)tileEntity;
/*    */     }
/* 22 */     net.minecraft.block.Block block = world.getBlockState(pos).getBlock();
/* 23 */     if ((block instanceof IPipe)) {
/* 24 */       return (IPipe)block;
/*    */     }
/*    */     
/* 27 */     return null;
/*    */   }
/*    */   
/*    */   public static boolean isOutputtingPipe(IBlockAccess world, BlockPos pos, EnumFacing dir) {
/* 31 */     IPipe pipe = getPipe(world, pos);
/* 32 */     return (pipe != null) && (pipe.canOutput(world, pos, dir));
/*    */   }
/*    */   
/*    */   public static boolean hasValidCapability(IBlockAccess world, BlockPos pos, EnumFacing dir) {
/* 36 */     net.minecraft.tileentity.TileEntity tileEntity = world.getTileEntity(pos);
/* 37 */     return (tileEntity != null) && (hasValidCapability(tileEntity, dir));
/*    */   }
/*    */   
/*    */   public static boolean hasValidCapability(ICapabilityProvider tileEntity, EnumFacing dir)
/*    */   {
/* 42 */     for (CapGetter<?> capability : CapGetter.caps) {
/* 43 */       if (capability.hasInterface(tileEntity, dir)) {
/* 44 */         return true;
/*    */       }
/*    */     }
/* 47 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\TransferHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */