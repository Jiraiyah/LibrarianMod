/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlockStaticRotation;
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockIndexer extends XUBlockStaticRotation
/*    */ {
/*    */   public BlockIndexer()
/*    */   {
/* 13 */     super(net.minecraft.block.material.Material.rock);
/*    */   }
/*    */   
/*    */   protected BoxModel createBaseModel(IBlockState baseState)
/*    */   {
/* 18 */     return BoxModel.newStandardBlock("panel_indexer_side").setTextures(new Object[] { EnumFacing.SOUTH, "panel_indexer_front" });
/*    */   }
/*    */   
/*    */   public boolean hasTileEntity(IBlockState state)
/*    */   {
/* 23 */     return true;
/*    */   }
/*    */   
/*    */   public net.minecraft.tileentity.TileEntity createTileEntity(World world, IBlockState state)
/*    */   {
/* 28 */     return new TileIndexer();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\BlockIndexer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */