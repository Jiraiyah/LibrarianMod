/*    */ package com.rwtema.extrautils2.transfernodes;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.entries.ItemClassEntry;
/*    */ import com.rwtema.extrautils2.backend.model.Box;
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public enum GrocketType
/*    */ {
/* 11 */   TRANSFER_NODE_ITEMS;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 47 */   BoxModel[] cache = new BoxModel[6];
/*    */   
/*    */   private GrocketType() {}
/*    */   
/*    */   public abstract Grocket create();
/*    */   
/*    */   public abstract BoxModel createBaseModel();
/*    */   
/*    */   @Nonnull
/* 56 */   public BoxModel createBaseModel(EnumFacing facing) { BoxModel model = createBaseModel();
/* 57 */     model.rotateToSide(facing);
/* 58 */     for (Box box : model) {
/* 59 */       box.tint = (6 + facing.ordinal());
/*    */     }
/* 61 */     return model;
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack createStack() {
/* 65 */     return com.rwtema.extrautils2.backend.entries.XU2Entries.grocket.newStack(ordinal());
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\transfernodes\GrocketType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */