/*     */ package com.rwtema.extrautils2.render;
/*     */ 
/*     */ import com.rwtema.extrautils2.items.ItemLawSword.EventHandlerSword;
/*     */ import gnu.trove.set.hash.THashSet;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.model.ModelBox;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.GLAllocation;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.WorldRenderer;
/*     */ import net.minecraft.client.renderer.entity.RenderPlayer;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class LayerSword implements net.minecraft.client.renderer.entity.layers.LayerRenderer<AbstractClientPlayer>
/*     */ {
/*  22 */   public static final ResourceLocation temaSword = new ResourceLocation("extrautils2", "textures/rwtema_sword.png");
/*     */   private final RenderPlayer renderPlayer;
/*  24 */   private int displayList = 0;
/*     */   
/*     */   public LayerSword(RenderPlayer renderPlayer) {
/*  27 */     this.renderPlayer = renderPlayer;
/*     */   }
/*     */   
/*     */ 
/*     */   public void doRenderLayer(AbstractClientPlayer entitylivingbaseIn, float p_177141_2_, float p_177141_3_, float partialTicks, float p_177141_5_, float p_177141_6_, float p_177141_7_, float scale)
/*     */   {
/*  33 */     String name = entitylivingbaseIn.getGameProfile().getName();
/*  34 */     if ((!ItemLawSword.EventHandlerSword.clientLawSwords.contains(name)) && (
/*  35 */       (!"RWTema".equals(name)) || (!entitylivingbaseIn.isWearing(net.minecraft.entity.player.EnumPlayerModelParts.CAPE)))) {
/*  36 */       return;
/*     */     }
/*     */     
/*  39 */     boolean holdingSword = false;
/*  40 */     ItemStack heldItem = entitylivingbaseIn.func_70694_bm();
/*  41 */     if ((heldItem != null) && ((heldItem.getItem() instanceof com.rwtema.extrautils2.items.ItemLawSword))) {
/*  42 */       holdingSword = true;
/*     */     }
/*     */     
/*  45 */     GL11.glPushMatrix();
/*     */     
/*  47 */     GlStateManager.enableRescaleNormal();
/*  48 */     GlStateManager.enableAlpha();
/*  49 */     ModelRenderer bipedBody = this.renderPlayer.getMainModel().bipedBody;
/*  50 */     bipedBody.postRender(0.0625F);
/*  51 */     float v = (((ModelBox)bipedBody.cubeList.get(0)).posZ2 - ((ModelBox)bipedBody.cubeList.get(0)).posZ1) / 2.0F;
/*  52 */     GL11.glTranslatef(0.0F, entitylivingbaseIn.isSneaking() ? 0.125F : 0.0F, 0.0625F * v);
/*     */     
/*     */ 
/*  55 */     Minecraft.getMinecraft().renderEngine.bindTexture(temaSword);
/*  56 */     if (this.displayList == 0) {
/*  57 */       this.displayList = GLAllocation.generateDisplayLists(2);
/*  58 */       GL11.glNewList(this.displayList, 4864);
/*  59 */       renderSword(false);
/*  60 */       GL11.glEndList();
/*  61 */       GL11.glNewList(this.displayList + 1, 4864);
/*  62 */       renderSword(true);
/*  63 */       GL11.glEndList();
/*     */     }
/*     */     
/*  66 */     GlStateManager.callList(this.displayList + (holdingSword ? 1 : 0));
/*     */     
/*  68 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void renderSword(boolean holdingSword)
/*     */   {
/*  75 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/*  77 */     GL11.glTranslatef(0.0F, 0.23750001F, 0.0F);
/*     */     
/*  79 */     GL11.glRotatef(-20.0F, 0.0F, 1.0F, 0.0F);
/*  80 */     GL11.glRotatef(-40.0F, 0.0F, 0.0F, 1.0F);
/*     */     
/*  82 */     float h = 87.0F;
/*  83 */     float h2 = holdingSword ? 20.0F : 0.0F;
/*  84 */     float w = 18.0F;
/*  85 */     float w2 = 5.0F;
/*  86 */     float w3 = 13.0F;
/*  87 */     double u = w2 / w;
/*  88 */     float h3 = h2 / h;
/*     */     
/*  90 */     GL11.glScalef(1.7F / h, 1.7F / h, 1.7F / h);
/*  91 */     GL11.glTranslatef(-w2 / 2.0F, -h / 2.0F, 0.0F);
/*     */     
/*     */ 
/*  94 */     WorldRenderer t = Tessellator.getInstance().getBuffer();
/*  95 */     t.begin(7, DefaultVertexFormats.OLDMODEL_POSITION_TEX_NORMAL);
/*     */     
/*  97 */     t.pos(0.0D, h2, 0.0D).func_181673_a(0.0D, h3).normal(0.0F, 0.0F, -1.0F).endVertex();
/*  98 */     t.pos(0.0D, h, 0.0D).func_181673_a(0.0D, 1.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
/*  99 */     t.pos(w2, h, 0.0D).func_181673_a(u, 1.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
/* 100 */     t.pos(w2, h2, 0.0D).func_181673_a(u, h3).normal(0.0F, 0.0F, -1.0F).endVertex();
/*     */     
/*     */ 
/* 103 */     t.pos(w2, h2, w2).func_181673_a(u, h3).normal(0.0F, 0.0F, 1.0F).endVertex();
/* 104 */     t.pos(w2, h, w2).func_181673_a(u, 1.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
/* 105 */     t.pos(0.0D, h, w2).func_181673_a(0.0D, 1.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
/* 106 */     t.pos(0.0D, h2, w2).func_181673_a(0.0D, h3).normal(0.0F, 0.0F, 1.0F).endVertex();
/*     */     
/*     */ 
/* 109 */     t.pos(w2, h2, w2).func_181673_a(u, h3).normal(1.0F, 0.0F, 0.0F).endVertex();
/* 110 */     t.pos(w2, h, w2).func_181673_a(u, 1.0D).normal(1.0F, 0.0F, 0.0F).endVertex();
/* 111 */     t.pos(w2, h, 0.0D).func_181673_a(0.0D, 1.0D).normal(1.0F, 0.0F, 0.0F).endVertex();
/* 112 */     t.pos(w2, h2, 0.0D).func_181673_a(0.0D, h3).normal(1.0F, 0.0F, 0.0F).endVertex();
/*     */     
/* 114 */     t.pos(0.0D, h2, 0.0D).func_181673_a(u, h3).normal(-1.0F, 0.0F, 0.0F).endVertex();
/* 115 */     t.pos(0.0D, h, 0.0D).func_181673_a(u, 1.0D).normal(-1.0F, 0.0F, 0.0F).endVertex();
/* 116 */     t.pos(0.0D, h, w2).func_181673_a(0.0D, 1.0D).normal(-1.0F, 0.0F, 0.0F).endVertex();
/* 117 */     t.pos(0.0D, h2, w2).func_181673_a(0.0D, h3).normal(-1.0F, 0.0F, 0.0F).endVertex();
/*     */     
/* 119 */     if (!holdingSword) {
/* 120 */       t.pos(0.0D, 0.0D, 0.0D).func_181673_a(9.0F / w, 4.0F / h).normal(0.0F, -1.0F, 0.0F).endVertex();
/* 121 */       t.pos(w2, 0.0D, 0.0D).func_181673_a(13.0F / w, 8.0F / h).normal(0.0F, -1.0F, 0.0F).endVertex();
/* 122 */       t.pos(w2, 0.0D, w2).func_181673_a(13.0F / w, 8.0F / h).normal(0.0F, -1.0F, 0.0F).endVertex();
/* 123 */       t.pos(0.0D, 0.0D, w2).func_181673_a(9.0F / w, 4.0F / h).normal(0.0F, -1.0F, 0.0F).endVertex();
/*     */     }
/*     */     
/*     */ 
/* 127 */     t.pos(0.0D, h, 0.0D).func_181673_a(9.0F / w, 4.0F / h).normal(0.0F, 1.0F, 0.0F).endVertex();
/* 128 */     t.pos(w2, h, 0.0D).func_181673_a(13.0F / w, 8.0F / h).normal(0.0F, 1.0F, 0.0F).endVertex();
/* 129 */     t.pos(w2, h, w2).func_181673_a(13.0F / w, 8.0F / h).normal(0.0F, 1.0F, 0.0F).endVertex();
/* 130 */     t.pos(0.0D, h, w2).func_181673_a(9.0F / w, 4.0F / h).normal(0.0F, 1.0F, 0.0F).endVertex();
/*     */     
/* 132 */     if (!holdingSword) {
/* 133 */       t.pos(-3.0D, 16.0D, -3.0D).func_181673_a(6.0F / w, 18.0F / h).normal(0.0F, -1.0F, 0.0F).endVertex();
/* 134 */       t.pos(8.0D, 16.0D, -3.0D).func_181673_a(17.0F / w, 18.0F / h).normal(0.0F, -1.0F, 0.0F).endVertex();
/* 135 */       t.pos(8.0D, 16.0D, 8.0D).func_181673_a(17.0F / w, 29.0F / h).normal(0.0F, -1.0F, 0.0F).endVertex();
/* 136 */       t.pos(-3.0D, 16.0D, 8.0D).func_181673_a(6.0F / w, 29.0F / h).normal(0.0F, -1.0F, 0.0F).endVertex();
/*     */       
/*     */ 
/* 139 */       t.pos(-3.0D, 20.0D, -3.0D).func_181673_a(6.0F / w, 1.0F / h).normal(0.0F, 1.0F, 0.0F).endVertex();
/* 140 */       t.pos(8.0D, 20.0D, -3.0D).func_181673_a(17.0F / w, 1.0F / h).normal(0.0F, 1.0F, 0.0F).endVertex();
/* 141 */       t.pos(8.0D, 20.0D, 8.0D).func_181673_a(17.0F / w, 12.0F / h).normal(0.0F, 1.0F, 0.0F).endVertex();
/* 142 */       t.pos(-3.0D, 20.0D, 8.0D).func_181673_a(6.0F / w, 12.0F / h).normal(0.0F, 1.0F, 0.0F).endVertex();
/*     */       
/*     */ 
/* 145 */       t.pos(-3.0D, 16.0D, -3.0D).func_181673_a(u, 12.0F / h).normal(0.0F, 0.0F, -1.0F).endVertex();
/* 146 */       t.pos(-3.0D, 20.0D, -3.0D).func_181673_a(u, 17.0F / h).normal(0.0F, 0.0F, -1.0F).endVertex();
/* 147 */       t.pos(8.0D, 20.0D, -3.0D).func_181673_a(1.0D, 17.0F / h).normal(0.0F, 0.0F, -1.0F).endVertex();
/* 148 */       t.pos(8.0D, 16.0D, -3.0D).func_181673_a(1.0D, 12.0F / h).normal(0.0F, 0.0F, -1.0F).endVertex();
/*     */       
/*     */ 
/* 151 */       t.pos(-3.0D, 16.0D, 8.0D).func_181673_a(u, 12.0F / h).normal(0.0F, 0.0F, 1.0F).endVertex();
/* 152 */       t.pos(-3.0D, 20.0D, 8.0D).func_181673_a(u, 17.0F / h).normal(0.0F, 0.0F, 1.0F).endVertex();
/* 153 */       t.pos(8.0D, 20.0D, 8.0D).func_181673_a(1.0D, 17.0F / h).normal(0.0F, 0.0F, 1.0F).endVertex();
/* 154 */       t.pos(8.0D, 16.0D, 8.0D).func_181673_a(1.0D, 12.0F / h).normal(0.0F, 0.0F, 1.0F).endVertex();
/*     */       
/*     */ 
/* 157 */       t.pos(8.0D, 16.0D, 8.0D).func_181673_a(u, 12.0F / h).normal(1.0F, 0.0F, 0.0F).endVertex();
/* 158 */       t.pos(8.0D, 20.0D, 8.0D).func_181673_a(u, 17.0F / h).normal(1.0F, 0.0F, 0.0F).endVertex();
/* 159 */       t.pos(8.0D, 20.0D, -3.0D).func_181673_a(1.0D, 17.0F / h).normal(1.0F, 0.0F, 0.0F).endVertex();
/* 160 */       t.pos(8.0D, 16.0D, -3.0D).func_181673_a(1.0D, 12.0F / h).normal(1.0F, 0.0F, 0.0F).endVertex();
/*     */       
/*     */ 
/* 163 */       t.pos(-3.0D, 16.0D, 8.0D).func_181673_a(u, 12.0F / h).normal(-1.0F, 0.0F, 0.0F).endVertex();
/* 164 */       t.pos(-3.0D, 20.0D, 8.0D).func_181673_a(u, 17.0F / h).normal(-1.0F, 0.0F, 0.0F).endVertex();
/* 165 */       t.pos(-3.0D, 20.0D, -3.0D).func_181673_a(1.0D, 17.0F / h).normal(-1.0F, 0.0F, 0.0F).endVertex();
/* 166 */       t.pos(-3.0D, 16.0D, -3.0D).func_181673_a(1.0D, 12.0F / h).normal(-1.0F, 0.0F, 0.0F).endVertex();
/*     */     }
/*     */     
/* 169 */     Tessellator.getInstance().draw();
/*     */   }
/*     */   
/*     */   public boolean shouldCombineTextures()
/*     */   {
/* 174 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\render\LayerSword.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */