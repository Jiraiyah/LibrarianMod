/*     */ package com.rwtema.extrautils2.render;
/*     */ 
/*     */ import com.rwtema.extrautils2.items.ItemAngelRing;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.model.ModelBox;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.WorldRenderer;
/*     */ import net.minecraft.client.renderer.entity.RenderPlayer;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class LayerWings implements net.minecraft.client.renderer.entity.layers.LayerRenderer<AbstractClientPlayer>
/*     */ {
/*  20 */   private static final ResourceLocation[] wing_textures = { null, new ResourceLocation("extrautils2", "textures/wing_feather.png"), new ResourceLocation("extrautils2", "textures/wing_butterfly.png"), new ResourceLocation("extrautils2", "textures/wing_demon.png"), new ResourceLocation("extrautils2", "textures/wing_golden.png"), new ResourceLocation("extrautils2", "textures/wing_bat.png") };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final RenderPlayer renderPlayer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  30 */   private int displayList = 0;
/*     */   
/*     */   public LayerWings(RenderPlayer renderPlayer) {
/*  33 */     this.renderPlayer = renderPlayer;
/*     */   }
/*     */   
/*     */   public void doRenderLayer(AbstractClientPlayer entitylivingbaseIn, float p_177141_2_, float p_177141_3_, float partialTicks, float p_177141_5_, float p_177141_6_, float p_177141_7_, float scale)
/*     */   {
/*  38 */     String name = entitylivingbaseIn.getGameProfile().getName();
/*  39 */     if (ItemAngelRing.clientFlyingPlayers.containsKey(name)) {
/*  40 */       int tex = ItemAngelRing.clientFlyingPlayers.get(name);
/*  41 */       if ((tex <= 0) || (tex >= wing_textures.length)) {
/*  42 */         return;
/*     */       }
/*  44 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */       
/*  46 */       GL11.glPushMatrix();
/*     */       
/*  48 */       ModelRenderer bipedBody = this.renderPlayer.getMainModel().bipedBody;
/*  49 */       bipedBody.postRender(0.0625F);
/*  50 */       Minecraft.getMinecraft().renderEngine.bindTexture(wing_textures[tex]);
/*     */       
/*  52 */       float v = (((ModelBox)bipedBody.cubeList.get(0)).posZ2 - ((ModelBox)bipedBody.cubeList.get(0)).posZ1) / 2.0F;
/*     */       
/*  54 */       GL11.glTranslatef(0.0F, entitylivingbaseIn.isSneaking() ? 0.125F : 0.0F, 0.0625F * v);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  59 */       boolean isFlying = entitylivingbaseIn.capabilities.isFlying;
/*  60 */       float a = (1.0F + (float)Math.cos(com.rwtema.extrautils2.utils.MCTimer.renderTimer / 4.0F)) * (isFlying ? 20 : 2) + 25.0F;
/*     */       
/*  62 */       if (this.displayList == 0) {
/*  63 */         Tessellator instance = Tessellator.getInstance();
/*  64 */         WorldRenderer t = instance.getBuffer();
/*  65 */         this.displayList = net.minecraft.client.renderer.GLAllocation.generateDisplayLists(2);
/*  66 */         GL11.glNewList(this.displayList, 4864);
/*  67 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  68 */         GL11.glTranslatef(0.0F, -0.3125F, 0.0F);
/*  69 */         t.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  70 */         t.pos(0.0D, 0.0D, 0.0D).func_181673_a(0.0D, 0.0D).endVertex();
/*  71 */         t.pos(0.0D, 1.0D, 0.0D).func_181673_a(0.0D, 1.0D).endVertex();
/*  72 */         t.pos(1.0D, 1.0D, 0.0D).func_181673_a(1.0D, 1.0D).endVertex();
/*  73 */         t.pos(1.0D, 0.0D, 0.0D).func_181673_a(1.0D, 0.0D).endVertex();
/*  74 */         instance.draw();
/*  75 */         GL11.glEndList();
/*     */         
/*  77 */         GL11.glNewList(this.displayList + 1, 4864);
/*  78 */         t.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  79 */         GL11.glTranslatef(0.0F, -0.3125F, 0.0F);
/*  80 */         t.pos(0.0D, 0.0D, 0.0D).func_181673_a(0.0D, 0.0D).endVertex();
/*  81 */         t.pos(0.0D, 1.0D, 0.0D).func_181673_a(0.0D, 1.0D).endVertex();
/*  82 */         t.pos(-1.0D, 1.0D, 0.0D).func_181673_a(1.0D, 1.0D).endVertex();
/*  83 */         t.pos(-1.0D, 0.0D, 0.0D).func_181673_a(1.0D, 0.0D).endVertex();
/*  84 */         instance.draw();
/*  85 */         GL11.glEndList();
/*     */       }
/*     */       
/*  88 */       GL11.glPushMatrix();
/*     */       
/*  90 */       GL11.glRotatef(-a, 0.0F, 1.0F, 0.0F);
/*  91 */       GlStateManager.callList(this.displayList);
/*     */       
/*     */ 
/*  94 */       GL11.glPopMatrix();
/*  95 */       GL11.glPushMatrix();
/*     */       
/*  97 */       GL11.glRotatef(a, 0.0F, 1.0F, 0.0F);
/*  98 */       GlStateManager.callList(this.displayList + 1);
/*     */       
/* 100 */       GL11.glPopMatrix();
/*     */       
/* 102 */       GL11.glPopMatrix();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean shouldCombineTextures()
/*     */   {
/* 108 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\render\LayerWings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */