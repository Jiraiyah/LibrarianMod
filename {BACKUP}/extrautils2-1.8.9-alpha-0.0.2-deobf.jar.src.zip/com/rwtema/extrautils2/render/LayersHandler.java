/*    */ package com.rwtema.extrautils2.render;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.datastructures.WeakLinkedSet;
/*    */ import com.rwtema.extrautils2.utils.datastructures.WeakSet;
/*    */ import net.minecraft.client.renderer.entity.RenderPlayer;
/*    */ import net.minecraft.client.renderer.entity.RendererLivingEntity;
/*    */ import net.minecraftforge.client.event.RenderLivingEvent.Pre;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent;
/*    */ 
/*    */ public class LayersHandler
/*    */ {
/* 13 */   public static WeakSet<RendererLivingEntity<?>> initRenderers = new WeakSet();
/* 14 */   public static WeakLinkedSet<RendererLivingEntity<?>> toInit = new WeakLinkedSet();
/*    */   
/*    */   public static void init() {
/* 17 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new LayersHandler());
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void renderStart(RenderLivingEvent.Pre event) {
/* 22 */     if (!initRenderers.contains(event.renderer)) {
/* 23 */       initRenderers.add(event.renderer);
/* 24 */       toInit.add(event.renderer);
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void layers(TickEvent.RenderTickEvent event) {
/* 30 */     if (toInit.isEmpty()) return;
/* 31 */     for (RendererLivingEntity<?> rendererLivingEntity : toInit) {
/* 32 */       addLayers(rendererLivingEntity);
/*    */     }
/* 34 */     toInit.clear();
/*    */   }
/*    */   
/*    */   private void addLayers(RendererLivingEntity<?> renderer) {
/* 38 */     if ((renderer instanceof RenderPlayer)) {
/* 39 */       RenderPlayer renderPlayer = (RenderPlayer)renderer;
/* 40 */       renderer.addLayer(new LayerWings(renderPlayer));
/* 41 */       renderer.addLayer(new LayerSword(renderPlayer));
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\render\LayersHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */