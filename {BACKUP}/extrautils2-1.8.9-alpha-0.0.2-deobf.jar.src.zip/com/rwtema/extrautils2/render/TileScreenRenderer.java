/*     */ package com.rwtema.extrautils2.render;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.model.XUBlockState;
/*     */ import com.rwtema.extrautils2.textures.ImgurTextureHolder;
/*     */ import com.rwtema.extrautils2.tile.TileScreen;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.WorldRenderer;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ 
/*     */ public class TileScreenRenderer extends net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer<TileScreen>
/*     */ {
/*  15 */   public static TileScreenRenderer instance = new TileScreenRenderer();
/*     */   
/*  17 */   static float[][] offsets = { null, null, { 0.0F, 0.0F, 0.1F }, { 0.0F, 0.0F, 0.9F }, { 0.1F, 0.0F, 0.0F }, { 0.9F, 0.0F, 0.0F } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  25 */   static float[][][] vecs = { (float[][])null, (float[][])null, { { 0.0F, 0.0F, 0.0F }, { 0.0F, 1.0F, 0.0F }, { 1.0F, 1.0F, 0.0F }, { 1.0F, 0.0F, 0.0F } }, { { 1.0F, 0.0F, 0.0F }, { 1.0F, 1.0F, 0.0F }, { 0.0F, 1.0F, 0.0F }, { 0.0F, 0.0F, 0.0F } }, { { 0.0F, 0.0F, 1.0F }, { 0.0F, 1.0F, 1.0F }, { 0.0F, 1.0F, 0.0F }, { 0.0F, 0.0F, 0.0F } }, { { 0.0F, 0.0F, 0.0F }, { 0.0F, 1.0F, 0.0F }, { 0.0F, 1.0F, 1.0F }, { 0.0F, 0.0F, 1.0F } } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */   EnumFacing[] right = { null, null, EnumFacing.EAST, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.SOUTH };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void renderTileEntityAt(TileScreen te, double x, double y, double z, float partialTicks, int destroyStage)
/*     */   {
/*  65 */     if (!te.active) return;
/*  66 */     EnumFacing side = (EnumFacing)te.getBlockState().getValue(com.rwtema.extrautils2.backend.XUBlockStateCreator.ROTATION_HORIZONTAL);
/*     */     
/*  68 */     int s = side.ordinal();
/*  69 */     EnumFacing right = this.right[s];
/*     */     
/*  71 */     if ((te.canJoinWith(te.getPos().down())) || (te.canJoinWith(te.getPos().offset(right, -1)))) { return;
/*     */     }
/*  73 */     int w = 1;
/*  74 */     int h = 1;
/*     */     
/*  76 */     while ((w < 8) && 
/*  77 */       (te.canJoinWith(te.getPos().offset(right, w))) && (!te.canJoinWith(te.getPos().offset(right, w).down()))) {
/*  78 */       w++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     while (h < 8) {
/*  86 */       for (int i = 0; i < w; i++) {
/*  87 */         if (!te.canJoinWith(te.getPos().up(h).offset(right, i)))
/*     */           break label184;
/*     */       }
/*  90 */       h++;
/*     */     }
/*     */     
/*     */     label184:
/*  94 */     ImgurTextureHolder tex = ImgurTextureHolder.getTex(te.id);
/*     */     
/*  96 */     if ((tex.width == 0) || (tex.height == 0)) { return;
/*     */     }
/*  98 */     bindTexture(tex.getResourceLocationForBinding());
/*     */     
/*     */ 
/* 101 */     GlStateManager.pushMatrix();
/*     */     
/* 103 */     GlStateManager.translate(x, y, z);
/* 104 */     GlStateManager.depthMask(true);
/* 105 */     GlStateManager.disableLighting();
/* 106 */     GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 107 */     GlStateManager.enableTexture2D();
/* 108 */     Tessellator tessellator = Tessellator.getInstance();
/* 109 */     WorldRenderer worldrenderer = tessellator.getBuffer();
/* 110 */     float[][] uvs = { { tex.u0, tex.v1 }, { tex.u0, tex.v0 }, { tex.u1, tex.v0 }, { tex.u1, tex.v1 } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */     float[] offset = offsets[s];
/* 118 */     GlStateManager.translate(offset[0], offset[1], offset[2]);
/*     */     
/* 120 */     worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
/*     */     
/* 122 */     float scale = Math.min(w / tex.width, h / tex.height);
/*     */     
/*     */ 
/*     */ 
/* 126 */     float dx = tex.width * scale - 0.03125F;
/* 127 */     float dy = tex.height * scale - 0.03125F;
/*     */     
/*     */ 
/* 130 */     float x0 = (w - dx) / 2.0F;
/* 131 */     float y0 = (h - dy) / 2.0F;
/*     */     
/* 133 */     for (int i = 3; i >= 0; i--) {
/* 134 */       float[] vec = vecs[s][i];
/* 135 */       float[] uv = uvs[i];
/* 136 */       worldrenderer.pos(s >= 4 ? 0.0D : x0 + vec[0] * dx, y0 + vec[1] * dy, s < 4 ? 0.0D : x0 + vec[2] * dx).func_181673_a(uv[0], uv[1]).endVertex();
/*     */     }
/*     */     
/* 139 */     tessellator.draw();
/*     */     
/* 141 */     GlStateManager.enableLighting();
/* 142 */     GlStateManager.enableDepth();
/* 143 */     GlStateManager.popMatrix();
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\render\TileScreenRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */