/*    */ package com.rwtema.extrautils2.chunkloading;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import com.rwtema.extrautils2.backend.save.SaveModule;
/*    */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*    */ import gnu.trove.map.hash.TObjectLongHashMap;
/*    */ import gnu.trove.procedure.TObjectLongProcedure;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
/*    */ 
/*    */ public class ChunkLoaderLoginTimes extends SaveModule
/*    */ {
/*    */   private static final long MAX_WAIT_TIME = 604800000L;
/*    */   public static ChunkLoaderLoginTimes instance;
/* 20 */   static TObjectLongHashMap<GameProfile> loginTimes = new TObjectLongHashMap();
/*    */   
/*    */   static {
/* 23 */     instance = new ChunkLoaderLoginTimes();
/* 24 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(instance);
/*    */   }
/*    */   
/* 27 */   boolean loaded = false;
/*    */   
/*    */   public ChunkLoaderLoginTimes() {
/* 30 */     super("ChunkLoaderData");
/*    */   }
/*    */   
/*    */   public boolean isValid(GameProfile profile) {
/* 34 */     if (!this.loaded) return true;
/* 35 */     for (EntityPlayerMP playerMP : MinecraftServer.func_71276_C().func_71203_ab().playerEntityList) {
/* 36 */       if (playerMP.getGameProfile().equals(profile)) {
/* 37 */         loginTimes.put(profile, System.currentTimeMillis());
/* 38 */         return true;
/*    */       }
/*    */     }
/*    */     
/* 42 */     long l = System.currentTimeMillis() - loginTimes.get(profile);
/* 43 */     return l < 604800000L;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void playerLogin(PlayerEvent.PlayerLoggedInEvent event) {
/* 48 */     loginTimes.put(event.player.getGameProfile(), System.currentTimeMillis());
/* 49 */     XUChunkLoaderManager.dirty = true;
/* 50 */     markDirty();
/*    */   }
/*    */   
/*    */   public void readFromNBT(NBTTagCompound nbt)
/*    */   {
/* 55 */     loginTimes.clear();
/* 56 */     NBTTagList loginTimes = nbt.getTagList("LoginTimes", 10);
/* 57 */     for (int i = 0; i < loginTimes.tagCount(); i++) {
/* 58 */       NBTTagCompound loginTime = loginTimes.getCompoundTagAt(i);
/* 59 */       GameProfile profile = NBTHelper.profileFromNBT(loginTime);
/* 60 */       if (profile != null) {
/* 61 */         loginTimes.put(profile, loginTime.getLong("LoginTime"));
/*    */       }
/*    */     }
/*    */     
/* 65 */     this.loaded = true;
/*    */   }
/*    */   
/*    */   public void writeToNBT(NBTTagCompound nbt)
/*    */   {
/* 70 */     final NBTTagList tagList = new NBTTagList();
/* 71 */     loginTimes.forEachEntry(new TObjectLongProcedure()
/*    */     {
/*    */       public boolean execute(GameProfile a, long b) {
/* 74 */         NBTTagCompound t = NBTHelper.proifleToNBT(a);
/* 75 */         t.setLong("LoginTime", b);
/* 76 */         tagList.appendTag(t);
/* 77 */         return true;
/*    */       }
/* 79 */     });
/* 80 */     nbt.setTag("LoginTimes", tagList);
/*    */   }
/*    */   
/*    */   public void reset()
/*    */   {
/* 85 */     loginTimes.clear();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\chunkloading\ChunkLoaderLoginTimes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */