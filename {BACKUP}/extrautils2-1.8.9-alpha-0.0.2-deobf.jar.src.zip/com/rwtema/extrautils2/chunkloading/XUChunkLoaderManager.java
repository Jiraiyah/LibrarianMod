/*     */ package com.rwtema.extrautils2.chunkloading;
/*     */ 
/*     */ import com.google.common.collect.HashMultimap;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import com.google.common.collect.ListMultimap;
/*     */ import com.google.common.collect.Multimap;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.tile.TileChunkLoader;
/*     */ import com.rwtema.extrautils2.utils.helpers.DescribeHelper;
/*     */ import gnu.trove.list.array.TIntArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.world.ChunkCoordIntPair;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.ForgeChunkManager;
/*     */ import net.minecraftforge.common.ForgeChunkManager.Ticket;
/*     */ import net.minecraftforge.event.world.WorldEvent.Unload;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent.ServerTickEvent;
/*     */ 
/*     */ public class XUChunkLoaderManager implements net.minecraftforge.common.ForgeChunkManager.LoadingCallback, net.minecraftforge.common.ForgeChunkManager.PlayerOrderedLoadingCallback
/*     */ {
/*  28 */   public static final HashMultimap<World, TileChunkLoader> chunkLoaders = ;
/*     */   
/*  30 */   public static XUChunkLoaderManager instance = new XUChunkLoaderManager();
/*  31 */   public static boolean dirty = false;
/*  32 */   private static HashMap<World, HashMap<GameProfile, ForgeChunkManager.Ticket>> playerTickets = new HashMap();
/*     */   
/*     */   public static void init() {
/*  35 */     ForgeChunkManager.setForcedChunkLoadingCallback(ExtraUtils2.instance, instance);
/*  36 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(instance);
/*     */   }
/*     */   
/*     */   public static void register(TileChunkLoader loader) {
/*  40 */     synchronized (chunkLoaders) {
/*  41 */       GameProfile profile = loader.getProfile();
/*  42 */       if (profile != null) {
/*  43 */         ForgeChunkManager.Ticket playerTicket = instance.getPlayerTicket(profile, loader.world());
/*  44 */         if (playerTicket != null) {
/*  45 */           ForgeChunkManager.forceChunk(playerTicket, new ChunkCoordIntPair(loader.getPos().getX() >> 4, loader.getPos().getZ() >> 4));
/*     */         }
/*     */       }
/*  48 */       chunkLoaders.put(loader.world(), loader);
/*  49 */       dirty = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unregister(TileChunkLoader loader) {
/*  54 */     synchronized (chunkLoaders) {
/*  55 */       chunkLoaders.remove(loader.world(), loader);
/*  56 */       dirty = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void clear()
/*     */   {
/*  62 */     chunkLoaders.clear();
/*  63 */     playerTickets.clear();
/*  64 */     ChunkLoaderLoginTimes.instance.loaded = false;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void serverTick(TickEvent.ServerTickEvent event) {
/*  69 */     if (dirty) {
/*  70 */       reloadChunkLoaders();
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onWorldUnload(WorldEvent.Unload event)
/*     */   {
/*  77 */     playerTickets.remove(event.world);
/*  78 */     chunkLoaders.removeAll(event.world); }
/*     */   
/*     */   public void reloadChunkLoaders() { Multimap<ForgeChunkManager.Ticket, ChunkCoordIntPair> toUnload;
/*     */     Multimap<ForgeChunkManager.Ticket, ChunkCoordIntPair> toAdd;
/*     */     Iterator<ForgeChunkManager.Ticket> iterator;
/*  83 */     synchronized (chunkLoaders) {
/*  84 */       dirty = false;
/*     */       
/*  86 */       HashMultimap<World, ChunkCoordIntPair> worldChunks = HashMultimap.create();
/*  87 */       toUnload = HashMultimap.create();
/*  88 */       Multimap<ForgeChunkManager.Ticket, ChunkCoordIntPair> loaded = HashMultimap.create();
/*  89 */       toAdd = HashMultimap.create();
/*     */       
/*  91 */       for (HashMap<GameProfile, ForgeChunkManager.Ticket> map : playerTickets.values()) {
/*  92 */         for (ForgeChunkManager.Ticket ticket : map.values()) {
/*  93 */           ImmutableSet<ChunkCoordIntPair> chunkList = ticket.getChunkList();
/*  94 */           for (ChunkCoordIntPair pair : chunkList) {
/*  95 */             ticket.world.getBlockState(pair.getCenterBlock(20));
/*     */           }
/*     */           
/*  98 */           worldChunks.putAll(ticket.world, chunkList);
/*  99 */           toUnload.putAll(ticket, chunkList);
/* 100 */           loaded.putAll(ticket, chunkList);
/*     */         }
/*     */       }
/*     */       
/* 104 */       for (Iterator<TileChunkLoader> iterator = chunkLoaders.values().iterator(); iterator.hasNext();) {
/* 105 */         chunkLoader = (TileChunkLoader)iterator.next();
/* 106 */         if (chunkLoader.isInvalid()) {
/* 107 */           dirty = true;
/* 108 */           iterator.remove();
/*     */         }
/*     */         
/* 111 */         if (!chunkLoader.isLoaded()) {
/* 112 */           dirty = true;
/*     */         }
/* 114 */         GameProfile profile = chunkLoader.getProfile();
/* 115 */         if ((chunkLoader.active) && (profile != null) && (ChunkLoaderLoginTimes.instance.isValid(profile))) {
/* 116 */           ticket = getPlayerTicket(profile, chunkLoader.world());
/* 117 */           if (ticket != null)
/* 118 */             for (ChunkCoordIntPair coordIntPair : chunkLoader.getChunkCoords()) {
/* 119 */               worldChunks.remove(chunkLoader.world(), coordIntPair);
/* 120 */               toUnload.remove(ticket, coordIntPair);
/* 121 */               if (!loaded.containsEntry(ticket, coordIntPair))
/* 122 */                 toAdd.put(ticket, coordIntPair);
/*     */             }
/*     */         } }
/*     */       TileChunkLoader chunkLoader;
/*     */       ForgeChunkManager.Ticket ticket;
/* 127 */       for (HashMap<GameProfile, ForgeChunkManager.Ticket> map : playerTickets.values()) {
/* 128 */         for (iterator = map.values().iterator(); iterator.hasNext();) {
/* 129 */           ForgeChunkManager.Ticket ticket = (ForgeChunkManager.Ticket)iterator.next();
/* 130 */           for (ChunkCoordIntPair pair : toUnload.get(ticket)) {
/* 131 */             ForgeChunkManager.unforceChunk(ticket, pair);
/*     */           }
/* 133 */           for (ChunkCoordIntPair pair : toAdd.get(ticket)) {
/* 134 */             ForgeChunkManager.forceChunk(ticket, pair);
/*     */           }
/* 136 */           if (ticket.getChunkList().isEmpty()) {
/* 137 */             ForgeChunkManager.releaseTicket(ticket);
/* 138 */             iterator.remove();
/*     */           } else {
/* 140 */             TIntArrayList x = new TIntArrayList();
/* 141 */             TIntArrayList z = new TIntArrayList();
/* 142 */             for (ChunkCoordIntPair chunkCoordIntPair : ticket.getChunkList()) {
/* 143 */               x.add(chunkCoordIntPair.chunkXPos);
/* 144 */               z.add(chunkCoordIntPair.chunkZPos);
/*     */             }
/* 146 */             ticket.getModData().setIntArray("x", x.toArray());
/* 147 */             ticket.getModData().setIntArray("z", z.toArray());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ForgeChunkManager.Ticket getPlayerTicket(GameProfile profile, World world)
/*     */   {
/* 163 */     HashMap<GameProfile, ForgeChunkManager.Ticket> gameProfileTicketHashMap = (HashMap)playerTickets.get(world);
/* 164 */     if (gameProfileTicketHashMap == null) {
/* 165 */       playerTickets.put(world, gameProfileTicketHashMap = new HashMap());
/*     */     }
/* 167 */     ForgeChunkManager.Ticket ticket = (ForgeChunkManager.Ticket)gameProfileTicketHashMap.get(profile);
/*     */     
/* 169 */     if (ticket == null) {
/* 170 */       ticket = ForgeChunkManager.requestPlayerTicket(ExtraUtils2.instance, profile.getName(), world, net.minecraftforge.common.ForgeChunkManager.Type.NORMAL);
/* 171 */       NBTTagCompound tag = ticket.getModData();
/* 172 */       tag.setString("Name", profile.getName());
/* 173 */       UUID id = profile.getId();
/* 174 */       if (id != null) {
/* 175 */         tag.setLong("UUIDL", id.getLeastSignificantBits());
/* 176 */         tag.setLong("UUIDU", id.getMostSignificantBits());
/*     */       }
/*     */       
/* 179 */       gameProfileTicketHashMap.put(profile, ticket);
/*     */     }
/* 181 */     return ticket;
/*     */   }
/*     */   
/*     */ 
/*     */   public void ticketsLoaded(List<ForgeChunkManager.Ticket> tickets, World world)
/*     */   {
/* 187 */     dirty = true;
/* 188 */     HashMap<GameProfile, ForgeChunkManager.Ticket> cache = new HashMap();
/* 189 */     playerTickets.put(world, cache);
/* 190 */     for (ForgeChunkManager.Ticket ticket : tickets) {
/* 191 */       NBTTagCompound modData = ticket.getModData();
/* 192 */       GameProfile profile = com.rwtema.extrautils2.utils.helpers.NBTHelper.profileFromNBT(modData);
/* 193 */       cache.put(profile, ticket);
/* 194 */       int[] x = modData.getIntArray("x");
/* 195 */       int[] z = modData.getIntArray("z");
/*     */       
/* 197 */       if (x.length == z.length) { net.minecraft.world.chunk.Chunk chunk;
/* 198 */         for (int i = 0; i < x.length; i++) {
/* 199 */           ForgeChunkManager.forceChunk(ticket, new ChunkCoordIntPair(x[i], z[i]));
/* 200 */           chunk = world.getChunkFromChunkCoords(x[i], z[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void getDebug(List<String> info)
/*     */   {
/* 209 */     DescribeHelper.addDescription(info, "Chunk Loaders", chunkLoaders);
/* 210 */     DescribeHelper.addDescription(info, "Player Tickets", playerTickets);
/*     */   }
/*     */   
/*     */   public ListMultimap<String, ForgeChunkManager.Ticket> playerTicketsLoaded(ListMultimap<String, ForgeChunkManager.Ticket> tickets, World world)
/*     */   {
/* 215 */     return tickets;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\chunkloading\XUChunkLoaderManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */