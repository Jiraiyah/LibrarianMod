/*    */ package com.rwtema.extrautils2.blocks;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlockStaticRotation;
/*    */ import com.rwtema.extrautils2.backend.model.Box;
/*    */ import com.rwtema.extrautils2.backend.model.BoxDoubleSided;
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumWorldBlockLayer;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public abstract class BlockWardBase extends XUBlockStaticRotation
/*    */ {
/*    */   private final int irisColor;
/*    */   private final int tex_type;
/*    */   
/*    */   public BlockWardBase(int irisColor, int tex_type)
/*    */   {
/* 23 */     super(net.minecraft.block.material.Material.wood);
/* 24 */     this.irisColor = irisColor;
/* 25 */     this.tex_type = tex_type;
/*    */   }
/*    */   
/*    */   protected BoxModel createBaseModel(IBlockState baseState)
/*    */   {
/* 30 */     BoxModel model = new BoxModel();
/* 31 */     model.addBoxI(7, 0, 7, 9, 7, 9, "ward/ward_stick");
/* 32 */     model.add(new BoxDoubleSided(0.0F, 0.0F, 0.4375F, 1.0F, 1.0F, 0.5625F).setTexture("ward/ward_prongs").setInvisible(-13).setFlipU(new int[] { 2 }));
/* 33 */     Box box = model.addBoxI(5, 8, 5, 11, 14, 11).setTextureSides(new Object[] { Integer.valueOf(0), "ward/ward_eye_top_" + this.tex_type, "ward/ward_eye_top_" + this.tex_type, "ward/ward_eye_front_" + this.tex_type, "ward/ward_eye_back_" + this.tex_type, "ward/ward_eye_side_" + this.tex_type, "ward/ward_eye_side_" + this.tex_type });
/* 34 */     box.setFlipU(new int[] { 5 });
/* 35 */     box.setFlipV(new int[] { 1 });
/* 36 */     if (this.irisColor >= 0)
/* 37 */       model.addBoxI(5, 8, 5, 11, 14, 11, "ward/ward_iris").setInvisible(-5).setTint(1);
/* 38 */     for (Box box1 : model) {
/* 39 */       box1.noCollide = true;
/*    */     }
/*    */     
/* 42 */     model.setLayer(EnumWorldBlockLayer.CUTOUT);
/* 43 */     model.rotateY(2);
/* 44 */     return model;
/*    */   }
/*    */   
/*    */ 
/*    */   public abstract TileEntity createTileEntity(World paramWorld, IBlockState paramIBlockState);
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public int func_180662_a(IBlockAccess worldIn, BlockPos pos, int renderPass)
/*    */   {
/* 53 */     if (renderPass == 1)
/* 54 */       return this.irisColor;
/* 55 */     return super.func_180662_a(worldIn, pos, renderPass);
/*    */   }
/*    */   
/*    */   public boolean hasTileEntity(IBlockState state)
/*    */   {
/* 60 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockWardBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */