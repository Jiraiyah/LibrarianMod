/*    */ package com.rwtema.extrautils2.blocks;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ 
/*    */ public class BlockPowerOverload extends com.rwtema.extrautils2.backend.XUBlockStatic
/*    */ {
/*    */   public BlockPowerOverload()
/*    */   {
/* 10 */     super(net.minecraft.block.material.Material.rock);
/*    */   }
/*    */   
/*    */   public BoxModel getModel(IBlockState state)
/*    */   {
/* 15 */     BoxModel boxes = new BoxModel();
/* 16 */     boxes.addBoxI(1, 1, 1, 15, 15, 15, "power_overloader");
/* 17 */     return boxes;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockPowerOverload.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */