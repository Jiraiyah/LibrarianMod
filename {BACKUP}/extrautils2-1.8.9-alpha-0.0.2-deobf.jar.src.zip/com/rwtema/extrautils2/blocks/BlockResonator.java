/*    */ package com.rwtema.extrautils2.blocks;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlockStatic;
/*    */ import com.rwtema.extrautils2.backend.model.Box;
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockResonator extends XUBlockStatic
/*    */ {
/*    */   public BlockResonator()
/*    */   {
/* 13 */     super(net.minecraft.block.material.Material.rock);
/*    */   }
/*    */   
/*    */   public BoxModel getModel(IBlockState state)
/*    */   {
/* 18 */     BoxModel boxes = new BoxModel();
/* 19 */     boxes.addBoxI(0, 0, 0, 16, 15, 16, "resonator_side").setTextureSides(new Object[] { Integer.valueOf(0), "resonator_bottom", Integer.valueOf(1), "resonator_top" });
/* 20 */     return boxes;
/*    */   }
/*    */   
/*    */   public boolean hasTileEntity(IBlockState state)
/*    */   {
/* 25 */     return true;
/*    */   }
/*    */   
/*    */   public net.minecraft.tileentity.TileEntity createTileEntity(World world, IBlockState state)
/*    */   {
/* 30 */     return new com.rwtema.extrautils2.tile.TileResonator();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockResonator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */