/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.PropertyEnumSimple;
/*     */ import com.rwtema.extrautils2.backend.XUBlockFull;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.textures.TextureRedstoneClock;
/*     */ import com.rwtema.extrautils2.utils.datastructures.ThreadLocalBoolean;
/*     */ import java.util.HashMap;
/*     */ import java.util.Random;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockRedstoneClock extends XUBlockFull
/*     */ {
/*  23 */   public static final PropertyEnumSimple<PowerState> propertyPowerState = new PropertyEnumSimple(PowerState.class);
/*     */   public static final int POWER_TIME = 2;
/*     */   public static final int TICK_TIME = 20;
/*  26 */   final ThreadLocal<Boolean> canProvidePower = new ThreadLocalBoolean(false);
/*  27 */   final ThreadLocal<Boolean> changing = new ThreadLocalBoolean(false);
/*     */   
/*     */   public BlockRedstoneClock() {
/*  30 */     super(net.minecraft.block.material.Material.rock);
/*     */     
/*  32 */     for (PowerState powerState : PowerState.values()) {
/*  33 */       powerState.state = getDefaultState().withProperty(propertyPowerState, powerState);
/*     */     }
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/*  39 */     return new XUBlockStateCreator(this, new IProperty[] { propertyPowerState });
/*     */   }
/*     */   
/*     */   public void registerTextures()
/*     */   {
/*  44 */     Textures.register(new String[] { "redstone_clock_off" });
/*  45 */     Textures.textureNames.put("redstone_clock_on", new TextureRedstoneClock("ExtraUtils2:redstone_clock_on"));
/*     */   }
/*     */   
/*     */   public String getTexture(IBlockState state, EnumFacing side)
/*     */   {
/*  50 */     if (state.getValue(propertyPowerState) == PowerState.DISABLED) {
/*  51 */       return "redstone_clock_off";
/*     */     }
/*  53 */     return "redstone_clock_on";
/*     */   }
/*     */   
/*     */   public int getMobilityFlag()
/*     */   {
/*  58 */     return 2;
/*     */   }
/*     */   
/*     */   public int getWeakPower(IBlockAccess worldIn, BlockPos pos, IBlockState state, EnumFacing side)
/*     */   {
/*  63 */     if (!((Boolean)this.canProvidePower.get()).booleanValue()) {
/*  64 */       return 0;
/*     */     }
/*  66 */     if (state.getValue(propertyPowerState) == PowerState.ENABLED_POWERED) return 15;
/*  67 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isSideSolid(IBlockAccess world, BlockPos pos, EnumFacing side)
/*     */   {
/*  73 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isBlockNormalCube()
/*     */   {
/*  78 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canProvidePower()
/*     */   {
/*  83 */     return true;
/*     */   }
/*     */   
/*     */   public void onBlockAdded(World worldIn, BlockPos pos, IBlockState state)
/*     */   {
/*  88 */     worldIn.scheduleBlockUpdate(pos, this, 1, 0);
/*     */   }
/*     */   
/*     */   public boolean canConnectRedstone(IBlockAccess world, BlockPos pos, EnumFacing side)
/*     */   {
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public void onNeighborBlockChange(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock)
/*     */   {
/*  98 */     if (((Boolean)this.changing.get()).booleanValue()) return;
/*  99 */     boolean powered = isPowered(worldIn, pos);
/*     */     
/* 101 */     PowerState value = (PowerState)state.getValue(propertyPowerState);
/*     */     
/* 103 */     if ((powered) && (value != PowerState.DISABLED)) {
/* 104 */       worldIn.setBlockState(pos, PowerState.DISABLED.state, 3);
/* 105 */     } else if ((!powered) && (value == PowerState.DISABLED)) {
/* 106 */       int l = (int)(worldIn.getTotalWorldTime() % 20L);
/*     */       
/* 108 */       this.changing.set(Boolean.valueOf(true));
/* 109 */       if (l < 2) {
/* 110 */         worldIn.setBlockState(pos, PowerState.ENABLED_POWERED.state, 3);
/* 111 */         worldIn.scheduleBlockUpdate(pos, this, 2 - l, 0);
/*     */       } else {
/* 113 */         worldIn.setBlockState(pos, PowerState.ENABLED_NOT_POWERED.state, 3);
/* 114 */         worldIn.scheduleBlockUpdate(pos, this, 20 - l, 0);
/*     */       }
/* 116 */       this.changing.set(Boolean.valueOf(false));
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand)
/*     */   {
/* 122 */     PowerState powerState = (PowerState)state.getValue(propertyPowerState);
/*     */     
/* 124 */     if (powerState == PowerState.DISABLED) { return;
/*     */     }
/* 126 */     int l = (int)(worldIn.getTotalWorldTime() % 20L);
/*     */     
/* 128 */     this.changing.set(Boolean.valueOf(true));
/* 129 */     if (l < 2) {
/* 130 */       worldIn.setBlockState(pos, PowerState.ENABLED_POWERED.state, 1);
/* 131 */       worldIn.scheduleBlockUpdate(pos, this, 2 - l, 0);
/*     */     } else {
/* 133 */       worldIn.setBlockState(pos, PowerState.ENABLED_NOT_POWERED.state, 1);
/* 134 */       if (isPowered(worldIn, pos)) {
/* 135 */         worldIn.setBlockState(pos, PowerState.DISABLED.state, 3);
/*     */       } else {
/* 137 */         worldIn.scheduleBlockUpdate(pos, this, 20 - l, 0);
/*     */       }
/*     */     }
/* 140 */     this.changing.set(Boolean.valueOf(false));
/*     */   }
/*     */   
/*     */   @javax.annotation.Nonnull
/*     */   public BoxModel getWorldModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/* 146 */     return super.getWorldModel(world, pos, state);
/*     */   }
/*     */   
/*     */   private boolean isPowered(IBlockAccess worldIn, BlockPos pos) {
/* 150 */     this.canProvidePower.set(Boolean.valueOf(false));
/* 151 */     boolean powered = false;
/* 152 */     for (EnumFacing side : EnumFacing.values()) {
/* 153 */       if (worldIn.getStrongPower(pos.offset(side), side) > 0) {
/* 154 */         powered = true;
/* 155 */         break;
/*     */       }
/*     */     }
/* 158 */     this.canProvidePower.set(Boolean.valueOf(true));
/* 159 */     return powered;
/*     */   }
/*     */   
/*     */   static enum PowerState {
/* 163 */     ENABLED_NOT_POWERED, 
/* 164 */     ENABLED_POWERED, 
/* 165 */     DISABLED;
/*     */     
/*     */     public IBlockState state;
/*     */     
/*     */     private PowerState() {}
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockRedstoneClock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */