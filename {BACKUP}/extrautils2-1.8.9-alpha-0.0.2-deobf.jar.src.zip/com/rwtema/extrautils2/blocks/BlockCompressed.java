/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.google.common.base.Throwables;
/*     */ import com.rwtema.extrautils2.backend.XUBlockFull;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.textures.TextureCompressed;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.blockaccess.BlockAccessDelegate;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.properties.PropertyInteger;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.Explosion;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockCompressed extends XUBlockFull
/*     */ {
/*     */   public final PropertyInteger property_compression;
/*     */   private final IBlockState baseState;
/*     */   private final String texture;
/*     */   private final int max_n;
/*     */   private final Block baseBlock;
/*     */   
/*     */   public BlockCompressed(IBlockState baseState, String texture, int max_n)
/*     */   {
/*  34 */     super(baseState.getBlock().getMaterial());
/*  35 */     this.baseState = baseState;
/*  36 */     this.baseBlock = baseState.getBlock();
/*  37 */     this.texture = texture;
/*  38 */     this.max_n = max_n;
/*  39 */     setHardness(2.0F);
/*  40 */     setSoundType(field_149769_e);
/*  41 */     setResistance(10.0F);
/*  42 */     this.property_compression = PropertyInteger.create("Compression_level_" + texture, 1, max_n);
/*  43 */     setBlockState(new XUBlockStateCreator(this, false, new net.minecraft.block.properties.IProperty[] { this.property_compression }));
/*     */   }
/*     */   
/*     */   public void registerTextures()
/*     */   {
/*  48 */     for (int i = 0; i <= this.max_n; i++) {
/*  49 */       com.rwtema.extrautils2.backend.model.Textures.textureNames.put("compr_" + this.texture + "_" + i, new TextureCompressed(this.texture, i, MathHelper.sqrt_float(this.max_n * 8) + 0.5F));
/*     */     }
/*     */   }
/*     */   
/*     */   public String getTexture(IBlockState state, EnumFacing side)
/*     */   {
/*  55 */     int i = ((Integer)state.getValue(this.property_compression)).intValue();
/*  56 */     return "compr_" + this.texture + "_" + i;
/*     */   }
/*     */   
/*     */   public boolean canHarvestBlock(IBlockAccess world, final BlockPos pos, EntityPlayer player)
/*     */   {
/*  61 */     net.minecraftforge.common.ForgeHooks.canHarvestBlock(this.baseBlock, player, new BlockAccessDelegate(world)
/*     */     {
/*     */ 
/*  64 */       public IBlockState getBlockState(BlockPos p) { return p.equals(pos) ? BlockCompressed.this.baseState : super.getBlockState(pos); } }, pos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFireSource(World worldIn, BlockPos pos, EnumFacing side)
/*     */   {
/*  71 */     IBlockState oldState = worldIn.getBlockState(pos);
/*     */     try {
/*  73 */       worldIn.setBlockState(pos, this.baseState, 4);
/*  74 */       boolean v = this.baseBlock.isFireSource(worldIn, pos, side);
/*  75 */       worldIn.setBlockState(pos, oldState, 4);
/*  76 */       return v;
/*     */     } catch (Throwable err) {
/*  78 */       worldIn.setBlockState(pos, oldState, 4);
/*  79 */       throw Throwables.propagate(err);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean canEntityDestroy(IBlockAccess world, BlockPos pos, Entity entity)
/*     */   {
/*  85 */     int value = ((Integer)world.getBlockState(pos).getValue(this.property_compression)).intValue();
/*  86 */     return value <= 6;
/*     */   }
/*     */   
/*     */   public float getExplosionResistance(World world, BlockPos pos, Entity exploder, Explosion explosion)
/*     */   {
/*  91 */     int value = ((Integer)world.getBlockState(pos).getValue(this.property_compression)).intValue();
/*  92 */     return this.baseBlock.getExplosionResistance(exploder) * (int)Math.pow(1.5D, value - 1);
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/*  97 */     IBlockState state = this.xuBlockState.getStateFromItemStack(stack);
/*  98 */     int value = ((Integer)state.getValue(this.property_compression)).intValue();
/*  99 */     tooltip.add(Lang.translateArgs("%s Blocks", new Object[] { Double.valueOf(Math.pow(9.0D, value)) }));
/*     */   }
/*     */   
/*     */   public float getBlockHardness(World worldIn, BlockPos pos)
/*     */   {
/* 104 */     int value = ((Integer)worldIn.getBlockState(pos).getValue(this.property_compression)).intValue();
/* 105 */     IBlockState oldState = worldIn.getBlockState(pos);
/*     */     try {
/* 107 */       worldIn.setBlockState(pos, this.baseState, 4);
/* 108 */       float v = this.baseBlock.getBlockHardness(worldIn, pos) * (float)Math.pow(2.25D, value - 1);
/* 109 */       worldIn.setBlockState(pos, oldState, 4);
/* 110 */       return v;
/*     */     } catch (Throwable err) {
/* 112 */       worldIn.setBlockState(pos, oldState, 4);
/* 113 */       throw Throwables.propagate(err);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockCompressed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */