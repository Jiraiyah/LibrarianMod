/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStatic;
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.backend.model.MutableModel;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem.ModelLayer;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.backend.model.Transforms;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.IGrowable;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyInteger;
/*     */ import net.minecraft.block.state.BlockState;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.EnumPlantType;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockEnderLilly extends XUBlockStatic implements net.minecraftforge.common.IPlantable, IGrowable
/*     */ {
/*  44 */   public static final EnumPlantType ender = EnumPlantType.getPlantType("Ender");
/*  45 */   public static final PropertyInteger GROWTH_STATE = PropertyInteger.create("Growth", 0, 7);
/*  46 */   public static final HashSet<IBlockState> end_stone_states = com.google.common.collect.Sets.newHashSet(Blocks.end_stone.getBlockState().getValidStates());
/*  47 */   static float[] size_w = { 0.125F, 0.1875F, 0.25F, 0.375F, 0.5F, 0.5F, 0.5F, 0.5F };
/*  48 */   static float[] size_h = { 0.25F, 0.4375F, 0.4375F, 0.5F, 0.6875F, 0.75F, 0.75F, 0.875F };
/*     */   public final IBlockState FULLY_GROWN_STATE;
/*     */   
/*     */   public BlockEnderLilly() {
/*  52 */     super(Material.plants);
/*  53 */     setTickRandomly(true);
/*  54 */     setHardness(0.0F);
/*  55 */     this.FULLY_GROWN_STATE = getDefaultState().withProperty(GROWTH_STATE, Integer.valueOf(7));
/*     */   }
/*     */   
/*     */   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand)
/*     */   {
/*  60 */     int i = ((Integer)state.getValue(GROWTH_STATE)).intValue();
/*  61 */     if (i >= 7) { return;
/*     */     }
/*  63 */     boolean endStone = isEndStoneBlock(worldIn, pos);
/*  64 */     long period = endStone ? 17000L : 96000L;
/*     */     
/*  66 */     long midPeriod = worldIn.getWorldTime() % (2L * period);
/*  67 */     if ((i % 2 == 0 ? 1 : 0) != (midPeriod <= period ? 1 : 0)) {
/*  68 */       return;
/*     */     }
/*     */     
/*  71 */     if (rand.nextInt(endStone ? 2 : 40) != 0) {
/*  72 */       return;
/*     */     }
/*  74 */     worldIn.setBlockState(pos, state.withProperty(GROWTH_STATE, Integer.valueOf(i + 1)), 2);
/*     */   }
/*     */   
/*     */   public boolean isEndStoneBlock(IBlockAccess worldIn, BlockPos pos) {
/*  78 */     return end_stone_states.contains(worldIn.getBlockState(pos.down()));
/*     */   }
/*     */   
/*     */   public void grow(World worldIn, Random rand, BlockPos pos, IBlockState state)
/*     */   {
/*  83 */     int i = ((Integer)state.getValue(GROWTH_STATE)).intValue();
/*  84 */     i += MathHelper.getRandomIntegerInRange(worldIn.rand, 2, 5);
/*  85 */     if (i >= 7) {
/*  86 */       i = 7;
/*  87 */       if (worldIn.getBlockState(pos.down()).getBlock() == Blocks.redstone_ore) {
/*  88 */         worldIn.setBlockState(pos.down(), Blocks.lit_redstone_ore.getDefaultState());
/*     */       }
/*     */     }
/*     */     
/*  92 */     worldIn.setBlockState(pos, state.withProperty(GROWTH_STATE, Integer.valueOf(i)), 2);
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/*  97 */     return new XUBlockStateCreator(this, new IProperty[] { GROWTH_STATE });
/*     */   }
/*     */   
/*     */   public BoxModel getModel(IBlockState state)
/*     */   {
/* 102 */     int value = ((Integer)state.getValue(GROWTH_STATE)).intValue();
/* 103 */     BoxModel boxes = BoxModel.crossBoxModel().setTexture("plants/ender_lilly_stage_" + value);
/* 104 */     for (Box box : boxes) {
/* 105 */       box.noCollide = true;
/* 106 */       box.setLayer(EnumWorldBlockLayer.CUTOUT);
/*     */     }
/*     */     
/* 109 */     boxes.overrideBounds = new Box(0.5F - size_w[value], 0.0F, 0.5F - size_w[value], 0.5F + size_w[value], size_h[value], 0.5F + size_w[value]);
/*     */     
/* 111 */     return boxes;
/*     */   }
/*     */   
/*     */   public boolean canGrow(World worldIn, BlockPos pos, IBlockState state, boolean isClient)
/*     */   {
/* 116 */     return ((Integer)state.getValue(GROWTH_STATE)).intValue() < 7;
/*     */   }
/*     */   
/*     */   public boolean canUseBonemeal(World worldIn, Random rand, BlockPos pos, IBlockState state)
/*     */   {
/* 121 */     return false;
/*     */   }
/*     */   
/*     */   public void onNeighborBlockChange(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock)
/*     */   {
/* 126 */     if (!validLocation(worldIn, pos)) {
/* 127 */       dropBlockAsItem(worldIn, pos, state, 0);
/* 128 */       worldIn.setBlockToAir(pos);
/* 129 */       return;
/*     */     }
/*     */     
/* 132 */     super.onNeighborBlockChange(worldIn, pos, state, neighborBlock);
/*     */   }
/*     */   
/*     */   public boolean canReplace(World worldIn, BlockPos pos, EnumFacing side, ItemStack stack)
/*     */   {
/* 137 */     return (validLocation(worldIn, pos)) && (super.canReplace(worldIn, pos, side, stack));
/*     */   }
/*     */   
/*     */   public List<ItemStack> getDrops(IBlockAccess world, BlockPos pos, IBlockState state, int fortune)
/*     */   {
/* 142 */     List<ItemStack> drops = super.getDrops(world, pos, state, fortune);
/* 143 */     if (state == this.FULLY_GROWN_STATE)
/* 144 */       addAdditionalDrops(world, pos, fortune, drops, (world instanceof World) ? ((World)world).rand : RANDOM);
/* 145 */     return drops;
/*     */   }
/*     */   
/*     */   protected List<ItemStack> addAdditionalDrops(IBlockAccess world, BlockPos pos, int fortune, List<ItemStack> drops, Random random) {
/* 149 */     drops.add(new ItemStack(Items.ender_pearl, 1));
/*     */     
/* 151 */     if ((isEndStoneBlock(world, pos)) && (random.nextInt(20) <= 1 + fortune)) {
/* 152 */       drops.add(new ItemStack(this, 1));
/*     */     }
/* 154 */     return drops;
/*     */   }
/*     */   
/*     */   public boolean validLocation(World world, BlockPos pos) {
/* 158 */     Block block = world.getBlockState(pos.down()).getBlock();
/* 159 */     return (isEndStoneBlock(world, pos)) || (block == Blocks.dirt) || (block == Blocks.grass);
/*     */   }
/*     */   
/*     */   public EnumPlantType getPlantType(IBlockAccess world, BlockPos pos)
/*     */   {
/* 164 */     return ender;
/*     */   }
/*     */   
/*     */   public IBlockState getPlant(IBlockAccess world, BlockPos pos)
/*     */   {
/* 169 */     if ((world == null) || (pos == null)) return getDefaultState();
/* 170 */     IBlockState state = world.getBlockState(pos);
/* 171 */     if (state.getBlock() != this) return getDefaultState();
/* 172 */     return state;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public MutableModel createInventoryMutableModel()
/*     */   {
/* 178 */     return new PassthruModelItem.ModelLayer(Transforms.itemTransforms);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/* 184 */     super.registerTextures();
/* 185 */     Textures.register(new String[] { "plants/ender_lilly_seed" });
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addInventoryQuads(MutableModel result, ItemStack stack)
/*     */   {
/* 191 */     PassthruModelItem.ModelLayer layer = (PassthruModelItem.ModelLayer)result;
/* 192 */     layer.addSprite((net.minecraft.client.renderer.texture.TextureAtlasSprite)Textures.sprites.get("plants/ender_lilly_seed"));
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World worldIn, BlockPos pos, IBlockState state, Random rand)
/*     */   {
/* 198 */     if ((((Integer)state.getValue(GROWTH_STATE)).intValue() != 7) || (rand.nextInt(5) != 0)) { return;
/*     */     }
/*     */     
/* 201 */     int ddx = rand.nextInt(2) * 2 - 1;
/* 202 */     int ddz = rand.nextInt(2) * 2 - 1;
/* 203 */     double dx = rand.nextFloat() * 1.0F * ddx;
/* 204 */     double dy = (rand.nextFloat() - 0.5D) * 0.125D;
/* 205 */     double dz = rand.nextFloat() * 1.0F * ddz;
/* 206 */     double x = pos.getX() + 0.5D + 0.25D * ddx;
/* 207 */     double y = pos.getY() + rand.nextFloat();
/* 208 */     double z = pos.getZ() + 0.5D + 0.25D * ddz;
/*     */     
/* 210 */     worldIn.spawnParticle(EnumParticleTypes.PORTAL, x, y, z, dx, dy, dz, new int[0]);
/*     */   }
/*     */   
/*     */   public int getWeakPower(IBlockAccess worldIn, BlockPos pos, IBlockState state, EnumFacing side)
/*     */   {
/* 215 */     return state == this.FULLY_GROWN_STATE ? 15 : 0;
/*     */   }
/*     */   
/*     */   public boolean canConnectRedstone(IBlockAccess world, BlockPos pos, EnumFacing side)
/*     */   {
/* 220 */     return world.getBlockState(pos) == this.FULLY_GROWN_STATE;
/*     */   }
/*     */   
/*     */   public boolean canProvidePower()
/*     */   {
/* 225 */     return true;
/*     */   }
/*     */   
/*     */   public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn)
/*     */   {
/* 230 */     if (((Integer)state.getValue(GROWTH_STATE)).intValue() >= 3) {
/* 231 */       if ((entityIn instanceof EntityItem)) {
/* 232 */         ItemStack item = ((EntityItem)entityIn).getEntityItem();
/*     */         
/* 234 */         if ((item != null) && ((item.getItem() == Items.ender_pearl) || (item.getItem() == Item.getItemFromBlock(this)))) {
/* 235 */           return;
/*     */         }
/*     */         
/* 238 */         if (worldIn.isRemote) {
/* 239 */           worldIn.spawnParticle(EnumParticleTypes.CRIT, entityIn.posX, entityIn.posY, entityIn.posZ, 0.0D, 0.0D, 0.0D, new int[0]);
/*     */         }
/*     */       }
/*     */       
/* 243 */       if ((entityIn instanceof EntityEnderman)) {
/* 244 */         return;
/*     */       }
/*     */       
/* 247 */       entityIn.attackEntityFrom(DamageSource.cactus, 0.1F);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/* 253 */     if (state != this.FULLY_GROWN_STATE) {
/* 254 */       return false;
/*     */     }
/*     */     
/* 257 */     worldIn.setBlockState(pos, getDefaultState());
/*     */     
/* 259 */     if (worldIn.isRemote) {
/* 260 */       return true;
/*     */     }
/* 262 */     List<ItemStack> drops = addAdditionalDrops(worldIn, pos, net.minecraft.enchantment.EnchantmentHelper.func_77517_e(playerIn), com.google.common.collect.Lists.newArrayList(), worldIn.rand);
/*     */     
/* 264 */     for (ItemStack drop : drops) {
/* 265 */       spawnAsEntity(worldIn, pos, drop);
/*     */     }
/* 267 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockEnderLilly.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */