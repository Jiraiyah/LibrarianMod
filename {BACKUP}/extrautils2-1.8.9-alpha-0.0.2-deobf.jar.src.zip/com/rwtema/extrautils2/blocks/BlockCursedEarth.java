/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.PropertyEnumSimple;
/*     */ import com.rwtema.extrautils2.backend.XUBlockConnectedTextureBase;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.textures.ConnectedTexture;
/*     */ import com.rwtema.extrautils2.textures.ISolidWorldTexture;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EnumCreatureType;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.entity.ai.attributes.IAttributeInstance;
/*     */ import net.minecraft.entity.monster.EntityCreeper;
/*     */ import net.minecraft.entity.monster.EntityMob;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraft.world.biome.BiomeGenBase.SpawnListEntry;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class BlockCursedEarth extends XUBlockConnectedTextureBase
/*     */ {
/*  36 */   public static final PropertyEnumSimple<Type> TYPE = new PropertyEnumSimple(Type.class);
/*     */   ISolidWorldTexture tex;
/*     */   
/*  39 */   public BlockCursedEarth() { super(Material.grass);
/*  40 */     MinecraftForge.EVENT_BUS.register(this);
/*  41 */     setTickRandomly(true);
/*     */   }
/*     */   
/*     */   public Item getItemDropped(IBlockState state, Random rand, int fortune)
/*     */   {
/*  46 */     return Item.getItemFromBlock(net.minecraft.init.Blocks.dirt);
/*     */   }
/*     */   
/*     */   public int damageDropped(IBlockState state)
/*     */   {
/*  51 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean canSilkHarvest(World world, BlockPos pos, IBlockState state, EntityPlayer player)
/*     */   {
/*  56 */     return true;
/*     */   }
/*     */   
/*     */   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand)
/*     */   {
/*  61 */     if ((worldIn == null) || (worldIn.isRemote)) return;
/*  62 */     WorldServer world = (WorldServer)worldIn;
/*     */     
/*  64 */     EnumCreatureType type = EnumCreatureType.MONSTER;
/*  65 */     BiomeGenBase.SpawnListEntry entry = world.getSpawnListEntryForTypeAt(type, pos);
/*     */     
/*  67 */     if (!world.canCreatureTypeSpawnHere(type, entry, pos)) {
/*     */       return;
/*     */     }
/*     */     EntityLiving mob;
/*     */     try
/*     */     {
/*  73 */       mob = (EntityLiving)entry.entityClass.getConstructor(new Class[] { World.class }).newInstance(new Object[] { world });
/*     */     } catch (Exception exception) {
/*  75 */       exception.printStackTrace();
/*  76 */       return;
/*     */     }
/*     */     
/*  79 */     float x = pos.getX() + 0.5F;
/*  80 */     float y = pos.getY() + 1;
/*  81 */     float z = pos.getZ() + 0.5F;
/*  82 */     mob.setLocationAndAngles(x, y, z, world.rand.nextFloat() * 360.0F, 0.0F);
/*     */     
/*  84 */     if (!net.minecraftforge.event.ForgeEventFactory.doSpecialSpawn(mob, world, x, y, z)) {
/*  85 */       mob.onInitialSpawn(world.getDifficultyForLocation(new BlockPos(mob)), null);
/*     */     }
/*  87 */     if ((!mob.isNotColliding()) || (!mob.getCanSpawnHere())) { return;
/*     */     }
/*  89 */     mob.forceSpawn = true;
/*  90 */     mob.getEntityData().setInteger("CursedEarth", 1200);
/*  91 */     mob.addPotionEffect(new PotionEffect(Potion.moveSpeed.field_76415_H, 3600, 1));
/*  92 */     mob.addPotionEffect(new PotionEffect(Potion.damageBoost.field_76415_H, 3600, 1));
/*  93 */     IAttributeInstance entityAttribute = mob.getEntityAttribute(net.minecraft.entity.SharedMonsterAttributes.FOLLOW_RANGE);
/*  94 */     if (entityAttribute != null) {
/*  95 */       entityAttribute.applyModifier(new AttributeModifier("CursedEarthBonus", 0.5D, 2));
/*     */     }
/*  97 */     if ((state.getValue(TYPE) == Type.CURSED_SUPERCHARGED) && ((mob instanceof EntityMob))) {
/*  98 */       ((EntityMob)mob).hurtResistantTime = 40;
/*  99 */       mob.setCanPickUpLoot(true);
/*     */       
/* 101 */       mob.enablePersistence();
/*     */       
/* 103 */       if ((mob instanceof EntityCreeper)) {
/* 104 */         mob.func_70096_w().func_75692_b(17, Byte.valueOf((byte)1));
/*     */       }
/*     */       
/* 107 */       mob.getEntityData().removeTag("CursedEarth");
/* 108 */       if (!world.playerEntities.isEmpty()) {
/* 109 */         double d = entityAttribute != null ? entityAttribute.getAttributeValue() : 16.0D;
/*     */         
/*     */ 
/* 112 */         EntityPlayer closestPlayer = world.getClosestPlayerToEntity(mob, d);
/* 113 */         if (closestPlayer != null) {
/* 114 */           EntityMob entityMob = (EntityMob)mob;
/* 115 */           if (entityMob.getAttackTarget() == null) {
/* 116 */             entityMob.setAttackTarget(closestPlayer);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 122 */     world.spawnEntityInWorld(mob);
/* 123 */     mob.playLivingSound();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void entTick(LivingEvent.LivingUpdateEvent event) {
/* 128 */     NBTTagCompound entityData = event.entity.getEntityData();
/* 129 */     if (entityData.hasKey("CursedEarth")) {
/* 130 */       int cursedEarth = entityData.getInteger("CursedEarth");
/* 131 */       if (cursedEarth > 0) {
/* 132 */         if (cursedEarth == 1) {
/* 133 */           event.entity.setDead();
/*     */         } else {
/* 135 */           cursedEarth--;
/* 136 */           entityData.setInteger("CursedEarth", cursedEarth);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/* 144 */     return new XUBlockStateCreator(this, new IProperty[] { TYPE });
/*     */   }
/*     */   
/*     */   public boolean isOpaqueCube()
/*     */   {
/* 149 */     return true;
/*     */   }
/*     */   
/*     */   public ISolidWorldTexture getConnectedTexture(IBlockState state, EnumFacing side)
/*     */   {
/* 154 */     return this.tex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void registerTextures()
/*     */   {
/* 161 */     this.tex = new ConnectedTexture("evil_earth", getDefaultState(), this);
/*     */   }
/*     */   
/*     */   public static enum Type {
/* 165 */     CURSED_NORMAL, 
/* 166 */     CURSED_SUPERCHARGED;
/*     */     
/*     */     private Type() {}
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockCursedEarth.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */