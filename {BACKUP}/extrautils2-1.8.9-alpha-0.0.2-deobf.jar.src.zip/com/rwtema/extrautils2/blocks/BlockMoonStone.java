/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUBlockStatic;
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxMimic;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.items.ItemIngredients.Type;
/*     */ import com.rwtema.extrautils2.utils.helpers.ColorHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.WorldHelper;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockStone;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.MinecraftForgeClient;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockMoonStone extends XUBlockStatic
/*     */ {
/*  30 */   public static IBlockState mimicState = Blocks.stone.getDefaultState().withProperty(BlockStone.VARIANT, net.minecraft.block.BlockStone.EnumType.STONE);
/*     */   
/*     */   public BlockMoonStone() {
/*  33 */     super(net.minecraft.block.material.Material.rock);
/*     */   }
/*     */   
/*     */   public int func_176207_c(IBlockAccess worldIn, BlockPos pos)
/*     */   {
/*  38 */     EnumWorldBlockLayer renderLayer = MinecraftForgeClient.getRenderLayer();
/*  39 */     if (renderLayer == EnumWorldBlockLayer.TRANSLUCENT) {
/*  40 */       return 15728880;
/*     */     }
/*     */     
/*  43 */     return super.func_176207_c(worldIn, pos);
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {}
/*     */   
/*     */ 
/*     */   public boolean isFullMoon(World world)
/*     */   {
/*  53 */     return world.getCurrentMoonPhaseFactor() == 1.0F;
/*     */   }
/*     */   
/*     */   @javax.annotation.Nonnull
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BoxModel getRenderModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/*  60 */     BoxModel model = BoxModel.newStandardBlock(false);
/*  61 */     model.add(new BoxMimic(world, pos, mimicState));
/*     */     
/*  63 */     if (WorldHelper.isFullMoon(Minecraft.getMinecraft().theWorld)) {
/*  64 */       Box box = model.addBox(-9.765625E-4F, -9.765625E-4F, -9.765625E-4F, 1.0009766F, 1.0009766F, 1.0009766F).setTexture("moon_stone_cutout");
/*  65 */       box.layer = EnumWorldBlockLayer.TRANSLUCENT;
/*  66 */       int combinedLight = world.getCombinedLight(pos, 0);
/*  67 */       int b = combinedLight >> 4 & 0xF;
/*  68 */       b = (int)(b * WorldHelper.getMoonBrightness(Minecraft.getMinecraft().theWorld));
/*  69 */       int alpha = 255 - 2 * b * 16;
/*  70 */       box.color = ColorHelper.makeAlphaWhite(alpha);
/*     */     }
/*  72 */     return model;
/*     */   }
/*     */   
/*     */   public Item getItemDropped(IBlockState state, Random rand, int fortune)
/*     */   {
/*  77 */     return Blocks.stone.getItemDropped(mimicState, rand, fortune);
/*     */   }
/*     */   
/*     */   public int damageDropped(IBlockState state)
/*     */   {
/*  82 */     return Blocks.stone.damageDropped(mimicState);
/*     */   }
/*     */   
/*     */   public int quantityDropped(Random random)
/*     */   {
/*  87 */     return 1;
/*     */   }
/*     */   
/*     */   public List<ItemStack> getDrops(IBlockAccess world, BlockPos pos, IBlockState state, int fortune)
/*     */   {
/*  92 */     List<ItemStack> drops = Blocks.stone.getDrops(world, pos, mimicState, fortune);
/*  93 */     if ((world instanceof World)) {
/*  94 */       World world1 = (World)world;
/*  95 */       if (WorldHelper.isFullMoon(world1)) {
/*  96 */         drops.add(ItemIngredients.Type.MOON_STONE.newStack(1));
/*     */       }
/*     */     }
/*  99 */     return drops;
/*     */   }
/*     */   
/*     */   public BoxModel getModel(IBlockState state)
/*     */   {
/* 104 */     BoxModel model = BoxModel.newStandardBlock(false);
/* 105 */     model.add(new BoxMimic(mimicState));
/* 106 */     Box box = model.addBox(-9.765625E-4F, -9.765625E-4F, -9.765625E-4F, 1.0009766F, 1.0009766F, 1.0009766F).setTexture("moon_stone_cutout");
/* 107 */     box.layer = EnumWorldBlockLayer.TRANSLUCENT;
/* 108 */     return model;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockMoonStone.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */