/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStatic;
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.backend.model.MutableModel;
/*     */ import com.rwtema.extrautils2.backend.model.PassthruModelItem.ModelLayer;
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.backend.model.Transforms;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.IGrowable;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyInteger;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.EnumPlantType;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockRedOrchid extends XUBlockStatic implements net.minecraftforge.common.IPlantable, IGrowable
/*     */ {
/*  41 */   public static final PropertyInteger GROWTH_STATE = PropertyInteger.create("Growth", 0, 6);
/*  42 */   static float[] size_w = { 0.0625F, 0.0625F, 0.125F, 0.1875F, 0.1875F, 0.25F, 0.3125F };
/*  43 */   static float[] size_h = { 0.3125F, 0.5F, 0.5625F, 0.6875F, 0.75F, 0.8125F, 1.0F };
/*     */   public final IBlockState FULLY_GROWN_STATE;
/*  45 */   EnumPlantType redstone = EnumPlantType.getPlantType("Redstone");
/*  46 */   HashSet<IBlockState> validStates = null;
/*     */   
/*     */   public BlockRedOrchid() {
/*  49 */     super(Material.plants);
/*  50 */     setTickRandomly(true);
/*  51 */     setHardness(0.0F);
/*  52 */     this.FULLY_GROWN_STATE = getDefaultState().withProperty(GROWTH_STATE, Integer.valueOf(6));
/*     */   }
/*     */   
/*     */   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand)
/*     */   {
/*  57 */     int i = ((Integer)state.getValue(GROWTH_STATE)).intValue();
/*  58 */     if ((i >= 6) || (rand.nextInt(3) != 0)) return;
/*  59 */     worldIn.setBlockState(pos, state.withProperty(GROWTH_STATE, Integer.valueOf(i + 1)), 2);
/*  60 */     if ((i + 1 == 6) && 
/*  61 */       (worldIn.getBlockState(pos.down()).getBlock() == Blocks.redstone_ore)) {
/*  62 */       worldIn.setBlockState(pos.down(), Blocks.lit_redstone_ore.getDefaultState());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void grow(World worldIn, Random rand, BlockPos pos, IBlockState state)
/*     */   {
/*  69 */     int i = ((Integer)state.getValue(GROWTH_STATE)).intValue();
/*  70 */     i += MathHelper.getRandomIntegerInRange(worldIn.rand, 2, 5);
/*  71 */     if (i >= 6) {
/*  72 */       i = 6;
/*  73 */       if (worldIn.getBlockState(pos.down()).getBlock() == Blocks.redstone_ore) {
/*  74 */         worldIn.setBlockState(pos.down(), Blocks.lit_redstone_ore.getDefaultState());
/*     */       }
/*     */     }
/*     */     
/*  78 */     worldIn.setBlockState(pos, state.withProperty(GROWTH_STATE, Integer.valueOf(i)), 2);
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/*  83 */     return new XUBlockStateCreator(this, new IProperty[] { GROWTH_STATE });
/*     */   }
/*     */   
/*     */   public BoxModel getModel(IBlockState state)
/*     */   {
/*  88 */     int value = ((Integer)state.getValue(GROWTH_STATE)).intValue();
/*  89 */     BoxModel boxes = BoxModel.crossBoxModel().setTexture("plants/redorchid_" + value);
/*  90 */     boxes.addBoxI(0, 0, 0, 16, 0, 16, "plants/redorchid_base_" + value).setInvisible(61);
/*  91 */     for (Box box : boxes) {
/*  92 */       box.noCollide = true;
/*  93 */       box.setLayer(EnumWorldBlockLayer.CUTOUT);
/*     */     }
/*     */     
/*  96 */     boxes.overrideBounds = new Box(0.5F - size_w[value], 0.0F, 0.5F - size_w[value], 0.5F + size_w[value], size_h[value], 0.5F + size_w[value]);
/*     */     
/*  98 */     return boxes;
/*     */   }
/*     */   
/*     */   public boolean canGrow(World worldIn, BlockPos pos, IBlockState state, boolean isClient)
/*     */   {
/* 103 */     return ((Integer)state.getValue(GROWTH_STATE)).intValue() < 6;
/*     */   }
/*     */   
/*     */   public boolean canUseBonemeal(World worldIn, Random rand, BlockPos pos, IBlockState state)
/*     */   {
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   public void onNeighborBlockChange(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock)
/*     */   {
/* 113 */     if (!validLocation(worldIn, pos)) {
/* 114 */       dropBlockAsItem(worldIn, pos, state, 0);
/* 115 */       worldIn.setBlockToAir(pos);
/* 116 */       return;
/*     */     }
/*     */     
/* 119 */     super.onNeighborBlockChange(worldIn, pos, state, neighborBlock);
/*     */     
/* 121 */     if ((state == this.FULLY_GROWN_STATE) && (worldIn.getBlockState(pos.down()).getBlock() == Blocks.redstone_ore)) {
/* 122 */       worldIn.setBlockState(pos.down(), Blocks.lit_redstone_ore.getDefaultState());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean canReplace(World worldIn, BlockPos pos, EnumFacing side, ItemStack stack)
/*     */   {
/* 128 */     return (validLocation(worldIn, pos)) && (super.canReplace(worldIn, pos, side, stack));
/*     */   }
/*     */   
/*     */   public List<ItemStack> getDrops(IBlockAccess world, BlockPos pos, IBlockState state, int fortune)
/*     */   {
/* 133 */     List<ItemStack> drops = super.getDrops(world, pos, state, fortune);
/* 134 */     if (state == this.FULLY_GROWN_STATE)
/* 135 */       addAdditionalDrops(fortune, drops, (world instanceof World) ? ((World)world).rand : RANDOM);
/* 136 */     return drops;
/*     */   }
/*     */   
/*     */   protected List<ItemStack> addAdditionalDrops(int fortune, List<ItemStack> drops, Random random) {
/* 140 */     int n = 1 + random.nextInt(1 + fortune);
/* 141 */     for (int i = 0; i < n; i++) {
/* 142 */       drops.add(new ItemStack(Items.redstone, 1));
/*     */     }
/*     */     
/* 145 */     int k = random.nextInt(3 + fortune) - random.nextInt(10);
/* 146 */     if (k > 0) {
/* 147 */       for (int i = 0; i < k; i++) {
/* 148 */         drops.add(new ItemStack(this, 1));
/*     */       }
/*     */     }
/* 151 */     return drops;
/*     */   }
/*     */   
/*     */   public boolean validLocation(World world, BlockPos pos) {
/* 155 */     if (this.validStates == null) {
/* 156 */       this.validStates = new HashSet();
/* 157 */       this.validStates.add(Blocks.redstone_ore.getDefaultState());
/* 158 */       this.validStates.add(Blocks.lit_redstone_ore.getDefaultState());
/* 159 */       com.rwtema.extrautils2.utils.helpers.ItemStackHelper.addBlockStates("oreRedstone", this.validStates);
/*     */     }
/*     */     
/* 162 */     return this.validStates.contains(world.getBlockState(pos.down()));
/*     */   }
/*     */   
/*     */   public EnumPlantType getPlantType(IBlockAccess world, BlockPos pos)
/*     */   {
/* 167 */     return this.redstone;
/*     */   }
/*     */   
/*     */   public IBlockState getPlant(IBlockAccess world, BlockPos pos)
/*     */   {
/* 172 */     if ((world == null) || (pos == null)) return getDefaultState();
/* 173 */     IBlockState state = world.getBlockState(pos);
/* 174 */     if (state.getBlock() != this) return getDefaultState();
/* 175 */     return state;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public MutableModel createInventoryMutableModel()
/*     */   {
/* 181 */     return new PassthruModelItem.ModelLayer(Transforms.itemTransforms);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/* 187 */     super.registerTextures();
/* 188 */     Textures.register(new String[] { "plants/redorchid_seeds" });
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void addInventoryQuads(MutableModel result, ItemStack stack)
/*     */   {
/* 194 */     PassthruModelItem.ModelLayer layer = (PassthruModelItem.ModelLayer)result;
/* 195 */     layer.addSprite((net.minecraft.client.renderer.texture.TextureAtlasSprite)Textures.sprites.get("plants/redorchid_seeds"));
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World worldIn, BlockPos pos, IBlockState state, Random rand)
/*     */   {
/* 201 */     if (((Integer)state.getValue(GROWTH_STATE)).intValue() != 6) { return;
/*     */     }
/* 203 */     AxisAlignedBB bb = getCollisionBoundingBox(worldIn, pos);
/* 204 */     for (int i = 0; i < 2; i++) {
/* 205 */       double x = MathHelper.getRandomDoubleInRange(rand, bb.minX, bb.maxX);
/* 206 */       double y = MathHelper.getRandomDoubleInRange(rand, bb.minY, bb.maxY);
/* 207 */       double z = MathHelper.getRandomDoubleInRange(rand, bb.minZ, bb.maxZ);
/*     */       
/* 209 */       worldIn.spawnParticle(EnumParticleTypes.REDSTONE, x, y, z, 0.0D, 0.0D, 0.0D, new int[0]);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getWeakPower(IBlockAccess worldIn, BlockPos pos, IBlockState state, EnumFacing side)
/*     */   {
/* 215 */     return state == this.FULLY_GROWN_STATE ? 15 : 0;
/*     */   }
/*     */   
/*     */   public boolean canConnectRedstone(IBlockAccess world, BlockPos pos, EnumFacing side)
/*     */   {
/* 220 */     return world.getBlockState(pos) == this.FULLY_GROWN_STATE;
/*     */   }
/*     */   
/*     */   public boolean canProvidePower()
/*     */   {
/* 225 */     return true;
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/* 230 */     if (state != this.FULLY_GROWN_STATE) {
/* 231 */       return false;
/*     */     }
/*     */     
/* 234 */     worldIn.setBlockState(pos, getDefaultState());
/*     */     
/* 236 */     if (worldIn.isRemote) {
/* 237 */       return true;
/*     */     }
/* 239 */     List<ItemStack> drops = addAdditionalDrops(net.minecraft.enchantment.EnchantmentHelper.func_77517_e(playerIn), Lists.newArrayList(), worldIn.rand);
/*     */     
/* 241 */     for (ItemStack drop : drops) {
/* 242 */       spawnAsEntity(worldIn, pos, drop);
/*     */     }
/* 244 */     return true;
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/* 249 */     tooltip.add(Lang.translatePrefix("Plant on redstone ore."));
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockRedOrchid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */