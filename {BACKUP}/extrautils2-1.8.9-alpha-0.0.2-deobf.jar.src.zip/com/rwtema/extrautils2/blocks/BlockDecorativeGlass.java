/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.PropertyEnumSimple;
/*     */ import com.rwtema.extrautils2.backend.XUBlockConnectedTextureBase;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.backend.entries.BlockClassEntry;
/*     */ import com.rwtema.extrautils2.backend.entries.IItemStackMaker;
/*     */ import com.rwtema.extrautils2.backend.entries.XU2Entries;
/*     */ import com.rwtema.extrautils2.crafting.CraftingHelper;
/*     */ import com.rwtema.extrautils2.textures.ConnectedTexture;
/*     */ import com.rwtema.extrautils2.textures.ISolidWorldTexture;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockDecorativeGlass extends XUBlockConnectedTextureBase
/*     */ {
/*  26 */   public static final PropertyEnumSimple<DecorStates> decor = new PropertyEnumSimple(DecorStates.class);
/*     */   
/*     */   public BlockDecorativeGlass() {
/*  29 */     super(net.minecraft.block.material.Material.glass);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/*  35 */     for (DecorStates decorState : ) {
/*  36 */       decorState.tex = new ConnectedTexture(decorState.toString(), this.xuBlockState.defaultState.withProperty(decor, decorState), this);
/*     */     }
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/*  42 */     return new XUBlockStateCreator(this, false, new IProperty[] { decor });
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isOpaqueCube()
/*     */   {
/*  48 */     return false;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer getBlockLayer()
/*     */   {
/*  54 */     return EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */   
/*     */   public boolean canRenderInLayer(EnumWorldBlockLayer layer)
/*     */   {
/*  59 */     return (layer == EnumWorldBlockLayer.CUTOUT) || (layer == EnumWorldBlockLayer.TRANSLUCENT);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public ISolidWorldTexture getConnectedTexture(IBlockState state, EnumFacing side)
/*     */   {
/*  65 */     return ((DecorStates)state.getValue(decor)).tex;
/*     */   }
/*     */   
/*     */   public boolean isNormalCube(IBlockAccess world, BlockPos pos)
/*     */   {
/*  70 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isFullCube() {
/*  74 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getLightOpacity(IBlockAccess world, BlockPos pos)
/*     */   {
/*  80 */     if (((world instanceof World)) && 
/*  81 */       (!((World)world).isBlockLoaded(pos))) {
/*  82 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*  86 */     IBlockState state = world.getBlockState(pos);
/*  87 */     if (state.getBlock() != this) {
/*  88 */       return 0;
/*     */     }
/*  90 */     return ((DecorStates)state.getValue(decor)).opacity;
/*     */   }
/*     */   
/*     */   public int getLightValue(IBlockAccess world, BlockPos pos)
/*     */   {
/*  95 */     if (((world instanceof World)) && 
/*  96 */       (!((World)world).isBlockLoaded(pos))) {
/*  97 */       return 0;
/*     */     }
/*     */     
/*     */ 
/* 101 */     IBlockState state = world.getBlockState(pos);
/* 102 */     if (state.getBlock() != this)
/* 103 */       return 0;
/* 104 */     return ((DecorStates)state.getValue(decor)).light_level;
/*     */   }
/*     */   
/*     */   public EnumWorldBlockLayer renderLayer(IBlockState state)
/*     */   {
/* 109 */     return ((DecorStates)state.getValue(decor)).layer;
/*     */   }
/*     */   
/*     */   public boolean canConnectRedstone(IBlockAccess world, BlockPos pos, EnumFacing side)
/*     */   {
/* 114 */     if (((world instanceof World)) && 
/* 115 */       (!((World)world).isBlockLoaded(pos))) {
/* 116 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 120 */     IBlockState state = world.getBlockState(pos);
/* 121 */     return (state.getBlock() == this) && (((DecorStates)state.getValue(decor)).redstone_level > 0);
/*     */   }
/*     */   
/*     */   public int getWeakPower(IBlockAccess worldIn, BlockPos pos, IBlockState state, EnumFacing side)
/*     */   {
/* 126 */     if (state == null) {
/* 127 */       if (((worldIn instanceof World)) && 
/* 128 */         (!((World)worldIn).isBlockLoaded(pos))) {
/* 129 */         return 0;
/*     */       }
/*     */       
/*     */ 
/* 133 */       state = worldIn.getBlockState(pos);
/*     */     }
/*     */     
/* 136 */     if (state.getBlock() != this)
/* 137 */       return 0;
/* 138 */     return ((DecorStates)state.getValue(decor)).redstone_level;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract enum DecorStates
/*     */     implements IItemStackMaker
/*     */   {
/*     */     private DecorStates() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */     glass, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 164 */     glass_border, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */     glass_diamonds, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 176 */     darkglass, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */     glass_glowstone, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */     glass_redstone;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     @SideOnly(Side.CLIENT)
/*     */     public ISolidWorldTexture tex;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 214 */     int opacity = 0;
/* 215 */     int light_level = 0;
/* 216 */     int redstone_level = 0;
/* 217 */     EnumWorldBlockLayer layer = EnumWorldBlockLayer.CUTOUT;
/*     */     
/*     */     public abstract void addRecipes();
/*     */     
/*     */     public ItemStack newStack(int amount) {
/* 222 */       return XU2Entries.decorativeGlass.newStack(amount, new Object[] { BlockDecorativeGlass.decor, this });
/*     */     }
/*     */     
/*     */     public ItemStack newStack()
/*     */     {
/* 227 */       return newStack(1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockDecorativeGlass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */