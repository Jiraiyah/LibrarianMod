/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.PropertyEnumSimple;
/*     */ import com.rwtema.extrautils2.backend.XUBlockConnectedTextureBase;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.backend.entries.BlockEntry;
/*     */ import com.rwtema.extrautils2.backend.entries.IItemStackMaker;
/*     */ import com.rwtema.extrautils2.backend.entries.XU2Entries;
/*     */ import com.rwtema.extrautils2.crafting.CraftingHelper;
/*     */ import com.rwtema.extrautils2.crafting.EnchantRecipe;
/*     */ import com.rwtema.extrautils2.crafting.XUShapelessRecipe;
/*     */ import com.rwtema.extrautils2.textures.ConnectedTexture;
/*     */ import com.rwtema.extrautils2.textures.ISolidWorldTexture;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockDecorativeSolidWood extends XUBlockConnectedTextureBase
/*     */ {
/*  31 */   public static final PropertyEnumSimple<DecorStates> decor = new PropertyEnumSimple(DecorStates.class);
/*     */   
/*     */   public BlockDecorativeSolidWood() {
/*  34 */     super(Material.wood);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/*  40 */     for (DecorStates decorState : ) {
/*  41 */       decorState.tex = decorState.createTexture(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isOpaqueCube()
/*     */   {
/*  47 */     return true;
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/*  52 */     return new XUBlockStateCreator(this, false, new IProperty[] { decor });
/*     */   }
/*     */   
/*     */   public ISolidWorldTexture getConnectedTexture(IBlockState state, EnumFacing side)
/*     */   {
/*  57 */     return ((DecorStates)state.getValue(decor)).tex;
/*     */   }
/*     */   
/*     */   public float getEnchantPowerBonus(World world, BlockPos pos)
/*     */   {
/*  62 */     IBlockState state = world.getBlockState(pos);
/*  63 */     if (state.getBlock() != this) return 0.0F;
/*  64 */     return ((DecorStates)state.getValue(decor)).enchantBonus;
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/*  69 */     ((DecorStates)this.xuBlockState.getStateFromItemStack(stack).getValue(decor)).addInformation(stack, playerIn, tooltip, advanced);
/*     */   }
/*     */   
/*     */   public static abstract enum DecorStates implements IItemStackMaker {
/*  73 */     magical_planks, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     magical_wood, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     diagonalwood;
/*     */     
/*     */ 
/*     */     @SideOnly(Side.CLIENT)
/*     */     public ISolidWorldTexture tex;
/*     */     
/*     */ 
/*     */     private DecorStates() {}
/*     */     
/*     */ 
/* 109 */     public float enchantBonus = 0.0F;
/*     */     
/*     */     public abstract void addRecipes();
/*     */     
/*     */     public ItemStack newStack(int amount) {
/* 114 */       return XU2Entries.decorativeSolidWood.newStack(amount, new Object[] { BlockDecorativeSolidWood.decor, this }); }
/*     */     
/*     */ 
/*     */ 
/*     */     public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced) {}
/*     */     
/*     */ 
/*     */ 
/*     */     @Nonnull
/*     */     @SideOnly(Side.CLIENT)
/*     */     public ISolidWorldTexture createTexture(XUBlockConnectedTextureBase block)
/*     */     {
/* 126 */       return new ConnectedTexture(toString(), block.xuBlockState.defaultState.withProperty(BlockDecorativeSolidWood.decor, this), block);
/*     */     }
/*     */     
/*     */     public ItemStack newStack()
/*     */     {
/* 131 */       return newStack(1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockDecorativeSolidWood.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */