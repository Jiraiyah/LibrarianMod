/*    */ package com.rwtema.extrautils2.blocks;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlockStaticRotation;
/*    */ import com.rwtema.extrautils2.backend.model.Box;
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import com.rwtema.extrautils2.tile.TilePlayerChest;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockPlayerChest extends XUBlockStaticRotation
/*    */ {
/*    */   public BlockPlayerChest()
/*    */   {
/* 15 */     super(net.minecraft.block.material.Material.wood);
/*    */   }
/*    */   
/*    */   protected BoxModel createBaseModel(IBlockState baseState)
/*    */   {
/* 20 */     BoxModel boxes = new BoxModel();
/* 21 */     boxes.addBoxI(1, 0, 1, 15, 14, 15, "player_chest_side").setTextureSides(new Object[] { Integer.valueOf(0), "player_chest_bottom", Integer.valueOf(1), "player_chest_top", Integer.valueOf(3), "player_chest_front" });
/* 22 */     return boxes;
/*    */   }
/*    */   
/*    */   public TileEntity createTileEntity(World world, IBlockState state)
/*    */   {
/* 27 */     return new TilePlayerChest();
/*    */   }
/*    */   
/*    */   public boolean hasTileEntity(IBlockState state)
/*    */   {
/* 32 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockPlayerChest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */