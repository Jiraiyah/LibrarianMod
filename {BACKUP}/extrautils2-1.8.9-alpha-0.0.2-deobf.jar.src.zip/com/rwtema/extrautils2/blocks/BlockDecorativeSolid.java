/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.PropertyEnumSimple;
/*     */ import com.rwtema.extrautils2.backend.XUBlockConnectedTextureBase;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.backend.entries.BlockClassEntry;
/*     */ import com.rwtema.extrautils2.backend.entries.IItemStackMaker;
/*     */ import com.rwtema.extrautils2.backend.entries.XU2Entries;
/*     */ import com.rwtema.extrautils2.crafting.CraftingHelper;
/*     */ import com.rwtema.extrautils2.textures.ConnectedTexture;
/*     */ import com.rwtema.extrautils2.textures.ISolidWorldTexture;
/*     */ import com.rwtema.extrautils2.textures.TextureLocation;
/*     */ import com.rwtema.extrautils2.textures.TextureRandom;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockDecorativeSolid extends XUBlockConnectedTextureBase
/*     */ {
/*  30 */   public static final PropertyEnumSimple<DecorStates> decor = new PropertyEnumSimple(DecorStates.class);
/*     */   
/*     */   public BlockDecorativeSolid() {
/*  33 */     super(net.minecraft.block.material.Material.rock);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/*  39 */     for (DecorStates decorState : ) {
/*  40 */       decorState.tex = decorState.createTexture(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isOpaqueCube()
/*     */   {
/*  46 */     return true;
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/*  51 */     return new XUBlockStateCreator(this, false, new IProperty[] { decor });
/*     */   }
/*     */   
/*     */   public ISolidWorldTexture getConnectedTexture(IBlockState state, EnumFacing side)
/*     */   {
/*  56 */     return ((DecorStates)state.getValue(decor)).tex;
/*     */   }
/*     */   
/*     */   public float getEnchantPowerBonus(World world, BlockPos pos)
/*     */   {
/*  61 */     IBlockState state = world.getBlockState(pos);
/*  62 */     if (state.getBlock() != this) return 0.0F;
/*  63 */     return ((DecorStates)state.getValue(decor)).enchantBonus;
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/*  68 */     ((DecorStates)this.xuBlockState.getStateFromItemStack(stack).getValue(decor)).addInformation(stack, playerIn, tooltip, advanced);
/*     */   }
/*     */   
/*     */   public static abstract enum DecorStates implements IItemStackMaker {
/*  72 */     borderstone, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */     endstone, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */     stonecross, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */     stoneslab, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     stoneburnt, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */     sandy_glass, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */     truchet, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */     blue_quartz, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */     endstone_brick;
/*     */     
/*     */ 
/*     */     @SideOnly(Side.CLIENT)
/*     */     public ISolidWorldTexture tex;
/*     */     
/*     */ 
/*     */     private DecorStates() {}
/*     */     
/* 183 */     public float enchantBonus = 0.0F;
/*     */     
/*     */     public abstract void addRecipes();
/*     */     
/*     */     public ItemStack newStack(int amount) {
/* 188 */       return XU2Entries.decorativeSolid.newStack(amount, new Object[] { BlockDecorativeSolid.decor, this }); }
/*     */     
/*     */ 
/*     */ 
/*     */     public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced) {}
/*     */     
/*     */ 
/*     */     @Nonnull
/*     */     @SideOnly(Side.CLIENT)
/*     */     public ISolidWorldTexture createTexture(XUBlockConnectedTextureBase block)
/*     */     {
/* 199 */       return new ConnectedTexture(toString(), block.xuBlockState.defaultState.withProperty(BlockDecorativeSolid.decor, this), block);
/*     */     }
/*     */     
/*     */     public ItemStack newStack()
/*     */     {
/* 204 */       return newStack(1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockDecorativeSolid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */