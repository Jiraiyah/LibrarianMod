/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.rwtema.extrautils2.achievements.AchievementHelper;
/*     */ import com.rwtema.extrautils2.backend.PropertyEnumSimple;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStatic;
/*     */ import com.rwtema.extrautils2.backend.entries.IItemStackMaker;
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.crafting.CraftingHelper;
/*     */ import com.rwtema.extrautils2.items.ItemIngredients.Type;
/*     */ import com.rwtema.extrautils2.power.IWorldPowerMultiplier;
/*     */ import com.rwtema.extrautils2.power.PowerMultipliers;
/*     */ import com.rwtema.extrautils2.tile.TilePassiveGenerator;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.StringHelper;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockLiquid;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldProvider;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockPassiveGenerator extends XUBlockStatic
/*     */ {
/*  38 */   public static final PropertyEnumSimple<GeneratorTypes> GENERATOR_TYPE = new PropertyEnumSimple(GeneratorTypes.class);
/*     */   public static final int BASE_SOLAR_VALUE = 2;
/*     */   
/*     */   public BlockPassiveGenerator() {
/*  42 */     super(net.minecraft.block.material.Material.rock);
/*     */   }
/*     */   
/*     */   private static int getBaseSolarPower(World world) {
/*  46 */     return world.isDaytime() ? 2 : 0;
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/*  51 */     return new XUBlockStateCreator(this, false, new IProperty[] { GENERATOR_TYPE });
/*     */   }
/*     */   
/*     */   public BoxModel getModel(IBlockState baseState)
/*     */   {
/*  56 */     GeneratorTypes value = (GeneratorTypes)baseState.getValue(GENERATOR_TYPE);
/*  57 */     BoxModel model = new BoxModel();
/*  58 */     value.createModel(model, false);
/*  59 */     return model;
/*     */   }
/*     */   
/*     */   public BoxModel getModelInv(IBlockState baseState) {
/*  63 */     GeneratorTypes value = (GeneratorTypes)baseState.getValue(GENERATOR_TYPE);
/*  64 */     BoxModel model = new BoxModel();
/*  65 */     value.createModel(model, true);
/*  66 */     return model;
/*     */   }
/*     */   
/*     */ 
/*     */   public TileEntity createTileEntity(World world, IBlockState state)
/*     */   {
/*  72 */     return ((GeneratorTypes)state.getValue(GENERATOR_TYPE)).createTileEntity(world);
/*     */   }
/*     */   
/*     */   public boolean hasTileEntity(IBlockState state)
/*     */   {
/*  77 */     return true;
/*     */   }
/*     */   
/*     */   public EnumWorldBlockLayer getBlockLayer()
/*     */   {
/*  82 */     return super.getBlockLayer();
/*     */   }
/*     */   
/*     */   public boolean canReplace(World worldIn, BlockPos pos, EnumFacing side, ItemStack stack)
/*     */   {
/*  87 */     if (!super.canReplace(worldIn, pos, side, stack))
/*  88 */       return false;
/*  89 */     IBlockState state = this.xuBlockState.getStateFromItemStack(stack);
/*     */     
/*  91 */     return ((GeneratorTypes)state.getValue(GENERATOR_TYPE)).validPos(worldIn, pos);
/*     */   }
/*     */   
/*     */   public void onNeighborBlockChange(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock)
/*     */   {
/*  96 */     if (!((GeneratorTypes)state.getValue(GENERATOR_TYPE)).validPos(worldIn, pos)) {
/*  97 */       dropBlockAsItem(worldIn, pos, state, 0);
/*  98 */       worldIn.setBlockToAir(pos);
/*  99 */       return;
/*     */     }
/*     */     
/* 102 */     super.onNeighborBlockChange(worldIn, pos, state, neighborBlock);
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/* 107 */     ((GeneratorTypes)this.xuBlockState.getStateFromItemStack(stack).getValue(GENERATOR_TYPE)).addInformation(stack, playerIn, tooltip, advanced);
/*     */   }
/*     */   
/*     */   public float getBlockHardness(World worldIn, BlockPos pos)
/*     */   {
/* 112 */     if (worldIn.getBlockState(pos) == getDefaultState().withProperty(GENERATOR_TYPE, GeneratorTypes.CREATIVE))
/* 113 */       return -1.0F;
/* 114 */     return super.getBlockHardness(worldIn, pos);
/*     */   }
/*     */   
/*     */   public static abstract enum GeneratorTypes implements IItemStackMaker {
/* 118 */     Solar(PowerMultipliers.SOLAR), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */     Lunar(PowerMultipliers.LUNAR), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 193 */     Lava(IWorldPowerMultiplier.CONSTANT), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */     Water(IWorldPowerMultiplier.CONSTANT), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 281 */     Wind(PowerMultipliers.WIND), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 323 */     FIRE(IWorldPowerMultiplier.CONSTANT), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 357 */     CREATIVE(IWorldPowerMultiplier.CONSTANT), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 383 */     PLAYER_WIND_UP(IWorldPowerMultiplier.CONSTANT);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public final IWorldPowerMultiplier powerMultiplier;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private GeneratorTypes(IWorldPowerMultiplier powerMultiplier)
/*     */     {
/* 423 */       this.powerMultiplier = powerMultiplier;
/*     */     }
/*     */     
/*     */     public ItemStack newStack(int i) {
/* 427 */       return com.rwtema.extrautils2.backend.entries.XU2Entries.passiveGenerator.newStack(i, new Object[] { BlockPassiveGenerator.GENERATOR_TYPE, this });
/*     */     }
/*     */     
/*     */     public abstract float getPowerLevel(TilePassiveGenerator paramTilePassiveGenerator, World paramWorld);
/*     */     
/*     */     public abstract void createModel(BoxModel paramBoxModel, boolean paramBoolean);
/*     */     
/*     */     public boolean validPos(World worldIn, BlockPos pos) {
/* 435 */       return true;
/*     */     }
/*     */     
/*     */     public abstract void addRecipe();
/*     */     
/*     */     public float basePowerGen() {
/* 441 */       return 1.0F;
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced) {
/* 446 */       if (this.powerMultiplier != IWorldPowerMultiplier.CONSTANT) {
/* 447 */         tooltip.add(Lang.translateArgs("Base Power Given: %s GP", new Object[] { Float.valueOf(basePowerGen()) }));
/* 448 */         WorldClient theWorld = Minecraft.getMinecraft().theWorld;
/* 449 */         if (theWorld != null)
/* 450 */           tooltip.add(Lang.translateArgs("Cur Power Given: %s GP", new Object[] { StringHelper.niceFormat(basePowerGen() * this.powerMultiplier.multiplier(theWorld)) }));
/*     */       } else {
/* 452 */         tooltip.add(Lang.translateArgs("Power Given: %s GP", new Object[] { Float.valueOf(basePowerGen()) }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public ItemStack newStack()
/*     */     {
/* 459 */       return newStack(1);
/*     */     }
/*     */     
/*     */     public abstract void registerAchievements();
/*     */     
/*     */     public TilePassiveGenerator createTileEntity(World world)
/*     */     {
/* 466 */       return new TilePassiveGenerator();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockPassiveGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */