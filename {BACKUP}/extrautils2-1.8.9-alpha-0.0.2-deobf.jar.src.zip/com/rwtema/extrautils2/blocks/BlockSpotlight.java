/*     */ package com.rwtema.extrautils2.blocks;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.backend.model.Box;
/*     */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*     */ import com.rwtema.extrautils2.backend.model.BoxRotatable;
/*     */ import com.rwtema.extrautils2.backend.model.BoxSingleQuad;
/*     */ import com.rwtema.extrautils2.backend.model.UV;
/*     */ import com.rwtema.extrautils2.tile.TileSpotlight;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ 
/*     */ public class BlockSpotlight extends XUBlock
/*     */ {
/*  36 */   public static final WeakHashMap<TileEntity, BoxModel> worldModelCache = new WeakHashMap();
/*  37 */   public static final WeakHashMap<TileEntity, BoxModel> renderModelCache = new WeakHashMap(1);
/*     */   BoxModel invCache;
/*     */   
/*     */   public BlockSpotlight()
/*     */   {
/*  42 */     super(Material.rock);
/*     */   }
/*     */   
/*     */   protected XUBlockStateCreator createBlockState()
/*     */   {
/*  47 */     return new XUBlockStateCreator(this, new IProperty[] { XUBlockStateCreator.ROTATION_ALL });
/*     */   }
/*     */   
/*     */   public IBlockState onBlockPlaced(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer)
/*     */   {
/*  52 */     return this.xuBlockState.getStateFromDropMeta(meta).withProperty(XUBlockStateCreator.ROTATION_ALL, facing);
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
/*     */   {
/*  57 */     super.onBlockPlacedBy(worldIn, pos, state, placer, stack);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerTextures()
/*     */   {
/*  63 */     super.registerTextures();
/*  64 */     com.rwtema.extrautils2.backend.model.Textures.register(new String[] { "spotlight", "spotlight_stand", "gradient_64" });
/*     */   }
/*     */   
/*     */   public BoxModel getStandModel(EnumFacing facing)
/*     */   {
/*  69 */     BoxModel model = new BoxModel();
/*  70 */     model.addBoxI(2, 0, 2, 14, 1, 14, "spotlight_stand");
/*  71 */     Box stand = model.addBox(0.46875F, 0.0625F, 0.46875F, 0.53125F, 0.5F, 0.53125F);
/*  72 */     model.setTexture("spotlight_stand");
/*  73 */     stand.setTextureBounds(new float[][] { { 15.0F, 15.0F, 16.0F, 16.0F }, { 15.0F, 15.0F, 16.0F, 16.0F }, { 15.0F, 8.0F, 16.0F, 16.0F }, { 15.0F, 8.0F, 16.0F, 16.0F }, { 15.0F, 8.0F, 16.0F, 16.0F }, { 15.0F, 8.0F, 16.0F, 16.0F } });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */     model.rotateToSide(facing.getOpposite());
/*  82 */     return model;
/*     */   }
/*     */   
/*     */   public boolean canRenderInLayer(EnumWorldBlockLayer layer)
/*     */   {
/*  87 */     return (layer == EnumWorldBlockLayer.SOLID) || (layer == EnumWorldBlockLayer.TRANSLUCENT);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BoxModel getRenderModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/*  93 */     TileEntity tileEntity = world.getTileEntity(pos);
/*  94 */     if ((tileEntity instanceof TileSpotlight)) {
/*  95 */       BoxModel model = (BoxModel)renderModelCache.get(tileEntity);
/*  96 */       if (model != null) return model;
/*  97 */       model = new BoxModel();
/*  98 */       model.addAll(super.getRenderModel(world, pos, state));
/*     */       
/* 100 */       TileSpotlight spotlight = (TileSpotlight)tileEntity;
/*     */       
/* 102 */       BoxRotatable lamp = (BoxRotatable)model.get(model.size() - 1);
/* 103 */       float[] normal = (float[])spotlight.getBaseNormal().clone();
/*     */       
/* 105 */       if ((tileEntity.getWorld().isRemote) && (spotlight.active)) {
/* 106 */         UV[] faceVec = lamp.faceVecs[5];
/* 107 */         float d = -0.1F;float d2 = 4.0F;
/* 108 */         Vector3f v = new Vector3f(d * normal[0] + 0.5F, d * normal[1] + 0.5F, d * normal[2] + 0.5F);
/* 109 */         for (int i = 0; i < 4; i++) {
/* 110 */           UV a = faceVec[i];
/* 111 */           UV b = faceVec[((i + 1) % 4)];
/* 112 */           BoxSingleQuad glow = new BoxSingleQuad(new UV[] { new UV(a.x, a.y, a.z, 1), new UV(b.x, b.y, b.z, 2), new UV(v.x + (b.x - v.x) * d2, v.y + (b.y - v.y) * d2, v.z + (b.z - v.z) * d2, 3), new UV(v.x + (a.x - v.x) * d2, v.y + (a.y - v.y) * d2, v.z + (a.z - v.z) * d2, 0) });
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 117 */           glow.setTexture("gradient_64");
/* 118 */           glow.noCollide = true;
/* 119 */           glow.setDoubleSided(true);
/* 120 */           glow.addShading = false;
/* 121 */           glow.layer = EnumWorldBlockLayer.TRANSLUCENT;
/* 122 */           model.add(glow);
/*     */         }
/*     */       }
/* 125 */       renderModelCache.put(tileEntity, model);
/* 126 */       return model;
/*     */     }
/* 128 */     return this.invCache;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public BoxModel getWorldModel(IBlockAccess world, BlockPos pos, @Nullable IBlockState state)
/*     */   {
/* 134 */     TileEntity tileEntity = world.getTileEntity(pos);
/* 135 */     if ((tileEntity instanceof TileSpotlight)) {
/* 136 */       BoxModel model = (BoxModel)worldModelCache.get(tileEntity);
/* 137 */       if (model != null) return model;
/* 138 */       if (state == null) { state = world.getBlockState(pos);
/*     */       }
/* 140 */       TileSpotlight spotlight = (TileSpotlight)tileEntity;
/*     */       
/* 142 */       model = new BoxModel();
/* 143 */       model.addAll(getStandModel((EnumFacing)state.getValue(XUBlockStateCreator.ROTATION_ALL)));
/* 144 */       BoxRotatable lamp = new BoxRotatable(0.1875F, 0.3125F, 0.3125F, 0.8125F, 0.6875F, 0.6875F);
/* 145 */       lamp.setTexture("spotlight");
/* 146 */       lamp.setTextureBounds(new float[][] { { 10.0F, 10.0F, 0.0F, 16.0F }, { 0.0F, 10.0F, 10.0F, 16.0F }, { 0.0F, 10.0F, 10.0F, 16.0F }, { 10.0F, 10.0F, 0.0F, 16.0F }, { 10.0F, 10.0F, 16.0F, 16.0F }, { spotlight.active ? 10.0F : 0.0F, 0.0F, spotlight.active ? 16.0F : 6.0F, 6.0F } });
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */       float[] normal = (float[])spotlight.getBaseNormal().clone();
/* 158 */       float x = normal[0];
/* 159 */       float y = normal[1];
/* 160 */       float z = normal[2];
/* 161 */       lamp.rotate(MathHelper.sqrt_float(1.0F - y * y), y, 0.5F, 0.5F, 0.5F, 0.0F, 0.0F, 1.0F);
/* 162 */       lamp.rotate(x, -z, 0.5F, 0.5F, 0.5F, 0.0F, 1.0F, 0.0F);
/* 163 */       model.add(lamp);
/*     */       
/* 165 */       worldModelCache.put(tileEntity, model);
/* 166 */       return model;
/*     */     }
/* 168 */     return getInventoryModel(null);
/*     */   }
/*     */   
/*     */   public void clearCaches()
/*     */   {
/* 173 */     this.invCache = null;
/* 174 */     worldModelCache.clear();
/* 175 */     renderModelCache.clear();
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public BoxModel getInventoryModel(@Nullable ItemStack item)
/*     */   {
/* 181 */     BoxModel inv = this.invCache;
/* 182 */     if (inv != null) return this.invCache;
/* 183 */     inv = new BoxModel();
/* 184 */     inv.addAll(getStandModel(EnumFacing.UP));
/* 185 */     inv.addBoxI(3, 5, 5, 13, 11, 11, "spotlight").textureBounds = new float[][] { { 10.0F, 0.0F, 0.0F, 6.0F }, { 0.0F, 0.0F, 10.0F, 6.0F }, { 10.0F, 0.0F, 0.0F, 6.0F }, { 0.0F, 0.0F, 10.0F, 6.0F }, { 10.0F, 0.0F, 16.0F, 6.0F }, { 0.0F, 10.0F, 6.0F, 16.0F } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */     this.invCache = inv;
/* 195 */     return inv;
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
/*     */   {
/* 200 */     tooltip.add(Lang.translateArgs("Power Required: %s GP", new Object[] { Float.valueOf(4.0F) }));
/*     */   }
/*     */   
/*     */   public boolean hasTileEntity(IBlockState state)
/*     */   {
/* 205 */     return true;
/*     */   }
/*     */   
/*     */   public TileEntity createTileEntity(World world, IBlockState state)
/*     */   {
/* 210 */     return new TileSpotlight();
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {}
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockSpotlight.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */