/*    */ package com.rwtema.extrautils2.blocks;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlockFull;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public class BlockAngelBlock extends XUBlockFull
/*    */ {
/*    */   public BlockAngelBlock()
/*    */   {
/* 10 */     super(net.minecraft.block.material.Material.rock);
/*    */   }
/*    */   
/*    */   public String getTexture(net.minecraft.block.state.IBlockState state, EnumFacing side)
/*    */   {
/* 15 */     return "angel_block";
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockAngelBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */