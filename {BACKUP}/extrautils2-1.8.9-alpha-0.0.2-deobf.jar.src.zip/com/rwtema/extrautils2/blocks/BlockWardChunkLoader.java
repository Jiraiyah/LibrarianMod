/*    */ package com.rwtema.extrautils2.blocks;
/*    */ 
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockWardChunkLoader extends BlockWardBase
/*    */ {
/*    */   public BlockWardChunkLoader()
/*    */   {
/* 10 */     super(-1, 1);
/*    */   }
/*    */   
/*    */   public net.minecraft.tileentity.TileEntity createTileEntity(World world, IBlockState state)
/*    */   {
/* 15 */     return new com.rwtema.extrautils2.tile.TileChunkLoader();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockWardChunkLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */