/*    */ package com.rwtema.extrautils2.blocks;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import com.rwtema.extrautils2.backend.XUBlockStaticRotation;
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import com.rwtema.extrautils2.tile.TileTrashCan;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockTrashCan extends XUBlockStaticRotation
/*    */ {
/*    */   public BlockTrashCan()
/*    */   {
/* 15 */     super(net.minecraft.block.material.Material.rock);
/* 16 */     ExtraUtils2.proxy.registerTexture(new String[] { "trashcan", "trashcan_top", "trashcan_bottom" });
/* 17 */     setHardness(3.5F).setSoundType(field_149769_e);
/*    */   }
/*    */   
/*    */   protected BoxModel createBaseModel(IBlockState state)
/*    */   {
/* 22 */     BoxModel model = new BoxModel();
/* 23 */     model.addBox(0.125F, 0.0F, 0.125F, 0.875F, 0.625F, 0.875F);
/* 24 */     model.addBox(0.0625F, 0.625F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
/* 25 */     model.addBox(0.3125F, 0.875F, 0.4375F, 0.6875F, 0.9375F, 0.5625F);
/* 26 */     model.setTextures(new Object[] { "trashcan", EnumFacing.DOWN, "trashcan_bottom", EnumFacing.UP, "trashcan_top" });
/* 27 */     return model;
/*    */   }
/*    */   
/*    */   public boolean hasTileEntity(IBlockState state)
/*    */   {
/* 32 */     return true;
/*    */   }
/*    */   
/*    */   public net.minecraft.tileentity.TileEntity createTileEntity(World world, IBlockState state)
/*    */   {
/* 37 */     return new TileTrashCan();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockTrashCan.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */