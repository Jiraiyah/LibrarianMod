/*    */ package com.rwtema.extrautils2.blocks;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlockFull;
/*    */ import com.rwtema.extrautils2.sounds.SoundMuffler;
/*    */ import com.rwtema.extrautils2.tile.TileSoundMuffler;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.audio.ISound;
/*    */ import net.minecraft.client.audio.ITickableSound;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.client.event.sound.PlaySoundEvent;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BlockSoundMuffler extends XUBlockFull
/*    */ {
/*    */   static final int range = 8;
/*    */   
/*    */   public BlockSoundMuffler()
/*    */   {
/* 28 */     super(net.minecraft.block.material.Material.cloth);
/* 29 */     MinecraftForge.EVENT_BUS.register(this);
/*    */   }
/*    */   
/*    */   public String getTexture(IBlockState state, EnumFacing side)
/*    */   {
/* 34 */     return "sound_muffler";
/*    */   }
/*    */   
/*    */   public boolean hasTileEntity(IBlockState state)
/*    */   {
/* 39 */     return true;
/*    */   }
/*    */   
/*    */   public net.minecraft.tileentity.TileEntity createTileEntity(World world, IBlockState state)
/*    */   {
/* 44 */     return new TileSoundMuffler();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void supressSound(PlaySoundEvent event) {
/* 50 */     WorldClient theWorld = Minecraft.getMinecraft().theWorld;
/* 51 */     if (theWorld == null) return;
/* 52 */     ISound sound = event.sound;
/* 53 */     if ((sound instanceof ITickableSound)) { return;
/*    */     }
/* 55 */     AxisAlignedBB expand = new AxisAlignedBB(sound.getXPosF(), sound.getYPosF(), sound.getZPosF(), sound.getXPosF(), sound.getYPosF(), sound.getZPosF()).expand(8.0D, 8.0D, 8.0D);
/*    */     
/* 57 */     List<TileSoundMuffler> tileSoundMufflers = com.rwtema.extrautils2.tile.XUTile.searchAABBForTiles(theWorld, expand, TileSoundMuffler.class, true, null);
/* 58 */     if (tileSoundMufflers.isEmpty()) { return;
/*    */     }
/* 60 */     float volume = 0.05F;
/*    */     
/* 62 */     event.result = new SoundMuffler(sound, volume);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockSoundMuffler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */