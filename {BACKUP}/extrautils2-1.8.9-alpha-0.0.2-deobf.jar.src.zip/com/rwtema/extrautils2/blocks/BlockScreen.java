/*    */ package com.rwtema.extrautils2.blocks;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*    */ import com.rwtema.extrautils2.backend.XUBlockStateCreator.Builder;
/*    */ import com.rwtema.extrautils2.backend.XUBlockStatic;
/*    */ import com.rwtema.extrautils2.backend.model.Box;
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import com.rwtema.extrautils2.tile.TileScreen;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockScreen extends XUBlockStatic
/*    */ {
/*    */   public static final float SIZE = 0.1F;
/* 19 */   public static int maxSize = -1;
/*    */   
/*    */   public BlockScreen() {
/* 22 */     super(net.minecraft.block.material.Material.rock);
/*    */   }
/*    */   
/*    */   protected XUBlockStateCreator createBlockState()
/*    */   {
/* 27 */     return new XUBlockStateCreator.Builder(this).addWorldPropertyWithDefault(XUBlockStateCreator.ROTATION_HORIZONTAL, EnumFacing.SOUTH).build();
/*    */   }
/*    */   
/*    */   public boolean isPassable(IBlockAccess worldIn, BlockPos pos)
/*    */   {
/* 32 */     return true;
/*    */   }
/*    */   
/*    */   public BoxModel getModel(IBlockState state)
/*    */   {
/* 37 */     BoxModel model = new BoxModel();
/* 38 */     model.addBox(0.0F, 0.0F, 0.0F, 1.0F, 0.09804688F, 1.0F).setTextureSides(new Object[] { "panel_bottom", Integer.valueOf(0), "panel_bottom", Integer.valueOf(1), "black_screen" });
/* 39 */     model.rotateToSide((EnumFacing)state.getValue(XUBlockStateCreator.ROTATION_HORIZONTAL));
/* 40 */     return model;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean hasTileEntity(IBlockState state)
/*    */   {
/* 46 */     return true;
/*    */   }
/*    */   
/*    */   public net.minecraft.tileentity.TileEntity createTileEntity(World world, IBlockState state)
/*    */   {
/* 51 */     return new TileScreen();
/*    */   }
/*    */   
/*    */   public IBlockState onBlockPlaced(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer)
/*    */   {
/* 56 */     if ((facing == EnumFacing.DOWN) || (facing == EnumFacing.UP)) facing = placer.getHorizontalFacing().getOpposite();
/* 57 */     return this.xuBlockState.getStateFromDropMeta(meta).withProperty(XUBlockStateCreator.ROTATION_HORIZONTAL, facing.getOpposite());
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\blocks\BlockScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */