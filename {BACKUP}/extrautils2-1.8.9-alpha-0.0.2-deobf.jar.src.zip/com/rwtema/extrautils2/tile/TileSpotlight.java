/*     */ package com.rwtema.extrautils2.tile;
/*     */ 
/*     */ import com.rwtema.extrautils2.asm.Lighting;
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.blocks.BlockSpotlight;
/*     */ import com.rwtema.extrautils2.lighting.ILight;
/*     */ import com.rwtema.extrautils2.utils.helpers.LightMathHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*     */ import java.util.Arrays;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.EnumSkyBlock;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileSpotlight
/*     */   extends TilePower
/*     */   implements ILight
/*     */ {
/*     */   public static final int range = 78;
/*     */   public static final int range_side = 32;
/*     */   public static final int range_back = 1;
/*     */   public static final float POWER = 4.0F;
/*     */   public static HashMap<EnumFacing, float[]> baseNormals;
/*     */   public float[] normal;
/*     */   
/*     */   private static void initNormals()
/*     */   {
/*  46 */     baseNormals = new HashMap();
/*  47 */     baseNormals.put(EnumFacing.DOWN, new float[] { 0.0F, -1.0F, 0.0F });
/*  48 */     baseNormals.put(EnumFacing.UP, new float[] { 0.0F, 1.0F, 0.0F });
/*  49 */     float sqr2 = (float)Math.sqrt(0.5D);
/*  50 */     for (EnumFacing facing : EnumFacing.HORIZONTALS) {
/*  51 */       float[] normal = { facing.getFrontOffsetX() * sqr2, -sqr2, facing.getFrontOffsetZ() * sqr2 };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  56 */       baseNormals.put(facing, normal);
/*     */     }
/*     */   }
/*     */   
/*     */   public float getPower()
/*     */   {
/*  62 */     return 4.0F;
/*     */   }
/*     */   
/*     */   public World getLightWorld()
/*     */   {
/*  67 */     return this.worldObj;
/*     */   }
/*     */   
/*     */   public float getLightOffset(BlockPos p)
/*     */   {
/*  72 */     if (!this.active) { return 0.0F;
/*     */     }
/*  74 */     if (this.normal == null) { this.normal = getBaseNormal();
/*     */     }
/*  76 */     float foreDist = 1.0F + this.normal[0] * (p.getX() - this.pos.getX()) + this.normal[1] * (p.getY() - this.pos.getY()) + this.normal[2] * (p.getZ() - this.pos.getZ());
/*     */     
/*     */ 
/*     */ 
/*  80 */     if (foreDist <= 0.0F) { return 0.0F;
/*     */     }
/*  82 */     float sideDist = dist(p.getX() - this.pos.getX() - foreDist * this.normal[0], p.getY() - this.pos.getY() - foreDist * this.normal[1], p.getZ() - this.pos.getZ() - foreDist * this.normal[2]);
/*     */     
/*     */ 
/*     */ 
/*  86 */     float mH = 1.0F - LightMathHelper.approxSqrt(foreDist * foreDist + sideDist * sideDist, 6084.0F);
/*  87 */     if (mH < 0.0F) { return 0.0F;
/*     */     }
/*  89 */     mH *= (1.0F - sideDist / (0.5F + foreDist) / 2.0F);
/*  90 */     if (mH < 0.0F) return 0.0F;
/*  91 */     return Math.min(mH * 16.0F, 16.0F);
/*     */   }
/*     */   
/*     */   private float dist(float a, float b, float c) {
/*  95 */     return MathHelper.sqrt_float(a * a + b * b + c * c);
/*     */   }
/*     */   
/*     */   public float sqr(float a) {
/*  99 */     return a * a;
/*     */   }
/*     */   
/*     */   public EnumSkyBlock[] getLightType()
/*     */   {
/* 104 */     return new EnumSkyBlock[] { EnumSkyBlock.BLOCK };
/*     */   }
/*     */   
/*     */   public void onPowerChanged()
/*     */   {
/* 109 */     this.worldObj.func_175689_h(this.pos);
/*     */   }
/*     */   
/*     */   public Packet getDescriptionPacket()
/*     */   {
/* 114 */     NBTTagCompound tags = new NBTTagCompound();
/* 115 */     tags.setBoolean("Active", this.active);
/* 116 */     writeNormal(tags);
/* 117 */     return new S35PacketUpdateTileEntity(this.pos, -1, tags);
/*     */   }
/*     */   
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt)
/*     */   {
/* 122 */     NBTTagCompound nbt = pkt.getNbtCompound();
/* 123 */     boolean b = nbt.getBoolean("Active");
/*     */     
/* 125 */     float[] prevNormal = this.normal != null ? (float[])this.normal.clone() : null;
/* 126 */     readNormal(nbt);
/*     */     
/* 128 */     if ((b != this.active) || (!Arrays.equals(prevNormal, this.normal))) {
/* 129 */       BlockSpotlight.worldModelCache.remove(this);
/* 130 */       BlockSpotlight.renderModelCache.remove(this);
/* 131 */       this.active = b;
/* 132 */       updateLight();
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateLight() {
/* 137 */     this.worldObj.markBlockRangeForRenderUpdate(this.pos.getX() - 78, this.pos.getY() - 78, this.pos.getZ() - 78, this.pos.getX() + 78, this.pos.getY() + 78, this.pos.getZ() + 78);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 148 */     super.writeToNBT(compound);
/* 149 */     writeNormal(compound);
/*     */   }
/*     */   
/*     */   protected void writeNormal(NBTTagCompound compound) {
/* 153 */     if (this.normal != null) {
/* 154 */       NBTTagCompound normal = NBTHelper.getOrInitTagCompound(compound, "Normal");
/* 155 */       normal.setFloat("NormalX", this.normal[0]);
/* 156 */       normal.setFloat("NormalY", this.normal[1]);
/* 157 */       normal.setFloat("NormalZ", this.normal[2]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 163 */     super.readFromNBT(compound);
/* 164 */     readNormal(compound);
/*     */   }
/*     */   
/*     */   protected void readNormal(NBTTagCompound compound) {
/* 168 */     if (compound.hasKey("Normal", 10)) {
/* 169 */       this.normal = new float[3];
/* 170 */       NBTTagCompound normalTag = compound.getCompoundTag("Normal");
/* 171 */       this.normal[0] = normalTag.getFloat("NormalX");
/* 172 */       this.normal[1] = normalTag.getFloat("NormalY");
/* 173 */       this.normal[2] = normalTag.getFloat("NormalZ");
/*     */     } else {
/* 175 */       this.normal = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void onChunkUnload()
/*     */   {
/* 181 */     super.onChunkUnload();
/* 182 */     Lighting.unregister(this, getLightMap());
/* 183 */     if (this.worldObj.isRemote) {
/* 184 */       updateLight();
/*     */     }
/*     */   }
/*     */   
/*     */   public void invalidate()
/*     */   {
/* 190 */     super.invalidate();
/* 191 */     Lighting.unregister(this, getLightMap());
/* 192 */     if (this.worldObj.isRemote) {
/* 193 */       updateLight();
/*     */     }
/*     */   }
/*     */   
/*     */   public void validate()
/*     */   {
/* 199 */     super.validate();
/* 200 */     Lighting.register(this, getLightMap());
/*     */   }
/*     */   
/*     */   protected WeakHashMap<World, EnumMap<EnumSkyBlock, Set<ILight>>> getLightMap() {
/* 204 */     return Lighting.plusLights;
/*     */   }
/*     */   
/*     */   public float[] getBaseNormal() {
/* 208 */     if (this.normal == null) {
/* 209 */       EnumFacing facing = (EnumFacing)this.worldObj.getBlockState(this.pos).getValue(XUBlockStateCreator.ROTATION_HORIZONTAL_INC_DOWN);
/* 210 */       this.normal = ((float[])((float[])baseNormals.get(facing)).clone());
/*     */     }
/* 212 */     return this.normal;
/*     */   }
/*     */   
/*     */ 
/*     */   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack, XUBlock xuBlock)
/*     */   {
/* 218 */     super.onBlockPlacedBy(worldIn, pos, state, placer, stack, xuBlock);
/* 219 */     this.normal = null;
/* 220 */     updateNormal(state, placer);
/*     */   }
/*     */   
/*     */   public void updateNormal(IBlockState state, EntityLivingBase placer) {
/* 224 */     EnumFacing facing = (EnumFacing)state.getValue(XUBlockStateCreator.ROTATION_ALL);
/* 225 */     Vec3 lookVec = placer.getLookVec();
/* 226 */     lookVec = lookVec.normalize();
/*     */     
/* 228 */     if (this.normal != null) {
/* 229 */       double v = lookVec.dotProduct(new Vec3(this.normal[0], this.normal[1], this.normal[2]));
/* 230 */       if (v > 0.995D) {
/* 231 */         lookVec = new Vec3(-lookVec.xCoord, -lookVec.yCoord, -lookVec.zCoord);
/*     */       }
/*     */     }
/*     */     
/* 235 */     double v = lookVec.dotProduct(new Vec3(facing.getDirectionVec()));
/* 236 */     if (v < 0.75D) {
/* 237 */       this.normal = new float[] { (float)lookVec.xCoord, (float)lookVec.yCoord, (float)lookVec.zCoord };
/*     */     } else {
/* 239 */       this.normal = ((float[])baseNormals.get(facing));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/* 245 */     if (worldIn.isRemote) return true;
/* 246 */     if (isValidPlayer(playerIn)) return false;
/* 247 */     updateNormal(state, playerIn);
/* 248 */     worldIn.func_175689_h(pos);
/* 249 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canRenderBreaking()
/*     */   {
/* 255 */     return true;
/*     */   }
/*     */   
/*     */   static {}
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TileSpotlight.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */