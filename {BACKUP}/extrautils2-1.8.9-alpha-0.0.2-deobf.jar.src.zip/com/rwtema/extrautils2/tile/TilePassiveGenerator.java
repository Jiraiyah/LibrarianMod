/*    */ package com.rwtema.extrautils2.tile;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.model.XUBlockState;
/*    */ import com.rwtema.extrautils2.blocks.BlockPassiveGenerator;
/*    */ import com.rwtema.extrautils2.blocks.BlockPassiveGenerator.GeneratorTypes;
/*    */ import com.rwtema.extrautils2.power.PowerManager;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.BlockPos;
/*    */ 
/*    */ public class TilePassiveGenerator extends TilePower
/*    */ {
/*    */   public float getPower()
/*    */   {
/* 14 */     BlockPassiveGenerator.GeneratorTypes value = (BlockPassiveGenerator.GeneratorTypes)getBlockState().getValue(BlockPassiveGenerator.GENERATOR_TYPE);
/* 15 */     return -value.getPowerLevel(this, this.worldObj);
/*    */   }
/*    */   
/*    */   public void onNeighborBlockChange(net.minecraft.world.World worldIn, BlockPos pos, IBlockState state, net.minecraft.block.Block neighborBlock)
/*    */   {
/* 20 */     PowerManager.instance.markDirty(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void onPowerChanged() {}
/*    */   
/*    */ 
/*    */   public com.rwtema.extrautils2.power.IWorldPowerMultiplier getMultiplier()
/*    */   {
/* 30 */     return ((BlockPassiveGenerator.GeneratorTypes)getBlockState().getValue(BlockPassiveGenerator.GENERATOR_TYPE)).powerMultiplier;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TilePassiveGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */