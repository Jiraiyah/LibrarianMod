/*     */ package com.rwtema.extrautils2.tile;
/*     */ 
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.XUProxy;
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.XUBlockStateCreator;
/*     */ import com.rwtema.extrautils2.gui.GuiEditTileScreen;
/*     */ import com.rwtema.extrautils2.network.XUPacketClientToServer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.StringUtils;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.network.IGuiHandler;
/*     */ 
/*     */ public class TileScreen extends TilePower implements IGuiHandler
/*     */ {
/*  33 */   public static final Pattern illegalPatternControlCode = Pattern.compile("[^0-9A-Za-z]");
/*     */   
/*  35 */   public TileScreen() { this.id = ""; }
/*     */   
/*     */   @Nonnull
/*     */   public String id;
/*     */   public void onPowerChanged() {
/*  40 */     this.worldObj.func_175689_h(this.pos);
/*     */   }
/*     */   
/*     */   public float getPower()
/*     */   {
/*  45 */     return 1.0F;
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/*  50 */     super.writeToNBT(compound);
/*  51 */     compound.setString("image_id", this.id);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/*  56 */     super.readFromNBT(compound);
/*  57 */     this.id = compound.getString("image_id");
/*     */   }
/*     */   
/*     */   public net.minecraft.network.Packet getDescriptionPacket()
/*     */   {
/*  62 */     NBTTagCompound tags = new NBTTagCompound();
/*  63 */     tags.setBoolean("active", this.active);
/*  64 */     tags.setString("image_id", this.id);
/*  65 */     tags.setInteger("freq", this.frequency);
/*  66 */     return new S35PacketUpdateTileEntity(this.pos, -1, tags);
/*     */   }
/*     */   
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt)
/*     */   {
/*  71 */     NBTTagCompound tags = pkt.getNbtCompound();
/*  72 */     this.id = tags.getString("image_id");
/*  73 */     this.active = tags.getBoolean("active");
/*  74 */     this.frequency = tags.getInteger("freq");
/*  75 */     this.worldObj.func_175689_h(this.pos);
/*     */   }
/*     */   
/*     */   public boolean canRenderBreaking()
/*     */   {
/*  80 */     return false;
/*     */   }
/*     */   
/*     */   public boolean shouldRenderInPass(int pass)
/*     */   {
/*  85 */     return super.shouldRenderInPass(pass);
/*     */   }
/*     */   
/*     */   public boolean canJoinWith(BlockPos pos) {
/*  89 */     TileEntity tileEntity = getWorld().getTileEntity(pos);
/*  90 */     if (!(tileEntity instanceof TileScreen)) return false;
/*  91 */     TileScreen te = (TileScreen)tileEntity;
/*  92 */     return (getBlockState() == te.getBlockState()) && (this.id.equals(te.id)) && (this.worldObj.isRemote) && (this.frequency == te.frequency);
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*  97 */     if (worldIn.isRemote)
/*  98 */       openGUI(playerIn);
/*  99 */     return true;
/*     */   }
/*     */   
/*     */   public AxisAlignedBB getRenderBoundingBox()
/*     */   {
/* 104 */     return INFINITE_EXTENT_AABB;
/*     */   }
/*     */   
/*     */   public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/* 109 */     return null;
/*     */   }
/*     */   
/*     */   public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/* 114 */     return new GuiEditTileScreen(this);
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack, XUBlock xuBlock)
/*     */   {
/* 119 */     super.onBlockPlacedBy(worldIn, pos, state, placer, stack, xuBlock);
/* 120 */     if (this.worldObj.isRemote) return;
/* 121 */     if (((placer instanceof EntityPlayerMP)) && (ExtraUtils2.proxy.isAltSneaking((EntityPlayerMP)placer))) return;
/* 122 */     EnumFacing side = (EnumFacing)state.getValue(XUBlockStateCreator.ROTATION_HORIZONTAL);
/*     */     
/* 124 */     TileScreen toCopy = null;
/*     */     
/* 126 */     for (EnumFacing enumFacing : com.rwtema.extrautils2.utils.helpers.SideHelper.perp_sides[side.ordinal()]) {
/* 127 */       TileEntity te = worldIn.getTileEntity(pos.offset(enumFacing));
/* 128 */       if ((te instanceof TileScreen)) {
/* 129 */         TileScreen otherScreen = (TileScreen)te;
/* 130 */         if ((otherScreen.getBlockState() == state) && (otherScreen.frequency == this.frequency) && (!StringUtils.isNullOrEmpty(otherScreen.id)))
/* 131 */           if (toCopy != null) {
/* 132 */             if (!toCopy.id.equals(otherScreen.id)) {
/* 133 */               toCopy = null;
/* 134 */               break;
/*     */             }
/* 136 */           } else toCopy = otherScreen;
/*     */       }
/*     */     }
/* 139 */     if (toCopy != null) {
/* 140 */       this.id = toCopy.id;
/* 141 */       worldIn.func_175689_h(pos);
/*     */     }
/*     */   }
/*     */   
/*     */   @com.rwtema.extrautils2.network.NetworkHandler.XUPacket
/*     */   public static class PacketEditScreen
/*     */     extends XUPacketClientToServer
/*     */   {
/*     */     private String id;
/*     */     private BlockPos pos;
/*     */     private EntityPlayer player;
/*     */     
/*     */     public PacketEditScreen() {}
/*     */     
/*     */     public PacketEditScreen(BlockPos pos, String id)
/*     */     {
/* 157 */       this.pos = pos;
/* 158 */       this.id = id;
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/* 163 */       writeString(this.id);
/* 164 */       writeBlockPos(this.pos);
/* 165 */       if (TileScreen.illegalPatternControlCode.matcher(this.id).find()) {
/* 166 */         throw new RuntimeException("Illegal ID");
/*     */       }
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player)
/*     */     {
/* 172 */       this.player = player;
/* 173 */       this.id = readString();
/* 174 */       this.pos = readBlockPos();
/* 175 */       if (TileScreen.illegalPatternControlCode.matcher(this.id).find()) {
/* 176 */         throw new RuntimeException("Illegal ID");
/*     */       }
/*     */     }
/*     */     
/*     */     public Runnable doStuffServer()
/*     */     {
/* 182 */       new Runnable()
/*     */       {
/*     */         public void run() {
/* 185 */           if ("error".equals(TileScreen.PacketEditScreen.this.id)) {
/* 186 */             throw new RuntimeException("Artificial error");
/*     */           }
/* 188 */           World worldObj = TileScreen.PacketEditScreen.this.player.worldObj;
/* 189 */           TileEntity t = worldObj.getTileEntity(TileScreen.PacketEditScreen.this.pos);
/* 190 */           if (!(t instanceof TileScreen)) return;
/* 191 */           TileScreen screen = (TileScreen)t;
/* 192 */           if (!screen.isValidPlayer(TileScreen.PacketEditScreen.this.player)) { return;
/*     */           }
/* 194 */           String oldID = screen.id;
/* 195 */           screen.id = TileScreen.PacketEditScreen.this.id;
/* 196 */           screen.markDirty();
/* 197 */           worldObj.func_175689_h(screen.getPos());
/*     */           
/* 199 */           ArrayList<TileScreen> screens = new ArrayList();
/* 200 */           LinkedHashSet<BlockPos> checkedPositions = new LinkedHashSet();
/* 201 */           LinkedList<BlockPos> toCheck = new LinkedList();
/* 202 */           checkedPositions.add(TileScreen.PacketEditScreen.this.pos);
/* 203 */           EnumFacing[] perp_sides = com.rwtema.extrautils2.utils.helpers.SideHelper.perp_sides[((EnumFacing)screen.getBlockState().getValue(XUBlockStateCreator.ROTATION_HORIZONTAL)).ordinal()];
/* 204 */           for (EnumFacing perp_side : perp_sides) {
/* 205 */             toCheck.add(TileScreen.PacketEditScreen.this.pos.offset(perp_side));
/*     */           }
/*     */           BlockPos next;
/* 208 */           while (((next = (BlockPos)toCheck.poll()) != null) && (checkedPositions.size() < 100)) {
/* 209 */             checkedPositions.add(next);
/* 210 */             TileEntity tileEntity = worldObj.getTileEntity(next);
/* 211 */             if ((tileEntity instanceof TileScreen)) {
/* 212 */               TileScreen te = (TileScreen)tileEntity;
/* 213 */               if ((te.frequency == screen.frequency) && (te.getBlockState() == screen.getBlockState()) && 
/* 214 */                 (oldID.equals(te.id)))
/*     */               {
/* 216 */                 screens.add(te);
/* 217 */                 for (EnumFacing side : perp_sides) {
/* 218 */                   BlockPos offset = next.offset(side);
/* 219 */                   if (!checkedPositions.contains(offset))
/* 220 */                     toCheck.offer(offset);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 225 */           for (TileScreen tileScreen : screens) {
/* 226 */             tileScreen.id = TileScreen.PacketEditScreen.this.id;
/* 227 */             tileScreen.markDirty();
/* 228 */             worldObj.func_175689_h(tileScreen.getPos());
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TileScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */