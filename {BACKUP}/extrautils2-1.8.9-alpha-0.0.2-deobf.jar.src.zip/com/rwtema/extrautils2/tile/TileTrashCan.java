/*    */ package com.rwtema.extrautils2.tile;
/*    */ 
/*    */ import com.rwtema.extrautils2.gui.backend.DynamicContainerTile;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ import net.minecraftforge.items.IItemHandlerModifiable;
/*    */ 
/*    */ public class TileTrashCan extends XUTile implements com.rwtema.extrautils2.gui.backend.IDynamicHandler
/*    */ {
/*    */   IItemHandler ABSORB_HANDLER;
/*    */   
/*    */   public TileTrashCan()
/*    */   {
/* 17 */     this.ABSORB_HANDLER = new IItemHandlerModifiable()
/*    */     {
/*    */       public void setStackInSlot(int slot, ItemStack stack) {}
/*    */       
/*    */ 
/*    */ 
/*    */       public int getSlots()
/*    */       {
/* 25 */         return 16;
/*    */       }
/*    */       
/*    */       public ItemStack getStackInSlot(int slot)
/*    */       {
/* 30 */         return null;
/*    */       }
/*    */       
/*    */       public ItemStack insertItem(int slot, ItemStack stack, boolean simulate)
/*    */       {
/* 35 */         return null;
/*    */       }
/*    */       
/*    */       public ItemStack extractItem(int slot, int amount, boolean simulate)
/*    */       {
/* 40 */         return null;
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   public IItemHandler getItemHandler(EnumFacing facing) {
/* 46 */     return this.ABSORB_HANDLER;
/*    */   }
/*    */   
/*    */   public com.rwtema.extrautils2.gui.backend.DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z)
/*    */   {
/* 51 */     return new ContainerTrashCan(player);
/*    */   }
/*    */   
/*    */   public class ContainerTrashCan extends DynamicContainerTile
/*    */   {
/*    */     public ContainerTrashCan(EntityPlayer player) {
/* 57 */       super(16, 64);
/* 58 */       addTitle(com.rwtema.extrautils2.utils.Lang.getItemName(TileTrashCan.this.getXUBlock()), false);
/* 59 */       addWidget(new com.rwtema.extrautils2.gui.backend.WidgetSlotItemHandler(TileTrashCan.this.ABSORB_HANDLER, 0, 76, 40));
/* 60 */       cropAndAddPlayerSlots(player.inventory);
/* 61 */       validate();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TileTrashCan.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */