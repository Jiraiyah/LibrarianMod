/*     */ package com.rwtema.extrautils2.tile;
/*     */ 
/*     */ import com.rwtema.extrautils2.asm.Lighting;
/*     */ import com.rwtema.extrautils2.lighting.ILight;
/*     */ import com.rwtema.extrautils2.utils.helpers.LightMathHelper;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.world.EnumSkyBlock;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ 
/*     */ public class TileSun extends TilePower implements ILight
/*     */ {
/*     */   private static final int range = 120;
/*     */   
/*     */   public World getLightWorld()
/*     */   {
/*  23 */     return this.worldObj;
/*     */   }
/*     */   
/*     */   public float getLightOffset(BlockPos lightPos)
/*     */   {
/*  28 */     float dx = lightPos.getX() - this.pos.getX();
/*  29 */     float dy = lightPos.getY() - this.pos.getY();
/*  30 */     float dz = lightPos.getZ() - this.pos.getZ();
/*  31 */     float mH = 1.0F - LightMathHelper.approxSqrt(dx * dx + dy * dy + dz * dz, 14400.0F);
/*  32 */     if (mH < 0.06666665F) return 0.0F;
/*  33 */     Chunk chunk = this.worldObj.getChunkFromBlockCoords(lightPos);
/*  34 */     int lightFor = chunk.getLightFor(EnumSkyBlock.SKY, lightPos);
/*  35 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public float sqr(float a) {
/*  39 */     return a * a;
/*     */   }
/*     */   
/*     */   public EnumSkyBlock[] getLightType()
/*     */   {
/*  44 */     return new EnumSkyBlock[] { EnumSkyBlock.BLOCK };
/*     */   }
/*     */   
/*     */   public void onPowerChanged()
/*     */   {
/*  49 */     this.worldObj.func_175689_h(this.pos);
/*     */   }
/*     */   
/*     */   public float getPower()
/*     */   {
/*  54 */     return 16.0F;
/*     */   }
/*     */   
/*     */ 
/*     */   public Packet getDescriptionPacket()
/*     */   {
/*  60 */     NBTTagCompound tags = new NBTTagCompound();
/*  61 */     tags.setBoolean("Active", this.active);
/*  62 */     return new S35PacketUpdateTileEntity(this.pos, -1, tags);
/*     */   }
/*     */   
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt)
/*     */   {
/*  67 */     NBTTagCompound nbt = pkt.getNbtCompound();
/*  68 */     boolean b = nbt.getBoolean("Active");
/*     */     
/*     */ 
/*  71 */     if (b != this.active) {
/*  72 */       this.active = b;
/*  73 */       updateLight();
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateLight() {
/*  78 */     this.worldObj.markBlockRangeForRenderUpdate(this.pos.getX() - 120, this.pos.getY() - 120, this.pos.getZ() - 120, this.pos.getX() + 120, this.pos.getY() + 120, this.pos.getZ() + 120);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onChunkUnload()
/*     */   {
/*  90 */     super.onChunkUnload();
/*  91 */     Lighting.unregister(this, getLightMap());
/*  92 */     if (this.worldObj.isRemote) {
/*  93 */       updateLight();
/*     */     }
/*     */   }
/*     */   
/*     */   public void invalidate()
/*     */   {
/*  99 */     super.invalidate();
/* 100 */     Lighting.unregister(this, getLightMap());
/* 101 */     if (this.worldObj.isRemote) {
/* 102 */       updateLight();
/*     */     }
/*     */   }
/*     */   
/*     */   public void validate()
/*     */   {
/* 108 */     super.validate();
/* 109 */     Lighting.register(this, getLightMap());
/*     */   }
/*     */   
/*     */   protected WeakHashMap<World, java.util.EnumMap<EnumSkyBlock, Set<ILight>>> getLightMap() {
/* 113 */     return Lighting.plusLights;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TileSun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */