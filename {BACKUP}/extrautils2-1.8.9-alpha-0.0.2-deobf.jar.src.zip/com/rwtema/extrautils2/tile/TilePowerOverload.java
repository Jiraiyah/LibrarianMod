/*    */ package com.rwtema.extrautils2.tile;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.model.XUBlockState;
/*    */ import com.rwtema.extrautils2.power.IPower;
/*    */ import com.rwtema.extrautils2.power.IWorldPowerMultiplier;
/*    */ import javax.annotation.Nonnull;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.util.ITickable;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class TilePowerOverload extends XUTile implements ITickable, IPower
/*    */ {
/*    */   public float getPower()
/*    */   {
/* 15 */     return 1.0E9F;
/*    */   }
/*    */   
/*    */   public IWorldPowerMultiplier getMultiplier()
/*    */   {
/* 20 */     return IWorldPowerMultiplier.CONSTANT;
/*    */   }
/*    */   
/*    */   public int frequency()
/*    */   {
/* 25 */     return 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void powerChanged(boolean powered) {}
/*    */   
/*    */ 
/*    */   @Nullable
/*    */   public World world()
/*    */   {
/* 36 */     return this.worldObj;
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public String getName()
/*    */   {
/* 42 */     return getBlockState().getUnlocalizedName();
/*    */   }
/*    */   
/*    */   public void update() {}
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TilePowerOverload.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */