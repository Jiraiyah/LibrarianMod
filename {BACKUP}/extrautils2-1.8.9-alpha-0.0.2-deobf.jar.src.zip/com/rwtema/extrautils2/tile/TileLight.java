/*    */ package com.rwtema.extrautils2.tile;
/*    */ 
/*    */ import com.rwtema.extrautils2.asm.Lighting;
/*    */ import com.rwtema.extrautils2.lighting.ILight;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.network.NetworkManager;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.EnumSkyBlock;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class TileLight extends XUTile implements ILight
/*    */ {
/*    */   static final int r = 96;
/* 16 */   public boolean active = false;
/*    */   
/*    */   public World getLightWorld()
/*    */   {
/* 20 */     return this.worldObj;
/*    */   }
/*    */   
/*    */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt)
/*    */   {
/* 25 */     boolean b = pkt.getNbtCompound().getBoolean("Active");
/* 26 */     if (b != this.active) {
/* 27 */       this.active = b;
/* 28 */       updateLight();
/*    */     }
/*    */   }
/*    */   
/*    */   private void updateLight() {
/* 33 */     this.worldObj.markBlockRangeForRenderUpdate(this.pos.getX() - 96, this.pos.getY() - 96, this.pos.getZ() - 96, this.pos.getX() + 96, this.pos.getY() + 96, this.pos.getZ() + 96);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Packet getDescriptionPacket()
/*    */   {
/* 44 */     NBTTagCompound tags = new NBTTagCompound();
/* 45 */     tags.setBoolean("Active", this.active);
/* 46 */     return new S35PacketUpdateTileEntity(this.pos, -1, tags);
/*    */   }
/*    */   
/*    */   public float getLightOffset(BlockPos pos)
/*    */   {
/* 51 */     if (!this.active) return 0.0F;
/* 52 */     return Math.max(15 - getRange(pos) * 15 / 96, 0);
/*    */   }
/*    */   
/*    */   public int getRange(BlockPos pos) {
/* 56 */     return Math.abs(this.pos.getX() - pos.getX()) + Math.abs(this.pos.getY() - pos.getY()) + Math.abs(this.pos.getZ() - pos.getZ());
/*    */   }
/*    */   
/*    */   public EnumSkyBlock[] getLightType()
/*    */   {
/* 61 */     return new EnumSkyBlock[] { EnumSkyBlock.BLOCK };
/*    */   }
/*    */   
/*    */   public void onChunkUnload()
/*    */   {
/* 66 */     super.onChunkUnload();
/* 67 */     Lighting.unregister(this, Lighting.plusLights);
/* 68 */     if (this.worldObj.isRemote) {
/* 69 */       updateLight();
/*    */     }
/*    */   }
/*    */   
/*    */   public void invalidate()
/*    */   {
/* 75 */     super.invalidate();
/* 76 */     Lighting.unregister(this, Lighting.plusLights);
/* 77 */     if (this.worldObj.isRemote) {
/* 78 */       updateLight();
/*    */     }
/*    */   }
/*    */   
/*    */   public void validate()
/*    */   {
/* 84 */     super.validate();
/* 85 */     Lighting.register(this, Lighting.plusLights);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TileLight.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */