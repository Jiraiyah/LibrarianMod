/*    */ package com.rwtema.extrautils2.tile;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.datastructures.InitMap;
/*    */ import com.rwtema.extrautils2.utils.datastructures.WeakSet;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class LocationRegistry
/*    */ {
/*  9 */   public static LocationRegistry sunTorches = new LocationRegistry();
/* 10 */   public static LocationRegistry magnumTorches = new LocationRegistry();
/*    */   
/* 12 */   InitMap<World, WeakSet<IRange>> locations = new InitMap(new java.util.WeakHashMap())
/*    */   {
/*    */     protected WeakSet<IRange> initValue(World key) {
/* 15 */       return new WeakSet();
/*    */     }
/*    */   };
/*    */   
/*    */   public void register(IRange range)
/*    */   {
/* 21 */     World world = range.world();
/* 22 */     if (world.isRemote) return;
/* 23 */     WeakSet<IRange> iRanges = (WeakSet)this.locations.get(world);
/* 24 */     iRanges.add(range);
/*    */   }
/*    */   
/*    */   public void unregister(IRange range) {
/* 28 */     World world = range.world();
/* 29 */     WeakSet<IRange> iRanges = (WeakSet)this.locations.get(world);
/* 30 */     iRanges.remove(range);
/* 31 */     if (iRanges.isEmpty()) this.locations.remove(world);
/*    */   }
/*    */   
/*    */   public boolean inRange(World world, double x, double y, double z) {
/* 35 */     if ((this.locations.isEmpty()) || (!this.locations.containsKey(world))) return false;
/* 36 */     WeakSet<IRange> iRanges = (WeakSet)this.locations.get(world);
/* 37 */     if (iRanges.isEmpty()) {
/* 38 */       this.locations.remove(world);
/* 39 */       return false;
/*    */     }
/*    */     
/* 42 */     for (IRange iRange : iRanges) {
/* 43 */       if (iRange.inRange(x, y, z)) return true;
/*    */     }
/* 45 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\LocationRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */