/*    */ package com.rwtema.extrautils2.tile;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import com.rwtema.extrautils2.backend.XUBlock;
/*    */ import com.rwtema.extrautils2.chunkloading.XUChunkLoaderManager;
/*    */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.ChunkCoordIntPair;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class TileChunkLoader extends TilePower
/*    */ {
/*    */   private GameProfile profile;
/* 21 */   public final int CHUNK_RANGE = 1;
/*    */   
/*    */   public void onPowerChanged()
/*    */   {
/* 25 */     XUChunkLoaderManager.dirty = true;
/*    */   }
/*    */   
/*    */   public void writeToNBT(NBTTagCompound compound)
/*    */   {
/* 30 */     super.writeToNBT(compound);
/* 31 */     if (this.profile != null) {
/* 32 */       compound.setTag("profile", NBTHelper.proifleToNBT(this.profile));
/*    */     }
/*    */   }
/*    */   
/*    */   public void readFromNBT(NBTTagCompound compound) {
/* 37 */     super.readFromNBT(compound);
/* 38 */     this.profile = NBTHelper.profileFromNBT(compound.getCompoundTag("profile"));
/*    */   }
/*    */   
/*    */   public float getPower()
/*    */   {
/* 43 */     return 8.0F;
/*    */   }
/*    */   
/*    */   public GameProfile getProfile() {
/* 47 */     return this.profile;
/*    */   }
/*    */   
/*    */   public java.util.Collection<ChunkCoordIntPair> getChunkCoords() {
/* 51 */     List<ChunkCoordIntPair> list = new ArrayList(10);
/* 52 */     int x = getPos().getX() >> 4;
/* 53 */     int z = getPos().getZ() >> 4;
/* 54 */     for (int dx = -1; dx <= 1; dx++) {
/* 55 */       for (int dz = -1; dz <= 1; dz++) {
/* 56 */         list.add(new ChunkCoordIntPair(x + dx, z + dz));
/*    */       }
/*    */     }
/*    */     
/* 60 */     return list;
/*    */   }
/*    */   
/*    */   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack, XUBlock xuBlock)
/*    */   {
/* 65 */     if ((placer instanceof EntityPlayerMP)) {
/* 66 */       GameProfile gameProfile = ((EntityPlayerMP)placer).getGameProfile();
/* 67 */       this.profile = new GameProfile(gameProfile.getId(), gameProfile.getName());
/*    */     }
/* 69 */     super.onBlockPlacedBy(worldIn, pos, state, placer, stack, xuBlock);
/*    */   }
/*    */   
/*    */   public void invalidate()
/*    */   {
/* 74 */     super.invalidate();
/* 75 */     if (!this.worldObj.isRemote) {
/* 76 */       XUChunkLoaderManager.unregister(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public void onChunkUnload()
/*    */   {
/* 82 */     super.onChunkUnload();
/* 83 */     if (!this.worldObj.isRemote) {
/* 84 */       XUChunkLoaderManager.unregister(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public void validate()
/*    */   {
/* 90 */     super.validate();
/* 91 */     if (!this.worldObj.isRemote) {
/* 92 */       XUChunkLoaderManager.register(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TileChunkLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */