/*     */ package com.rwtema.extrautils2.tile;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainer;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainerTile;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicGui;
/*     */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*     */ import com.rwtema.extrautils2.gui.backend.IWidgetServerNetwork;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetClick;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetSlotItemHandler;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetText;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetTextData;
/*     */ import com.rwtema.extrautils2.itemhandler.ConcatFixedLength;
/*     */ import com.rwtema.extrautils2.itemhandler.EmptyHandlerModifiable;
/*     */ import com.rwtema.extrautils2.itemhandler.SingleStackHandlerBase;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.ColorHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.PlayerHelper;
/*     */ import gnu.trove.set.hash.TIntHashSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityMinecartChest;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.management.ServerConfigurationManager;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.StringUtils;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import net.minecraftforge.items.IItemHandlerModifiable;
/*     */ import net.minecraftforge.items.ItemStackHandler;
/*     */ import net.minecraftforge.items.wrapper.InvWrapper;
/*     */ 
/*     */ public class TilePlayerChest extends TilePower implements IDynamicHandler
/*     */ {
/*  57 */   private static final int[] col = { -2142220208, -2130751408, -2142175408, -2130706433 };
/*     */   public IItemHandlerModifiable PLAYER_HANDLER;
/*     */   
/*  60 */   public TilePlayerChest() { this.extractable = new TIntHashSet();
/*  61 */     this.insertable = new TIntHashSet();
/*     */     
/*     */ 
/*     */ 
/*  65 */     this.playerInvHandlers = new IItemHandler[5];
/*     */     
/*  67 */     this.playerInvHandlers[0 = new IItemHandlerModifiable()
/*     */     {
/*     */       public void setStackInSlot(int slot, ItemStack stack) {
/*  70 */         EntityPlayerMP ownerPlayer = TilePlayerChest.this.getOwnerPlayer();
/*  71 */         if (ownerPlayer != null) {
/*  72 */           ownerPlayer.inventory.setInventorySlotContents(slot, stack);
/*  73 */           PlayerHelper.syncInventory(ownerPlayer);
/*     */         }
/*     */       }
/*     */       
/*     */       public int getSlots()
/*     */       {
/*  79 */         return 36;
/*     */       }
/*     */       
/*     */       public ItemStack getStackInSlot(int slot)
/*     */       {
/*  84 */         return TilePlayerChest.this.getTarget().getStackInSlot(slot);
/*     */       }
/*     */       
/*     */       public ItemStack insertItem(int slot, ItemStack stack, boolean simulate)
/*     */       {
/*  89 */         if (simulate)
/*  90 */           return TilePlayerChest.this.getTarget().insertItem(slot, stack, true);
/*  91 */         EntityPlayerMP ownerPlayer = TilePlayerChest.this.getOwnerPlayer();
/*  92 */         if (ownerPlayer == null) return stack;
/*  93 */         ItemStack itemStack = TilePlayerChest.this.getTarget().insertItem(slot, stack, false);
/*  94 */         PlayerHelper.syncInventory(ownerPlayer);
/*  95 */         return itemStack;
/*     */       }
/*     */       
/*     */       public ItemStack extractItem(int slot, int amount, boolean simulate)
/*     */       {
/* 100 */         if (simulate)
/* 101 */           return TilePlayerChest.this.getTarget().extractItem(slot, amount, true);
/* 102 */         EntityPlayerMP ownerPlayer = TilePlayerChest.this.getOwnerPlayer();
/* 103 */         if (ownerPlayer == null) return null;
/* 104 */         ItemStack itemStack = TilePlayerChest.this.getTarget().extractItem(slot, amount, false);
/* 105 */         PlayerHelper.syncInventory(ownerPlayer);
/* 106 */         return itemStack;
/*     */       }
/*     */     };
/*     */     
/* 110 */     for (int i = 0; i < 4; i++) {
/* 111 */       final int finalI = i;
/* 112 */       this.playerInvHandlers[(i + 1) = new SingleStackHandlerBase()
/*     */       {
/*     */         public ItemStack getStack() {
/* 115 */           EntityPlayerMP ownerPlayer = TilePlayerChest.this.getOwnerPlayer();
/* 116 */           if (ownerPlayer == null) return null;
/* 117 */           return ownerPlayer.inventory.armorInventory[(3 - finalI)];
/*     */         }
/*     */         
/*     */         public void setStack(ItemStack curStack)
/*     */         {
/* 122 */           EntityPlayerMP ownerPlayer = TilePlayerChest.this.getOwnerPlayer();
/* 123 */           if (ownerPlayer == null) return;
/* 124 */           ownerPlayer.inventory.armorInventory[(3 - finalI)] = curStack;
/* 125 */           PlayerHelper.syncInventory(ownerPlayer);
/*     */         }
/*     */         
/*     */         protected int getStackLimit(ItemStack stack)
/*     */         {
/* 130 */           if (stack == null) return 0;
/* 131 */           EntityPlayerMP ownerPlayer = TilePlayerChest.this.getOwnerPlayer();
/* 132 */           return (ownerPlayer != null) && (stack.getItem().isValidArmor(stack, finalI, ownerPlayer)) ? 1 : 0;
/*     */         }
/*     */       };
/*     */     }
/*     */     
/* 137 */     this.PLAYER_HANDLER = new ConcatFixedLength(this.playerInvHandlers)
/*     */     {
/*     */       public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
/* 140 */         if (!TilePlayerChest.this.insertable.contains(slot)) return stack;
/* 141 */         return super.insertItem(slot, stack, simulate);
/*     */       }
/*     */       
/*     */       public ItemStack extractItem(int slot, int amount, boolean simulate)
/*     */       {
/* 146 */         if (!TilePlayerChest.this.extractable.contains(slot)) return null;
/* 147 */         return super.extractItem(slot, amount, simulate);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   GameProfile profile;
/* 153 */   public IItemHandlerModifiable getTarget() { EntityPlayerMP target = getOwnerPlayer();
/* 154 */     if (target == null)
/* 155 */       return EmptyHandlerModifiable.INSTANCE;
/* 156 */     return new InvWrapper(target.inventory);
/*     */   }
/*     */   
/*     */   @javax.annotation.Nullable
/*     */   public EntityPlayerMP getOwnerPlayer() {
/* 161 */     if ((this.profile == null) || (this.worldObj == null) || (this.worldObj.isRemote) || (!this.active))
/* 162 */       return null;
/* 163 */     EntityPlayerMP target = null;
/* 164 */     MinecraftServer server = MinecraftServer.func_71276_C();
/* 165 */     if (server != null) {
/* 166 */       for (EntityPlayerMP playerMP : server.func_71203_ab().playerEntityList)
/* 167 */         if (this.profile.equals(playerMP.getGameProfile())) {
/* 168 */           if (playerMP.isDead) return null;
/* 169 */           target = playerMP;
/*     */         }
/*     */     }
/* 172 */     return target;
/*     */   }
/*     */   
/*     */   public IItemHandler getItemHandler(EnumFacing facing)
/*     */   {
/* 177 */     return this.PLAYER_HANDLER;
/*     */   }
/*     */   
/*     */   public void onPowerChanged()
/*     */   {
/* 182 */     this.worldObj.func_175689_h(this.pos);
/*     */   }
/*     */   
/*     */   public void addToDescriptionPacket(PacketBuffer packet)
/*     */   {
/* 187 */     packet.writeBoolean(this.active);
/* 188 */     if (this.profile != null) {
/* 189 */       String name = this.profile.getName();
/* 190 */       packet.writeString(name);
/*     */     } else {
/* 192 */       packet.writeShort(0);
/*     */     }
/*     */   }
/*     */   
/*     */   public void handleDescriptionPacket(PacketBuffer packet) {
/* 197 */     this.active = packet.readBoolean();
/* 198 */     String s = packet.readString();
/* 199 */     if (StringUtils.isNullOrEmpty(s)) {
/* 200 */       this.profile = null;
/*     */     } else {
/* 202 */       this.profile = new GameProfile(null, s);
/*     */     }
/*     */   }
/*     */   
/*     */   public float getPower() {
/* 207 */     return 4.0F;
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 212 */     super.writeToNBT(compound);
/* 213 */     if (this.profile != null) {
/* 214 */       compound.setTag("Owner", NBTHelper.proifleToNBT(this.profile));
/*     */     }
/* 216 */     compound.setIntArray("InsertSlots", this.insertable.toArray());
/* 217 */     compound.setIntArray("ExtractSlots", this.extractable.toArray());
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 222 */     super.readFromNBT(compound);
/* 223 */     this.profile = NBTHelper.profileFromNBT(compound.getCompoundTag("Owner"));
/* 224 */     this.insertable.addAll(compound.getIntArray("InsertSlots"));
/* 225 */     this.extractable.addAll(compound.getIntArray("ExtractSlots"));
/*     */   }
/*     */   
/*     */   TIntHashSet extractable;
/*     */   TIntHashSet insertable;
/*     */   IItemHandler[] playerInvHandlers;
/* 231 */   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack, XUBlock xuBlock) { super.onBlockPlacedBy(worldIn, pos, state, placer, stack, xuBlock);
/* 232 */     if ((placer instanceof EntityPlayer)) {
/* 233 */       if (PlayerHelper.isPlayerReal((EntityPlayer)placer)) {
/* 234 */         this.profile = ((EntityPlayer)placer).getGameProfile();
/*     */       } else {
/* 236 */         this.profile = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/* 243 */     if (!worldIn.isRemote) {
/* 244 */       if ((ExtraUtils2.deobf_folder) && 
/* 245 */         (ExtraUtils2.proxy.isAltSneaking(playerIn))) {
/* 246 */         openGUI(playerIn, 2);
/* 247 */         return true;
/*     */       }
/*     */       
/*     */ 
/* 251 */       EntityPlayerMP ownerPlayer = getOwnerPlayer();
/* 252 */       if (ownerPlayer == playerIn) {
/* 253 */         openGUI(playerIn, 0);
/* 254 */       } else if (ownerPlayer != null)
/* 255 */         openGUI(playerIn, 1);
/*     */     }
/* 257 */     return true;
/*     */   }
/*     */   
/*     */   public DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/* 262 */     if (ID == 0) {
/* 263 */       return new DynamicPlayerChestConfig(player);
/*     */     }
/* 265 */     if (ID == 1) {
/* 266 */       if (world.isRemote) {
/* 267 */         return new DynamicPlayerChest(player, new ItemStackHandler(40));
/*     */       }
/* 269 */       return new DynamicPlayerChest(player, this.PLAYER_HANDLER);
/*     */     }
/*     */     
/*     */ 
/* 273 */     if (ID == 2) {
/* 274 */       if (world.isRemote) {
/* 275 */         return new DynamicPlayerChest(player, new ItemStackHandler(40));
/*     */       }
/* 277 */       List<EntityMinecartChest> ents = world.getEntitiesWithinAABB(EntityMinecartChest.class, new AxisAlignedBB(x, y, z, x + 1, y + 1, z + 1).expand(10.0D, 10.0D, 10.0D));
/* 278 */       if ((ents == null) || (ents.isEmpty())) {
/* 279 */         return new DynamicPlayerChest(player, EmptyHandlerModifiable.INSTANCE);
/*     */       }
/*     */       
/* 282 */       EntityMinecartChest entityMinecartChest = (EntityMinecartChest)ents.get(0);
/* 283 */       final InvWrapper invWrapper = new InvWrapper(entityMinecartChest);
/* 284 */       new DynamicPlayerChest(player, new IItemHandlerModifiable()
/*     */       {
/*     */         public void setStackInSlot(int slot, ItemStack stack) {
/* 287 */           if (slot < invWrapper.getSlots()) invWrapper.setStackInSlot(slot, stack);
/*     */         }
/*     */         
/*     */         public int getSlots()
/*     */         {
/* 292 */           return 40;
/*     */         }
/*     */         
/*     */         public ItemStack getStackInSlot(int slot)
/*     */         {
/* 297 */           if (slot < invWrapper.getSlots()) return invWrapper.getStackInSlot(slot);
/* 298 */           return null;
/*     */         }
/*     */         
/*     */         public ItemStack insertItem(int slot, ItemStack stack, boolean simulate)
/*     */         {
/* 303 */           if (slot < invWrapper.getSlots()) return invWrapper.insertItem(slot, stack, simulate);
/* 304 */           return stack;
/*     */         }
/*     */         
/*     */         public ItemStack extractItem(int slot, int amount, boolean simulate)
/*     */         {
/* 309 */           if (slot < invWrapper.getSlots()) return invWrapper.extractItem(slot, amount, simulate);
/* 310 */           return null;
/*     */         }
/*     */       });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 317 */     return null;
/*     */   }
/*     */   
/*     */   public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {}
/*     */   
/*     */   public class DynamicPlayerChest
/*     */     extends DynamicContainerTile
/*     */   {
/*     */     IItemHandler target;
/*     */     
/*     */     public DynamicPlayerChest(EntityPlayer player, IItemHandler target)
/*     */     {
/* 329 */       super();
/* 330 */       this.target = target;
/* 331 */       int x = 4;int y = 4;
/* 332 */       addWidget(new WidgetTextData(x, y, 162)
/*     */       {
/*     */         public void addToDescription(PacketBuffer packet) {
/* 335 */           packet.writeString(TilePlayerChest.this.profile == null ? "" : TilePlayerChest.this.profile.getName());
/*     */         }
/*     */         
/*     */         protected String constructText(PacketBuffer packet)
/*     */         {
/* 340 */           String s = packet.readString();
/* 341 */           if (StringUtils.isNullOrEmpty(s)) return "";
/* 342 */           return Lang.translateArgs("%s's Inventory", new Object[] { s });
/*     */         }
/*     */         
/*     */ 
/* 346 */       });
/* 347 */       y += 9;
/*     */       
/* 349 */       for (int i = 0; i < 4; i++) {
/* 350 */         final int finalI = i;
/* 351 */         addWidget(new WidgetSlotAccess(target, 36 + finalI, x + finalI * 18, y, TilePlayerChest.this) {
/*     */           @SideOnly(Side.CLIENT)
/*     */           public String getSlotTexture() {
/* 354 */             return net.minecraft.item.ItemArmor.EMPTY_SLOT_NAMES[finalI];
/*     */           }
/*     */           
/*     */           public int getSlotStackLimit() {
/* 358 */             return 1;
/*     */           }
/*     */           
/*     */           public boolean isItemValid(ItemStack stack) {
/* 362 */             if (!super.isItemValid(stack)) return false;
/* 363 */             EntityPlayerMP ownerPlayer = TilePlayerChest.this.getOwnerPlayer();
/* 364 */             return (ownerPlayer != null) && (stack.getItem().isValidArmor(stack, finalI, ownerPlayer));
/*     */           }
/*     */         });
/*     */       }
/*     */       
/* 369 */       y += 18;
/*     */       
/* 371 */       for (int j = 0; j < 3; j++) {
/* 372 */         for (int k = 0; k < 9; k++) {
/* 373 */           addWidget(new WidgetSlotAccess(target, k + j * 9 + 9, x + k * 18, y + 14 + j * 18));
/*     */         }
/*     */       }
/*     */       
/* 377 */       for (int j = 0; j < 9; j++) {
/* 378 */         addWidget(new WidgetSlotAccess(target, j, x + j * 18, y + 14 + 58));
/*     */       }
/*     */       
/* 381 */       cropAndAddPlayerSlots(player.inventory);
/* 382 */       validate();
/*     */     }
/*     */     
/*     */     public boolean canInteractWith(EntityPlayer playerIn)
/*     */     {
/* 387 */       return super.canInteractWith(playerIn);
/*     */     }
/*     */     
/*     */     public class WidgetSlotAccess extends WidgetSlotItemHandler implements IWidgetServerNetwork {
/* 391 */       byte accessType = 3;
/*     */       
/*     */       public WidgetSlotAccess(IItemHandler itemHandler, int index, int xPosition, int yPosition) {
/* 394 */         super(index, xPosition, yPosition);
/*     */       }
/*     */       
/*     */       public void addToDescription(PacketBuffer packet)
/*     */       {
/* 399 */         this.accessType = ((byte)((TilePlayerChest.this.insertable.contains(this.index) ? 1 : 0) | (TilePlayerChest.this.extractable.contains(this.index) ? 2 : 0)));
/* 400 */         packet.writeByte(this.accessType);
/*     */       }
/*     */       
/*     */       public void handleDescriptionPacket(PacketBuffer packet)
/*     */       {
/* 405 */         this.accessType = packet.readByte();
/*     */       }
/*     */       
/*     */       public boolean isItemValid(ItemStack stack)
/*     */       {
/* 410 */         return ((this.accessType & 0x1) != 0) && (super.isItemValid(stack));
/*     */       }
/*     */       
/*     */       public boolean canTakeStack(EntityPlayer playerIn)
/*     */       {
/* 415 */         return ((this.accessType & 0x2) != 0) && (super.canTakeStack(playerIn));
/*     */       }
/*     */       
/*     */ 
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */       {
/* 422 */         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 423 */         gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 0, 0, 18, 18);
/* 424 */         int color = TilePlayerChest.col[(this.accessType & 0x3)];
/* 425 */         GlStateManager.color(ColorHelper.getRF(color), ColorHelper.getGF(color), ColorHelper.getBF(color), 1.0F);
/* 426 */         gui.drawTexturedModalRect(guiLeft + getX() + 1, guiTop + getY() + 1, 1, 1, 16, 16);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public class DynamicPlayerChestConfig extends DynamicContainerTile
/*     */   {
/* 433 */     int clickType = -1;
/*     */     
/*     */     public DynamicPlayerChestConfig(EntityPlayer player) {
/* 436 */       super();
/* 437 */       int x = 4;int y = 4;
/* 438 */       addWidget(new WidgetTextData(x, y, 162)
/*     */       {
/*     */         public void addToDescription(PacketBuffer packet) {
/* 441 */           packet.writeString(TilePlayerChest.this.profile == null ? "" : TilePlayerChest.this.profile.getName());
/*     */         }
/*     */         
/*     */         @SideOnly(Side.CLIENT)
/*     */         protected String constructText(PacketBuffer packet)
/*     */         {
/* 447 */           String s = packet.readString();
/* 448 */           if (StringUtils.isNullOrEmpty(s)) return "";
/* 449 */           return Lang.translateArgs("%s's Inventory", new Object[] { s });
/*     */         }
/*     */         
/* 452 */       });
/* 453 */       y += 9;
/*     */       
/* 455 */       addWidget(new WidgetText(x, y, Lang.translate("Configuration")));
/*     */       
/* 457 */       y += 9;
/*     */       
/* 459 */       for (int i = 0; i < 4; i++) {
/* 460 */         final int finalI = i;
/* 461 */         addWidget(new WidgetClickableSlot(36 + finalI, x + finalI * 18, y, TilePlayerChest.this)
/*     */         {
/*     */           @SideOnly(Side.CLIENT)
/*     */           public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop) {
/* 465 */             super.renderBackground(manager, gui, guiLeft, guiTop);
/* 466 */             if (this.displayStack != null) return;
/* 467 */             net.minecraft.client.renderer.texture.TextureAtlasSprite textureExtry = Minecraft.getMinecraft().getTextureMapBlocks().getTextureExtry(net.minecraft.item.ItemArmor.EMPTY_SLOT_NAMES[finalI]);
/* 468 */             if (textureExtry != null) {
/* 469 */               manager.bindTexture(TextureMap.locationBlocksTexture);
/* 470 */               gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), textureExtry, 16, 16);
/* 471 */               manager.bindTexture(gui.getWidgetTexture());
/*     */             }
/*     */           }
/*     */         });
/*     */       }
/*     */       
/*     */ 
/* 478 */       y += 18;
/*     */       
/* 480 */       for (int j = 0; j < 3; j++) {
/* 481 */         for (int k = 0; k < 9; k++) {
/* 482 */           addWidget(new WidgetClickableSlot(k + j * 9 + 9, x + k * 18, y + 14 + j * 18));
/*     */         }
/*     */       }
/*     */       
/* 486 */       for (int j = 0; j < 9; j++) {
/* 487 */         addWidget(new WidgetClickableSlot(j, x + j * 18, y + 14 + 58));
/*     */       }
/*     */       
/* 490 */       cropAndAddPlayerSlots(player.inventory);
/* 491 */       validate();
/*     */     }
/*     */     
/*     */     public ItemStack func_75144_a(int slotId, int clickedButton, int mode, EntityPlayer playerIn)
/*     */     {
/* 496 */       return super.func_75144_a(slotId, clickedButton, mode, playerIn);
/*     */     }
/*     */     
/*     */     protected void retrySlotClick(int slotId, int clickedButton, boolean mode, EntityPlayer playerIn)
/*     */     {
/* 501 */       super.retrySlotClick(slotId, clickedButton, mode, playerIn);
/*     */     }
/*     */     
/*     */     public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int par2)
/*     */     {
/* 506 */       return super.transferStackInSlot(par1EntityPlayer, par2);
/*     */     }
/*     */     
/*     */     public boolean canInteractWith(EntityPlayer playerIn)
/*     */     {
/* 511 */       if ((!this.isClient) && 
/* 512 */         (playerIn != TilePlayerChest.this.getOwnerPlayer())) {
/* 513 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 517 */       return (super.canInteractWith(playerIn)) && (TilePlayerChest.this.active);
/*     */     }
/*     */     
/*     */     public class WidgetClickableSlot extends WidgetClick implements IWidgetServerNetwork {
/*     */       private final int slot;
/*     */       ItemStack displayStack;
/* 523 */       byte accessType = 0;
/*     */       
/* 525 */       boolean overMe = false;
/*     */       
/*     */       public WidgetClickableSlot(int slot, int x, int y) {
/* 528 */         super(y, 18, 18);
/* 529 */         this.slot = slot;
/*     */       }
/*     */       
/*     */       public void onClick(byte b)
/*     */       {
/* 534 */         if ((b & 0x1) != 0) {
/* 535 */           TilePlayerChest.this.insertable.add(this.slot);
/*     */         } else {
/* 537 */           TilePlayerChest.this.insertable.remove(this.slot);
/*     */         }
/* 539 */         if ((b & 0x2) != 0) {
/* 540 */           TilePlayerChest.this.extractable.add(this.slot);
/*     */         } else {
/* 542 */           TilePlayerChest.this.extractable.remove(this.slot);
/*     */         }
/*     */       }
/*     */       
/*     */       public void addToDescription(PacketBuffer packet)
/*     */       {
/* 548 */         packet.writeByte((TilePlayerChest.this.insertable.contains(this.slot) ? 1 : 0) | (TilePlayerChest.this.extractable.contains(this.slot) ? 2 : 0));
/* 549 */         packet.writeItemStack(TilePlayerChest.this.PLAYER_HANDLER.getStackInSlot(this.slot));
/*     */       }
/*     */       
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void handleDescriptionPacket(PacketBuffer packet)
/*     */       {
/* 555 */         this.accessType = packet.readByte();
/* 556 */         this.displayStack = packet.readItemStack();
/*     */       }
/*     */       
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */       {
/* 562 */         if (this.displayStack == null) return;
/* 563 */         GlStateManager.enableLighting();
/* 564 */         RenderHelper.enableGUIStandardItemLighting();
/* 565 */         gui.renderStack(this.displayStack, guiLeft + getX() + 1, guiTop + getY() + 1, null);
/* 566 */         RenderHelper.disableStandardItemLighting();
/* 567 */         GlStateManager.disableLighting();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */       {
/* 576 */         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 577 */         gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 0, 0, 18, 18);
/* 578 */         int color = TilePlayerChest.col[(this.accessType & 0x3)];
/* 579 */         GlStateManager.color(ColorHelper.getRF(color), ColorHelper.getGF(color), ColorHelper.getBF(color), 1.0F);
/* 580 */         gui.drawTexturedModalRect(guiLeft + getX() + 1, guiTop + getY() + 1, 1, 1, 16, 16);
/*     */       }
/*     */       
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void mouseClicked(int mouseX, int mouseY, int mouseButton, boolean mouseOver)
/*     */       {
/* 586 */         if ((mouseOver) && ((mouseButton == 0) || (mouseButton == 1))) {
/* 587 */           TilePlayerChest.DynamicPlayerChestConfig.this.clickType = (this.accessType + (mouseButton * 2 - 1) & 0x3);
/* 588 */           this.overMe = true;
/* 589 */           sendClick(TilePlayerChest.DynamicPlayerChestConfig.this.clickType);
/*     */         }
/*     */       }
/*     */       
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void mouseReleased(int mouseX, int mouseY, int mouseButton, boolean mouseOver)
/*     */       {
/* 596 */         super.mouseReleased(mouseX, mouseY, mouseButton, mouseOver);
/* 597 */         TilePlayerChest.DynamicPlayerChestConfig.this.clickType = -1;
/* 598 */         this.overMe = false;
/*     */       }
/*     */       
/*     */ 
/*     */       @SideOnly(Side.CLIENT)
/*     */       public void mouseClickMove(int mouseX, int mouseY, int mouseButton, long timeSinceLastMove, boolean mouseOver)
/*     */       {
/* 605 */         if ((mouseOver) && (TilePlayerChest.DynamicPlayerChestConfig.this.clickType != -1) && 
/* 606 */           (!this.overMe)) {
/* 607 */           sendClick(TilePlayerChest.DynamicPlayerChestConfig.this.clickType);
/* 608 */           this.overMe = true;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */       @SideOnly(Side.CLIENT)
/*     */       public List<String> getToolTip()
/*     */       {
/* 616 */         ArrayList<String> strings = com.google.common.collect.Lists.newArrayList();
/* 617 */         switch (this.accessType) {
/*     */         case 0: 
/* 619 */           strings.add(ChatFormatting.GRAY + Lang.translate("No Access") + ChatFormatting.RESET);
/* 620 */           break;
/*     */         case 1: 
/* 622 */           strings.add(ChatFormatting.RED + Lang.translate("Insert Only") + ChatFormatting.RESET);
/* 623 */           break;
/*     */         case 2: 
/* 625 */           strings.add(ChatFormatting.GREEN + Lang.translate("Extract Only") + ChatFormatting.RESET);
/* 626 */           break;
/*     */         case 3: 
/* 628 */           strings.add(ChatFormatting.WHITE + Lang.translate("Full Access") + ChatFormatting.RESET);
/*     */         }
/*     */         
/* 631 */         return strings;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TilePlayerChest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */