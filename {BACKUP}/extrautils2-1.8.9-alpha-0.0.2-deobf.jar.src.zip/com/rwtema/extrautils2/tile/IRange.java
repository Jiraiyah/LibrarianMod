package com.rwtema.extrautils2.tile;

import net.minecraft.world.World;

public abstract interface IRange
{
  public abstract boolean inRange(double paramDouble1, double paramDouble2, double paramDouble3);
  
  public abstract World world();
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\IRange.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */