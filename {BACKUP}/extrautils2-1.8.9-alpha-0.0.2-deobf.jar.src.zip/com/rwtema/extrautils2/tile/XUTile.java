/*     */ package com.rwtema.extrautils2.tile;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.model.XUBlockState;
/*     */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*     */ import com.rwtema.extrautils2.itemhandler.ConcatItemHandler;
/*     */ import com.rwtema.extrautils2.itemhandler.InventoryHelper;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.renderer.BlockModelRenderer;
/*     */ import net.minecraft.client.renderer.BlockRendererDispatcher;
/*     */ import net.minecraft.client.renderer.WorldRenderer;
/*     */ import net.minecraft.client.resources.model.IBakedModel;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ import net.minecraftforge.common.capabilities.Capability;
/*     */ import net.minecraftforge.common.util.INBTSerializable;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.minecraftforge.items.CapabilityItemHandler;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import net.minecraftforge.items.wrapper.EmptyHandler;
/*     */ 
/*     */ public abstract class XUTile extends TileEntity
/*     */ {
/*     */   @Nullable
/*     */   public HashMap<Capability<?>, XUTileCapabilitySide<?, ?>> sidedCapabilities;
/*     */   XUBlock xuBlock;
/*     */   XUBlockState state;
/*     */   @Nullable
/*     */   private HashMap<String, INBTSerializable> nbtHandlers;
/*     */   
/*     */   public static boolean isLoaded(TileEntity tile)
/*     */   {
/*  61 */     return (!tile.isInvalid()) && (tile.getWorld() != null) && (tile.getPos() != null) && (tile.getWorld().isBlockLoaded(tile.getPos())) && (tile.getWorld().getTileEntity(tile.getPos()) == tile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static <T extends TileEntity> List<T> searchAABBForTiles(World world, AxisAlignedBB area, Class<T> tileClazz, boolean firstOnly, List<T> list)
/*     */   {
/*  68 */     int x0 = (int)Math.floor(area.minX) >> 4;
/*  69 */     int x1 = (int)Math.ceil(area.maxX) >> 4;
/*  70 */     int z0 = (int)Math.floor(area.minZ) >> 4;
/*  71 */     int z1 = (int)Math.ceil(area.maxZ) >> 4;
/*     */     
/*  73 */     if (list == null) { list = Lists.newArrayList();
/*     */     }
/*  75 */     for (int x = x0; x <= x1; x++) {
/*  76 */       for (int z = z0; z <= z1; z++) {
/*  77 */         Chunk chunk = world.getChunkFromChunkCoords(x, z);
/*  78 */         for (Map.Entry<BlockPos, TileEntity> entry : chunk.getTileEntityMap().entrySet()) {
/*  79 */           BlockPos pos = (BlockPos)entry.getKey();
/*  80 */           if ((tileClazz == ((TileEntity)entry.getValue()).getClass()) && (area.isVecInside(new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D)))) {
/*  81 */             list.add((TileEntity)entry.getValue());
/*  82 */             if (firstOnly) { return list;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  88 */     return list;
/*     */   }
/*     */   
/*     */   protected <T extends INBTSerializable> T registerNBT(String key, T t) {
/*  92 */     if (this.nbtHandlers == null) {
/*  93 */       this.nbtHandlers = new HashMap();
/*     */     }
/*  95 */     this.nbtHandlers.put(key, t);
/*  96 */     return t;
/*     */   }
/*     */   
/*     */ 
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 102 */     super.readFromNBT(compound);
/* 103 */     if (this.nbtHandlers != null) {
/* 104 */       for (Map.Entry<String, INBTSerializable> entry : this.nbtHandlers.entrySet()) {
/* 105 */         NBTBase tag = compound.getTag((String)entry.getKey());
/* 106 */         if (tag != null)
/* 107 */           ((INBTSerializable)entry.getValue()).deserializeNBT(tag);
/*     */       }
/*     */     }
/* 110 */     if (this.sidedCapabilities != null) {
/* 111 */       for (XUTileCapabilitySide<?, ?> entry : this.sidedCapabilities.values()) {
/* 112 */         entry.readNBT(compound);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound) {
/* 118 */     super.writeToNBT(compound);
/* 119 */     if (this.nbtHandlers != null) {
/* 120 */       for (Map.Entry<String, INBTSerializable> entry : this.nbtHandlers.entrySet()) {
/* 121 */         compound.setTag((String)entry.getKey(), ((INBTSerializable)entry.getValue()).serializeNBT());
/*     */       }
/*     */     }
/* 124 */     if (this.sidedCapabilities != null) {
/* 125 */       for (XUTileCapabilitySide<?, ?> entry : this.sidedCapabilities.values())
/* 126 */         entry.writeNBT(compound);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isLoaded() {
/* 131 */     return isLoaded(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack, XUBlock xuBlock) {}
/*     */   
/*     */ 
/*     */   public void onNeighborBlockChange(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock) {}
/*     */   
/*     */ 
/*     */   public void breakBlock(World worldIn, BlockPos pos, IBlockState state)
/*     */   {
/* 143 */     IItemHandler itemHandler = getItemHandler(null);
/* 144 */     if (itemHandler != null) {
/* 145 */       InventoryHelper.dropAll(worldIn, pos, itemHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean harvestBlock(World worldIn, EntityPlayer player, BlockPos pos, IBlockState state) {
/* 150 */     return false;
/*     */   }
/*     */   
/*     */   public void updateContainingBlockInfo()
/*     */   {
/* 155 */     super.updateContainingBlockInfo();
/* 156 */     this.xuBlock = null;
/* 157 */     this.state = null;
/*     */   }
/*     */   
/*     */   public XUBlockState getBlockState() {
/* 161 */     if (this.state == null) {
/* 162 */       this.state = ((XUBlockState)this.worldObj.getBlockState(this.pos));
/*     */     }
/* 164 */     return this.state;
/*     */   }
/*     */   
/*     */   public XUBlock getXUBlock() {
/* 168 */     if (this.xuBlock == null) {
/* 169 */       this.xuBlock = ((XUBlock)getBlockState().getBlock());
/*     */     }
/* 171 */     return this.xuBlock;
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 175 */     if ((this instanceof IDynamicHandler)) {
/* 176 */       if (!worldIn.isRemote) {
/* 177 */         openGUI(playerIn);
/*     */       }
/* 179 */       return true;
/*     */     }
/* 181 */     return false;
/*     */   }
/*     */   
/*     */   public void openGUI(EntityPlayer player) {
/* 185 */     openGUI(player, 0);
/*     */   }
/*     */   
/*     */   public void openGUI(EntityPlayer player, int modGuiId) {
/* 189 */     player.openGui(ExtraUtils2.instance, modGuiId, this.worldObj, this.pos.getX(), this.pos.getY(), this.pos.getZ());
/*     */   }
/*     */   
/*     */   public IItemHandler getItemHandler(EnumFacing facing) {
/* 193 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> T getCapability(Capability<T> capability, EnumFacing facing)
/*     */   {
/* 199 */     if ((this.sidedCapabilities != null) && (this.sidedCapabilities.containsKey(capability))) {
/* 200 */       XUTileCapabilitySide<?, ?> capabilityEntry = (XUTileCapabilitySide)this.sidedCapabilities.get(capability);
/* 201 */       T handler = capabilityEntry.get(facing);
/* 202 */       if (handler != null) {
/* 203 */         return handler;
/*     */       }
/*     */     }
/* 206 */     if (CapabilityItemHandler.ITEM_HANDLER_CAPABILITY == capability) {
/* 207 */       IItemHandler handler = getItemHandler(facing);
/* 208 */       if (handler != null) return handler;
/*     */     }
/* 210 */     return (T)super.getCapability(capability, facing);
/*     */   }
/*     */   
/*     */   public final boolean hasCapability(Capability<?> capability, EnumFacing facing)
/*     */   {
/* 215 */     return getCapability(capability, facing) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addToDescriptionPacket(PacketBuffer packet) {}
/*     */   
/*     */ 
/*     */   public void handleDescriptionPacket(PacketBuffer packet) {}
/*     */   
/*     */ 
/*     */   public Packet getDescriptionPacket()
/*     */   {
/* 228 */     ByteBuf buffer = Unpooled.buffer();
/* 229 */     addToDescriptionPacket(new PacketBuffer(buffer));
/* 230 */     int readableBytes = buffer.readableBytes();
/* 231 */     if (readableBytes == 0)
/* 232 */       return null;
/* 233 */     byte[] b = new byte[readableBytes];
/* 234 */     buffer.readBytes(b);
/* 235 */     NBTTagCompound tags = new NBTTagCompound();
/* 236 */     tags.setByteArray("a", b);
/* 237 */     return new S35PacketUpdateTileEntity(this.pos, -1, tags);
/*     */   }
/*     */   
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt)
/*     */   {
/* 242 */     NBTTagCompound nbtCompound = pkt.getNbtCompound();
/* 243 */     if (nbtCompound.hasKey("a", 7)) {
/* 244 */       handleDescriptionPacket(new PacketBuffer(Unpooled.wrappedBuffer(nbtCompound.getByteArray("a"))));
/*     */     }
/* 246 */     super.onDataPacket(net, pkt);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void renderBakedModel(IBlockAccess world, WorldRenderer renderer, BlockRendererDispatcher blockRenderer, IBakedModel model) {
/* 251 */     blockRenderer.getBlockModelRenderer().renderModel(world, model, getBlockState(), getPos(), renderer, false);
/*     */   }
/*     */   
/*     */   public static enum IN_OUT_DISABLED {
/* 255 */     INPUT,  OUTPUT,  DISABLED;
/*     */     
/* 257 */     public static IN_OUT_DISABLED[] _default = { OUTPUT, INPUT, OUTPUT };
/*     */     
/*     */     private IN_OUT_DISABLED() {}
/*     */     
/* 261 */     public static XUTile.XUTileSideManager<IN_OUT_DISABLED> defaultManager = new XUTile.XUTileSideManager(IN_OUT_DISABLED.class, _default);
/*     */     
/*     */     public static XUTile.XUTileSideItemHandlerXUTile<IN_OUT_DISABLED> newItemHandlerInstance(XUTile parent, IItemHandler input, IItemHandler output) {
/* 264 */       return new XUTile.XUTileSideItemHandlerXUTile(parent, defaultManager, new IItemHandler[] { input, output, EmptyHandler.INSTANCE }); }
/*     */   }
/*     */   
/*     */   public static class XUTileSideItemHandlerXUTile<S extends Enum<S>> extends XUTile.XUTileCapabilitySide<IItemHandler, S>
/*     */   {
/*     */     public XUTileSideItemHandlerXUTile(XUTile parent, XUTile.XUTileSideManager<S> manager, IItemHandler... values)
/*     */     {
/* 271 */       super(manager, CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, ConcatItemHandler.concatNonNull(values), values);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class XUTileSideManager<S extends Enum<S>> {
/*     */     public final S[] values;
/* 277 */     public final EnumMap<EnumFacing, S> defaultChoices = new EnumMap(EnumFacing.class);
/*     */     
/*     */     public final Class<S> enumClass;
/*     */     public final EnumMap<S, ?> basePassThru;
/*     */     
/*     */     public XUTileSideManager(Class<S> enumClass, S[] defaultChoices)
/*     */     {
/* 284 */       this.enumClass = enumClass;
/* 285 */       this.values = ((Enum[])enumClass.getEnumConstants());
/*     */       
/* 287 */       for (int i = 0; i < 6; i++) {
/* 288 */         this.defaultChoices.put(EnumFacing.values()[i], defaultChoices[Math.min(i, defaultChoices.length - 1)]);
/*     */       }
/*     */       
/* 291 */       this.basePassThru = new EnumMap(enumClass);
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class XUTileCapabilitySide<T, S extends Enum<S>> {
/*     */     public final XUTile.XUTileSideManager<S> manager;
/*     */     private final XUTile parent;
/*     */     private final Capability<T> capability;
/*     */     private final T defaultValue;
/* 300 */     public EnumMap<EnumFacing, S> choices = new EnumMap(EnumFacing.class);
/*     */     EnumMap<S, T> sidedChoices;
/*     */     
/*     */     public XUTileCapabilitySide(XUTile parent, XUTile.XUTileSideManager<S> manager, Capability<T> capability, T defaultValue, T... values)
/*     */     {
/* 305 */       this.parent = parent;
/* 306 */       this.manager = manager;
/* 307 */       this.capability = capability;
/* 308 */       this.defaultValue = defaultValue;
/* 309 */       this.choices.putAll(manager.defaultChoices);
/*     */       
/* 311 */       this.sidedChoices = new EnumMap(manager.basePassThru);
/* 312 */       if (values.length != manager.values.length) {
/* 313 */         throw new IllegalArgumentException("Insufficent handlers");
/*     */       }
/* 315 */       for (int i = 0; i < values.length; i++) {
/* 316 */         this.sidedChoices.put(manager.values[i], values[i]);
/*     */       }
/*     */       
/* 319 */       if (parent.sidedCapabilities == null) {
/* 320 */         parent.sidedCapabilities = new HashMap();
/*     */       }
/* 322 */       parent.sidedCapabilities.put(capability, this);
/*     */     }
/*     */     
/*     */     public void readNBT(NBTTagCompound compound) {
/* 326 */       NBTTagCompound tagCompound = NBTHelper.getOrInitTagCompound(compound, this.capability.getName());
/* 327 */       for (EnumFacing facing : EnumFacing.values()) {
/* 328 */         String name = facing.getName();
/*     */         
/*     */         byte i;
/* 331 */         if ((!tagCompound.hasKey(name, 1)) || ((i = tagCompound.getByte(name)) < 0) || (i >= this.manager.values.length)) {
/* 332 */           this.choices.put(facing, this.manager.defaultChoices.get(facing));
/*     */         } else { byte i;
/* 334 */           this.choices.put(facing, this.manager.values[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public void setValue(EnumFacing facing, int ordinal)
/*     */     {
/* 341 */       if ((ordinal < 0) || (ordinal >= this.manager.values.length)) {
/* 342 */         this.choices.put(facing, this.manager.defaultChoices.get(facing));
/*     */       } else {
/* 344 */         this.choices.put(facing, this.manager.values[ordinal]);
/*     */       }
/*     */     }
/*     */     
/*     */     public void writeNBT(NBTTagCompound compound) {
/* 349 */       NBTTagCompound tagCompound = NBTHelper.getOrInitTagCompound(compound, this.capability.getName());
/* 350 */       S[] values = this.manager.values;
/* 351 */       for (EnumFacing facing : EnumFacing.values()) {
/* 352 */         String name = facing.getName();
/* 353 */         S s = (Enum)this.choices.get(facing);
/* 354 */         tagCompound.setByte(name, (byte)s.ordinal());
/*     */       }
/*     */     }
/*     */     
/*     */     public T get(EnumFacing facing) {
/* 359 */       if (facing == null) return (T)this.defaultValue;
/* 360 */       return (T)this.sidedChoices.get(getValue(facing));
/*     */     }
/*     */     
/*     */     public void cycleForward(EnumFacing side) {
/* 364 */       cycle(1, side);
/*     */     }
/*     */     
/*     */     public void cycleBackward(EnumFacing side) {
/* 368 */       cycle(-1, side);
/*     */     }
/*     */     
/*     */     public void cycle(int increase, EnumFacing side) {
/* 372 */       int i = (this.manager.values.length + ((Enum)this.choices.get(side)).ordinal() + increase) % this.manager.values.length;
/* 373 */       this.choices.put(side, this.manager.values[i]);
/* 374 */       this.parent.markDirty();
/*     */     }
/*     */     
/*     */     public S getValue(EnumFacing facing) {
/* 378 */       S s = (Enum)this.choices.get(facing);
/* 379 */       if (s == null) {
/* 380 */         this.choices.put(facing, s = (Enum)this.manager.defaultChoices.get(facing));
/*     */       }
/* 382 */       return s;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\XUTile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */