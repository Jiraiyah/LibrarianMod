/*     */ package com.rwtema.extrautils2.tile;
/*     */ 
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainer;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainerTile;
/*     */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetProgressArrow;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetSlotItemHandler;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetTextData;
/*     */ import com.rwtema.extrautils2.itemhandler.ConcatItemHandler;
/*     */ import com.rwtema.extrautils2.itemhandler.PublicWrapper.Extract;
/*     */ import com.rwtema.extrautils2.itemhandler.PublicWrapper.Insert;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.power.IWorldPowerMultiplier;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.CollectionHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.StringHelper;
/*     */ import gnu.trove.set.hash.TCustomHashSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.ITickable;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import net.minecraftforge.items.ItemStackHandler;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ 
/*     */ public class TileResonator
/*     */   extends TilePower
/*     */   implements ITickable, IWorldPowerMultiplier, IDynamicHandler
/*     */ {
/*  38 */   public static final ArrayList<ResonatorRecipe> resonatorRecipes = new ArrayList();
/*  39 */   public TileResonator() { this.MULTIPLIER = 0.01F;
/*  40 */     this.currentRecipe = null;
/*  41 */     this.progress = 0;
/*  42 */     this.OUTPUT = new ItemStackHandler() {
/*     */       protected void onContentsChanged(int slot) {
/*  44 */         TileResonator.this.onInputChanged();
/*     */       }
/*  46 */     };
/*  47 */     this.INPUT = new ItemStackHandler()
/*     */     {
/*     */       protected void onContentsChanged(int slot) {
/*  50 */         TileResonator.this.onInputChanged();
/*     */       }
/*     */       
/*     */       protected int getStackLimit(int slot, ItemStack stack)
/*     */       {
/*  55 */         if ((stack == null) || ((!TileResonator.ResonatorRecipe.WildCardItems.contains(stack.getItem())) && (!TileResonator.ResonatorRecipe.SpecificItems.contains(stack))))
/*     */         {
/*     */ 
/*  58 */           return 0; }
/*  59 */         return super.getStackLimit(slot, stack);
/*     */       }
/*  61 */     };
/*  62 */     this.handler = ConcatItemHandler.concatNonNull(new IItemHandler[] { new PublicWrapper.Insert(this.INPUT), new PublicWrapper.Extract(this.OUTPUT) });
/*     */   }
/*     */   
/*  65 */   public static void register(ItemStack input, ItemStack output, int energy) { register(input, output, energy, false); }
/*     */   
/*     */   public final float MULTIPLIER = 0.01F;
/*     */   
/*  69 */   public static void register(ItemStack input, ItemStack output, int energy, boolean addOwnerTag) { resonatorRecipes.add(new ResonatorRecipe(input, output, energy, addOwnerTag));
/*  70 */     if ((input.getItemDamage() == 32767) || (!input.getHasSubtypes())) {
/*  71 */       ResonatorRecipe.WildCardItems.add(input.getItem());
/*     */     } else
/*  73 */       ResonatorRecipe.SpecificItems.add(new ItemStack(input.getItem(), 1, input.getItemDamage()));
/*     */   }
/*     */   
/*     */   ResonatorRecipe currentRecipe;
/*     */   int progress;
/*  78 */   public IItemHandler getItemHandler(EnumFacing facing) { return this.handler; }
/*     */   
/*     */ 
/*     */   private void onInputChanged() {
/*  82 */     this.currentRecipe = getPotentialOutput();
/*  83 */     markDirty();
/*     */     
/*  85 */     if (this.currentRecipe == null) {
/*  86 */       this.progress = 0;
/*  87 */       return;
/*     */     }
/*     */     
/*  90 */     ItemStack curOutput = this.OUTPUT.getStackInSlot(0);
/*     */     
/*  92 */     if (this.OUTPUT.insertItem(0, curOutput, true) != null) {
/*  93 */       this.currentRecipe = null;
/*  94 */       this.progress = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public ResonatorRecipe getPotentialOutput() {
/*  99 */     ItemStack input = this.INPUT.getStackInSlot(0);
/* 100 */     if (input != null) {
/* 101 */       for (ResonatorRecipe resonatorRecipe : resonatorRecipes) {
/* 102 */         if ((OreDictionary.itemMatches(resonatorRecipe.input, input, false)) && (resonatorRecipe.input.stackSize <= input.stackSize))
/* 103 */           return resonatorRecipe;
/*     */       }
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   public void update()
/*     */   {
/* 111 */     if ((this.worldObj.isRemote) || (!this.active) || (this.currentRecipe == null)) return;
/* 112 */     this.progress += 4;
/* 113 */     markDirty();
/* 114 */     if (this.progress >= this.currentRecipe.energy) {
/* 115 */       ItemStack stack = this.currentRecipe.output.copy();
/* 116 */       if (this.currentRecipe.addOwnerTag) {
/* 117 */         NBTHelper.getOrInitTagCompound(stack).setInteger("Freq", this.frequency);
/*     */       }
/*     */       
/* 120 */       this.INPUT.extractItem(0, this.currentRecipe.input.stackSize, false);
/* 121 */       this.OUTPUT.insertItem(0, stack, false);
/* 122 */       this.progress = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 128 */     super.writeToNBT(compound);
/* 129 */     compound.setTag("Input", this.INPUT.serializeNBT());
/* 130 */     compound.setTag("Output", this.OUTPUT.serializeNBT());
/* 131 */     compound.setInteger("Progress", this.progress);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 136 */     super.readFromNBT(compound);
/* 137 */     this.INPUT.deserializeNBT(compound.getCompoundTag("Input"));
/* 138 */     this.OUTPUT.deserializeNBT(compound.getCompoundTag("Output"));
/* 139 */     this.progress = compound.getInteger("Progress");
/* 140 */     onInputChanged();
/*     */   }
/*     */   
/*     */   private ItemStackHandler OUTPUT;
/*     */   private ItemStackHandler INPUT;
/*     */   private IItemHandler handler;
/*     */   public void onPowerChanged() {}
/*     */   
/*     */   public float getPower()
/*     */   {
/* 150 */     return 1.0F;
/*     */   }
/*     */   
/*     */   public IWorldPowerMultiplier getMultiplier()
/*     */   {
/* 155 */     return this;
/*     */   }
/*     */   
/*     */   public float multiplier(World world)
/*     */   {
/* 160 */     return this.progress * 0.01F;
/*     */   }
/*     */   
/*     */   public DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/* 165 */     return new ContainerResonator(player.inventory);
/*     */   }
/*     */   
/*     */   public void addToDescriptionPacket(PacketBuffer packet)
/*     */   {
/* 170 */     packet.writeBoolean(this.active);
/* 171 */     ResonatorRecipe recipe = getPotentialOutput();
/* 172 */     ItemStack outStack = recipe != null ? recipe.output : null;
/* 173 */     packet.writeItemStack(outStack);
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleDescriptionPacket(PacketBuffer packet)
/*     */   {
/* 179 */     super.handleDescriptionPacket(packet);
/*     */   }
/*     */   
/*     */   public static class ResonatorRecipe {
/* 183 */     public static HashSet<Item> WildCardItems = new HashSet();
/* 184 */     public static TCustomHashSet<ItemStack> SpecificItems = new TCustomHashSet(CollectionHelper.HASHING_STRATEGY_ITEMSTACK);
/*     */     public ItemStack input;
/*     */     public ItemStack output;
/*     */     public int energy;
/*     */     public boolean addOwnerTag;
/*     */     
/*     */     public ResonatorRecipe(ItemStack input, ItemStack output, int energy, boolean addOwnerTag)
/*     */     {
/* 192 */       this.input = input;
/* 193 */       this.output = output;
/* 194 */       this.energy = energy;
/* 195 */       this.addOwnerTag = addOwnerTag;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 200 */       return "ResonatorRecipe{input=" + this.input + ", output=" + this.output + ", energy=" + this.energy + '}';
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public class ContainerResonator
/*     */     extends DynamicContainerTile
/*     */   {
/*     */     public ContainerResonator(InventoryPlayer inventory)
/*     */     {
/* 210 */       super(30, 64);
/* 211 */       addTitle(Lang.getItemName(TileResonator.this.getXUBlock()), false);
/*     */       
/* 213 */       addWidget(new WidgetProgressArrow(74, 52)
/*     */       {
/*     */         public float getProgress() {
/* 216 */           TileResonator.ResonatorRecipe recipe = TileResonator.this.currentRecipe;
/* 217 */           if (recipe == null)
/* 218 */             return 0.0F;
/* 219 */           return TileResonator.this.progress / recipe.energy;
/*     */         }
/*     */         
/* 222 */       });
/* 223 */       addWidget(new WidgetSlotItemHandler(TileResonator.this.INPUT, 0, 50, 52));
/* 224 */       addWidget(new WidgetSlotItemHandler(TileResonator.this.OUTPUT, 0, 102, 52)
/*     */       {
/*     */         public boolean isItemValid(ItemStack stack) {
/* 227 */           return false;
/*     */         }
/*     */         
/* 230 */       });
/* 231 */       addWidget(new WidgetTextData(8, 20, 160)
/*     */       {
/*     */         public void addToDescription(PacketBuffer packet) {
/* 234 */           TileResonator.ResonatorRecipe recipe = TileResonator.this.currentRecipe;
/* 235 */           if (recipe == null) {
/* 236 */             packet.writeBoolean(false);
/*     */           } else {
/* 238 */             packet.writeBoolean(true);
/* 239 */             packet.writeInt(TileResonator.this.progress);
/* 240 */             packet.writeInt(recipe.energy);
/*     */           }
/*     */         }
/*     */         
/*     */         protected String constructText(PacketBuffer packet)
/*     */         {
/* 246 */           this.align = 0;
/* 247 */           if (packet.readBoolean()) {
/* 248 */             int progress = packet.readInt();
/* 249 */             TileResonator.this.progress = progress;
/* 250 */             return Lang.translateArgs("Power: %s / %s GP", new Object[] { String.format(Locale.ENGLISH, "%.2f", new Object[] { Float.valueOf(progress * 0.01F) }), StringHelper.niceFormat(packet.readInt() * 0.01F) });
/*     */           }
/* 252 */           return null;
/*     */         }
/*     */         
/* 255 */       });
/* 256 */       cropAndAddPlayerSlots(inventory);
/* 257 */       validate();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TileResonator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */