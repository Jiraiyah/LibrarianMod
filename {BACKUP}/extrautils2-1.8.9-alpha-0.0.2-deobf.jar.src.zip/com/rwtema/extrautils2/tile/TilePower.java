/*     */ package com.rwtema.extrautils2.tile;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.model.XUBlockState;
/*     */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*     */ import com.rwtema.extrautils2.power.Freq;
/*     */ import com.rwtema.extrautils2.power.IWorldPowerMultiplier;
/*     */ import com.rwtema.extrautils2.power.PowerManager;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public abstract class TilePower extends XUTile implements com.rwtema.extrautils2.power.IPower
/*     */ {
/*     */   public static final String NBT_FREQUENCY = "Frequency";
/*     */   public static final String NBT_ACTIVE = "Active";
/*     */   public static final int FREQUENCY_CREATIVE = 1337;
/*     */   public int frequency;
/*     */   public boolean active;
/*     */   
/*     */   public World world()
/*     */   {
/*  31 */     return getWorld();
/*     */   }
/*     */   
/*     */   public int frequency()
/*     */   {
/*  36 */     return this.frequency;
/*     */   }
/*     */   
/*     */   public void powerChanged(boolean powered)
/*     */   {
/*  41 */     if (this.active != powered) {
/*  42 */       this.active = powered;
/*  43 */       markDirty();
/*  44 */       onPowerChanged();
/*     */     }
/*     */   }
/*     */   
/*     */   public abstract void onPowerChanged();
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/*  52 */     super.writeToNBT(compound);
/*  53 */     compound.setInteger("Frequency", this.frequency);
/*  54 */     compound.setBoolean("Active", this.active);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/*  59 */     super.readFromNBT(compound);
/*  60 */     this.frequency = compound.getInteger("Frequency");
/*  61 */     this.active = compound.getBoolean("Active");
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack, XUBlock xuBlock)
/*     */   {
/*  66 */     if ((!this.worldObj.isRemote) && ((placer instanceof EntityPlayerMP))) {
/*  67 */       this.frequency = Freq.getBasePlayerFreq((EntityPlayerMP)placer);
/*     */     }
/*     */   }
/*     */   
/*     */   public IWorldPowerMultiplier getMultiplier() {
/*  72 */     return IWorldPowerMultiplier.CONSTANT;
/*     */   }
/*     */   
/*     */   public void invalidate()
/*     */   {
/*  77 */     super.invalidate();
/*  78 */     if (!this.worldObj.isRemote) {
/*  79 */       PowerManager.instance.removePowerHandler(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onChunkUnload() {
/*  84 */     super.onChunkUnload();
/*  85 */     if (!this.worldObj.isRemote) {
/*  86 */       PowerManager.instance.removePowerHandler(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void validate() {
/*  91 */     super.validate();
/*  92 */     if (!this.worldObj.isRemote)
/*  93 */       PowerManager.instance.addPowerHandler(this);
/*     */   }
/*     */   
/*     */   public boolean isValidPlayer(EntityPlayer playerIn) {
/*  97 */     return PowerManager.canUse(playerIn, this);
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public String getName()
/*     */   {
/* 103 */     return getBlockState().getUnlocalizedName();
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/* 108 */     if ((this instanceof IDynamicHandler)) {
/* 109 */       if (!worldIn.isRemote) {
/* 110 */         if (PowerManager.canUse(playerIn, this)) {
/* 111 */           openGUI(playerIn);
/*     */         } else {
/* 113 */           com.rwtema.extrautils2.network.SpecialChat.sendChat(playerIn, Lang.chat("Access Denied.", new Object[0]));
/*     */         }
/*     */       }
/* 116 */       return true;
/*     */     }
/* 118 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TilePower.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */