/*    */ package com.rwtema.extrautils2.tile;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.model.Box;
/*    */ import com.rwtema.extrautils2.backend.model.BoxModel;
/*    */ import com.rwtema.extrautils2.backend.model.MutableModel;
/*    */ import com.rwtema.extrautils2.power.IWorldPowerMultiplier;
/*    */ import com.rwtema.extrautils2.tile.tesr.ITESRHook;
/*    */ import com.rwtema.extrautils2.utils.datastructures.NBTSerializable.Float;
/*    */ import com.rwtema.extrautils2.utils.helpers.PlayerHelper;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.client.renderer.BlockRendererDispatcher;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.ITickable;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class TilePowerHandCrank extends TilePassiveGenerator implements ITickable, ITESRHook, IWorldPowerMultiplier
/*    */ {
/* 24 */   public final double DELTA_OFFSET = 0.3141592653589793D;
/* 25 */   public final NBTSerializable.Float TIME = (NBTSerializable.Float)registerNBT("time", new NBTSerializable.Float());
/*    */   float renderOffset;
/*    */   
/*    */   public void update()
/*    */   {
/* 30 */     if (this.TIME.value > 0.0F) {
/* 31 */       if (this.worldObj.isRemote) {
/* 32 */         this.renderOffset = ((float)(this.renderOffset + this.TIME.value * 0.3141592653589793D));
/*    */       }
/*    */       
/* 35 */       NBTSerializable.Float tmp49_46 = this.TIME;tmp49_46.value = ((float)(tmp49_46.value - 0.05D));
/*    */       
/* 37 */       if (this.TIME.value < 0.0F) this.TIME.value = 0.0F;
/*    */     }
/*    */   }
/*    */   
/*    */   public IWorldPowerMultiplier getMultiplier()
/*    */   {
/* 43 */     return this;
/*    */   }
/*    */   
/*    */   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
/*    */   {
/* 48 */     if (worldIn.isRemote) {
/* 49 */       this.TIME.value = 1.0F;
/* 50 */       com.rwtema.extrautils2.keyhandler.ConstantClickHandler.setPlayerRightClicking(worldIn, pos);
/*    */     }
/* 52 */     else if (PlayerHelper.isPlayerReal(playerIn)) {
/* 53 */       this.TIME.value = 1.0F;
/*    */     }
/*    */     
/* 56 */     return true;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void render(IBlockAccess world, BlockPos pos, double x, double y, double z, float partialTicks, int destroyStage, WorldRenderer renderer, BlockRendererDispatcher blockRenderer)
/*    */   {
/* 62 */     double v = this.renderOffset + partialTicks * Math.max(Math.min(this.TIME.value, 0.5F) - 0.05D * partialTicks, 0.0D) * 0.3141592653589793D;
/* 63 */     MutableModel model = new MutableModel(com.rwtema.extrautils2.backend.model.Transforms.blockTransforms);
/*    */     
/* 65 */     BoxModel boxes = new BoxModel();
/* 66 */     boxes.addBoxI(6, 6, 6, 10, 10, 10, "redstone_gear");
/* 67 */     boxes.addBoxI(2, 7, 7, 14, 9, 9, "redstone_gear");
/* 68 */     boxes.addBoxI(7, 7, 2, 9, 9, 14, "redstone_gear");
/* 69 */     boxes.addBoxI(1, 7, 1, 15, 9, 15, "redstone_gear").setInvisible(-4);
/*    */     
/*    */ 
/* 72 */     boxes.addBoxI(1, 6, 7, 15, 10, 9, "redstone_gear").setInvisible(-13);
/* 73 */     boxes.addBoxI(7, 6, 1, 9, 10, 15, "redstone_gear").setInvisible(-49);
/*    */     
/* 75 */     boxes.loadIntoMutable(model, null);
/*    */     
/* 77 */     model.rotateY(0.5F, 0.5F, (float)v);
/*    */     
/* 79 */     renderBakedModel(world, renderer, blockRenderer, model);
/*    */   }
/*    */   
/*    */   public float multiplier(World world)
/*    */   {
/* 84 */     return Math.min(this.TIME.value, 0.5F) * 30.0F;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TilePowerHandCrank.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */