/*    */ package com.rwtema.extrautils2.tile;
/*    */ 
/*    */ import com.rwtema.extrautils2.asm.Lighting;
/*    */ import com.rwtema.extrautils2.network.PacketBuffer;
/*    */ import com.rwtema.extrautils2.tile.tesr.ITESRHook;
/*    */ import com.rwtema.extrautils2.utils.datastructures.NBTSerializable.Float;
/*    */ import com.rwtema.extrautils2.utils.helpers.BlockStates;
/*    */ import net.minecraft.client.renderer.BlockRendererDispatcher;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.client.resources.model.IBakedModel;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.world.EnumSkyBlock;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class TileEvil extends XUTile implements com.rwtema.extrautils2.lighting.ILight, ITESRHook
/*    */ {
/* 19 */   NBTSerializable.Float range = (NBTSerializable.Float)registerNBT("Range", new NBTSerializable.Float(0.0F));
/*    */   
/*    */   public World getLightWorld()
/*    */   {
/* 23 */     return this.worldObj;
/*    */   }
/*    */   
/*    */   public float getLightOffset(BlockPos lightPos)
/*    */   {
/* 28 */     int dx = lightPos.getX() - this.pos.getX();
/* 29 */     int dz = lightPos.getZ() - this.pos.getZ();
/* 30 */     int ri = Math.abs(dx) + Math.abs(lightPos.getY() - this.pos.getY()) + Math.abs(dz);
/*    */     
/*    */ 
/* 33 */     if (ri >= this.range.value) return 0.0F;
/* 34 */     float r = this.range.value - ri;
/* 35 */     if (r > 16.0F) { r = 16.0F;
/*    */     }
/* 37 */     float v = (float)Math.atan2(dx, dz);
/* 38 */     float v2 = (1.0F + MathHelper.cos(r / 24.0F + v * 10.0F)) / 2.0F;
/*    */     
/* 40 */     return -r * v2;
/*    */   }
/*    */   
/*    */   public EnumSkyBlock[] getLightType()
/*    */   {
/* 45 */     return new EnumSkyBlock[] { EnumSkyBlock.BLOCK, EnumSkyBlock.SKY };
/*    */   }
/*    */   
/*    */   public void invalidate()
/*    */   {
/* 50 */     super.invalidate();
/* 51 */     Lighting.unregister(this, Lighting.negLights);
/* 52 */     if (this.worldObj.isRemote) {
/* 53 */       updateLight();
/*    */     }
/*    */   }
/*    */   
/*    */   public void validate()
/*    */   {
/* 59 */     super.validate();
/* 60 */     Lighting.register(this, Lighting.negLights);
/*    */   }
/*    */   
/*    */   public void onChunkUnload()
/*    */   {
/* 65 */     super.onChunkUnload();
/* 66 */     Lighting.unregister(this, Lighting.negLights);
/* 67 */     if (this.worldObj.isRemote) {
/* 68 */       updateLight();
/*    */     }
/*    */   }
/*    */   
/*    */   public void addToDescriptionPacket(PacketBuffer packet)
/*    */   {
/* 74 */     packet.writeFloat(this.range.value);
/*    */   }
/*    */   
/*    */   public void handleDescriptionPacket(PacketBuffer packet)
/*    */   {
/* 79 */     this.range.value = packet.readFloat();
/* 80 */     updateLight();
/*    */   }
/*    */   
/*    */   private void updateLight() {
/* 84 */     int r = (int)Math.ceil(this.range.value);
/* 85 */     this.worldObj.markBlockRangeForRenderUpdate(this.pos.getX() - r, this.pos.getY() - r, this.pos.getZ() - r, this.pos.getX() + r, this.pos.getY() + r, this.pos.getZ() + r);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void render(IBlockAccess world, BlockPos pos, double x, double y, double z, float partialTicks, int destroyStage, WorldRenderer renderer, BlockRendererDispatcher blockRenderer)
/*    */   {
/* 96 */     IBakedModel model = blockRenderer.func_175022_a(BlockStates.enchanting_table, world, pos);
/* 97 */     renderBakedModel(world, renderer, blockRenderer, model);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\TileEvil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */