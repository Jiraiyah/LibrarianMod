/*    */ package com.rwtema.extrautils2.tile.tesr;
/*    */ 
/*    */ import com.rwtema.extrautils2.tile.XUTile;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.BlockRendererDispatcher;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraftforge.client.MinecraftForgeClient;
/*    */ 
/*    */ public class XUTESRHook extends XUTESRBase<XUTile>
/*    */ {
/*    */   private BlockRendererDispatcher blockRenderer;
/*    */   
/*    */   public void render(XUTile te, double x, double y, double z, float partialTicks, int destroyStage, WorldRenderer renderer)
/*    */   {
/* 16 */     if (this.blockRenderer == null) this.blockRenderer = Minecraft.getMinecraft().getBlockRendererDispatcher();
/* 17 */     BlockPos pos = te.getPos();
/* 18 */     net.minecraft.world.IBlockAccess world = MinecraftForgeClient.getRegionRenderCache(te.getWorld(), pos);
/* 19 */     ((ITESRHook)te).render(world, pos, x, y, z, partialTicks, destroyStage, renderer, this.blockRenderer);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\tesr\XUTESRHook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */