package com.rwtema.extrautils2.tile.tesr;

import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.util.BlockPos;
import net.minecraft.world.IBlockAccess;

public abstract interface ITESRHook
{
  public abstract void render(IBlockAccess paramIBlockAccess, BlockPos paramBlockPos, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat, int paramInt, WorldRenderer paramWorldRenderer, BlockRendererDispatcher paramBlockRendererDispatcher);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\tesr\ITESRHook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */