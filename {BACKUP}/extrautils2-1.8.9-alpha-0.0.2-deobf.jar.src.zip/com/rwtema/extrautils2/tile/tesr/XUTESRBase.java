/*    */ package com.rwtema.extrautils2.tile.tesr;
/*    */ 
/*    */ import com.rwtema.extrautils2.tile.XUTile;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraftforge.client.model.animation.FastTESR;
/*    */ 
/*    */ public abstract class XUTESRBase<T extends XUTile> extends FastTESR<T>
/*    */ {
/*    */   public void renderTileEntityFast(T te, double x, double y, double z, float partialTicks, int destroyStage, WorldRenderer renderer)
/*    */   {
/* 12 */     BlockPos pos = te.getPos();
/* 13 */     renderer.setTranslation(x - pos.getX(), y - pos.getY(), z - pos.getZ());
/* 14 */     render(te, x, y, z, partialTicks, destroyStage, renderer);
/*    */   }
/*    */   
/*    */   public abstract void render(T paramT, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat, int paramInt, WorldRenderer paramWorldRenderer);
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\tile\tesr\XUTESRBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */