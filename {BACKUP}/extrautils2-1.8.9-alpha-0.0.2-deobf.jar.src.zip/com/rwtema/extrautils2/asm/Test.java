/*    */ package com.rwtema.extrautils2.asm;
/*    */ 
/*    */ import net.minecraft.util.BlockPos;
/*    */ 
/*    */ public class Test extends net.minecraft.world.chunk.Chunk
/*    */ {
/*    */   private net.minecraft.world.World worldObj;
/*    */   
/*    */   public Test(net.minecraft.world.World worldIn, int x, int z) {
/* 10 */     super(worldIn, x, z);
/*    */   }
/*    */   
/*    */ 
/*    */   public int getLightSubtracted(BlockPos pos, int amount)
/*    */   {
/* 16 */     return Lighting.getCombinedLight(this.worldObj, pos, getLightSubtractedPassThru(pos, amount));
/*    */   }
/*    */   
/*    */   public int getLightSubtractedPassThru(BlockPos pos, int amount) {
/* 20 */     return 0;
/*    */   }
/*    */   
/*    */   public void run() {}
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\asm\Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */