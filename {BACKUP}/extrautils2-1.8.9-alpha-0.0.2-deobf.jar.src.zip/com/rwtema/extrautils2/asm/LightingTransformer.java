/*     */ package com.rwtema.extrautils2.asm;
/*     */ 
/*     */ import com.google.common.collect.Sets;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Set;
/*     */ import net.minecraft.launchwrapper.IClassTransformer;
/*     */ import net.minecraftforge.fml.relauncher.FMLLaunchHandler;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.objectweb.asm.ClassReader;
/*     */ import org.objectweb.asm.ClassWriter;
/*     */ import org.objectweb.asm.tree.AbstractInsnNode;
/*     */ import org.objectweb.asm.tree.ClassNode;
/*     */ import org.objectweb.asm.tree.FieldNode;
/*     */ import org.objectweb.asm.tree.InsnList;
/*     */ import org.objectweb.asm.tree.MethodInsnNode;
/*     */ import org.objectweb.asm.tree.MethodNode;
/*     */ 
/*     */ 
/*     */ public class LightingTransformer
/*     */   implements IClassTransformer
/*     */ {
/*  24 */   Set<String> getLightFor = Sets.newHashSet(new String[] { "getLightFor", "func_175642_b" });
/*  25 */   Set<String> getLightFromNeighborsFor = Sets.newHashSet(new String[] { "getLightFromNeighborsFor", "func_175705_a" });
/*  26 */   Set<String> getLightForExt = Sets.newHashSet(new String[] { "getLightForExt", "func_175629_a" });
/*  27 */   Set<String> exceptions = Sets.newHashSet(new String[] { "checkLightFor", "getRawLight", "func_180500_c", "func_175638_a" });
/*  28 */   Set<String> getLightSubtracted = Sets.newHashSet(new String[] { "getLightSubtracted", "func_177443_a" });
/*  29 */   Set<String> worldObj = Sets.newHashSet(new String[] { "worldObj", "field_72815_e", "field_76637_e" });
/*     */   
/*     */   public byte[] transform(String s2, String s, byte[] bytes)
/*     */   {
/*  33 */     if (bytes == null) {
/*  34 */       return null;
/*     */     }
/*  36 */     if (s.equals("net.minecraft.world.chunk.Chunk")) {
/*  37 */       ClassNode classNode = new ClassNode();
/*  38 */       ClassReader classReader = new ClassReader(bytes);
/*  39 */       classReader.accept(classNode, 0);
/*     */       
/*  41 */       String getLightSubtractedName = null;
/*  42 */       MethodNode m = null;
/*     */       
/*  44 */       String passThru = "getLightSubtractedPassThru";
/*     */       
/*  46 */       for (MethodNode method : classNode.methods) {
/*  47 */         if (this.getLightSubtracted.contains(method.name)) {
/*  48 */           m = method;
/*  49 */           getLightSubtractedName = method.name;
/*  50 */           method.name = passThru;
/*     */         }
/*     */       }
/*     */       
/*  54 */       String worldObjFieldName = getField(classNode, this.worldObj);
/*     */       
/*  56 */       if ((getLightSubtractedName == null) || (worldObjFieldName == null)) {
/*  57 */         ClassTransformerHandler.logger.info("Chunk Failed - " + getLightSubtractedName + " " + worldObjFieldName);
/*  58 */         return bytes;
/*     */       }
/*     */       
/*  61 */       MethodNode methodNode = new MethodNode(m.access, getLightSubtractedName, m.desc, m.signature, (String[])m.exceptions.toArray(new String[m.exceptions.size()]));
/*  62 */       methodNode.visitCode();
/*  63 */       methodNode.visitVarInsn(25, 0);
/*  64 */       methodNode.visitFieldInsn(180, "net/minecraft/world/chunk/Chunk", worldObjFieldName, "Lnet/minecraft/world/World;");
/*  65 */       methodNode.visitVarInsn(25, 1);
/*  66 */       methodNode.visitVarInsn(25, 0);
/*  67 */       methodNode.visitVarInsn(25, 1);
/*  68 */       methodNode.visitVarInsn(21, 2);
/*  69 */       methodNode.visitMethodInsn(182, "net/minecraft/world/chunk/Chunk", passThru, m.desc, false);
/*  70 */       methodNode.visitMethodInsn(184, "com/rwtema/extrautils2/asm/Lighting", "getCombinedLight", "(Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;I)I", false);
/*  71 */       methodNode.visitInsn(172);
/*     */       
/*  73 */       classNode.methods.add(methodNode);
/*     */       
/*  75 */       ClassWriter writer = new ClassWriter(1);
/*  76 */       classNode.accept(writer);
/*     */       
/*  78 */       return writer.toByteArray(); }
/*  79 */     if (s.equals("net.minecraft.world.World")) {
/*  80 */       ClassNode classNode = new ClassNode();
/*  81 */       ClassReader classReader = new ClassReader(bytes);
/*  82 */       classReader.accept(classNode, 0);
/*     */       
/*  84 */       if (overrideType(classNode, this.getLightFor, this.exceptions)) {
/*  85 */         ClassTransformerHandler.logger.info("World failed -" + this.getLightFor.toString() + " " + this.exceptions.toString());
/*  86 */         return bytes;
/*     */       }
/*     */       
/*  89 */       if ((FMLLaunchHandler.side() == Side.CLIENT) && 
/*  90 */         (overrideType(classNode, this.getLightFromNeighborsFor, null))) {
/*  91 */         ClassTransformerHandler.logger.info("World failed -" + this.getLightFromNeighborsFor.toString());
/*     */       }
/*     */       
/*     */ 
/*  95 */       ClassWriter writer = new ClassWriter(1);
/*  96 */       classNode.accept(writer);
/*     */       
/*  98 */       return writer.toByteArray(); }
/*  99 */     if (s.equals("net.minecraft.world.ChunkCache")) {
/* 100 */       if (FMLLaunchHandler.side() != Side.CLIENT) {
/* 101 */         return bytes;
/*     */       }
/* 103 */       ClassNode classNode = new ClassNode();
/* 104 */       ClassReader classReader = new ClassReader(bytes);
/* 105 */       classReader.accept(classNode, 0);
/*     */       
/* 107 */       String getLightForExtName = null;
/* 108 */       MethodNode m = null;
/*     */       
/* 110 */       String passThru = "getLightForExtPassThru";
/*     */       
/* 112 */       for (MethodNode method : classNode.methods) {
/* 113 */         if (this.getLightForExt.contains(method.name)) {
/* 114 */           m = method;
/* 115 */           getLightForExtName = method.name;
/* 116 */           method.name = passThru;
/*     */         }
/*     */       }
/*     */       
/* 120 */       String worldObjFieldName = getField(classNode, this.worldObj);
/*     */       
/* 122 */       if ((getLightForExtName == null) || (worldObjFieldName == null)) {
/* 123 */         ClassTransformerHandler.logger.info("Chunk Failed - " + getLightForExtName + " " + worldObjFieldName);
/* 124 */         return bytes;
/*     */       }
/* 126 */       MethodNode methodNode = new MethodNode(m.access, getLightForExtName, m.desc, m.signature, (String[])m.exceptions.toArray(new String[m.exceptions.size()]));
/* 127 */       methodNode.visitCode();
/* 128 */       methodNode.visitVarInsn(25, 0);
/* 129 */       methodNode.visitFieldInsn(180, "net/minecraft/world/ChunkCache", worldObjFieldName, "Lnet/minecraft/world/World;");
/* 130 */       methodNode.visitVarInsn(25, 1);
/* 131 */       methodNode.visitVarInsn(25, 2);
/* 132 */       methodNode.visitVarInsn(25, 0);
/* 133 */       methodNode.visitVarInsn(25, 1);
/* 134 */       methodNode.visitVarInsn(25, 2);
/* 135 */       methodNode.visitMethodInsn(182, "net/minecraft/world/ChunkCache", passThru, m.desc, false);
/* 136 */       methodNode.visitMethodInsn(184, "com/rwtema/extrautils2/asm/Lighting", "getLightFor", "(Lnet/minecraft/world/World;Lnet/minecraft/world/EnumSkyBlock;Lnet/minecraft/util/BlockPos;I)I", false);
/* 137 */       methodNode.visitInsn(172);
/*     */       
/* 139 */       classNode.methods.add(methodNode);
/*     */       
/* 141 */       ClassWriter writer = new ClassWriter(1);
/* 142 */       classNode.accept(writer);
/*     */       
/* 144 */       return writer.toByteArray();
/*     */     }
/*     */     
/*     */ 
/* 148 */     return bytes;
/*     */   }
/*     */   
/*     */   public String getField(ClassNode classNode, Set<String> fieldNames)
/*     */   {
/* 153 */     String fieldName = null;
/* 154 */     for (FieldNode field : classNode.fields) {
/* 155 */       if (fieldNames.contains(field.name)) {
/* 156 */         fieldName = field.name;
/* 157 */         break;
/*     */       }
/*     */     }
/* 160 */     return fieldName;
/*     */   }
/*     */   
/*     */   private boolean overrideType(ClassNode classNode, Set<String> methodName, Set<String> exceptions) {
/* 164 */     String getLightForName = null;
/* 165 */     MethodNode m = null;
/*     */     
/* 167 */     String passThru = null;
/* 168 */     for (MethodNode method : classNode.methods) {
/* 169 */       if (methodName.contains(method.name)) {
/* 170 */         m = method;
/* 171 */         getLightForName = method.name;
/* 172 */         passThru = getLightForName + "Implementation";
/* 173 */         method.name = passThru;
/* 174 */         break;
/*     */       }
/*     */     }
/*     */     
/* 178 */     if (getLightForName == null) { return true;
/*     */     }
/* 180 */     if (exceptions != null) {
/* 181 */       for (MethodNode method : classNode.methods) {
/* 182 */         if (exceptions.contains(method.name)) {
/* 183 */           ListIterator<AbstractInsnNode> iterator = method.instructions.iterator();
/* 184 */           while (iterator.hasNext()) {
/* 185 */             AbstractInsnNode next = (AbstractInsnNode)iterator.next();
/* 186 */             if (next.getType() == 5) {
/* 187 */               MethodInsnNode methodNode = (MethodInsnNode)next;
/* 188 */               if (getLightForName.equals(methodNode.name)) {
/* 189 */                 methodNode.name = passThru;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 196 */     MethodNode methodNode = new MethodNode(m.access, getLightForName, m.desc, m.signature, (String[])m.exceptions.toArray(new String[m.exceptions.size()]));
/* 197 */     methodNode.visitCode();
/* 198 */     methodNode.visitVarInsn(25, 0);
/* 199 */     methodNode.visitVarInsn(25, 1);
/* 200 */     methodNode.visitVarInsn(25, 2);
/* 201 */     methodNode.visitVarInsn(25, 0);
/* 202 */     methodNode.visitVarInsn(25, 1);
/* 203 */     methodNode.visitVarInsn(25, 2);
/* 204 */     methodNode.visitMethodInsn(182, "net/minecraft/world/World", passThru, m.desc, false);
/* 205 */     methodNode.visitMethodInsn(184, "com/rwtema/extrautils2/asm/Lighting", "getLightFor", "(Lnet/minecraft/world/World;Lnet/minecraft/world/EnumSkyBlock;Lnet/minecraft/util/BlockPos;I)I", false);
/* 206 */     methodNode.visitInsn(172);
/*     */     
/* 208 */     classNode.methods.add(methodNode);
/* 209 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\asm\LightingTransformer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */