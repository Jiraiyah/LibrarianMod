/*    */ package com.rwtema.extrautils2.asm;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.launchwrapper.IClassTransformer;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class ClassTransformerHandler implements IClassTransformer
/*    */ {
/* 10 */   static final ArrayList<IClassTransformer> transformers = Lists.newArrayList(new IClassTransformer[] { new LightingTransformer(), new TessellatorTransformer() });
/*    */   
/*    */ 
/*    */ 
/* 14 */   static Logger logger = org.apache.logging.log4j.LogManager.getLogger("ExtraUtils2CoreMod");
/*    */   
/*    */   static {
/* 17 */     logger.info("Transformer Class Initialized");
/*    */   }
/*    */   
/*    */   public ClassTransformerHandler() {
/* 21 */     logger.info("Transformer Created");
/*    */   }
/*    */   
/*    */   public byte[] transform(String s, String s2, byte[] bytes)
/*    */   {
/* 26 */     StringBuilder builder = null;
/*    */     
/* 28 */     for (IClassTransformer transformer : transformers) {
/* 29 */       byte[] b = bytes;
/* 30 */       bytes = transformer.transform(s, s2, bytes);
/* 31 */       if (b != bytes) {
/* 32 */         if (builder == null) {
/* 33 */           builder = new StringBuilder("XU Transformer: ").append(s).append("(").append(s2).append(")").append(" {").append(transformer.toString());
/*    */         } else
/* 35 */           builder.append(",  ").append(transformer.toString());
/*    */       }
/*    */     }
/* 38 */     if (builder != null) {
/* 39 */       builder.append("}");
/* 40 */       logger.info(builder.toString());
/*    */     }
/* 42 */     return bytes;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\asm\ClassTransformerHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */