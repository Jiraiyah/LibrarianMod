/*     */ package com.rwtema.extrautils2.asm;
/*     */ 
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import java.util.ArrayList;
/*     */ import org.objectweb.asm.ClassReader;
/*     */ import org.objectweb.asm.tree.AbstractInsnNode;
/*     */ import org.objectweb.asm.tree.ClassNode;
/*     */ import org.objectweb.asm.tree.InsnList;
/*     */ import org.objectweb.asm.tree.LdcInsnNode;
/*     */ import org.objectweb.asm.tree.MethodInsnNode;
/*     */ import org.objectweb.asm.tree.MethodNode;
/*     */ 
/*     */ public class LangGetterTransformer implements net.minecraft.launchwrapper.IClassTransformer
/*     */ {
/*  15 */   boolean initLoading = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  20 */   static String LANG_CLASS = "com.rwtema.extrautils2.utils.Lang";
/*     */   
/*     */ 
/*  23 */   String LANG_TYPE = LANG_CLASS.replace('.', '/');
/*     */   
/*  25 */   ArrayList<String> translating = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] transform(String s, String s2, byte[] bytes)
/*     */   {
/*  34 */     if (CoreXU2.runtimeDeobfuscationEnabled) {
/*  35 */       return bytes;
/*     */     }
/*  37 */     if (!s2.startsWith("com.rwtema.extrautils2")) {
/*  38 */       return bytes;
/*     */     }
/*  40 */     if (LANG_CLASS.equals(s2)) {
/*  41 */       return bytes;
/*     */     }
/*  43 */     ClassNode classNode = new ClassNode();
/*  44 */     ClassReader classReader = new ClassReader(bytes);
/*  45 */     classReader.accept(classNode, 0);
/*     */     
/*  47 */     for (MethodNode method : classNode.methods)
/*     */     {
/*     */ 
/*  50 */       AbstractInsnNode[] nodes = method.instructions.toArray();
/*  51 */       for (int i = 0; i < nodes.length; i++) {
/*  52 */         AbstractInsnNode node = nodes[i];
/*  53 */         if ((i > 0) && (node.getOpcode() == 184)) {
/*  54 */           MethodInsnNode node1 = (MethodInsnNode)node;
/*  55 */           if (this.LANG_TYPE.equals(node1.owner)) {
/*  56 */             if (("translate".equals(node1.name)) && ("(Ljava/lang/String;)Ljava/lang/String;".equals(node1.desc))) {
/*  57 */               AbstractInsnNode node2 = nodes[(i - 1)];
/*  58 */               if (node2.getOpcode() == 18) {
/*  59 */                 LdcInsnNode ldc = (LdcInsnNode)node2;
/*  60 */                 if ((ldc.cst instanceof String)) {
/*  61 */                   addTranslate((String)ldc.cst);
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*  66 */             if ((("translateArgs".equals(node1.name)) && ("(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;".equals(node1.desc))) || (("chat".equals(node1.name)) && ("(Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/util/ChatComponentTranslation;".equals(node1.desc))))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*  71 */               for (int j = i - 1; j >= 2; j--) {
/*  72 */                 if (nodes[j].getType() == 15) {
/*     */                   break;
/*     */                 }
/*     */                 
/*  76 */                 if (nodes[j].getOpcode() == 189) {
/*  77 */                   if (nodes[(j - 2)].getOpcode() != 18) break;
/*  78 */                   LdcInsnNode node2 = (LdcInsnNode)nodes[(j - 2)];
/*  79 */                   if ((node2.cst instanceof String)) {
/*  80 */                     addTranslate((String)node2.cst);
/*     */                   }
/*  82 */                   break;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  92 */     return bytes;
/*     */   }
/*     */   
/*     */   protected void addTranslate(String cst) {
/*  96 */     ArrayList<String> list = this.translating;
/*  97 */     if (list != null) {
/*  98 */       list.add(cst);
/*     */     } else {
/* 100 */       ArrayList<String> strings = new ArrayList();
/* 101 */       strings.add(cst);
/* 102 */       this.translating = strings;
/* 103 */       Lang.init();
/* 104 */       this.translating = null;
/* 105 */       for (String string : strings) {
/* 106 */         Lang.translate(string);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\asm\LangGetterTransformer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */