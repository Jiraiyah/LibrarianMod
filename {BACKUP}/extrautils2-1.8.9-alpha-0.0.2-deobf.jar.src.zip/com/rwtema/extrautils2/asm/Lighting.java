/*     */ package com.rwtema.extrautils2.asm;
/*     */ 
/*     */ import com.rwtema.extrautils2.lighting.ILight;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.world.EnumSkyBlock;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class Lighting
/*     */ {
/*  13 */   public static final WeakHashMap<World, EnumMap<EnumSkyBlock, Set<ILight>>> plusLights = new WeakHashMap();
/*  14 */   public static final WeakHashMap<World, EnumMap<EnumSkyBlock, Set<ILight>>> negLights = new WeakHashMap();
/*  15 */   static final EnumMap<EnumSkyBlock, Set<ILight>> baseMap = new EnumMap(EnumSkyBlock.class);
/*     */   
/*     */   public static void register(ILight light, WeakHashMap<World, EnumMap<EnumSkyBlock, Set<ILight>>> lightType) {
/*  18 */     EnumMap<EnumSkyBlock, Set<ILight>> enumMap = (EnumMap)lightType.get(light.getLightWorld());
/*  19 */     if (enumMap == null) {
/*  20 */       enumMap = new EnumMap(baseMap);
/*  21 */       lightType.put(light.getLightWorld(), enumMap);
/*     */     }
/*     */     
/*  24 */     for (EnumSkyBlock type : light.getLightType()) {
/*  25 */       Set<ILight> lightMap = (Set)enumMap.get(type);
/*  26 */       if (lightMap == null) {
/*  27 */         lightMap = new com.rwtema.extrautils2.utils.datastructures.WeakLinkedSet();
/*  28 */         enumMap.put(type, lightMap);
/*     */       }
/*     */       
/*  31 */       lightMap.add(light);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unregister(ILight light, WeakHashMap<World, EnumMap<EnumSkyBlock, Set<ILight>>> lightType) {
/*  36 */     EnumMap<EnumSkyBlock, Set<ILight>> enumMap = (EnumMap)lightType.get(light.getLightWorld());
/*  37 */     if (enumMap == null) { return;
/*     */     }
/*  39 */     for (EnumSkyBlock type : EnumSkyBlock.values()) {
/*  40 */       Set<ILight> lightMap = (Set)enumMap.get(type);
/*  41 */       if (lightMap != null)
/*     */       {
/*  43 */         lightMap.remove(light);
/*     */         
/*  45 */         if (lightMap.isEmpty()) {
/*  46 */           enumMap.remove(type);
/*  47 */           if (enumMap.isEmpty())
/*  48 */             lightType.remove(light.getLightWorld());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static Set<ILight> getLightList(World world, BlockPos pos, EnumSkyBlock type, WeakHashMap<World, EnumMap<EnumSkyBlock, Set<ILight>>> lightType) {
/*  55 */     EnumMap<EnumSkyBlock, Set<ILight>> enumMap = (EnumMap)lightType.get(world);
/*  56 */     if (enumMap == null) return null;
/*  57 */     Set<ILight> worldMap = (Set)enumMap.get(type);
/*  58 */     if (worldMap == null) return null;
/*  59 */     if (worldMap.isEmpty()) {
/*  60 */       enumMap.remove(type);
/*  61 */       if (enumMap.isEmpty()) {
/*  62 */         lightType.remove(world);
/*     */       }
/*  64 */       return null;
/*     */     }
/*  66 */     return worldMap;
/*     */   }
/*     */   
/*     */   public static int getLightFor(World world, EnumSkyBlock type, BlockPos pos, int curLevel) {
/*  70 */     if ((plusLights.isEmpty()) && (negLights.isEmpty())) return curLevel;
/*  71 */     Set<ILight> negLightList = getLightList(world, pos, type, negLights);
/*  72 */     Set<ILight> plusLightList = getLightList(world, pos, type, plusLights);
/*  73 */     if (negLightList == null) {
/*  74 */       if (plusLightList == null) return curLevel;
/*  75 */       float level = curLevel;
/*  76 */       for (ILight iLight : plusLightList) {
/*  77 */         level += iLight.getLightOffset(pos);
/*  78 */         if (level > 15.0F) return 15;
/*     */       }
/*  80 */       return Math.min((int)level, 15);
/*     */     }
/*  82 */     float level = curLevel;
/*  83 */     if (plusLightList != null)
/*  84 */       for (ILight iLight : plusLightList) {
/*  85 */         level += iLight.getLightOffset(pos);
/*  86 */         if (level > 15.0F)
/*     */           break;
/*     */       }
/*  89 */     if (level > 15.0F) { level = 15.0F;
/*     */     }
/*  91 */     for (ILight iLight : negLightList) {
/*  92 */       level += iLight.getLightOffset(pos);
/*  93 */       if (level < 0.0F) return 0;
/*     */     }
/*  95 */     return Math.max(0, (int)level);
/*     */   }
/*     */   
/*     */   public static int getCombinedLight(World world, BlockPos pos, int curLevel)
/*     */   {
/* 100 */     if ((plusLights.isEmpty()) && (negLights.isEmpty())) { return curLevel;
/*     */     }
/*     */     
/* 103 */     Set<ILight> lightListP1 = getLightList(world, pos, EnumSkyBlock.BLOCK, plusLights);
/* 104 */     Set<ILight> lightListP2 = getLightList(world, pos, EnumSkyBlock.SKY, plusLights);
/* 105 */     Set<ILight> lightListN1 = getLightList(world, pos, EnumSkyBlock.BLOCK, negLights);
/* 106 */     Set<ILight> lightListN2 = getLightList(world, pos, EnumSkyBlock.SKY, negLights);
/*     */     
/* 108 */     if ((lightListN1 == null) && (lightListN2 == null)) {
/* 109 */       if (curLevel == 15) { return 15;
/*     */       }
/* 111 */       float level = curLevel;
/* 112 */       if (lightListP1 != null) {
/* 113 */         for (ILight iLight : lightListP1) {
/* 114 */           level += iLight.getLightOffset(pos);
/* 115 */           if (level >= 15.0F) return 15;
/*     */         }
/*     */       }
/* 118 */       if (lightListP2 != null) {
/* 119 */         for (ILight iLight : lightListP2) {
/* 120 */           level += iLight.getLightOffset(pos);
/* 121 */           if (level >= 15.0F) return 15;
/*     */         }
/*     */       }
/* 124 */       return (int)level;
/*     */     }
/* 126 */     float level = curLevel;
/* 127 */     if (lightListP1 != null)
/* 128 */       for (ILight iLight : lightListP1) {
/* 129 */         level += iLight.getLightOffset(pos);
/* 130 */         if (level >= 15.0F)
/*     */           break;
/*     */       }
/* 133 */     if ((lightListP2 != null) && (level < 15.0F))
/* 134 */       for (ILight iLight : lightListP2) {
/* 135 */         level += iLight.getLightOffset(pos);
/* 136 */         if (level >= 15.0F)
/*     */           break;
/*     */       }
/* 139 */     if (level > 15.0F) { level = 15.0F;
/*     */     }
/* 141 */     if (lightListN1 != null) {
/* 142 */       for (ILight iLight : lightListN1) {
/* 143 */         level += iLight.getLightOffset(pos);
/* 144 */         if (level <= 0.0F) { return 0;
/*     */         }
/*     */       }
/* 147 */       if (lightListN2 != null)
/* 148 */         for (ILight iLight : lightListN2) {
/* 149 */           level += iLight.getLightOffset(pos);
/* 150 */           if (level <= 0.0F) return 0;
/*     */         }
/*     */     } else {
/* 153 */       for (ILight iLight : lightListN2) {
/* 154 */         level += iLight.getLightOffset(pos);
/* 155 */         if (level <= 0.0F) { return 0;
/*     */         }
/*     */       }
/*     */     }
/* 159 */     return (int)level;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\asm\Lighting.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */