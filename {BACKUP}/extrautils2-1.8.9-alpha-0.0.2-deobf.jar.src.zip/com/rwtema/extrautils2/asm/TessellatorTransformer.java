/*    */ package com.rwtema.extrautils2.asm;
/*    */ 
/*    */ import com.google.common.collect.Sets;
/*    */ import java.util.ListIterator;
/*    */ import java.util.Set;
/*    */ import org.objectweb.asm.ClassReader;
/*    */ import org.objectweb.asm.ClassWriter;
/*    */ import org.objectweb.asm.tree.AbstractInsnNode;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.objectweb.asm.tree.InsnList;
/*    */ import org.objectweb.asm.tree.MethodInsnNode;
/*    */ import org.objectweb.asm.tree.MethodNode;
/*    */ 
/*    */ public class TessellatorTransformer implements net.minecraft.launchwrapper.IClassTransformer
/*    */ {
/* 16 */   Set<String> draw = Sets.newHashSet(new String[] { "draw", "func_78381_a" });
/* 17 */   String name = "net.minecraft.client.renderer.Tessellator";
/*    */   
/*    */   public byte[] transform(String s, String s1, byte[] bytes)
/*    */   {
/* 21 */     if (!this.name.equals(s1)) {
/* 22 */       return bytes;
/*    */     }
/* 24 */     ClassNode classNode = new ClassNode();
/* 25 */     ClassReader classReader = new ClassReader(bytes);
/* 26 */     classReader.accept(classNode, 0);
/*    */     
/* 28 */     for (MethodNode method : classNode.methods) {
/* 29 */       if (this.draw.contains(method.name)) {
/* 30 */         ListIterator<AbstractInsnNode> iter = method.instructions.iterator();
/* 31 */         while (iter.hasNext()) {
/* 32 */           AbstractInsnNode next = (AbstractInsnNode)iter.next();
/* 33 */           if (next.getOpcode() == 177) {
/* 34 */             method.instructions.insertBefore(next, new MethodInsnNode(184, "com/rwtema/extrautils2/utils/client/GLState", "resetStateQuads", "()V", false));
/* 35 */             break;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 41 */     ClassWriter writer = new ClassWriter(1);
/* 42 */     classNode.accept(writer);
/*    */     
/* 44 */     return writer.toByteArray();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\asm\TessellatorTransformer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */