package com.rwtema.extrautils2.gui.backend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public abstract interface ISlotClick
{
  public abstract ItemStack slotClick(DynamicContainer paramDynamicContainer, int paramInt1, int paramInt2, int paramInt3, EntityPlayer paramEntityPlayer);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\ISlotClick.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */