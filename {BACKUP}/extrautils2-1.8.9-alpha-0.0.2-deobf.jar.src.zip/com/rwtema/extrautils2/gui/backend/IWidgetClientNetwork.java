package com.rwtema.extrautils2.gui.backend;

import com.rwtema.extrautils2.network.PacketBuffer;

public abstract interface IWidgetClientNetwork
  extends IWidget
{
  public abstract void receiveClientPacket(PacketBuffer paramPacketBuffer);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\IWidgetClientNetwork.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */