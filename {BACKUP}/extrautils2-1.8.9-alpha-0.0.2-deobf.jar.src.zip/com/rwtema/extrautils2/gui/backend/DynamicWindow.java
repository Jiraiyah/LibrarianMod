/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import java.util.Set;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicWindow
/*    */ {
/* 13 */   public float b = 1.0F; public float g = 1.0F; public float r = 1.0F;
/*    */   public int y;
/*    */   
/* 16 */   public void crop(Set<IWidget> iWidgets) { int ax = Integer.MAX_VALUE;int ay = Integer.MAX_VALUE;int bx = 0;int by = 0;
/* 17 */     for (IWidget widget : iWidgets) {
/* 18 */       ax = Math.min(ax, widget.getX());
/* 19 */       ay = Math.min(ay, widget.getY());
/* 20 */       bx = Math.max(bx, widget.getX() + widget.getW());
/* 21 */       by = Math.max(by, widget.getY() + widget.getH());
/*    */     }
/*    */     
/* 24 */     this.w = (bx + ax);
/* 25 */     this.h = (by + ay); }
/*    */   
/*    */   public int x;
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/* 30 */   public boolean drawBackgroundOverride(DynamicGui gui, DynamicContainer container) { return false; }
/*    */   
/*    */   public int h;
/*    */   public int w;
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\DynamicWindow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */