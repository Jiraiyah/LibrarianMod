/*     */ package com.rwtema.extrautils2.gui.backend;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.LinkedHashMultimap;
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.backend.ISidedFunction;
/*     */ import com.rwtema.extrautils2.network.NetworkHandler;
/*     */ import com.rwtema.extrautils2.network.NetworkHandler.XUPacket;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.network.XUPacketClientToServer;
/*     */ import com.rwtema.extrautils2.network.XUPacketServerToClient;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.ICrafting;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.apache.commons.lang3.tuple.Pair;
/*     */ 
/*     */ public abstract class DynamicContainer extends Container
/*     */ {
/*     */   public static final int playerInvWidth = 162;
/*     */   public static final int centerX = 85;
/*     */   public static final int centerSlotX = 76;
/*     */   public static final int playerInvHeight = 95;
/*  42 */   public static final ISidedFunction<String, Integer> STRING_WIDTH_FUNCTION = new ISidedFunction()
/*     */   {
/*     */     @SideOnly(Side.SERVER)
/*     */     public Integer applyServer(String input) {
/*  46 */       return Integer.valueOf(input != null ? input.length() : 0);
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public Integer applyClient(String input)
/*     */     {
/*  52 */       return Integer.valueOf(input != null ? Minecraft.getMinecraft().fontRendererObj.getStringWidth(input) : 0);
/*     */     }
/*     */   };
/*  55 */   public static final ISidedFunction<Pair<String, Integer>, Integer> STRING_HEIGHTS = new ISidedFunction()
/*     */   {
/*     */     public Integer applyServer(Pair<String, Integer> input)
/*     */     {
/*  59 */       int w = 0;
/*  60 */       String[] split = ((String)input.getKey()).split("\n");
/*  61 */       for (String s : split) {
/*  62 */         float sw = ((Integer)DynamicContainer.STRING_WIDTH_FUNCTION.applyServer(s)).intValue();
/*  63 */         w += net.minecraft.util.MathHelper.ceiling_double_int(sw / w);
/*     */       }
/*     */       
/*  66 */       return Integer.valueOf(w * 9);
/*     */     }
/*     */     
/*     */     public Integer applyClient(Pair<String, Integer> input)
/*     */     {
/*  71 */       List<String> strings = Minecraft.getMinecraft().fontRendererObj.listFormattedStringToWidth((String)input.getKey(), ((Integer)input.getValue()).intValue());
/*  72 */       return Integer.valueOf(strings.size() * 9);
/*     */     }
/*     */   };
/*  75 */   private static final ItemStack genericItemStack = new ItemStack(net.minecraft.init.Blocks.cobblestone, 0);
/*  76 */   public int playerSlotsStart = -1;
/*  77 */   public LinkedList<EntityPlayerMP> entityPlayerMPs = new LinkedList();
/*  78 */   public int width = 176; public int height = 166;
/*  79 */   public boolean changesOnly = false;
/*  80 */   public boolean isClient = false;
/*  81 */   ByteBuf previousPacket = Unpooled.buffer();
/*  82 */   boolean fixed = false;
/*  83 */   private LinkedHashMultimap<DynamicWindow, IWidget> windowWidgets = LinkedHashMultimap.create();
/*  84 */   private List<IWidget> widgets = new ArrayList();
/*  85 */   private List<IWidgetKeyInput> widgetKeyInputs = new ArrayList();
/*  86 */   private List<IWidgetMouseInput> widgetMouseInputs = new ArrayList();
/*  87 */   private List<IWidgetClientNetwork> widgetReceivers = new ArrayList();
/*  88 */   private List<IWidgetServerNetwork> widgetNetworks = new ArrayList();
/*  89 */   private HashMap<IWidget, DynamicWindow> windowOwner = new HashMap();
/*  90 */   private HashSet<DynamicWindow> windows = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HashMap<IWidget, DynamicWindow> getWindowOwner()
/*     */   {
/*  97 */     return this.windowOwner;
/*     */   }
/*     */   
/*     */   public LinkedHashMultimap<DynamicWindow, IWidget> getWindowWidgets() {
/* 101 */     return this.windowWidgets;
/*     */   }
/*     */   
/*     */   public List<IWidgetKeyInput> getWidgetKeyInputs() {
/* 105 */     return ImmutableList.copyOf(this.widgetKeyInputs);
/*     */   }
/*     */   
/*     */   public List<IWidgetMouseInput> getWidgetMouseInputs() {
/* 109 */     return ImmutableList.copyOf(this.widgetMouseInputs);
/*     */   }
/*     */   
/*     */   public List<IWidget> getWidgets() {
/* 113 */     return ImmutableList.copyOf(this.widgets);
/*     */   }
/*     */   
/*     */   void addSlot(Slot slot) {
/* 117 */     addSlotToContainer(slot);
/*     */   }
/*     */   
/*     */   public void onCraftGuiOpened(ICrafting iCrafting)
/*     */   {
/* 122 */     if ((iCrafting instanceof EntityPlayerMP)) {
/* 123 */       this.entityPlayerMPs.add((EntityPlayerMP)iCrafting);
/*     */     }
/*     */     
/* 126 */     this.changesOnly = false;
/* 127 */     super.onCraftGuiOpened(iCrafting);
/*     */   }
/*     */   
/*     */   public void detectAndSendChanges()
/*     */   {
/* 132 */     if (this.isClient) return;
/* 133 */     super.detectAndSendChanges();
/*     */     
/* 135 */     ByteBuf buffer = Unpooled.buffer();
/* 136 */     PacketBuffer packetBuffer = new PacketBuffer(buffer);
/* 137 */     for (IWidgetServerNetwork widget : this.widgetNetworks) {
/* 138 */       widget.addToDescription(packetBuffer);
/*     */     }
/*     */     
/* 141 */     this.previousPacket.setIndex(0, this.previousPacket.writerIndex());
/* 142 */     if (ByteBufUtil.equals(buffer, this.previousPacket)) {
/* 143 */       return;
/*     */     }
/* 145 */     this.previousPacket = Unpooled.copiedBuffer(buffer);
/*     */     
/*     */ 
/* 148 */     for (EntityPlayerMP player : this.entityPlayerMPs) {
/* 149 */       NetworkHandler.sendPacketToPlayer(new PacketGUIData(this.windowId, packetBuffer), player);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void removeCraftingFromCrafters(ICrafting par1ICrafting)
/*     */   {
/* 160 */     if ((par1ICrafting instanceof EntityPlayerMP)) {
/* 161 */       this.entityPlayerMPs.remove(par1ICrafting);
/*     */     }
/*     */     
/* 164 */     super.removeCraftingFromCrafters(par1ICrafting);
/*     */   }
/*     */   
/*     */   protected void validate() {
/* 168 */     for (IWidget widget : this.widgets) {
/* 169 */       widget.addToContainer(this);
/*     */     }
/* 171 */     this.fixed = true;
/*     */   }
/*     */   
/*     */   public void addPlayerSlotsToBottom(IInventory inventory) {
/* 175 */     addPlayerSlots(inventory, (this.width - 162) / 2, this.height - 95);
/*     */   }
/*     */   
/*     */   public void crop() {
/* 179 */     crop(4);
/*     */   }
/*     */   
/*     */   public void crop(int border) {
/* 183 */     int maxX = 18;
/* 184 */     int maxY = 18;
/*     */     
/* 186 */     for (IWidget widget : this.windowWidgets.get(null)) {
/* 187 */       maxX = Math.max(maxX, widget.getX() + widget.getW());
/* 188 */       maxY = Math.max(maxY, widget.getY() + widget.getH());
/*     */     }
/*     */     
/* 191 */     this.width = (maxX + border);
/* 192 */     this.height = (maxY + border);
/*     */   }
/*     */   
/*     */   public void cropAndAddPlayerSlots(InventoryPlayer inventory) {
/* 196 */     crop(4);
/* 197 */     this.height += 95;
/*     */     
/* 199 */     if (this.width < 170) {
/* 200 */       this.width = 170;
/*     */     }
/*     */     
/* 203 */     addPlayerSlotsToBottom(inventory);
/*     */   }
/*     */   
/*     */   public void addPlayerSlots(IInventory inventory, int x, int y) {
/* 207 */     this.playerSlotsStart = 0;
/*     */     
/* 209 */     for (IWidget w : this.widgets) {
/* 210 */       if ((w instanceof Slot)) {
/* 211 */         this.playerSlotsStart += 1;
/*     */       }
/*     */     }
/*     */     
/* 215 */     addWidget(new WidgetTextTranslate(x, y, inventory.getName(), 162));
/*     */     
/* 217 */     for (int j = 0; j < 3; j++) {
/* 218 */       for (int k = 0; k < 9; k++) {
/* 219 */         WidgetSlot w = new WidgetSlot(inventory, k + j * 9 + 9, x + k * 18, y + 14 + j * 18);
/* 220 */         addWidget(w);
/*     */       }
/*     */     }
/*     */     
/* 224 */     for (int j = 0; j < 9; j++) {
/* 225 */       WidgetSlot w = new WidgetSlot(inventory, j, x + j * 18, y + 14 + 58);
/* 226 */       addWidget(w);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addWidget(IWidget w) {
/* 231 */     addWidget(w, null);
/*     */   }
/*     */   
/*     */   public void addWidget(IWidget w, DynamicWindow dynamicWindow) {
/* 235 */     if (this.fixed) throw new IllegalStateException();
/* 236 */     this.widgets.add(w);
/*     */     
/*     */ 
/* 239 */     if (dynamicWindow != null) { this.windows.add(dynamicWindow);
/*     */     }
/* 241 */     this.windowWidgets.put(dynamicWindow, w);
/* 242 */     this.windowOwner.put(w, dynamicWindow);
/*     */     
/* 244 */     if ((w instanceof IWidgetKeyInput)) {
/* 245 */       this.widgetKeyInputs.add((IWidgetKeyInput)w);
/*     */     }
/* 247 */     if ((w instanceof IWidgetMouseInput)) {
/* 248 */       this.widgetMouseInputs.add((IWidgetMouseInput)w);
/*     */     }
/* 250 */     if ((w instanceof IWidgetClientNetwork)) {
/* 251 */       this.widgetReceivers.add((IWidgetClientNetwork)w);
/*     */     }
/* 253 */     if ((w instanceof IWidgetServerNetwork)) {
/* 254 */       this.widgetNetworks.add((IWidgetServerNetwork)w);
/*     */     }
/*     */     
/* 257 */     if ((w instanceof IAdditionalWidgets)) {
/* 258 */       for (IWidget iWidget : ((IAdditionalWidgets)w).getAdditionalWidgets()) {
/* 259 */         addWidget(iWidget, dynamicWindow);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int par2)
/*     */   {
/* 266 */     ItemStack itemstack = null;
/* 267 */     Slot slot = (Slot)this.inventorySlots.get(par2);
/*     */     
/* 269 */     if ((this.playerSlotsStart > 0) && (slot != null) && (slot.getHasStack())) {
/* 270 */       ItemStack otherItemStack = slot.getStack();
/* 271 */       itemstack = otherItemStack.copy();
/*     */       
/* 273 */       if (par2 < this.playerSlotsStart) {
/* 274 */         if (!mergeItemStack(otherItemStack, this.playerSlotsStart, this.inventorySlots.size(), true)) {
/* 275 */           return null;
/*     */         }
/* 277 */       } else if (!mergeItemStack(otherItemStack, 0, this.playerSlotsStart, false)) {
/* 278 */         return null;
/*     */       }
/*     */       
/* 281 */       if (otherItemStack.stackSize == 0) {
/* 282 */         slot.putStack(null);
/*     */       } else {
/* 284 */         slot.onSlotChanged();
/*     */       }
/*     */     }
/*     */     
/* 288 */     return itemstack;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean mergeItemStack(ItemStack stack, int startIndex, int endIndex, boolean reverseDirection)
/*     */   {
/* 299 */     boolean flag = false;
/*     */     
/*     */ 
/* 302 */     int i = reverseDirection ? endIndex - 1 : startIndex;
/*     */     
/* 304 */     if (stack.isStackable()) {
/* 305 */       while ((stack.stackSize > 0) && (((!reverseDirection) && (i < endIndex)) || ((reverseDirection) && (i >= startIndex)))) {
/* 306 */         Slot slot = (Slot)this.inventorySlots.get(i);
/* 307 */         ItemStack itemstack = slot.getStack();
/*     */         
/* 309 */         if ((itemstack != null) && (slot.isItemValid(itemstack)) && (itemstack.getItem() == stack.getItem()) && ((!stack.getHasSubtypes()) || (stack.getMetadata() == itemstack.getMetadata())) && (ItemStack.areItemStackTagsEqual(stack, itemstack)))
/*     */         {
/* 311 */           int j = itemstack.stackSize + stack.stackSize;
/*     */           
/* 313 */           if (j <= Math.min(stack.getMaxStackSize(), slot.getItemStackLimit(itemstack))) {
/* 314 */             stack.stackSize = 0;
/* 315 */             itemstack.stackSize = j;
/* 316 */             slot.onSlotChanged();
/* 317 */             flag = true;
/* 318 */           } else if (itemstack.stackSize < stack.getMaxStackSize()) {
/* 319 */             stack.stackSize -= stack.getMaxStackSize() - itemstack.stackSize;
/* 320 */             itemstack.stackSize = stack.getMaxStackSize();
/* 321 */             slot.onSlotChanged();
/* 322 */             flag = true;
/*     */           }
/*     */         }
/*     */         
/* 326 */         if (reverseDirection) {
/* 327 */           i--;
/*     */         } else {
/* 329 */           i++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 334 */     if (stack.stackSize > 0) {
/* 335 */       i = reverseDirection ? endIndex - 1 : startIndex;
/*     */       
/* 337 */       while (((!reverseDirection) && (i < endIndex)) || ((reverseDirection) && (i >= startIndex))) {
/* 338 */         Slot slot1 = (Slot)this.inventorySlots.get(i);
/* 339 */         ItemStack otherStack = slot1.getStack();
/*     */         
/* 341 */         if ((otherStack == null) && (slot1.isItemValid(stack)))
/*     */         {
/* 343 */           int maxInsert = slot1.getItemStackLimit(stack);
/* 344 */           if (stack.stackSize > maxInsert) {
/* 345 */             slot1.putStack(stack.splitStack(maxInsert));
/* 346 */             slot1.onSlotChanged();
/* 347 */             flag = true;
/*     */           } else {
/* 349 */             slot1.putStack(stack.copy());
/* 350 */             slot1.onSlotChanged();
/* 351 */             stack.stackSize = 0;
/* 352 */             flag = true;
/* 353 */             break;
/*     */           }
/*     */         }
/*     */         
/* 357 */         if (reverseDirection) {
/* 358 */           i--;
/*     */         } else {
/* 360 */           i++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 365 */     return flag;
/*     */   }
/*     */   
/*     */   public int getStringWidth(String text) {
/* 369 */     return ((Integer)ExtraUtils2.proxy.apply(STRING_WIDTH_FUNCTION, text)).intValue();
/*     */   }
/*     */   
/*     */ 
/* 373 */   public void addTitle(String name) { addTitle(Lang.translate(name), false); }
/*     */   
/*     */   public void addTitle(String name, boolean translate) {
/*     */     WidgetText e;
/*     */     WidgetText e;
/* 378 */     if (translate) {
/* 379 */       e = new WidgetTextTranslate(5, 5, name, getStringWidth(net.minecraft.util.StatCollector.translateToLocal(name)));
/*     */     } else {
/* 381 */       e = new WidgetText(5, 5, name, getStringWidth(name));
/*     */     }
/* 383 */     addWidget(e);
/*     */   }
/*     */   
/*     */   public ItemStack func_75144_a(int slotId, int clickedButton, int mode, EntityPlayer playerIn)
/*     */   {
/* 388 */     if ((slotId >= 0) && (slotId < this.inventorySlots.size())) {
/* 389 */       Slot slot = (Slot)this.inventorySlots.get(slotId);
/* 390 */       if ((slot instanceof ISlotClick)) {
/* 391 */         return ((ISlotClick)slot).slotClick(this, slotId, clickedButton, mode, playerIn);
/*     */       }
/*     */     }
/* 394 */     return super.func_75144_a(slotId, clickedButton, mode, playerIn);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void sendInputPacket(IWidgetClientNetwork widget, PacketBuffer buffer) {
/* 399 */     int i = this.widgetReceivers.indexOf(widget);
/* 400 */     if (i < 0) throw new RuntimeException("Unable to find widget");
/* 401 */     NetworkHandler.sendPacketToServer(new PacketGUIInput(this.windowId, i, buffer));
/*     */   }
/*     */   
/*     */   public HashSet<DynamicWindow> getWindows() {
/* 405 */     return this.windows;
/*     */   }
/*     */   
/*     */   public void onSlotChanged(int index)
/*     */   {
/* 410 */     this.inventoryItemStacks.set(index, genericItemStack);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void loadGuiDimensions(DynamicGui dynamicGui)
/*     */   {
/* 419 */     dynamicGui.xSize = this.width;
/* 420 */     dynamicGui.ySize = this.height;
/* 421 */     dynamicGui.guiLeft = ((dynamicGui.width - dynamicGui.xSize) / 2);
/* 422 */     dynamicGui.guiTop = ((dynamicGui.height - dynamicGui.ySize) / 2);
/*     */   }
/*     */   
/*     */   @NetworkHandler.XUPacket
/*     */   public static class PacketGUIInput extends XUPacketClientToServer
/*     */   {
/*     */     private int windowId;
/*     */     private int widgetId;
/*     */     private PacketBuffer packetBuffer;
/*     */     private EntityPlayer player;
/*     */     
/*     */     public PacketGUIInput() {}
/*     */     
/*     */     public PacketGUIInput(int windowId, int widgetId, PacketBuffer packetBuffer)
/*     */     {
/* 437 */       this.windowId = windowId;
/* 438 */       this.widgetId = widgetId;
/* 439 */       this.packetBuffer = packetBuffer;
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/* 444 */       writeInt(this.windowId);
/* 445 */       writeShort(this.widgetId);
/* 446 */       if (this.packetBuffer == null) {
/* 447 */         writeInt(0);
/*     */       } else {
/* 449 */         writePacketBuffer(this.packetBuffer);
/*     */       }
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player) {
/* 454 */       this.player = player;
/* 455 */       this.windowId = readInt();
/* 456 */       this.widgetId = readUnsignedShort();
/* 457 */       this.packetBuffer = readPacketBuffer();
/*     */     }
/*     */     
/*     */     public Runnable doStuffServer()
/*     */     {
/* 462 */       new Runnable()
/*     */       {
/*     */         public void run() {
/* 465 */           Container openContainer = DynamicContainer.PacketGUIInput.this.player.openContainer;
/* 466 */           if ((DynamicContainer.PacketGUIInput.this.windowId == 0) || (openContainer.windowId != DynamicContainer.PacketGUIInput.this.windowId) || (!openContainer.canInteractWith(DynamicContainer.PacketGUIInput.this.player))) {
/* 467 */             return;
/*     */           }
/* 469 */           DynamicContainer dynamicContainer = (DynamicContainer)openContainer;
/* 470 */           List<IWidgetClientNetwork> receivers = dynamicContainer.widgetReceivers;
/* 471 */           if ((DynamicContainer.PacketGUIInput.this.widgetId < 0) || (DynamicContainer.PacketGUIInput.this.widgetId >= receivers.size())) return;
/* 472 */           ((IWidgetClientNetwork)receivers.get(DynamicContainer.PacketGUIInput.this.widgetId)).receiveClientPacket(DynamicContainer.PacketGUIInput.this.packetBuffer);
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */   
/*     */   @NetworkHandler.XUPacket
/*     */   public static class PacketGUIData extends XUPacketServerToClient
/*     */   {
/*     */     private int windowId;
/*     */     private PacketBuffer packetBuffer;
/*     */     
/*     */     public PacketGUIData() {}
/*     */     
/*     */     public PacketGUIData(int windowId, PacketBuffer packetBuffer)
/*     */     {
/* 488 */       this.windowId = windowId;
/* 489 */       this.packetBuffer = packetBuffer;
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/* 494 */       writeInt(this.windowId);
/* 495 */       writePacketBuffer(this.packetBuffer);
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player)
/*     */     {
/* 500 */       this.windowId = readInt();
/* 501 */       this.packetBuffer = readPacketBuffer();
/*     */     }
/*     */     
/*     */ 
/*     */     @SideOnly(Side.CLIENT)
/*     */     public Runnable doStuffClient()
/*     */     {
/* 508 */       new Runnable()
/*     */       {
/*     */         public void run() {
/* 511 */           Container openContainer = Minecraft.getMinecraft().thePlayer.openContainer;
/* 512 */           if ((DynamicContainer.PacketGUIData.this.windowId == 0) || (openContainer.windowId != DynamicContainer.PacketGUIData.this.windowId)) { return;
/*     */           }
/* 514 */           DynamicContainer dynamicContainer = (DynamicContainer)openContainer;
/* 515 */           for (IWidgetServerNetwork widget : dynamicContainer.widgetNetworks) {
/* 516 */             widget.handleDescriptionPacket(DynamicContainer.PacketGUIData.this.packetBuffer);
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean drawBackgroundOverride(DynamicGui gui)
/*     */   {
/* 526 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\DynamicContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */