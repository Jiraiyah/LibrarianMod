/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.network.PacketBuffer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ 
/*    */ public abstract class WidgetProgressArrow extends WidgetBase implements IWidgetServerNetwork
/*    */ {
/*    */   public static final int ARROW_WIDTH = 22;
/*    */   public static final int ARROW_HEIGHT = 17;
/* 10 */   byte curWidth = -1;
/*    */   
/*    */   public WidgetProgressArrow(int x, int y) {
/* 13 */     super(x, y, 22, 17);
/*    */   }
/*    */   
/*    */   public abstract float getProgress();
/*    */   
/*    */   public void handleDescriptionPacket(PacketBuffer packet)
/*    */   {
/* 20 */     this.curWidth = packet.readByte();
/*    */   }
/*    */   
/*    */   public void addToDescription(PacketBuffer packet)
/*    */   {
/* 25 */     packet.writeByte(getAdjustedWidth(getProgress()));
/*    */   }
/*    */   
/*    */   private byte getAdjustedWidth(float t)
/*    */   {
/* 30 */     int a = t >= 1.0F ? 1 : t < 0.0F ? 0 : Math.round(t * 22.0F);
/* 31 */     return (byte)a;
/*    */   }
/*    */   
/*    */ 
/*    */   public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 37 */     manager.bindTexture(gui.getWidgetTexture());
/* 38 */     gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 98, 16, this.curWidth, 16);
/*    */   }
/*    */   
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 43 */     manager.bindTexture(gui.getWidgetTexture());
/* 44 */     gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 98, 0, 22, 16);
/*    */   }
/*    */   
/*    */   public java.util.List<String> getToolTip()
/*    */   {
/* 49 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetProgressArrow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */