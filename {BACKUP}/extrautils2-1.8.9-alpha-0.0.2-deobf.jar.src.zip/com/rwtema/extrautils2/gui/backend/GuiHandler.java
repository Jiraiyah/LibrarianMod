/*     */ package com.rwtema.extrautils2.gui.backend;
/*     */ 
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.network.XUPacketClientToServer;
/*     */ import gnu.trove.map.hash.TIntObjectHashMap;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.network.IGuiHandler;
/*     */ 
/*     */ public class GuiHandler implements IGuiHandler
/*     */ {
/*  18 */   private static final TIntObjectHashMap<IDynamicHandler> customDynamicGuiMap = new TIntObjectHashMap();
/*     */   
/*     */   public static int register(String name, IDynamicHandler handler) {
/*  21 */     int id = name.hashCode() | 0x80000000;
/*     */     
/*  23 */     if (customDynamicGuiMap.containsKey(id))
/*  24 */       throw new RuntimeException("Duplicate id: " + id + " - " + customDynamicGuiMap.get(id) + " - (adding " + handler + ")");
/*  25 */     customDynamicGuiMap.put(id, handler);
/*     */     
/*  27 */     return id;
/*     */   }
/*     */   
/*     */   public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/*  32 */     if (customDynamicGuiMap.containsKey(ID)) {
/*  33 */       return ((IDynamicHandler)customDynamicGuiMap.get(ID)).getDynamicContainer(ID, player, world, x, y, z);
/*     */     }
/*     */     
/*  36 */     if (ID == -1) {
/*  37 */       ItemStack heldItem = player.func_70694_bm();
/*  38 */       if (heldItem == null) return null;
/*  39 */       Item item = heldItem.getItem();
/*  40 */       if ((item instanceof IGuiHandler))
/*  41 */         return ((IGuiHandler)item).getServerGuiElement(ID, player, world, x, y, z);
/*  42 */       if ((item instanceof IDynamicHandler))
/*  43 */         return ((IDynamicHandler)item).getDynamicContainer(ID, player, world, x, y, z);
/*     */     } else {
/*  45 */       BlockPos pos = new BlockPos(x, y, z);
/*  46 */       TileEntity tileEntity = world.getTileEntity(pos);
/*  47 */       if ((tileEntity instanceof IGuiHandler))
/*  48 */         return ((IGuiHandler)tileEntity).getServerGuiElement(ID, player, world, x, y, z);
/*  49 */       if ((tileEntity instanceof IDynamicHandler))
/*  50 */         return ((IDynamicHandler)tileEntity).getDynamicContainer(ID, player, world, x, y, z);
/*  51 */       IBlockState state = world.getBlockState(pos);
/*  52 */       if ((state instanceof IGuiHandler))
/*  53 */         return ((IGuiHandler)state).getServerGuiElement(ID, player, world, x, y, z);
/*  54 */       if ((state instanceof IDynamicHandler))
/*  55 */         return ((IDynamicHandler)state).getDynamicContainer(ID, player, world, x, y, z);
/*  56 */       Block block = state.getBlock();
/*  57 */       if ((block instanceof IGuiHandler))
/*  58 */         return ((IGuiHandler)block).getServerGuiElement(ID, player, world, x, y, z);
/*  59 */       if ((block instanceof IDynamicHandler))
/*  60 */         return ((IDynamicHandler)block).getDynamicContainer(ID, player, world, x, y, z);
/*     */     }
/*  62 */     return null;
/*     */   }
/*     */   
/*     */   public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/*  67 */     if (customDynamicGuiMap.containsKey(ID)) {
/*  68 */       return new DynamicGui(((IDynamicHandler)customDynamicGuiMap.get(ID)).getDynamicContainer(ID, player, world, x, y, z));
/*     */     }
/*     */     
/*  71 */     if (ID == -1) {
/*  72 */       ItemStack heldItem = player.func_70694_bm();
/*  73 */       if (heldItem == null) return null;
/*  74 */       Item item = heldItem.getItem();
/*  75 */       if ((item instanceof IGuiHandler))
/*  76 */         return ((IGuiHandler)item).getClientGuiElement(ID, player, world, x, y, z);
/*  77 */       if ((item instanceof IDynamicHandler))
/*  78 */         return new DynamicGui(((IDynamicHandler)item).getDynamicContainer(ID, player, world, x, y, z));
/*     */     } else {
/*  80 */       BlockPos pos = new BlockPos(x, y, z);
/*  81 */       TileEntity tileEntity = world.getTileEntity(pos);
/*  82 */       if ((tileEntity instanceof IGuiHandler))
/*  83 */         return ((IGuiHandler)tileEntity).getClientGuiElement(ID, player, world, x, y, z);
/*  84 */       if ((tileEntity instanceof IDynamicHandler))
/*  85 */         return new DynamicGui(((IDynamicHandler)tileEntity).getDynamicContainer(ID, player, world, x, y, z));
/*  86 */       IBlockState state = world.getBlockState(pos);
/*  87 */       if ((state instanceof IGuiHandler))
/*  88 */         return ((IGuiHandler)state).getClientGuiElement(ID, player, world, x, y, z);
/*  89 */       if ((state instanceof IDynamicHandler))
/*  90 */         return new DynamicGui(((IDynamicHandler)state).getDynamicContainer(ID, player, world, x, y, z));
/*  91 */       Block block = state.getBlock();
/*  92 */       if ((block instanceof IGuiHandler))
/*  93 */         return ((IGuiHandler)block).getClientGuiElement(ID, player, world, x, y, z);
/*  94 */       if ((block instanceof IDynamicHandler))
/*  95 */         return new DynamicGui(((IDynamicHandler)block).getDynamicContainer(ID, player, world, x, y, z));
/*     */     }
/*  97 */     return null;
/*     */   }
/*     */   
/*     */   @com.rwtema.extrautils2.network.NetworkHandler.XUPacket
/*     */   public static class PacketOpenGui
/*     */     extends XUPacketClientToServer
/*     */   {
/*     */     int id;
/*     */     private EntityPlayer player;
/*     */     
/*     */     public PacketOpenGui() {}
/*     */     
/*     */     public PacketOpenGui(int id)
/*     */     {
/* 111 */       this.id = id;
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/* 116 */       writeInt(this.id);
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player)
/*     */     {
/* 121 */       this.id = readInt();
/* 122 */       this.player = player;
/*     */     }
/*     */     
/*     */     public Runnable doStuffServer()
/*     */     {
/* 127 */       new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 131 */           GuiHandler.PacketOpenGui.this.player.openGui(ExtraUtils2.instance, GuiHandler.PacketOpenGui.this.id, GuiHandler.PacketOpenGui.this.player.worldObj, 0, 0, 0);
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\GuiHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */