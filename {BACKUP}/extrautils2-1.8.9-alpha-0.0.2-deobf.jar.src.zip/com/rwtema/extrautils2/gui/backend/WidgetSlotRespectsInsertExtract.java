/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.ISidedInventory;
/*    */ 
/*    */ public class WidgetSlotRespectsInsertExtract extends WidgetSlot
/*    */ {
/*    */   public WidgetSlotRespectsInsertExtract(ISidedInventory inv, int slot, int x, int y)
/*    */   {
/* 10 */     super(inv, slot, x, y);
/*    */   }
/*    */   
/*    */   public boolean canTakeStack(EntityPlayer par1EntityPlayer)
/*    */   {
/* 15 */     return (getStack() != null) && (((ISidedInventory)this.inventory).canExtractItem(getSlotIndex(), getStack(), net.minecraft.util.EnumFacing.DOWN));
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isItemValid(net.minecraft.item.ItemStack par1ItemStack)
/*    */   {
/* 21 */     return (!getHasStack()) && (super.isItemValid(par1ItemStack)) && (((ISidedInventory)this.inventory).canInsertItem(getSlotIndex(), par1ItemStack, net.minecraft.util.EnumFacing.DOWN));
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetSlotRespectsInsertExtract.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */