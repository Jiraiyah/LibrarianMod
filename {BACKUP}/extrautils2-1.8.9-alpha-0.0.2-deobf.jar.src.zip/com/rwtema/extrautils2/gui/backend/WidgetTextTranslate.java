/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ public class WidgetTextTranslate extends WidgetText {
/*    */   public WidgetTextTranslate(int x, int y, int w, int h, int align, int color, String msg) {
/*  7 */     super(x, y, w, h, align, color, msg);
/*    */   }
/*    */   
/*    */   public WidgetTextTranslate(int i, int j, String invName, int playerInvWidth) {
/* 11 */     super(i, j, invName, playerInvWidth);
/*    */   }
/*    */   
/*    */   public String getMsgClient()
/*    */   {
/* 16 */     return StatCollector.translateToLocal(this.msg);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetTextTranslate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */