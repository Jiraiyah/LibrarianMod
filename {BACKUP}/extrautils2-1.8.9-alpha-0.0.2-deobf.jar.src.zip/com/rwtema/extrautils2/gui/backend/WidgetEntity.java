/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.client.GLStateAttributes;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ 
/*    */ public class WidgetEntity extends WidgetBase
/*    */ {
/*    */   private final EntityLivingBase entityLivingBase;
/*    */   private final int scale;
/*    */   
/*    */   public WidgetEntity(EntityLivingBase entityLivingBase, int scale, int x, int y, int w, int h)
/*    */   {
/* 15 */     super(x, y, w, h);
/* 16 */     this.entityLivingBase = entityLivingBase;
/* 17 */     this.scale = scale;
/*    */   }
/*    */   
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 22 */     GLStateAttributes states = GLStateAttributes.loadStates();
/* 23 */     net.minecraft.client.Minecraft.getMinecraft().renderEngine.bindTexture(DynamicGui.texBackgroundBlack);
/* 24 */     gui.drawBasicBackground(guiLeft + getX(), guiTop + getY(), getW(), getH());
/*    */     
/* 26 */     AxisAlignedBB bb = this.entityLivingBase.getEntityBoundingBox();
/* 27 */     int h = (int)((bb.maxY - bb.minY) * this.scale);
/*    */     
/* 29 */     int posX = guiLeft + getX() + getW() / 2;
/* 30 */     int posY = guiTop + getY() + getH() - (getH() - h) / 4;
/* 31 */     states.restore();
/*    */     
/* 33 */     int i = gui.mouseX;
/* 34 */     int j = gui.mouseY;
/*    */     
/* 36 */     int v = (int)(this.scale * this.entityLivingBase.getEyeHeight());
/*    */     
/*    */ 
/*    */ 
/* 40 */     net.minecraft.client.gui.inventory.GuiInventory.drawEntityOnScreen(posX, posY, this.scale, posX - i, posY - v - j, this.entityLivingBase);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 47 */     states.restore();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */