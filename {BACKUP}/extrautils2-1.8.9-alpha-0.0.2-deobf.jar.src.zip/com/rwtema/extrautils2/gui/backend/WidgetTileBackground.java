/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.BlockRendererDispatcher;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*    */ import net.minecraft.client.resources.model.IBakedModel;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class WidgetTileBackground extends WidgetBase
/*    */ {
/*    */   private final World world;
/*    */   private final BlockPos pos;
/*    */   
/*    */   public WidgetTileBackground(World world, BlockPos pos, int y, int size)
/*    */   {
/* 26 */     super((170 - size) / 2, y, size, size);
/* 27 */     this.world = world;
/* 28 */     this.pos = pos;
/*    */   }
/*    */   
/*    */   public void addToContainer(DynamicContainer container)
/*    */   {
/* 33 */     super.addToContainer(container);
/* 34 */     this.x = ((container.width - this.w) / 2);
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 41 */     GlStateManager.enableBlend();
/* 42 */     GlStateManager.disableAlpha();
/* 43 */     GlStateManager.disableTexture2D();
/* 44 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/* 45 */     GlStateManager.color(0.0F, 0.0F, 0.0F, 0.2F);
/*    */     
/* 47 */     IBakedModel model = Minecraft.getMinecraft().getBlockRendererDispatcher().func_175022_a(this.world.getBlockState(this.pos), this.world, this.pos);
/* 48 */     Tessellator instance = Tessellator.getInstance();
/* 49 */     WorldRenderer t = instance.getBuffer();
/* 50 */     t.begin(7, DefaultVertexFormats.POSITION);
/*    */     
/* 52 */     renderQuads(t, model.func_177550_a(), guiLeft + this.x, guiTop + this.y, 0.0F);
/* 53 */     for (EnumFacing enumFacing : EnumFacing.values()) {
/* 54 */       renderQuads(t, model.func_177551_a(enumFacing), guiLeft + this.x, guiTop + this.y, 0.0F);
/*    */     }
/*    */     
/* 57 */     instance.draw();
/*    */     
/* 59 */     GlStateManager.enableTexture2D();
/* 60 */     GlStateManager.enableAlpha();
/* 61 */     GlStateManager.disableBlend();
/*    */   }
/*    */   
/*    */   public void renderQuads(WorldRenderer t, List<BakedQuad> quadList, float x, float y, float z) {
/* 65 */     for (BakedQuad bakedQuad : quadList) {
/* 66 */       renderQuad(t, bakedQuad, x, y, z);
/*    */     }
/*    */   }
/*    */   
/*    */   private void renderQuad(WorldRenderer t, BakedQuad bakedQuad, float x, float y, float z) {
/* 71 */     int[] vertexData = bakedQuad.getVertexData();
/* 72 */     for (int i = 0; i < 4; i++) {
/* 73 */       t.pos(x + this.w * Float.intBitsToFloat(vertexData[(i * 7)]), y + this.h * (1.0F - Float.intBitsToFloat(vertexData[(i * 7 + 1)])), z).endVertex();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public List<String> getToolTip()
/*    */   {
/* 82 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetTileBackground.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */