/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.helpers.ColorHelper;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public class DynamicContainerTile extends DynamicContainer
/*    */ {
/*    */   protected final TileEntity tile;
/*    */   
/*    */   public DynamicContainerTile(TileEntity tile)
/*    */   {
/* 12 */     this(tile, 0, 0);
/*    */   }
/*    */   
/*    */   public DynamicContainerTile(TileEntity tile, int y, int size) {
/* 16 */     this.tile = tile;
/* 17 */     if (size != 0) {
/* 18 */       addWidget(new WidgetTileBackground(tile.getWorld(), tile.getPos(), y, size));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(net.minecraft.entity.player.EntityPlayer playerIn)
/*    */   {
/* 24 */     return com.rwtema.extrautils2.tile.XUTile.isLoaded(this.tile);
/*    */   }
/*    */   
/*    */   public <S extends Enum<S>> void addSideManager(com.rwtema.extrautils2.tile.XUTile.XUTileCapabilitySide<?, S> XUTileCapabilitySide, int color) {
/* 28 */     DynamicWindow dynamicWindow = new DynamicWindow();
/* 29 */     dynamicWindow.r = (ColorHelper.getR(color) / 255.0F);
/* 30 */     dynamicWindow.g = (ColorHelper.getG(color) / 255.0F);
/* 31 */     dynamicWindow.b = (ColorHelper.getB(color) / 255.0F);
/* 32 */     addWidget(new WidgetSideHandler(XUTileCapabilitySide), dynamicWindow);
/*    */   }
/*    */   
/*    */   public void onSlotChanged(int index)
/*    */   {
/* 37 */     super.onSlotChanged(index);
/* 38 */     this.tile.markDirty();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\DynamicContainerTile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */