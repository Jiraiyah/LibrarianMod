/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.ISidedInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class WidgetSlot
/*    */   extends Slot implements IWidget
/*    */ {
/*    */   boolean isISided;
/*    */   int side;
/*    */   
/*    */   public WidgetSlot(IInventory inv, int slot, int x, int y)
/*    */   {
/* 21 */     super(inv, slot, x + 1, y + 1);
/* 22 */     this.isISided = (inv instanceof ISidedInventory);
/* 23 */     this.side = 0;
/*    */     
/* 25 */     if (this.isISided) {
/* 26 */       for (this.side = 0; this.side < 6; this.side += 1) {
/* 27 */         int[] slots = ((ISidedInventory)inv).getSlotsForFace(net.minecraft.util.EnumFacing.values()[this.side]);
/*    */         
/* 29 */         for (int s : slots) {
/* 30 */           if (s == slot) {
/* 31 */             return;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isItemValid(ItemStack par1ItemStack)
/*    */   {
/* 40 */     return this.inventory.isItemValidForSlot(getSlotIndex(), par1ItemStack);
/*    */   }
/*    */   
/*    */   public boolean canTakeStack(EntityPlayer par1EntityPlayer)
/*    */   {
/* 45 */     return true;
/*    */   }
/*    */   
/*    */   public int getX()
/*    */   {
/* 50 */     return this.xDisplayPosition - 1;
/*    */   }
/*    */   
/*    */   public int getY()
/*    */   {
/* 55 */     return this.yDisplayPosition - 1;
/*    */   }
/*    */   
/*    */   public int getW()
/*    */   {
/* 60 */     return 18;
/*    */   }
/*    */   
/*    */   public int getH()
/*    */   {
/* 65 */     return 18;
/*    */   }
/*    */   
/*    */   public void addToContainer(DynamicContainer container)
/*    */   {
/* 70 */     container.addSlot(this);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 76 */     gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 0, 0, 18, 18);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop) {}
/*    */   
/*    */ 
/*    */   public List<String> getToolTip()
/*    */   {
/* 86 */     return null;
/*    */   }
/*    */   
/*    */   public void addToGui(DynamicGui gui) {}
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetSlot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */