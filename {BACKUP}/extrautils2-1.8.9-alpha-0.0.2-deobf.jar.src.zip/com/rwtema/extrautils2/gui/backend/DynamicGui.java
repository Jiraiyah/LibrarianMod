/*     */ package com.rwtema.extrautils2.gui.backend;
/*     */ 
/*     */ import com.google.common.collect.LinkedHashMultimap;
/*     */ import com.rwtema.extrautils2.utils.client.GLStateAttributes;
/*     */ import gnu.trove.map.hash.TIntObjectHashMap;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*     */ public class DynamicGui extends GuiContainer
/*     */ {
/*  25 */   public static final ResourceLocation texBackground = new ResourceLocation("extrautils2", "textures/guiBase.png");
/*  26 */   public static final ResourceLocation texBackgroundIndentation = new ResourceLocation("extrautils2", "textures/guiBaseIndent.png");
/*  27 */   public static final ResourceLocation texBackgroundBlack = new ResourceLocation("extrautils2", "textures/guiBaseBlack.png");
/*  28 */   public static final ResourceLocation texWidgets = new ResourceLocation("extrautils2", "textures/guiWidget.png");
/*     */   public final DynamicContainer container;
/*     */   public int mouseX;
/*     */   public int mouseY;
/*  32 */   TIntObjectHashMap<WidgetButton> buttonWidgets = new TIntObjectHashMap();
/*     */   
/*     */   public DynamicGui(DynamicContainer container) {
/*  35 */     super(container);
/*  36 */     container.isClient = true;
/*  37 */     this.container = container;
/*  38 */     container.loadGuiDimensions(this);
/*     */   }
/*     */   
/*     */   public int nextButtonID()
/*     */   {
/*  43 */     return this.buttonList.size();
/*     */   }
/*     */   
/*     */   public void initGui()
/*     */   {
/*  48 */     super.initGui();
/*     */     
/*  50 */     int y = 0;
/*  51 */     for (DynamicWindow dynamicWindow : this.container.getWindowWidgets().keySet()) {
/*  52 */       if (dynamicWindow != null) {
/*  53 */         Set<IWidget> iWidgets = this.container.getWindowWidgets().get(dynamicWindow);
/*  54 */         dynamicWindow.crop(iWidgets);
/*  55 */         dynamicWindow.x = this.container.width;
/*  56 */         dynamicWindow.y = y;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  61 */     this.container.loadGuiDimensions(this);
/*     */     
/*  63 */     for (IWidget widget : this.container.getWidgets()) {
/*  64 */       widget.addToGui(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addButton(WidgetButton widgetButton, GuiButton button) {
/*  69 */     this.buttonWidgets.put(button.id, widgetButton);
/*  70 */     this.buttonList.add(button);
/*     */   }
/*     */   
/*     */   protected void actionPerformed(GuiButton button) throws IOException
/*     */   {
/*  75 */     super.actionPerformed(button);
/*     */     
/*  77 */     if (button.enabled) {
/*  78 */       WidgetButton widgetButton = (WidgetButton)this.buttonWidgets.get(button.id);
/*  79 */       if (widgetButton != null)
/*  80 */         widgetButton.onClientClick();
/*     */     }
/*     */   }
/*     */   
/*     */   public float getZLevel() {
/*  85 */     return this.zLevel;
/*     */   }
/*     */   
/*     */   public int getXSize() {
/*  89 */     return this.xSize;
/*     */   }
/*     */   
/*     */   public int getYSize() {
/*  93 */     return this.ySize;
/*     */   }
/*     */   
/*     */   public FontRenderer getFontRenderer() {
/*  97 */     return this.fontRendererObj;
/*     */   }
/*     */   
/*     */   public ResourceLocation getWidgetTexture() {
/* 101 */     return texWidgets;
/*     */   }
/*     */   
/*     */   public void drawScaledBox(ResourceLocation location, int x, int y, int w, int h) {
/* 105 */     this.mc.renderEngine.bindTexture(location);
/* 106 */     int dx = w / 2;
/* 107 */     int dy = h / 2;
/* 108 */     drawTexturedModalRect(this.guiLeft + x, this.guiTop + y, 0, 0, dx, dy);
/* 109 */     drawTexturedModalRect(this.guiLeft + x + dx, this.guiTop + y, 256 - dx, 0, dx, dy);
/* 110 */     drawTexturedModalRect(this.guiLeft + x, this.guiTop + y + dy, 0, 256 - dy, dx, dy);
/* 111 */     drawTexturedModalRect(this.guiLeft + x + dx, this.guiTop + y + dy, 256 - dx, 256 - dy, dx, dy);
/*     */   }
/*     */   
/*     */   protected void drawGuiContainerBackgroundLayer(float f, int a, int b)
/*     */   {
/* 116 */     GlStateManager.color(1.0F, 1.0F, 1.0F);
/*     */     
/* 118 */     for (Iterator i$ = this.container.getWindowWidgets().keySet().iterator(); i$.hasNext();) { dynamicWindow = (DynamicWindow)i$.next();
/* 119 */       GLStateAttributes glStateAttributes; if (dynamicWindow == null) {
/* 120 */         if (!this.container.drawBackgroundOverride(this)) {
/* 121 */           this.mc.renderEngine.bindTexture(texBackground);
/* 122 */           drawBasicBackground(this.guiLeft, this.guiTop, this.xSize, this.ySize);
/*     */         }
/*     */         
/* 125 */         this.mc.renderEngine.bindTexture(getWidgetTexture());
/* 126 */         GlStateManager.color(1.0F, 1.0F, 1.0F);
/* 127 */         glStateAttributes = GLStateAttributes.loadStates();
/* 128 */         for (IWidget widget : this.container.getWindowWidgets().get(null)) {
/* 129 */           widget.renderBackground(this.mc.renderEngine, this, this.guiLeft, this.guiTop);
/* 130 */           glStateAttributes.restore();
/*     */         }
/*     */       } else {
/* 133 */         if (!dynamicWindow.drawBackgroundOverride(this, this.container)) {
/* 134 */           this.mc.renderEngine.bindTexture(texBackground);
/* 135 */           GlStateManager.color(dynamicWindow.r, dynamicWindow.g, dynamicWindow.b);
/* 136 */           drawBasicBackground(this.guiLeft + dynamicWindow.x, this.guiTop + dynamicWindow.y, dynamicWindow.w, dynamicWindow.h);
/*     */         }
/*     */         
/* 139 */         this.mc.renderEngine.bindTexture(getWidgetTexture());
/* 140 */         GlStateManager.color(1.0F, 1.0F, 1.0F);
/* 141 */         glStateAttributes = GLStateAttributes.loadStates();
/* 142 */         for (IWidget widget : this.container.getWindowWidgets().get(dynamicWindow)) {
/* 143 */           widget.renderBackground(this.mc.renderEngine, this, this.guiLeft + dynamicWindow.x, this.guiTop + dynamicWindow.y);
/* 144 */           glStateAttributes.restore();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     DynamicWindow dynamicWindow;
/*     */     GLStateAttributes glStateAttributes;
/*     */   }
/*     */   
/*     */   public void drawBasicBackground(int x, int y, int w, int h)
/*     */   {
/* 155 */     int w2 = w >> 1;
/* 156 */     int h2 = h >> 1;
/* 157 */     int w3 = w - w2;
/* 158 */     int h3 = h - h2;
/* 159 */     drawTexturedModalRect(x, y, 0, 0, w2, h2);
/* 160 */     drawTexturedModalRect(x + w2, y, 256 - w3, 0, w3, h2);
/* 161 */     drawTexturedModalRect(x, y + h2, 0, 256 - h3, w2, h3);
/* 162 */     drawTexturedModalRect(x + w2, y + h2, 256 - w3, 256 - h3, w3, h3);
/*     */   }
/*     */   
/*     */   protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY)
/*     */   {
/* 167 */     List<String> tooltip = null;
/* 168 */     GlStateManager.disableRescaleNormal();
/* 169 */     net.minecraft.client.renderer.RenderHelper.disableStandardItemLighting();
/* 170 */     GlStateManager.disableLighting();
/* 171 */     GlStateManager.disableDepth();
/* 172 */     GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/* 174 */     GLStateAttributes glStateAttributes = GLStateAttributes.loadStates();
/*     */     
/* 176 */     for (DynamicWindow dynamicWindow : this.container.getWindowWidgets().keySet()) {
/* 177 */       if (dynamicWindow == null) {
/* 178 */         tooltip = renderForeground(mouseX, mouseY, tooltip, null, this.guiLeft, this.guiTop);
/*     */       } else {
/* 180 */         tooltip = renderForeground(mouseX, mouseY, tooltip, dynamicWindow, this.guiLeft + dynamicWindow.x, this.guiTop + dynamicWindow.y);
/*     */       }
/* 182 */       glStateAttributes.restore();
/*     */     }
/*     */     
/* 185 */     if (tooltip != null) {
/* 186 */       drawHoveringText(tooltip, mouseX - this.guiLeft, mouseY - this.guiTop, getFontRenderer());
/* 187 */       GlStateManager.enableLighting();
/* 188 */       GlStateManager.enableDepth();
/*     */     }
/*     */     
/* 191 */     net.minecraft.client.renderer.RenderHelper.enableGUIStandardItemLighting();
/*     */     
/* 193 */     GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 194 */     GlStateManager.enableRescaleNormal();
/*     */   }
/*     */   
/*     */   private List<String> renderForeground(int mouseX, int mouseY, List<String> tooltip, DynamicWindow dynamicWindow, int guiX, int guiY) {
/* 198 */     for (IWidget widget : this.container.getWindowWidgets().get(dynamicWindow)) {
/* 199 */       this.mc.renderEngine.bindTexture(getWidgetTexture());
/* 200 */       GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/*     */       
/* 202 */       widget.renderForeground(this.mc.renderEngine, this, guiX - this.guiLeft, guiY - this.guiTop);
/*     */       
/* 204 */       if (isInArea(mouseX, mouseY, widget)) {
/* 205 */         List<String> t = widget.getToolTip();
/*     */         
/* 207 */         if (t != null) {
/* 208 */           tooltip = t;
/*     */         }
/*     */       }
/*     */     }
/* 212 */     return tooltip;
/*     */   }
/*     */   
/*     */   public boolean isInArea(int x, int y, IWidget w) {
/* 216 */     DynamicWindow dynamicWindow = (DynamicWindow)this.container.getWindowOwner().get(w);
/* 217 */     if (dynamicWindow == null) {
/* 218 */       x -= this.guiLeft;
/* 219 */       y -= this.guiTop;
/*     */     } else {
/* 221 */       x -= dynamicWindow.x + this.guiLeft;
/* 222 */       y -= dynamicWindow.y + this.guiTop;
/*     */     }
/*     */     
/* 225 */     return (x >= w.getX()) && (x < w.getX() + w.getW()) && (y >= w.getY()) && (y < w.getY() + w.getH());
/*     */   }
/*     */   
/*     */   protected void keyTyped(char typedChar, int keyCode) throws IOException
/*     */   {
/* 230 */     super.keyTyped(typedChar, keyCode);
/* 231 */     for (IWidgetKeyInput input : this.container.getWidgetKeyInputs()) {
/* 232 */       input.keyTyped(typedChar, keyCode);
/*     */     }
/*     */   }
/*     */   
/*     */   public void handleMouseInput() throws IOException
/*     */   {
/* 238 */     this.mouseX = (Mouse.getEventX() * this.width / this.mc.displayWidth);
/* 239 */     this.mouseY = (this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1);
/*     */     
/* 241 */     int x = Mouse.getEventX() * this.width / this.mc.displayWidth;
/* 242 */     int y = this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1;
/*     */     
/* 244 */     for (IWidgetMouseInput widgetMouseInput : this.container.getWidgetMouseInputs()) {
/* 245 */       widgetMouseInput.mouseTick(x, y, isInArea(x, y, widgetMouseInput));
/*     */     }
/*     */     
/* 248 */     super.handleMouseInput();
/*     */     
/* 250 */     int i = Mouse.getEventDWheel();
/*     */     
/* 252 */     for (IWidgetMouseInput widgetMouseInput : this.container.getWidgetMouseInputs()) {
/* 253 */       widgetMouseInput.mouseWheelScroll(i);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void mouseReleased(int mouseX, int mouseY, int mouseButton)
/*     */   {
/* 259 */     super.mouseReleased(mouseX, mouseY, mouseButton);
/* 260 */     for (IWidgetMouseInput mouseInput : this.container.getWidgetMouseInputs()) {
/* 261 */       mouseInput.mouseReleased(mouseX, mouseY, mouseButton, isInArea(mouseX, mouseY, mouseInput));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick)
/*     */   {
/* 267 */     super.mouseClickMove(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
/* 268 */     for (IWidgetMouseInput mouseInput : this.container.getWidgetMouseInputs()) {
/* 269 */       mouseInput.mouseClickMove(mouseX, mouseY, clickedMouseButton, timeSinceLastClick, isInArea(mouseX, mouseY, mouseInput));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException
/*     */   {
/* 275 */     super.mouseClicked(mouseX, mouseY, mouseButton);
/* 276 */     for (IWidgetMouseInput mouseInput : this.container.getWidgetMouseInputs()) {
/* 277 */       mouseInput.mouseClicked(mouseX, mouseY, mouseButton, isInArea(mouseX, mouseY, mouseInput));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawHorizontalLine(int startX, int endX, int y, int color)
/*     */   {
/* 284 */     super.drawHorizontalLine(startX, endX, y, color);
/*     */   }
/*     */   
/*     */   public void drawVerticalLine(int x, int startY, int endY, int color)
/*     */   {
/* 289 */     super.drawVerticalLine(x, startY, endY, color);
/*     */   }
/*     */   
/*     */   public void drawGradientRect(int left, int top, int right, int bottom, int startColor, int endColor)
/*     */   {
/* 294 */     super.drawGradientRect(left, top, right, bottom, startColor, endColor);
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawCenteredString(FontRenderer fontRendererIn, String text, int x, int y, int color)
/*     */   {
/* 300 */     super.drawCenteredString(fontRendererIn, text, x, y, color);
/*     */   }
/*     */   
/*     */   public void drawString(FontRenderer fontRendererIn, String text, int x, int y, int color)
/*     */   {
/* 305 */     super.drawString(fontRendererIn, text, x, y, color);
/*     */   }
/*     */   
/*     */   public void drawTexturedModalRect(int x, int y, int textureX, int textureY, int width, int height)
/*     */   {
/* 310 */     super.drawTexturedModalRect(x, y, textureX, textureY, width, height);
/*     */   }
/*     */   
/*     */   public void drawTexturedModalRect(float xCoord, float yCoord, int minU, int minV, int maxU, int maxV)
/*     */   {
/* 315 */     super.drawTexturedModalRect(xCoord, yCoord, minU, minV, maxU, maxV);
/*     */   }
/*     */   
/*     */   public void drawTexturedModalRect(int xCoord, int yCoord, net.minecraft.client.renderer.texture.TextureAtlasSprite textureSprite, int widthIn, int heightIn)
/*     */   {
/* 320 */     super.drawTexturedModalRect(xCoord, yCoord, textureSprite, widthIn, heightIn);
/*     */   }
/*     */   
/*     */   public void renderStack(ItemStack stack, int x, int y, String altText) {
/* 324 */     if (stack == null) return;
/* 325 */     GlStateManager.pushMatrix();
/* 326 */     GlStateManager.translate(0.0F, 0.0F, 32.0F);
/* 327 */     this.zLevel = 200.0F;
/* 328 */     this.itemRender.zLevel = 200.0F;
/* 329 */     FontRenderer font = stack.getItem().getFontRenderer(stack);
/* 330 */     if (font == null) font = this.fontRendererObj;
/* 331 */     this.itemRender.renderItemAndEffectIntoGUI(stack, x, y);
/* 332 */     this.itemRender.renderItemOverlayIntoGUI(font, stack, x, y, altText);
/* 333 */     this.zLevel = 0.0F;
/* 334 */     this.itemRender.zLevel = 0.0F;
/* 335 */     GlStateManager.popMatrix();
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawRectangle(int x, int y, int w, int h, int color)
/*     */   {
/* 341 */     drawRect(x, y, x + w, y + h, color);
/*     */   }
/*     */   
/*     */   public void drawSlotBackground(int x, int y) {
/* 345 */     drawTexturedModalRect(x, y, 0, 0, 18, 18);
/*     */   }
/*     */   
/*     */   public void renderSmallStackText(ItemStack stack, String s, int x, int y) {
/* 349 */     if (stack == null) return;
/* 350 */     GlStateManager.pushMatrix();
/* 351 */     GlStateManager.translate(0.0F, 0.0F, 32.0F);
/* 352 */     this.zLevel = 200.0F;
/* 353 */     this.itemRender.zLevel = 200.0F;
/*     */     
/* 355 */     FontRenderer font = stack.getItem().getFontRenderer(stack);
/* 356 */     if (font == null) font = this.fontRendererObj;
/* 357 */     this.itemRender.renderItemAndEffectIntoGUI(stack, x, y);
/* 358 */     this.itemRender.renderItemOverlayIntoGUI(font, stack, x, y, "");
/*     */     
/* 360 */     if (!net.minecraft.util.StringUtils.isNullOrEmpty(s)) {
/* 361 */       GlStateManager.disableLighting();
/* 362 */       GlStateManager.disableDepth();
/* 363 */       GlStateManager.disableBlend();
/* 364 */       float scale = 2.0F;
/*     */       float scaledFontWidth;
/* 366 */       while ((scaledFontWidth = this.fontRendererObj.getStringWidth(s) / scale) >= 15.0F) scale += 1.0F;
/* 367 */       GlStateManager.translate(x + 16 - scaledFontWidth, y + 17 - 9.0F / scale, 0.0F);
/* 368 */       GlStateManager.scale(1.0F / scale, 1.0F / scale, 1.0F / scale);
/* 369 */       this.fontRendererObj.drawStringWithShadow(s, 0.0F, 0.0F, 16777215);
/* 370 */       GlStateManager.enableLighting();
/* 371 */       GlStateManager.enableDepth();
/*     */     }
/*     */     
/* 374 */     this.zLevel = 0.0F;
/* 375 */     this.itemRender.zLevel = 0.0F;
/* 376 */     GlStateManager.popMatrix();
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\DynamicGui.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */