package com.rwtema.extrautils2.gui.backend;

import java.util.List;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public abstract interface IWidget
{
  public abstract int getX();
  
  public abstract int getY();
  
  public abstract int getW();
  
  public abstract int getH();
  
  @SideOnly(Side.CLIENT)
  public abstract void renderForeground(TextureManager paramTextureManager, DynamicGui paramDynamicGui, int paramInt1, int paramInt2);
  
  @SideOnly(Side.CLIENT)
  public abstract void renderBackground(TextureManager paramTextureManager, DynamicGui paramDynamicGui, int paramInt1, int paramInt2);
  
  public abstract void addToContainer(DynamicContainer paramDynamicContainer);
  
  public abstract List<String> getToolTip();
  
  @SideOnly(Side.CLIENT)
  public abstract void addToGui(DynamicGui paramDynamicGui);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\IWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */