package com.rwtema.extrautils2.gui.backend;

import java.util.List;

public abstract interface IAdditionalWidgets
{
  public abstract List<IWidget> getAdditionalWidgets();
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\IAdditionalWidgets.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */