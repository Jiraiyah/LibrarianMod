/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ 
/*    */ public class WidgetTextSmallText extends WidgetTextMultiline
/*    */ {
/*  7 */   double scale = 2.0D;
/*    */   
/*    */   public WidgetTextSmallText(int x, int y, String msg, int w) {
/* 10 */     super(x, y, msg, w);
/*    */   }
/*    */   
/*    */   public WidgetTextSmallText(int x, int y, int align, int color, String msg) {
/* 14 */     super(x, y, align, color, msg);
/*    */   }
/*    */   
/*    */   public WidgetTextSmallText(int x, int y, int w, int h, int align, int color, String msg) {
/* 18 */     super(x, y, w, h, align, color, msg);
/*    */   }
/*    */   
/*    */   public <T extends WidgetTextSmallText> T setScale(double scale)
/*    */   {
/* 23 */     this.scale = scale;
/* 24 */     return this;
/*    */   }
/*    */   
/*    */   public void renderBackground(net.minecraft.client.renderer.texture.TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 29 */     String msg = getMsgClient();
/*    */     
/* 31 */     if (msg == null) return;
/* 32 */     int width = (int)(gui.getFontRenderer().getStringWidth(msg) / this.scale);
/* 33 */     int x1 = getX() + (1 - this.align) * (getW() - width) / 2;
/*    */     
/* 35 */     GlStateManager.pushMatrix();
/*    */     
/* 37 */     GlStateManager.translate(guiLeft + x1, guiTop + getY(), 0.0F);
/* 38 */     GlStateManager.scale(1.0D / this.scale, 1.0D / this.scale, 1.0D);
/* 39 */     gui.getFontRenderer().drawSplitString(msg, 0, 0, (int)(getW() * this.scale), 4210752);
/* 40 */     GlStateManager.translate(0.1D, 0.1D, 0.0D);
/* 41 */     gui.getFontRenderer().drawSplitString(msg, 0, 0, (int)(getW() * this.scale), 4210752);
/*    */     
/* 43 */     GlStateManager.popMatrix();
/* 44 */     manager.bindTexture(gui.getWidgetTexture());
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetTextSmallText.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */