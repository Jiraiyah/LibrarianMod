package com.rwtema.extrautils2.gui.backend;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public abstract interface IWidgetMouseInput
  extends IWidget
{
  @SideOnly(Side.CLIENT)
  public abstract void mouseClicked(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  @SideOnly(Side.CLIENT)
  public abstract void mouseReleased(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  @SideOnly(Side.CLIENT)
  public abstract void mouseClickMove(int paramInt1, int paramInt2, int paramInt3, long paramLong, boolean paramBoolean);
  
  @SideOnly(Side.CLIENT)
  public abstract void mouseWheelScroll(int paramInt);
  
  @SideOnly(Side.CLIENT)
  public abstract void mouseTick(int paramInt1, int paramInt2, boolean paramBoolean);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\IWidgetMouseInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */