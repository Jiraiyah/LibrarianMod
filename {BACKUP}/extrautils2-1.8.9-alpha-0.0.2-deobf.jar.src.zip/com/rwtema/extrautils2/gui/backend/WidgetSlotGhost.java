/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class WidgetSlotGhost extends WidgetSlot
/*    */ {
/*    */   public WidgetSlotGhost(net.minecraft.inventory.IInventory inv, int slot, int x, int y)
/*    */   {
/* 12 */     super(inv, slot, x, y);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop) {}
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isItemValid(ItemStack par1ItemStack)
/*    */   {
/* 24 */     return false;
/*    */   }
/*    */   
/*    */   public boolean canTakeStack(EntityPlayer par1EntityPlayer)
/*    */   {
/* 29 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void putStack(ItemStack p_75215_1_) {}
/*    */   
/*    */ 
/*    */   public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 39 */     boolean blendLevel = GlStateManager.blendState.blend.currentState;
/*    */     
/* 41 */     if (!blendLevel) {
/* 42 */       GlStateManager.enableBlend();
/*    */     }
/*    */     
/* 45 */     GlStateManager.blendFunc(770, 771);
/* 46 */     GlStateManager.color(1.0F, 1.0F, 1.0F, 0.4F);
/* 47 */     gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 0, 0, 18, 18);
/* 48 */     GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/*    */     
/* 50 */     if (!blendLevel) {
/* 51 */       GlStateManager.disableBlend();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetSlotGhost.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */