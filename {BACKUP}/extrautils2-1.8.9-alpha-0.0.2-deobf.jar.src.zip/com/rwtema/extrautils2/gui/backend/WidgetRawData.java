/*   */ package com.rwtema.extrautils2.gui.backend;
/*   */ 
/*   */ public abstract class WidgetRawData extends WidgetBase implements IWidgetServerNetwork {
/*   */   public WidgetRawData() {
/* 5 */     super(0, 0, 0, 0);
/*   */   }
/*   */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetRawData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */