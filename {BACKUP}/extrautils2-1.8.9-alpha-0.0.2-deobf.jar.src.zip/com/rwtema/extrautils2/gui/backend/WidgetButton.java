/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.network.PacketBuffer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public abstract class WidgetButton extends WidgetBase implements IWidgetClientNetwork
/*    */ {
/*    */   public String text;
/*    */   @SideOnly(Side.CLIENT)
/*    */   GuiButton button;
/*    */   private DynamicContainer container;
/*    */   
/*    */   public WidgetButton(int x, int y, int w, int h, String text)
/*    */   {
/* 17 */     super(x, y, w, h);
/* 18 */     this.text = text;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void addToGui(DynamicGui gui)
/*    */   {
/* 24 */     super.addToGui(gui);
/* 25 */     DynamicWindow window = (DynamicWindow)gui.container.getWindowOwner().get(this);
/* 26 */     int x = this.x + gui.guiLeft + (window != null ? window.x : 0);
/* 27 */     int y = this.y + gui.guiTop + (window != null ? window.y : 0);
/* 28 */     this.button = createButton(x, y, gui.nextButtonID());
/* 29 */     gui.addButton(this, this.button);
/*    */   }
/*    */   
/*    */   @javax.annotation.Nonnull
/*    */   @SideOnly(Side.CLIENT)
/*    */   public GuiButton createButton(int x, int y, int id)
/*    */   {
/* 36 */     return new GuiButton(id, x, y, this.w, this.h, this.text);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void onClientClick() {
/* 41 */     sendClickToServer();
/*    */   }
/*    */   
/*    */ 
/*    */   public void onClickServer(PacketBuffer buffer) {}
/*    */   
/*    */ 
/*    */   public void receiveClientPacket(PacketBuffer buffer)
/*    */   {
/* 50 */     onClickServer(buffer);
/*    */   }
/*    */   
/*    */   public void addToContainer(DynamicContainer container)
/*    */   {
/* 55 */     this.container = container;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void sendClickToServer() {
/* 60 */     sendClickToServer(null);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void sendClickToServer(PacketBuffer buffer) {
/* 65 */     this.container.sendInputPacket(this, buffer);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */