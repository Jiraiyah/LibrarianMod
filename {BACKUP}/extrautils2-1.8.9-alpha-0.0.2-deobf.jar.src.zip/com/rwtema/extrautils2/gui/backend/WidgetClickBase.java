/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public abstract class WidgetClickBase extends WidgetBase implements IWidgetMouseInput, IWidgetClientNetwork
/*    */ {
/*    */   @SideOnly(Side.CLIENT)
/*    */   protected boolean mouseOver;
/*    */   @SideOnly(Side.CLIENT)
/*    */   protected boolean hover;
/*    */   
/*    */   public WidgetClickBase(int x, int y, int w, int h)
/*    */   {
/* 15 */     super(x, y, w, h);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void mouseClicked(int mouseX, int mouseY, int mouseButton, boolean mouseOver)
/*    */   {
/* 21 */     if (mouseOver) {
/* 22 */       this.mouseOver = true;
/*    */     }
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void mouseReleased(int mouseX, int mouseY, int mouseButton, boolean mouseOver) {
/* 28 */     if (this.mouseOver) {
/* 29 */       if (mouseOver) {
/* 30 */         sendClick(mouseButton);
/*    */       }
/* 32 */       this.mouseOver = false;
/*    */     }
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void sendClick(int mouseButton) {
/* 38 */     com.rwtema.extrautils2.network.PacketBuffer pkt = getPacketToSend(mouseButton);
/* 39 */     if (pkt == null) return;
/* 40 */     this.container.sendInputPacket(this, pkt);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public abstract com.rwtema.extrautils2.network.PacketBuffer getPacketToSend(int paramInt);
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void mouseTick(int mouseX, int mouseY, boolean mouseOver)
/*    */   {
/* 49 */     this.hover = mouseOver;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void mouseClickMove(int mouseX, int mouseY, int mouseButton, long timeSinceLastMove, boolean mouseOver) {}
/*    */   
/*    */   public void mouseWheelScroll(int delta) {}
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetClickBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */