/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public abstract class WidgetBase implements IWidget
/*    */ {
/*    */   int x;
/*    */   int y;
/*    */   int w;
/*    */   int h;
/*    */   protected DynamicContainer container;
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   protected DynamicGui gui;
/*    */   
/*    */   public WidgetBase(int x, int y, int w, int h) {
/* 16 */     this.x = x;
/* 17 */     this.y = y;
/* 18 */     this.w = w;
/* 19 */     this.h = h;
/*    */   }
/*    */   
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void addToGui(DynamicGui gui)
/*    */   {
/* 25 */     this.gui = gui;
/*    */   }
/*    */   
/*    */   public int getX()
/*    */   {
/* 30 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY()
/*    */   {
/* 35 */     return this.y;
/*    */   }
/*    */   
/*    */   public int getW()
/*    */   {
/* 40 */     return this.w;
/*    */   }
/*    */   
/*    */   public int getH()
/*    */   {
/* 45 */     return this.h;
/*    */   }
/*    */   
/*    */   public void addToContainer(DynamicContainer container)
/*    */   {
/* 50 */     this.container = container;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void renderForeground(net.minecraft.client.renderer.texture.TextureManager manager, DynamicGui gui, int guiLeft, int guiTop) {}
/*    */   
/*    */ 
/*    */ 
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void renderBackground(net.minecraft.client.renderer.texture.TextureManager manager, DynamicGui gui, int guiLeft, int guiTop) {}
/*    */   
/*    */ 
/*    */ 
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public java.util.List<String> getToolTip()
/*    */   {
/* 68 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */