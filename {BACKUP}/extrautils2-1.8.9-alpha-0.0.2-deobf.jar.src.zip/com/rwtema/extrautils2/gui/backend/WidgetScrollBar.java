/*     */ package com.rwtema.extrautils2.gui.backend;
/*     */ 
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class WidgetScrollBar extends WidgetBase implements IWidgetMouseInput
/*     */ {
/*     */   public static final int BAR_WIDTH = 14;
/*     */   public int minValue;
/*     */   public int maxValue;
/*     */   public int scrollValue;
/*     */   private float drawValue;
/*     */   private boolean isScrolling;
/*     */   
/*     */   public WidgetScrollBar(int x, int y, int h, int minValue, int maxValue)
/*     */   {
/*  17 */     super(x, y, 14, h);
/*  18 */     this.minValue = minValue;
/*  19 */     this.maxValue = maxValue;
/*  20 */     this.scrollValue = minValue;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void mouseClicked(int mouseX, int mouseY, int mouseButton, boolean mouseOver)
/*     */   {
/*  26 */     if (this.minValue == this.maxValue) return;
/*  27 */     if ((mouseOver) && (mouseButton == 0)) {
/*  28 */       this.isScrolling = true;
/*  29 */       scroll(mouseY - this.gui.guiTop);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void setValues(int minValue, int maxValue) {
/*  35 */     this.minValue = minValue;
/*  36 */     this.maxValue = maxValue;
/*  37 */     if (minValue == maxValue) this.isScrolling = false;
/*  38 */     reScroll();
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void reScroll() {
/*  43 */     scroll(this.drawValue + 9.0F);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   private void scroll(float y)
/*     */   {
/*  49 */     if (y <= 9.0F) {
/*  50 */       this.drawValue = 0.0F;
/*  51 */       this.scrollValue = this.minValue;
/*  52 */     } else if (y >= this.h - 8) {
/*  53 */       this.drawValue = (this.h - 17);
/*  54 */       this.scrollValue = this.maxValue;
/*     */     } else {
/*  56 */       this.drawValue = (y - 9.0F);
/*  57 */       float a = this.drawValue * (this.maxValue - this.minValue) / (this.h - 7);
/*  58 */       int num = this.minValue + Math.round(a);
/*  59 */       this.scrollValue = net.minecraft.util.MathHelper.clamp_int(num, this.minValue, this.maxValue);
/*     */     }
/*     */     
/*  62 */     onChange();
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   protected void onChange() {}
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void mouseReleased(int mouseX, int mouseY, int mouseButton, boolean mouseOver)
/*     */   {
/*  73 */     this.isScrolling = false;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void mouseClickMove(int mouseX, int mouseY, int mouseButton, long timeSinceLastMove, boolean mouseOver)
/*     */   {
/*  79 */     if (this.isScrolling) {
/*  80 */       scroll(mouseY - this.gui.guiTop);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void renderBackground(net.minecraft.client.renderer.texture.TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */   {
/*  87 */     if (this.h == 112) {
/*  88 */       gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 220, 0, 14, 112);
/*  89 */     } else if (this.h < 112) {
/*  90 */       int h2 = this.h / 2;
/*  91 */       gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 220, 0, 14, h2);
/*  92 */       gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY() + this.h - h2 - 1, 220, 112 - h2, 14, h2 + 1);
/*     */     } else {
/*  94 */       gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 220, 0, 14, 16);
/*  95 */       for (int k = 16; 
/*  96 */           k + 80 < this.h; k += 80)
/*  97 */         gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY() + k, 220, 16, 14, 80);
/*  98 */       gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY() + k, 220, 112 - (this.h - k), 14, this.h - k);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void renderForeground(net.minecraft.client.renderer.texture.TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */   {
/* 105 */     gui.drawTexturedModalRect(guiLeft + getX() + 1, guiTop + getY() + this.drawValue, 196, 0, 12, 15);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void mouseWheelScroll(int delta)
/*     */   {
/* 111 */     if (delta == 0) return;
/* 112 */     if (delta > 0) {
/* 113 */       delta = -1;
/* 114 */     } else if (delta < 0) {
/* 115 */       delta = 1;
/*     */     }
/* 117 */     setValue(this.scrollValue + delta);
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void mouseTick(int mouseX, int mouseY, boolean mouseOver) {}
/*     */   
/*     */ 
/*     */   public void setValue(int newValue)
/*     */   {
/* 127 */     newValue = net.minecraft.util.MathHelper.clamp_int(newValue, this.minValue, this.maxValue);
/* 128 */     float a = newValue - this.minValue;
/* 129 */     scroll(a * (this.h - 7.0F) / (this.maxValue - this.minValue) + 9.0F);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetScrollBar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */