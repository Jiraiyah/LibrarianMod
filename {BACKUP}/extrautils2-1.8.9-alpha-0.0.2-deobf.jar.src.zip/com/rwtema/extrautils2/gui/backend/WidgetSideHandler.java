/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.network.PacketBuffer;
/*    */ import com.rwtema.extrautils2.tile.XUTile.XUTileCapabilitySide;
/*    */ import com.rwtema.extrautils2.utils.Lang;
/*    */ import gnu.trove.map.hash.TObjectIntHashMap;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public class WidgetSideHandler extends WidgetBase implements IWidget, IAdditionalWidgets
/*    */ {
/* 14 */   static int[][] locations = { { 17, 33 }, { 17, 0 }, { 0, 24 }, { 34, 7 }, { 0, 7 }, { 34, 24 } };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 25 */   static TObjectIntHashMap<String> xOffsets = new TObjectIntHashMap(10, 0.5F, 0);
/* 26 */   static { xOffsets.put("input", 1);
/* 27 */     xOffsets.put("disabled", 2);
/* 28 */     xOffsets.put("output", 3);
/*    */   }
/*    */   
/* 31 */   List<IWidget> buttons = new ArrayList(6);
/*    */   
/*    */   public WidgetSideHandler(XUTile.XUTileCapabilitySide XUTileCapabilitySide) {
/* 34 */     super(4, 4, 48, 47);
/* 35 */     for (int i = 0; i < 6; i++) {
/* 36 */       EnumFacing facing = EnumFacing.values()[i];
/* 37 */       this.buttons.add(new WidgetSideClick(i, XUTileCapabilitySide, facing));
/*    */     }
/*    */   }
/*    */   
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 43 */     gui.drawTexturedModalRect(guiLeft + getX() + 14, guiTop + getY() + 14, 234, 0, 20, 19);
/*    */   }
/*    */   
/*    */   public List<IWidget> getAdditionalWidgets()
/*    */   {
/* 48 */     return this.buttons;
/*    */   }
/*    */   
/*    */   private class WidgetSideClick extends WidgetClick implements IWidgetServerNetwork
/*    */   {
/*    */     private final XUTile.XUTileCapabilitySide XUTileCapabilitySide;
/*    */     private final EnumFacing facing;
/*    */     
/*    */     public WidgetSideClick(int i, XUTile.XUTileCapabilitySide XUTileCapabilitySide, EnumFacing facing) {
/* 57 */       super(WidgetSideHandler.this.getY() + WidgetSideHandler.locations[i][1], 14, 14);
/* 58 */       this.XUTileCapabilitySide = XUTileCapabilitySide;
/* 59 */       this.facing = facing;
/*    */     }
/*    */     
/*    */     public List<String> getToolTip()
/*    */     {
/* 64 */       return com.google.common.collect.ImmutableList.of(Lang.translate(this.facing.getName2()));
/*    */     }
/*    */     
/*    */     public void onClick(byte b)
/*    */     {
/* 69 */       if (b == 0) {
/* 70 */         this.XUTileCapabilitySide.cycleForward(this.facing);
/* 71 */       } else if (b == 1) {
/* 72 */         this.XUTileCapabilitySide.cycleBackward(this.facing);
/*    */       }
/*    */     }
/*    */     
/*    */     public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop) {
/* 77 */       String name = this.XUTileCapabilitySide.getValue(this.facing).name().toLowerCase();
/* 78 */       int u = WidgetSideHandler.xOffsets.get(name) * 14;
/* 79 */       gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), u, 128, 14, 14);
/*    */     }
/*    */     
/*    */     public void addToDescription(PacketBuffer packet)
/*    */     {
/* 84 */       for (EnumFacing facing : ) {
/* 85 */         packet.writeByte(this.XUTileCapabilitySide.getValue(facing).ordinal());
/*    */       }
/*    */     }
/*    */     
/*    */     public void handleDescriptionPacket(PacketBuffer packet)
/*    */     {
/* 91 */       for (EnumFacing facing : ) {
/* 92 */         this.XUTileCapabilitySide.setValue(facing, packet.readUnsignedByte());
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetSideHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */