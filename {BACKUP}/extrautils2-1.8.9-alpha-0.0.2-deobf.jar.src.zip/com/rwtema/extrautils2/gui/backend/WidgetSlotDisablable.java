/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.network.PacketBuffer;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ 
/*    */ public class WidgetSlotDisablable extends WidgetSlot implements IWidgetServerNetwork
/*    */ {
/* 11 */   boolean enabled = true;
/*    */   String methodName;
/*    */   
/*    */   public WidgetSlotDisablable(IInventory inv, int slot, int x, int y, String methodName) {
/* 15 */     super(inv, slot, x, y);
/* 16 */     this.methodName = methodName;
/*    */   }
/*    */   
/*    */   public boolean canTakeStack(EntityPlayer par1EntityPlayer)
/*    */   {
/* 21 */     return this.enabled;
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/*    */     try {
/* 26 */       return ((Boolean)this.inventory.getClass().getMethod(this.methodName, new Class[0]).invoke(this.inventory, new Object[0])).booleanValue();
/*    */     } catch (Exception e) {
/* 28 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 34 */     if (!this.enabled) {
/* 35 */       boolean blendLevel = GlStateManager.blendState.blend.currentState;
/*    */       
/* 37 */       if (!blendLevel) {
/* 38 */         GlStateManager.enableBlend();
/*    */       }
/*    */       
/* 41 */       GlStateManager.blendFunc(770, 771);
/* 42 */       GlStateManager.color(1.0F, 1.0F, 1.0F, 0.4F);
/* 43 */       gui.drawTexturedModalRect(guiLeft + getX(), guiTop + getY(), 0, 0, 18, 18);
/* 44 */       GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/*    */       
/* 46 */       if (!blendLevel) {
/* 47 */         GlStateManager.disableBlend();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void addToDescription(PacketBuffer packet)
/*    */   {
/* 54 */     packet.writeBoolean(this.enabled);
/*    */   }
/*    */   
/*    */   public void handleDescriptionPacket(PacketBuffer packet)
/*    */   {
/* 59 */     this.enabled = packet.readBoolean();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetSlotDisablable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */