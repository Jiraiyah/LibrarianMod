/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class WidgetText extends WidgetBase implements IWidget
/*    */ {
/*    */   public int align;
/*    */   public int color;
/*    */   public String msg;
/*    */   
/*    */   public WidgetText(int x, int y, String msg)
/*    */   {
/* 16 */     this(x, y, msg, ((Integer)com.rwtema.extrautils2.ExtraUtils2.proxy.apply(DynamicContainer.STRING_WIDTH_FUNCTION, msg)).intValue());
/*    */   }
/*    */   
/*    */   public WidgetText(int x, int y, String msg, int w) {
/* 20 */     this(x, y, w, 9, 1, 4210752, msg);
/*    */   }
/*    */   
/*    */   public WidgetText(int x, int y, int align, int color, String msg) {
/* 24 */     this(x, y, msg.length() * 12, 9, align, color, msg);
/*    */   }
/*    */   
/*    */   public WidgetText(int x, int y, int w, int h, int align, int color, String msg) {
/* 28 */     super(x, y, w, h);
/*    */     
/* 30 */     this.align = align;
/* 31 */     this.color = color;
/* 32 */     this.msg = msg;
/*    */   }
/*    */   
/*    */   public <T extends WidgetText> T setAlign(int align)
/*    */   {
/* 37 */     this.align = align;
/* 38 */     return this;
/*    */   }
/*    */   
/*    */   public <T extends WidgetText> T setColor(int color)
/*    */   {
/* 43 */     this.color = color;
/* 44 */     return this;
/*    */   }
/*    */   
/*    */   public int getX()
/*    */   {
/* 49 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY()
/*    */   {
/* 54 */     return this.y;
/*    */   }
/*    */   
/*    */   public int getW()
/*    */   {
/* 59 */     return this.w;
/*    */   }
/*    */   
/*    */   public int getH()
/*    */   {
/* 64 */     return this.h;
/*    */   }
/*    */   
/*    */   public String getMsgClient() {
/* 68 */     return this.msg;
/*    */   }
/*    */   
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 74 */     GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 75 */     int x = getX() + (1 - this.align) * (getW() - gui.getFontRenderer().getStringWidth(getMsgClient())) / 2;
/* 76 */     gui.getFontRenderer().drawString(getMsgClient(), guiLeft + x, guiTop + getY(), 4210752);
/* 77 */     manager.bindTexture(gui.getWidgetTexture());
/* 78 */     GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void addToContainer(DynamicContainer container) {}
/*    */   
/*    */ 
/*    */   public java.util.List<String> getToolTip()
/*    */   {
/* 88 */     return null;
/*    */   }
/*    */   
/*    */   public void addToGui(DynamicGui gui)
/*    */   {
/* 93 */     super.addToGui(gui);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetText.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */