/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.network.PacketBuffer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ 
/*    */ public abstract class WidgetTextData extends WidgetText implements IWidgetServerNetwork
/*    */ {
/*    */   public WidgetTextData(int x, int y, int w, int h, int align, int color)
/*    */   {
/* 10 */     super(x, y, w, h, align, color, null);
/*    */   }
/*    */   
/*    */   public WidgetTextData(int x, int y, int w)
/*    */   {
/* 15 */     super(x, y, null, w);
/*    */   }
/*    */   
/*    */   public WidgetTextData(int x, int y, int w, int h) {
/* 19 */     super(x, y, w, h, 1, 4210752, null);
/*    */   }
/*    */   
/*    */ 
/*    */   public abstract void addToDescription(PacketBuffer paramPacketBuffer);
/*    */   
/*    */   public void handleDescriptionPacket(PacketBuffer packet)
/*    */   {
/* 27 */     this.msg = constructText(packet);
/*    */   }
/*    */   
/*    */   protected abstract String constructText(PacketBuffer paramPacketBuffer);
/*    */   
/*    */   @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 35 */     if (this.msg == null) { return;
/*    */     }
/* 37 */     int x = getX() + (1 - this.align) * (getW() - gui.getFontRenderer().getStringWidth(getMsgClient())) / 2;
/* 38 */     gui.getFontRenderer().drawSplitString(this.msg, guiLeft + x, guiTop + getY(), getW(), 4210752);
/* 39 */     manager.bindTexture(gui.getWidgetTexture());
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetTextData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */