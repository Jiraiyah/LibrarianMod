/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.network.PacketBuffer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public abstract class WidgetTextDataScroll extends WidgetTextData implements IAdditionalWidgets
/*    */ {
/*    */   WidgetScrollBar scrollBar;
/* 14 */   List<String> strings = new ArrayList();
/*    */   int numLines;
/*    */   
/*    */   public WidgetTextDataScroll(int x, int y, int w, int h) {
/* 18 */     super(x, y, w - 14, h);
/* 19 */     this.scrollBar = new WidgetScrollBar(x + w - 14, y, h, 0, 1)
/*    */     {
/*    */ 
/*    */       protected void onChange() {}
/*    */ 
/* 24 */     };
/* 25 */     this.numLines = (h / 9);
/*    */   }
/*    */   
/*    */   public List<IWidget> getAdditionalWidgets()
/*    */   {
/* 30 */     return com.google.common.collect.Lists.newArrayList(new IWidget[] { this.scrollBar });
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void handleDescriptionPacket(PacketBuffer packet)
/*    */   {
/* 37 */     super.handleDescriptionPacket(packet);
/* 38 */     if (this.msg != null) {
/* 39 */       this.strings = this.gui.getFontRenderer().listFormattedStringToWidth(this.msg, this.w);
/*    */     } else
/* 41 */       this.strings = new ArrayList();
/* 42 */     this.scrollBar.setValues(0, Math.max(0, this.strings.size() - this.numLines));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop) {}
/*    */   
/*    */ 
/*    */   public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 52 */     if ((this.msg == null) || (this.strings.isEmpty())) return;
/* 53 */     net.minecraft.client.renderer.GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/*    */     
/* 55 */     int scrollValue = this.scrollBar.scrollValue;
/* 56 */     List<String> strings = this.strings;
/* 57 */     for (int i = scrollValue; i < Math.min(strings.size(), scrollValue + this.numLines); i++) {
/* 58 */       gui.getFontRenderer().drawString((String)strings.get(i), guiLeft + getX(), guiTop + getY() + (i - scrollValue) * 9, 4210752);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetTextDataScroll.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */