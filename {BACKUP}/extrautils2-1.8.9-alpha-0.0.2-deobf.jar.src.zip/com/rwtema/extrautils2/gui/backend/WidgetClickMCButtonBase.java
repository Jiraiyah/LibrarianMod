/*     */ package com.rwtema.extrautils2.gui.backend;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public abstract class WidgetClickMCButtonBase extends WidgetClickBase
/*     */ {
/*  13 */   public static final ResourceLocation vanillaButtonTexture = new ResourceLocation("textures/gui/widgets.png");
/*     */   protected int packedFGColour;
/*  15 */   protected boolean visible = true;
/*  16 */   protected boolean enabled = true;
/*     */   protected String text;
/*     */   
/*     */   public WidgetClickMCButtonBase(String text, int x, int y, int w, int h) {
/*  20 */     super(x, y, w, h);
/*  21 */     this.text = text;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */   {
/*  27 */     if (!this.visible) { return;
/*     */     }
/*  29 */     manager.bindTexture(vanillaButtonTexture);
/*  30 */     GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/*  32 */     int hoverState = getHoverState(this.hover);
/*  33 */     GlStateManager.enableBlend();
/*  34 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/*  35 */     GlStateManager.blendFunc(770, 771);
/*  36 */     int x = guiLeft + getX();
/*  37 */     int y = guiTop + getY();
/*     */     
/*     */ 
/*  40 */     int h = getH();
/*  41 */     int w2 = getW() / 2;
/*  42 */     int v = 46 + hoverState * 20;
/*  43 */     int u2 = 200 - w2;
/*  44 */     if (h == 20) {
/*  45 */       gui.drawTexturedModalRect(x, y, 0, v, w2, h);
/*  46 */       gui.drawTexturedModalRect(x + w2, y, u2, v, w2, h);
/*  47 */     } else if (h < 20) {
/*  48 */       int h2 = h / 2;
/*  49 */       gui.drawTexturedModalRect(x, y, 0, v, w2, h2);
/*  50 */       gui.drawTexturedModalRect(x + w2, y, u2, v, w2, h2);
/*  51 */       gui.drawTexturedModalRect(x, y + h - h2, 0, v, w2, h - h2);
/*  52 */       gui.drawTexturedModalRect(x + w2, y + h - h2, u2, v, w2, h - h2);
/*     */     }
/*     */     else {
/*  55 */       int y2 = y + h - 10;
/*  56 */       for (int k = y; k < y2; k += 10) {
/*  57 */         int dk = Math.min(k + 10, y2) - k;
/*  58 */         gui.drawTexturedModalRect(x, k, 0, v, w2, dk);
/*  59 */         gui.drawTexturedModalRect(x + w2, k, u2, v, w2, dk);
/*     */       }
/*     */       
/*  62 */       gui.drawTexturedModalRect(x, y2, 0, v, w2, 10);
/*  63 */       gui.drawTexturedModalRect(x + w2, y2, u2, v, w2, 10);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   private int getHoverState(boolean hover)
/*     */   {
/*  71 */     int i = 1;
/*     */     
/*  73 */     if (!this.enabled) {
/*  74 */       i = 0;
/*  75 */     } else if (this.mouseOver) {
/*  76 */       i = 2;
/*     */     }
/*     */     
/*  79 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */   public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */   {
/*  85 */     int col = 14737632;
/*     */     
/*  87 */     if (this.packedFGColour != 0) {
/*  88 */       col = this.packedFGColour;
/*  89 */     } else if (!this.enabled) {
/*  90 */       col = 10526880;
/*  91 */     } else if (this.hover) {
/*  92 */       col = 16777120;
/*     */     }
/*     */     
/*  95 */     renderButtonText(gui, Minecraft.getMinecraft().fontRendererObj, guiLeft + this.x, guiTop + this.y, col);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void renderButtonText(DynamicGui gui, FontRenderer fontrenderer, int xPosition, int yPosition, int color) {
/* 100 */     gui.drawCenteredString(fontrenderer, this.text, xPosition + getW() / 2, yPosition + (getH() - 8) / 2, color);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetClickMCButtonBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */