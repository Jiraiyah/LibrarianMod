package com.rwtema.extrautils2.gui.backend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public abstract interface IDynamicHandler
{
  public abstract DynamicContainer getDynamicContainer(int paramInt1, EntityPlayer paramEntityPlayer, World paramWorld, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\IDynamicHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */