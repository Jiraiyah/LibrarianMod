/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import org.apache.commons.lang3.tuple.Pair;
/*    */ 
/*    */ public class WidgetTextMultiline extends WidgetText
/*    */ {
/*    */   public WidgetTextMultiline(int x, int y, String msg)
/*    */   {
/* 14 */     super(x, y, msg);
/*    */   }
/*    */   
/*    */   public WidgetTextMultiline(int x, int y, String msg, int w) {
/* 18 */     this(x, y, w, ((Integer)ExtraUtils2.proxy.apply(DynamicContainer.STRING_HEIGHTS, Pair.of(msg, Integer.valueOf(w)))).intValue(), 1, 4210752, msg);
/*    */   }
/*    */   
/*    */   public WidgetTextMultiline(int x, int y, int align, int color, String msg) {
/* 22 */     super(x, y, align, color, msg);
/*    */   }
/*    */   
/*    */   public WidgetTextMultiline(int x, int y, int w, int h, int align, int color, String msg) {
/* 26 */     super(x, y, w, h, align, color, msg);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*    */   {
/* 32 */     if (this.msg == null) { return;
/*    */     }
/* 34 */     int x = getX() + (1 - this.align) * (getW() - gui.getFontRenderer().getStringWidth(getMsgClient())) / 2;
/* 35 */     gui.getFontRenderer().drawSplitString(this.msg, guiLeft + x, guiTop + getY(), getW(), 4210752);
/* 36 */     manager.bindTexture(gui.getWidgetTexture());
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetTextMultiline.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */