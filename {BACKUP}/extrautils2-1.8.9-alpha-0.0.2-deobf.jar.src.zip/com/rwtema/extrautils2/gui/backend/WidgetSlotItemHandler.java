/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ import net.minecraftforge.items.SlotItemHandler;
/*    */ 
/*    */ public class WidgetSlotItemHandler extends SlotItemHandler implements IWidget
/*    */ {
/*    */   protected final int index;
/*    */   private DynamicContainer container;
/*    */   
/*    */   public WidgetSlotItemHandler(IItemHandler itemHandler, int index, int xPosition, int yPosition)
/*    */   {
/* 16 */     super(itemHandler, index, xPosition + 1, yPosition + 1);
/* 17 */     this.index = index;
/*    */   }
/*    */   
/*    */   public int getX()
/*    */   {
/* 22 */     return this.xDisplayPosition - 1;
/*    */   }
/*    */   
/*    */   public int getY()
/*    */   {
/* 27 */     return this.yDisplayPosition - 1;
/*    */   }
/*    */   
/*    */   public int getW()
/*    */   {
/* 32 */     return 18;
/*    */   }
/*    */   
/*    */   public int getH()
/*    */   {
/* 37 */     return 18;
/*    */   }
/*    */   
/*    */   public void addToContainer(DynamicContainer container)
/*    */   {
/* 42 */     this.container = container;
/* 43 */     container.addSlot(this);
/*    */   }
/*    */   
/*    */   public void onSlotChange(ItemStack p_75220_1_, ItemStack p_75220_2_)
/*    */   {
/* 48 */     super.onSlotChange(p_75220_1_, p_75220_2_);
/* 49 */     this.container.onSlotChanged(this.slotNumber);
/*    */   }
/*    */   
/*    */ 
/*    */   public void onSlotChanged()
/*    */   {
/* 55 */     super.onSlotChanged();
/* 56 */     this.container.onSlotChanged(this.slotNumber);
/*    */   }
/*    */   
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void renderBackground(TextureManager manager, DynamicGui gui, int x, int y)
/*    */   {
/* 62 */     gui.drawTexturedModalRect(x + getX(), y + getY(), 0, 0, 18, 18);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void renderForeground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop) {}
/*    */   
/*    */ 
/*    */   public java.util.List<String> getToolTip()
/*    */   {
/* 72 */     return null;
/*    */   }
/*    */   
/*    */   public void addToGui(DynamicGui gui) {}
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetSlotItemHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */