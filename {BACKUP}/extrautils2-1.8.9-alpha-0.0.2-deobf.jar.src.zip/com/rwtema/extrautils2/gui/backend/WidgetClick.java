/*    */ package com.rwtema.extrautils2.gui.backend;
/*    */ 
/*    */ import com.rwtema.extrautils2.network.PacketBuffer;
/*    */ 
/*    */ public abstract class WidgetClick extends WidgetClickBase
/*    */ {
/*    */   public WidgetClick(int x, int y, int w, int h)
/*    */   {
/*  9 */     super(x, y, w, h);
/*    */   }
/*    */   
/*    */   public void receiveClientPacket(PacketBuffer buffer)
/*    */   {
/* 14 */     byte b = buffer.readByte();
/* 15 */     onClick(b);
/*    */   }
/*    */   
/*    */   public abstract void onClick(byte paramByte);
/*    */   
/*    */   @javax.annotation.Nonnull
/*    */   public PacketBuffer getPacketToSend(int mouseButton)
/*    */   {
/* 23 */     PacketBuffer pkt = new PacketBuffer();
/* 24 */     pkt.writeByte(mouseButton);
/* 25 */     return pkt;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\backend\WidgetClick.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */