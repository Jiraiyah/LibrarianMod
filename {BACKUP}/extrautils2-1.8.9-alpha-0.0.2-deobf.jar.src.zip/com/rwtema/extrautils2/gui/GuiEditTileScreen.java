/*     */ package com.rwtema.extrautils2.gui;
/*     */ 
/*     */ import com.rwtema.extrautils2.blocks.BlockScreen;
/*     */ import com.rwtema.extrautils2.tile.TileScreen;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import java.io.IOException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ public class GuiEditTileScreen extends GuiScreen
/*     */ {
/*     */   private final TileScreen screen;
/*     */   String text;
/*  19 */   int timer = 0;
/*     */   private GuiButton doneBtn;
/*     */   
/*     */   public GuiEditTileScreen(TileScreen screen) {
/*  23 */     this.screen = screen;
/*  24 */     this.text = screen.id;
/*     */   }
/*     */   
/*     */   public void updateScreen()
/*     */   {
/*  29 */     super.updateScreen();
/*  30 */     this.timer += 1;
/*     */   }
/*     */   
/*     */   public void initGui()
/*     */   {
/*  35 */     this.buttonList.clear();
/*  36 */     Keyboard.enableRepeatEvents(true);
/*  37 */     this.buttonList.add(this.doneBtn = new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120, net.minecraft.client.resources.I18n.format("gui.done", new Object[0])));
/*     */   }
/*     */   
/*     */   public void onGuiClosed() {
/*  41 */     Keyboard.enableRepeatEvents(false);
/*     */   }
/*     */   
/*     */   protected void actionPerformed(GuiButton button) throws IOException
/*     */   {
/*  46 */     if ((button.enabled) && 
/*  47 */       (button.id == 0))
/*     */     {
/*  49 */       com.rwtema.extrautils2.network.NetworkHandler.sendPacketToServer(new com.rwtema.extrautils2.tile.TileScreen.PacketEditScreen(this.screen.getPos(), this.text));
/*  50 */       this.mc.displayGuiScreen(null);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void keyTyped(char typedChar, int keyCode) throws IOException
/*     */   {
/*  56 */     if (keyCode == 1) {
/*  57 */       this.mc.displayGuiScreen(null);
/*  58 */     } else if (keyCode == 28) {
/*  59 */       actionPerformed(this.doneBtn);
/*     */     }
/*     */     
/*  62 */     if (GuiScreen.isKeyComboCtrlV(keyCode)) {
/*  63 */       String string = GuiScreen.getClipboardString();
/*  64 */       string = string.replace("http:", "");
/*  65 */       string = string.replace("https:", "");
/*  66 */       string = string.replace("www.", "");
/*  67 */       string = string.replace("i.imgur.com", "");
/*  68 */       string = string.replace("imgur.com", "");
/*  69 */       string = string.replace("gallery/", "");
/*  70 */       string = string.replace(".png", "");
/*  71 */       string = string.replace("/a/", "");
/*  72 */       string = string.replace("/", "");
/*  73 */       int i = string.lastIndexOf('.');
/*  74 */       if (i != -1) {
/*  75 */         string = string.substring(0, i);
/*     */       }
/*     */       
/*  78 */       string = string.replace(".", "");
/*  79 */       if ((string.length() > 10) || (TileScreen.illegalPatternControlCode.matcher(string).find())) {
/*  80 */         return;
/*     */       }
/*     */       
/*  83 */       this.text = string;
/*  84 */       return;
/*     */     }
/*     */     
/*     */ 
/*  88 */     String s = this.text;
/*     */     
/*  90 */     if ((keyCode == 14) && (s.length() > 0)) {
/*  91 */       s = s.substring(0, s.length() - 1);
/*     */     }
/*     */     
/*  94 */     if ((!TileScreen.illegalPatternControlCode.matcher("" + typedChar).find()) && (net.minecraft.util.ChatAllowedCharacters.isAllowedCharacter(typedChar)) && (s.length() <= 12)) {
/*  95 */       s = s + typedChar;
/*     */     }
/*     */     
/*  98 */     this.text = s;
/*     */   }
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/* 102 */     drawDefaultBackground();
/* 103 */     net.minecraft.client.renderer.GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 104 */     drawCenteredString(this.fontRendererObj, Lang.translate("Select Screen Display Image"), this.width / 2, 40, 16777215);
/* 105 */     drawCenteredString(this.fontRendererObj, "i.imgur.com/" + EnumChatFormatting.BOLD + this.text + EnumChatFormatting.RESET + ".png", this.width / 2, 80, 16777215);
/* 106 */     if (BlockScreen.maxSize > 0)
/* 107 */       drawCenteredString(this.fontRendererObj, Lang.translateArgs("Max file size is %s kb", new Object[] { Integer.valueOf(BlockScreen.maxSize >> 10) }), this.width / 2, 120, 16777215);
/* 108 */     net.minecraft.client.renderer.GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 109 */     super.drawScreen(mouseX, mouseY, partialTicks);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\GuiEditTileScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */