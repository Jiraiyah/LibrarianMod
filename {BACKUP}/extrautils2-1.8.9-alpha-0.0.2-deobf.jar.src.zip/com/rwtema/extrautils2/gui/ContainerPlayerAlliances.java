/*     */ package com.rwtema.extrautils2.gui;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicContainer;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicGui;
/*     */ import com.rwtema.extrautils2.gui.backend.GuiHandler;
/*     */ import com.rwtema.extrautils2.gui.backend.IDynamicHandler;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetClickMCButtonBase;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetRawData;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetScrollBar;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetText;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.power.Freq;
/*     */ import com.rwtema.extrautils2.power.PowerManager;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import gnu.trove.map.hash.TIntObjectHashMap;
/*     */ import gnu.trove.set.hash.TIntHashSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ContainerPlayerAlliances extends DynamicContainer
/*     */ {
/*  31 */   public static IDynamicHandler handler = new IDynamicHandler()
/*     */   {
/*     */     public DynamicContainer getDynamicContainer(int ID, EntityPlayer player, World world, int x, int y, int z) {
/*  34 */       return new ContainerPlayerAlliances(player);
/*     */     }
/*     */   };
/*     */   public static int ID;
/*     */   final WidgetScrollBar scrollBar;
/*     */   
/*     */   public static void init() {
/*  41 */     ID = GuiHandler.register("Alliances", handler);
/*     */   }
/*     */   
/*     */ 
/*  45 */   final int NUM_VERTICAL_ENTRIES = 10;
/*  46 */   final int BUTTON_HEIGHT = 20;
/*  47 */   final int BUTTON_WIDTH = 180;
/*     */   
/*  49 */   public ArrayList<PlayerEntry> entryList = new ArrayList();
/*     */   
/*     */   public ContainerPlayerAlliances(final EntityPlayer player) {
/*  52 */     EntityPlayerMP playerMP = (player instanceof EntityPlayerMP) ? (EntityPlayerMP)player : null;
/*  53 */     final int freq = playerMP != null ? Freq.getBasePlayerFreq(playerMP) : 0;
/*     */     
/*     */ 
/*  56 */     final PowerManager manager = PowerManager.instance;
/*     */     
/*  58 */     if ((playerMP != null) && (ExtraUtils2.deobf_folder)) {
/*  59 */       synchronized (PowerManager.MUTEX) {
/*  60 */         manager.frequncies.put(343, new GameProfile(UUID.randomUUID(), "Frank"));
/*  61 */         manager.frequncies.put(432132, new GameProfile(UUID.randomUUID(), "Tim"));
/*  62 */         manager.frequncies.put(432133, new GameProfile(UUID.randomUUID(), "Tom"));
/*  63 */         manager.frequncies.put(65396, new GameProfile(UUID.randomUUID(), "Katey"));
/*  64 */         manager.frequncies.put(322, new GameProfile(UUID.randomUUID(), "Sandy"));
/*  65 */         manager.frequncies.put(544, new GameProfile(UUID.randomUUID(), "Oscar"));
/*  66 */         manager.frequncies.put(5441, new GameProfile(UUID.randomUUID(), "Roger"));
/*  67 */         manager.frequncies.put(3223, new GameProfile(UUID.randomUUID(), "Olgoth the Destroyer"));
/*     */         
/*  69 */         TIntHashSet set = new TIntHashSet();
/*  70 */         set.add(freq);
/*  71 */         set.add(322);
/*  72 */         manager.alliances.put(343, set);
/*     */         
/*  74 */         set = new TIntHashSet();
/*  75 */         set.add(343);
/*  76 */         manager.alliances.put(322, set);
/*     */         
/*  78 */         manager.reassignValues();
/*     */       }
/*     */     }
/*     */     
/*  82 */     addWidget(new WidgetRawData()
/*     */     {
/*     */       public void addToDescription(PacketBuffer packet) {
/*  85 */         final ArrayList<ContainerPlayerAlliances.PlayerEntry> entryList = new ArrayList();
/*  86 */         synchronized (PowerManager.MUTEX) {
/*  87 */           manager.frequncies.forEachEntry(new gnu.trove.procedure.TIntObjectProcedure()
/*     */           {
/*     */             public boolean execute(int a, GameProfile b) {
/*  90 */               if (b.equals(ContainerPlayerAlliances.2.this.val$player.getGameProfile())) {
/*  91 */                 return true;
/*     */               }
/*  93 */               entryList.add(new ContainerPlayerAlliances.PlayerEntry(b, a, ContainerPlayerAlliances.2.this.val$manager.doesAWishToAllyWithB(a, ContainerPlayerAlliances.2.this.val$freq), ContainerPlayerAlliances.2.this.val$manager.doesAWishToAllyWithB(ContainerPlayerAlliances.2.this.val$freq, a), ContainerPlayerAlliances.2.this.val$manager.sameTeam(a, ContainerPlayerAlliances.2.this.val$freq)));
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*  98 */               return true;
/*     */             }
/*     */           });
/*     */         }
/* 102 */         packet.writeShort(entryList.size());
/* 103 */         for (ContainerPlayerAlliances.PlayerEntry entry : entryList) {
/* 104 */           packet.writeProfile(entry.profile);
/* 105 */           packet.writeInt(entry.freq);
/* 106 */           packet.writeBoolean(entry.themAlliedWithYou);
/* 107 */           packet.writeBoolean(entry.youAlliedWithThem);
/* 108 */           packet.writeBoolean(entry.sameTeam);
/*     */         }
/*     */       }
/*     */       
/*     */       public void handleDescriptionPacket(PacketBuffer packet)
/*     */       {
/* 114 */         ArrayList<ContainerPlayerAlliances.PlayerEntry> list = new ArrayList();
/* 115 */         list.clear();
/* 116 */         int n = packet.readUnsignedShort();
/* 117 */         for (int i = 0; i < n; i++) {
/* 118 */           GameProfile profile = packet.readProfile();
/* 119 */           int freq = packet.readInt();
/* 120 */           boolean them = packet.readBoolean();
/* 121 */           boolean you = packet.readBoolean();
/* 122 */           boolean sameTeam = packet.readBoolean();
/* 123 */           list.add(new ContainerPlayerAlliances.PlayerEntry(profile, freq, them, you, sameTeam));
/*     */         }
/* 125 */         java.util.Collections.sort(list);
/* 126 */         ContainerPlayerAlliances.this.entryList = list;
/* 127 */         ContainerPlayerAlliances.this.scrollBar.setValues(0, Math.max(0, n - 10 + 1));
/* 128 */         ContainerPlayerAlliances.this.scrollBar.reScroll();
/*     */       }
/*     */       
/* 131 */     });
/* 132 */     addWidget(this.scrollBar = new WidgetScrollBar(188, 17, 200, 0, 0));
/*     */     
/* 134 */     addWidget(new WidgetText(4, 4, Lang.translate("Select players to share power with."), 198));
/*     */     
/* 136 */     for (int i = 0; i < 10; i++) {
/* 137 */       final int k = i;
/* 138 */       addWidget(new WidgetClickMCButtonBase("", 4, 17 + i * 20, 180, 20)
/*     */       {
/*     */         public PacketBuffer getPacketToSend(int mouseButton) {
/* 141 */           PacketBuffer pkt = new PacketBuffer();
/* 142 */           ContainerPlayerAlliances.PlayerEntry ref = getEntry();
/* 143 */           if (ref == null) return null;
/* 144 */           pkt.writeInt(ref.freq);
/* 145 */           return pkt;
/*     */         }
/*     */         
/*     */         public void receiveClientPacket(PacketBuffer buffer)
/*     */         {
/* 150 */           int otherFreq = buffer.readInt();
/* 151 */           if (!manager.frequncies.containsKey(otherFreq)) {
/* 152 */             return;
/*     */           }
/* 154 */           synchronized (PowerManager.MUTEX) {
/* 155 */             TIntHashSet set = (TIntHashSet)manager.alliances.get(freq);
/* 156 */             if (set == null) {
/* 157 */               set = new TIntHashSet();
/* 158 */               manager.alliances.put(freq, set);
/*     */             }
/* 160 */             if (set.contains(otherFreq)) {
/* 161 */               set.remove(otherFreq);
/*     */             } else
/* 163 */               set.add(otherFreq);
/* 164 */             manager.reassignValues();
/*     */           }
/*     */         }
/*     */         
/*     */         public ContainerPlayerAlliances.PlayerEntry getEntry()
/*     */         {
/* 170 */           int j = k + ContainerPlayerAlliances.this.scrollBar.scrollValue;
/* 171 */           if (j < 0) {
/* 172 */             this.visible = false;
/* 173 */             return null;
/*     */           }
/* 175 */           ArrayList<ContainerPlayerAlliances.PlayerEntry> list = ContainerPlayerAlliances.this.entryList;
/* 176 */           if (j < list.size()) {
/* 177 */             this.visible = true;
/* 178 */             return (ContainerPlayerAlliances.PlayerEntry)list.get(j);
/*     */           }
/* 180 */           this.visible = false;
/* 181 */           return null;
/*     */         }
/*     */         
/*     */         @SideOnly(Side.CLIENT)
/*     */         public void renderButtonText(DynamicGui gui, FontRenderer fontrenderer, int xPosition, int yPosition, int color)
/*     */         {
/* 187 */           ContainerPlayerAlliances.PlayerEntry entry = getEntry();
/* 188 */           if (entry == null) return;
/* 189 */           StringBuilder builder = new StringBuilder();
/* 190 */           if (entry.youAlliedWithThem) {
/* 191 */             builder.append("[");
/* 192 */             builder.append(entry.getName());
/* 193 */             builder.append("]");
/*     */           } else {
/* 195 */             builder.append(entry.getName()); }
/* 196 */           builder.append(" ");
/* 197 */           builder.append(entry.sameTeam ? Lang.translate("[Sharing]") : "");
/* 198 */           String text = builder.toString();
/* 199 */           gui.drawCenteredString(fontrenderer, text, xPosition + getW() / 2, yPosition + (getH() - 8) / 2, color);
/*     */         }
/*     */       });
/*     */     }
/*     */     
/* 204 */     crop(4);
/* 205 */     validate();
/*     */   }
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer playerIn)
/*     */   {
/* 210 */     return true;
/*     */   }
/*     */   
/*     */   public static class PlayerEntry implements Comparable<PlayerEntry> {
/*     */     private final int freq;
/*     */     GameProfile profile;
/*     */     boolean themAlliedWithYou;
/*     */     boolean youAlliedWithThem;
/*     */     boolean sameTeam;
/*     */     
/*     */     public PlayerEntry(GameProfile profile, int freq, boolean themAlliedWithYou, boolean youAlliedWithThem, boolean sameTeam) {
/* 221 */       this.profile = profile;
/* 222 */       this.freq = freq;
/* 223 */       this.themAlliedWithYou = themAlliedWithYou;
/* 224 */       this.youAlliedWithThem = youAlliedWithThem;
/* 225 */       this.sameTeam = sameTeam;
/*     */     }
/*     */     
/*     */     public int compareTo(@Nonnull PlayerEntry o)
/*     */     {
/* 230 */       String nameA = getName();
/* 231 */       String nameB = o.getName();
/* 232 */       return nameA.compareTo(nameB);
/*     */     }
/*     */     
/*     */     @Nonnull
/*     */     public String getName() {
/* 237 */       String name = this.profile.getName();
/* 238 */       return name != null ? name : "";
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\ContainerPlayerAlliances.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */