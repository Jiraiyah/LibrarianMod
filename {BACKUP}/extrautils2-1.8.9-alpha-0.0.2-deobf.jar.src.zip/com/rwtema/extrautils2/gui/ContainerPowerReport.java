/*     */ package com.rwtema.extrautils2.gui;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.entries.ItemClassEntry;
/*     */ import com.rwtema.extrautils2.gui.backend.DynamicGui;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetBase;
/*     */ import com.rwtema.extrautils2.gui.backend.WidgetTextDataScroll;
/*     */ import com.rwtema.extrautils2.items.ItemIngredients.Type;
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.power.IPower;
/*     */ import com.rwtema.extrautils2.power.PowerManager;
/*     */ import com.rwtema.extrautils2.power.PowerManager.PowerFreq;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.StringHelper;
/*     */ import gnu.trove.map.hash.TObjectFloatHashMap;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class ContainerPowerReport extends com.rwtema.extrautils2.gui.backend.DynamicContainer
/*     */ {
/*     */   public ContainerPowerReport(final EntityPlayer player)
/*     */   {
/*  31 */     addWidget(new WidgetTextDataScroll(4, 24, 176, 176) {
/*  32 */       EntityPlayerMP playerMP = (player instanceof EntityPlayerMP) ? (EntityPlayerMP)player : null;
/*     */       
/*     */       public void addToDescription(PacketBuffer packet) { TObjectIntHashMap<String> numPowers;
/*     */         TObjectFloatHashMap<String> powerOutput;
/*  36 */         synchronized (PowerManager.MUTEX)
/*     */         {
/*  38 */           numPowers = new TObjectIntHashMap();
/*  39 */           powerOutput = new TObjectFloatHashMap();
/*  40 */           PowerManager.PowerFreq powerFreq = PowerManager.instance.getPowerFreq(com.rwtema.extrautils2.power.Freq.getBasePlayerFreq(this.playerMP));
/*  41 */           for (IPower handler : powerFreq.powerHandlers) {
/*  42 */             String name = handler.getName();
/*  43 */             if (name != null) {
/*  44 */               float f = PowerManager.getCurrentPower(handler);
/*  45 */               numPowers.adjustOrPutValue(name, 1, 1);
/*  46 */               powerOutput.adjustOrPutValue(name, f, f);
/*     */             }
/*     */           }
/*  49 */           Set<String> names = numPowers.keySet();
/*  50 */           packet.writeInt(names.size());
/*  51 */           for (String name : names) {
/*  52 */             packet.writeString(name);
/*  53 */             packet.writeInt(numPowers.get(name));
/*  54 */             packet.writeFloat(powerOutput.get(name));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */       @SideOnly(Side.CLIENT)
/*     */       protected String constructText(PacketBuffer packet)
/*     */       {
/*  62 */         int n = packet.readInt();
/*  63 */         if (n == 0) {
/*  64 */           return Lang.translate("No Power Handlers");
/*     */         }
/*  66 */         ArrayList<String> generators = new ArrayList();
/*  67 */         ArrayList<String> drainers = new ArrayList();
/*  68 */         ArrayList<String> inactive = new ArrayList();
/*  69 */         for (int i = 0; i < n; i++) {
/*  70 */           String formattedText = net.minecraft.util.StatCollector.translateToLocal(packet.readString());
/*  71 */           int num = packet.readInt();
/*  72 */           float power = packet.readFloat();
/*  73 */           if (power < 0.0F) {
/*  74 */             generators.add(Lang.translateArgs("%s x %s: %s GP", new Object[] { formattedText, Integer.valueOf(num), StringHelper.niceFormat(-power) }));
/*  75 */           } else if (power > 0.0F) {
/*  76 */             drainers.add(Lang.translateArgs("%s x %s: %s GP", new Object[] { formattedText, Integer.valueOf(num), StringHelper.niceFormat(power) }));
/*     */           } else {
/*  78 */             inactive.add(Lang.translateArgs("%s x %s", new Object[] { formattedText, Integer.valueOf(num) }));
/*     */           }
/*     */         }
/*     */         
/*  82 */         Collections.sort(generators);
/*  83 */         Collections.sort(drainers);
/*     */         
/*  85 */         StringBuilder builder = new StringBuilder();
/*  86 */         addEntries(builder, generators, "Power Generators");
/*  87 */         addEntries(builder, drainers, "Power Users");
/*  88 */         addEntries(builder, inactive, "Inactive");
/*     */         
/*     */ 
/*  91 */         return builder.toString();
/*     */       }
/*     */       
/*     */       @SideOnly(Side.CLIENT)
/*     */       private void addEntries(StringBuilder builder, ArrayList<String> generators, String text) {
/*  96 */         if (!generators.isEmpty()) {
/*  97 */           builder.append(Lang.translate(text)).append('\n');
/*  98 */           for (String s : generators) {
/*  99 */             builder.append(' ').append(s).append('\n');
/*     */           }
/*     */         }
/*     */       }
/* 103 */     });
/* 104 */     crop(4);
/*     */     
/* 106 */     if (com.rwtema.extrautils2.backend.entries.XU2Entries.itemIngredients.enabled) {
/* 107 */       addWidget(new WidgetBase(this.width / 2, 0, 0, 0) {
/* 108 */         int size = 40;
/*     */         
/*     */         public void renderBackground(TextureManager manager, DynamicGui gui, int guiLeft, int guiTop)
/*     */         {
/* 112 */           manager.bindTexture(net.minecraft.client.renderer.texture.TextureMap.locationBlocksTexture);
/* 113 */           TextureAtlasSprite sprite = (TextureAtlasSprite)com.rwtema.extrautils2.backend.model.Textures.sprites.get(ItemIngredients.Type.REDSTONE_CRYSTAL.texture);
/* 114 */           if (sprite != null)
/* 115 */             gui.drawTexturedModalRect(guiLeft + getX() - this.size, guiTop + getY() - this.size, sprite, this.size * 2, this.size * 2);
/* 116 */           manager.bindTexture(gui.getWidgetTexture());
/*     */         }
/*     */       });
/*     */     }
/*     */     
/* 121 */     validate();
/*     */   }
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer playerIn)
/*     */   {
/* 126 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\gui\ContainerPowerReport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */