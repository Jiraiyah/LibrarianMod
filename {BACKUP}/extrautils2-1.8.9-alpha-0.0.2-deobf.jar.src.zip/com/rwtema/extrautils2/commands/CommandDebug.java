/*    */ package com.rwtema.extrautils2.commands;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.rwtema.extrautils2.achievements.AchievementHelper;
/*    */ import com.rwtema.extrautils2.chunkloading.XUChunkLoaderManager;
/*    */ import com.rwtema.extrautils2.power.PowerManager;
/*    */ import com.rwtema.extrautils2.utils.helpers.PlayerHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.CommandBase;
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.ChatComponentText;
/*    */ 
/*    */ public class CommandDebug extends CommandBase
/*    */ {
/*    */   public String getCommandName()
/*    */   {
/* 19 */     return "xudebug";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 24 */     return "xudebug";
/*    */   }
/*    */   
/*    */   public boolean func_71519_b(ICommandSender sender)
/*    */   {
/* 29 */     return (((sender instanceof EntityPlayer)) && (PlayerHelper.isThisPlayerACheatyBastardOfCheatBastardness((EntityPlayer)sender))) || (super.func_71519_b(sender));
/*    */   }
/*    */   
/*    */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException
/*    */   {
/* 34 */     if (args.length == 0) { throw new CommandException("Unknown Command", new Object[0]);
/*    */     }
/* 36 */     String t = args[0];
/* 37 */     List<String> info = Lists.newArrayList();
/* 38 */     if ("power".equals(t)) {
/* 39 */       PowerManager.instance.getDebug(info);
/*    */     }
/* 41 */     else if ("chunks".equals(t)) {
/* 42 */       XUChunkLoaderManager.instance.getDebug(info);
/* 43 */     } else if (!"packethandler".equals(t))
/*    */     {
/* 45 */       if ("onetime".equals(t)) {
/* 46 */         info.addAll(com.rwtema.extrautils2.utils.LogHelper.getOneTimeStrings());
/* 47 */       } else if ("ach".equals(t)) {
/* 48 */         AchievementHelper.bake();
/*    */       } else {
/* 50 */         throw new CommandException("Unknown Command", new Object[0]);
/*    */       }
/*    */     }
/* 53 */     for (String s : info) {
/* 54 */       sender.addChatMessage(new ChatComponentText(s));
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\commands\CommandDebug.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */