/*    */ package com.rwtema.extrautils2.commands;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.LogHelper;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ import java.nio.IntBuffer;
/*    */ import javax.imageio.ImageIO;
/*    */ import javax.imageio.ImageTypeSpecifier;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.texture.ITextureObject;
/*    */ import net.minecraft.client.renderer.texture.TextureMap;
/*    */ import net.minecraft.command.CommandBase;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class CommandDumpTextureSheet extends CommandBase
/*    */ {
/*    */   public String getCommandName()
/*    */   {
/* 24 */     return "dumpTextureAtlas";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender p_71518_1_)
/*    */   {
/* 29 */     return "dumpTextureAtlas";
/*    */   }
/*    */   
/*    */   public boolean func_71519_b(ICommandSender p_71519_1_)
/*    */   {
/* 34 */     return true;
/*    */   }
/*    */   
/*    */   public void func_71515_b(ICommandSender p_71515_1_, String[] p_71515_2_)
/*    */   {
/* 39 */     outputTexture(TextureMap.locationBlocksTexture, "textures");
/*    */   }
/*    */   
/*    */   public void outputTexture(ResourceLocation locationTexture, String s) {
/* 43 */     int terrainTextureId = Minecraft.getMinecraft().renderEngine.getTexture(locationTexture).getGlTextureId();
/*    */     
/* 45 */     if (terrainTextureId == 0) { return;
/*    */     }
/* 47 */     int w = GL11.glGetTexLevelParameteri(3553, 0, 4096);
/* 48 */     int h = GL11.glGetTexLevelParameteri(3553, 0, 4097);
/* 49 */     int[] pixels = new int[w * h];
/*    */     
/* 51 */     IntBuffer pixelBuf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
/* 52 */     GL11.glGetTexImage(3553, 0, 32993, 5121, pixelBuf);
/* 53 */     pixelBuf.limit(w * h);
/* 54 */     pixelBuf.get(pixels);
/*    */     
/* 56 */     BufferedImage image = ImageTypeSpecifier.createFromBufferedImageType(2).createBufferedImage(w, h);
/* 57 */     image.setRGB(0, 0, w, h, pixels, 0, w);
/*    */     
/* 59 */     File f = new File(new File(Minecraft.getMinecraft().mcDataDir, "xutexture"), s + ".png");
/*    */     try
/*    */     {
/* 62 */       if ((!f.getParentFile().exists()) && (!f.getParentFile().mkdirs())) {
/* 63 */         return;
/*    */       }
/* 65 */       if ((!f.exists()) && (!f.createNewFile())) {
/* 66 */         return;
/*    */       }
/* 68 */       ImageIO.write(image, "png", f);
/*    */     } catch (IOException e) {
/* 70 */       LogHelper.info("Unable to output " + s, new Object[0]);
/* 71 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\commands\CommandDumpTextureSheet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */