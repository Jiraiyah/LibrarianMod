/*    */ package com.rwtema.extrautils2.commands;
/*    */ 
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ 
/*    */ public class CommandFrequency extends net.minecraft.command.CommandBase
/*    */ {
/*    */   public int getRequiredPermissionLevel()
/*    */   {
/* 10 */     return 2;
/*    */   }
/*    */   
/*    */   public String getCommandName()
/*    */   {
/* 15 */     return "xu_frequency";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 20 */     return "/xu_frequency <get|set|merge|reset> ...";
/*    */   }
/*    */   
/*    */   public void func_71515_b(ICommandSender sender, String[] args)
/*    */     throws CommandException
/*    */   {}
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\commands\CommandFrequency.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */