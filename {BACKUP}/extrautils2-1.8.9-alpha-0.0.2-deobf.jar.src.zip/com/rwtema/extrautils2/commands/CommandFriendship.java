/*    */ package com.rwtema.extrautils2.commands;
/*    */ 
/*    */ import com.rwtema.extrautils2.gui.ContainerPlayerAlliances;
/*    */ import com.rwtema.extrautils2.gui.backend.GuiHandler.PacketOpenGui;
/*    */ import net.minecraft.command.CommandBase;
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ 
/*    */ public class CommandFriendship extends CommandBase
/*    */ {
/*    */   public int getRequiredPermissionLevel()
/*    */   {
/* 13 */     return 0;
/*    */   }
/*    */   
/*    */   public String getCommandName()
/*    */   {
/* 18 */     return "xu_powersharing";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 23 */     return "/xu_powersharing";
/*    */   }
/*    */   
/*    */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException
/*    */   {
/* 28 */     com.rwtema.extrautils2.network.NetworkHandler.sendPacketToServer(new GuiHandler.PacketOpenGui(ContainerPlayerAlliances.ID));
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\commands\CommandFriendship.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */