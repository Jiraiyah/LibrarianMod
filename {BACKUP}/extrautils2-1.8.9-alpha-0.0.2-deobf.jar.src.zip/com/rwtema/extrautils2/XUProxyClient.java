/*     */ package com.rwtema.extrautils2;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.ClientCallable;
/*     */ import com.rwtema.extrautils2.backend.ISidedFunction;
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.model.IClientClearCache;
/*     */ import com.rwtema.extrautils2.hud.HUDHandler;
/*     */ import com.rwtema.extrautils2.keyhandler.KeyHandler;
/*     */ import com.rwtema.extrautils2.network.PacketHandler;
/*     */ import com.rwtema.extrautils2.network.PacketHandlerClient;
/*     */ import com.rwtema.extrautils2.power.ClientPower;
/*     */ import com.rwtema.extrautils2.render.LayersHandler;
/*     */ import com.rwtema.extrautils2.render.TileScreenRenderer;
/*     */ import com.rwtema.extrautils2.tile.TileScreen;
/*     */ import com.rwtema.extrautils2.tile.XUTile;
/*     */ import com.rwtema.extrautils2.tile.tesr.XUTESRHook;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.PlayerControllerMP;
/*     */ import net.minecraft.client.network.NetHandlerPlayClient;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.INetHandler;
/*     */ import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.ClientCommandHandler;
/*     */ import net.minecraftforge.fml.client.registry.ClientRegistry;
/*     */ 
/*     */ public class XUProxyClient extends XUProxy
/*     */ {
/*     */   public void run(ClientCallable callable)
/*     */   {
/*  35 */     callable.runClient();
/*     */   }
/*     */   
/*     */   public void clearClientCache(IClientClearCache box)
/*     */   {
/*  40 */     box.clientClear();
/*     */   }
/*     */   
/*     */   public boolean isClientSide()
/*     */   {
/*  45 */     return true;
/*     */   }
/*     */   
/*     */   public void registerTexture(String... texture)
/*     */   {
/*  50 */     com.rwtema.extrautils2.backend.model.Textures.register(texture);
/*     */   }
/*     */   
/*     */   public EntityPlayer getPlayerFromNetHandler(INetHandler handler)
/*     */   {
/*  55 */     EntityPlayer player = super.getPlayerFromNetHandler(handler);
/*  56 */     if (player == null) return getClientPlayer();
/*  57 */     return player;
/*     */   }
/*     */   
/*     */ 
/*     */   public EntityPlayer getClientPlayer()
/*     */   {
/*  63 */     return Minecraft.getMinecraft().thePlayer;
/*     */   }
/*     */   
/*     */   public World getClientWorld()
/*     */   {
/*  68 */     return Minecraft.getMinecraft().theWorld;
/*     */   }
/*     */   
/*     */   public PacketHandler getNewPacketHandler()
/*     */   {
/*  73 */     com.rwtema.extrautils2.utils.LogHelper.oneTimeInfo("CreatePacketHandler Client");
/*  74 */     return new PacketHandlerClient();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAltSneaking(EntityPlayer player)
/*     */   {
/*  80 */     Minecraft minecraft = Minecraft.getMinecraft();
/*  81 */     if (player == minecraft.thePlayer) {
/*  82 */       return KeyHandler.getIsKeyPressed(minecraft.gameSettings.keyBindSprint);
/*     */     }
/*  84 */     return super.isAltSneaking(player);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void registerBlock(XUBlock xuBlock) {}
/*     */   
/*     */ 
/*     */   public void sendUsePacket(ItemStack stack, EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ)
/*     */   {
/*  94 */     Minecraft.getMinecraft().getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(pos, side.ordinal(), stack, hitX, hitY, hitZ));
/*     */   }
/*     */   
/*     */   public void registerHandlers()
/*     */   {
/*  99 */     super.registerHandlers();
/* 100 */     HUDHandler.init();
/* 101 */     ClientPower.init();
/* 102 */     LayersHandler.init();
/* 103 */     ClientRegistry.bindTileEntitySpecialRenderer(TileScreen.class, TileScreenRenderer.instance);
/*     */   }
/*     */   
/*     */   public <F, T> T apply(ISidedFunction<F, T> func, F input)
/*     */   {
/* 108 */     return (T)func.applyClient(input);
/*     */   }
/*     */   
/*     */   public void registerClientCommand()
/*     */   {
/* 113 */     ClientCommandHandler.instance.registerCommand(new com.rwtema.extrautils2.commands.CommandDumpTextureSheet());
/*     */   }
/*     */   
/*     */   public boolean onBlockStartBreak(World world, ItemStack itemstack, BlockPos pos, EntityPlayer player, boolean reduceParticles)
/*     */   {
/* 118 */     if (!world.isRemote) return super.onBlockStartBreak(world, itemstack, pos, player, reduceParticles);
/* 119 */     Minecraft mc = Minecraft.getMinecraft();
/* 120 */     if (reduceParticles) {
/* 121 */       int particleSetting = mc.gameSettings.particleSetting;
/* 122 */       mc.gameSettings.particleSetting = 2;
/* 123 */       boolean flag = mc.playerController.func_178888_a(pos, EnumFacing.DOWN);
/* 124 */       mc.gameSettings.particleSetting = particleSetting;
/* 125 */       return flag;
/*     */     }
/* 127 */     return mc.playerController.func_178888_a(pos, EnumFacing.DOWN);
/*     */   }
/*     */   
/*     */   public <T> T nullifyOnServer(T object)
/*     */   {
/* 132 */     return object;
/*     */   }
/*     */   
/*     */   public void registerTESR(Class<? extends XUTile> clazz)
/*     */   {
/* 137 */     ClientRegistry.bindTileEntitySpecialRenderer(clazz, new XUTESRHook());
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\XUProxyClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */