/*     */ package com.rwtema.extrautils2.power;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.XUBlock;
/*     */ import com.rwtema.extrautils2.backend.entries.BlockEntry;
/*     */ import com.rwtema.extrautils2.backend.entries.Entry;
/*     */ import com.rwtema.extrautils2.hud.HUDHandler;
/*     */ import com.rwtema.extrautils2.hud.HUDHandler.IHudHandler;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.helpers.StringHelper;
/*     */ import java.util.HashSet;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraftforge.client.GuiIngameForge;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*     */ public class ClientPower implements HUDHandler.IHudHandler
/*     */ {
/*  30 */   private static final HashSet<Item> powerItems = new HashSet();
/*     */   
/*     */   static float powerCreated;
/*     */   static float powerDrained;
/*     */   static net.minecraft.util.BlockPos currentPosition;
/*     */   static float currentPositionEnergy;
/*     */   
/*     */   static
/*     */   {
/*  39 */     for (Entry entry : com.rwtema.extrautils2.backend.entries.EntryHandler.entries) {
/*  40 */       if ((entry instanceof BlockEntry)) {
/*  41 */         for (Class clazz : ((BlockEntry)entry).teClazzes) {
/*  42 */           if (IPower.class.isAssignableFrom(clazz)) {
/*  43 */             powerItems.add(((XUBlock)entry.value).itemBlock);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  51 */     ClientPower handler = new ClientPower();
/*  52 */     MinecraftForge.EVENT_BUS.register(handler);
/*  53 */     HUDHandler.register(handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String powerStatusString()
/*     */   {
/*  61 */     return Lang.translatePrefix("Grid Power: ") + StringHelper.niceFormat(powerDrained) + " / " + StringHelper.niceFormat(powerCreated);
/*     */   }
/*     */   
/*     */   public static boolean isPowered() {
/*  65 */     return powerDrained <= powerCreated;
/*     */   }
/*     */   
/*     */   public static boolean hasNoPower() {
/*  69 */     return (powerDrained == 0.0F) && (powerCreated == 0.0F);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void clientTick(TickEvent.ClientTickEvent event) {
/*  74 */     if (event.phase == TickEvent.Phase.END) return;
/*  75 */     MovingObjectPosition mop = Minecraft.getMinecraft().objectMouseOver;
/*     */     
/*  77 */     if ((mop == null) || (mop.typeOfHit != net.minecraft.util.MovingObjectPosition.MovingObjectType.BLOCK)) {
/*  78 */       currentPosition = null;
/*  79 */       currentPositionEnergy = NaN.0F;
/*     */     } else {
/*  81 */       if ((currentPosition != null) && (!java.util.Objects.equals(currentPosition, mop.getBlockPos()))) {
/*  82 */         currentPositionEnergy = NaN.0F;
/*     */       }
/*     */       
/*  85 */       currentPosition = mop.getBlockPos();
/*  86 */       WorldClient theWorld = Minecraft.getMinecraft().theWorld;
/*  87 */       if (theWorld != null) {
/*  88 */         TileEntity tileEntity = theWorld.getTileEntity(mop.getBlockPos());
/*  89 */         if ((tileEntity instanceof IPower)) {
/*  90 */           com.rwtema.extrautils2.network.NetworkHandler.sendPacketToServer(new PacketPowerInfo(currentPositionEnergy, currentPosition));
/*     */         } else {
/*  92 */           currentPositionEnergy = NaN.0F;
/*  93 */           currentPosition = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void render(GuiIngameForge hud, ScaledResolution resolution, float partialTicks)
/*     */   {
/* 101 */     boolean flag = currentPosition != null;
/* 102 */     EntityPlayerSP thePlayer = Minecraft.getMinecraft().thePlayer;
/*     */     
/* 104 */     if ((!flag) && (thePlayer != null) && (thePlayer.func_70694_bm() != null) && (powerItems.contains(thePlayer.func_70694_bm().getItem()))) {
/* 105 */       flag = true;
/*     */     }
/*     */     
/* 108 */     if (!flag) { return;
/*     */     }
/* 110 */     int y = resolution.getScaledHeight() * 7 / 10;
/* 111 */     hud.drawCenteredString(hud.getFontRenderer(), powerStatusString(), resolution.getScaledWidth() / 2, y, -1);
/* 112 */     if (!Float.isNaN(currentPositionEnergy)) {
/* 113 */       y += hud.getFontRenderer().FONT_HEIGHT + 1;
/*     */       String text;
/* 115 */       String text; if (currentPositionEnergy == 0.0F) {
/* 116 */         text = Lang.translatePrefix("No Power Used/Generated"); } else { String text;
/* 117 */         if (currentPositionEnergy < 0.0F) {
/* 118 */           text = Lang.translatePrefix("Power Generating: ") + StringHelper.niceFormat(-currentPositionEnergy);
/*     */         } else
/* 120 */           text = Lang.translatePrefix("Power Drain: ") + StringHelper.niceFormat(currentPositionEnergy);
/*     */       }
/* 122 */       hud.drawCenteredString(hud.getFontRenderer(), text, resolution.getScaledWidth() / 2, y, -1);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void init() {}
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\ClientPower.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */