package com.rwtema.extrautils2.power;

import javax.annotation.Nullable;
import net.minecraft.world.World;

public abstract interface IPower
{
  public abstract float getPower();
  
  public abstract IWorldPowerMultiplier getMultiplier();
  
  public abstract int frequency();
  
  public abstract void powerChanged(boolean paramBoolean);
  
  @Nullable
  public abstract World world();
  
  public abstract String getName();
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\IPower.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */