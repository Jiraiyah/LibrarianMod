/*    */ package com.rwtema.extrautils2.power;
/*    */ 
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class PowerMultipliers
/*    */ {
/*  7 */   public static final IWorldPowerMultiplier SOLAR = new IWorldPowerMultiplier()
/*    */   {
/*    */     public float multiplier(World world) {
/* 10 */       if (world.provider.getHasNoSky()) return 0.0F;
/* 11 */       return world.isRaining() ? 0.95F : !PowerMultipliers.isDaytime(world) ? 0.0F : 1.0F;
/*    */     }
/*    */   };
/* 14 */   public static final IWorldPowerMultiplier LUNAR = new IWorldPowerMultiplier()
/*    */   {
/*    */     public float multiplier(World world) {
/* 17 */       if (world.provider.getHasNoSky()) return 0.0F;
/* 18 */       return !PowerMultipliers.isDaytime(world) ? 1.0F + world.getCurrentMoonPhaseFactor() * 0.25F : 0.0F;
/*    */     }
/*    */   };
/*    */   
/*    */ 
/* 23 */   public static final IWorldPowerMultiplier WIND = new IWorldPowerMultiplier()
/*    */   {
/*    */     private static final int TIME_POWER = 8;
/*    */     private static final int MASK = 255;
/*    */     private static final float TIME_DIVISOR = 256.0F;
/*    */     private static final int RESULT_POW = 8;
/*    */     private static final int RESULT_MASK = 255;
/*    */     private static final float RESULT_DIVISOR = 256.0F;
/*    */     
/*    */     public float multiplier(World world)
/*    */     {
/* 34 */       if (world.provider.getHasNoSky()) return 0.0F;
/* 35 */       long t = world.getTotalWorldTime();
/* 36 */       float v = ((int)t & 0xFF) / 256.0F;
/* 37 */       long k = t >> 8;
/* 38 */       k += world.provider.func_177502_q() * 31L;
/*    */       
/* 40 */       long a = k * k * 42317861L + k * 11L;
/* 41 */       long b = a + (2L * k + 1L) * 42317861L + 11L;
/*    */       
/* 43 */       float ai = (int)(a & 0xFF) / 256.0F;
/* 44 */       float bi = (int)(b & 0xFF) / 256.0F;
/*    */       
/* 46 */       float v1 = ai + (bi - ai) * v;
/*    */       
/* 48 */       return 0.5F + v1 * 2.0F + (world.isRaining() ? 1 : 0) + (world.isThundering() ? 2 : 0);
/*    */     }
/*    */   };
/*    */   
/*    */   public static boolean isDaytime(World world) {
/* 53 */     return net.minecraft.util.MathHelper.cos(world.getCelestialAngle(1.0F) * 6.2831855F) >= 0.0F;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\PowerMultipliers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */