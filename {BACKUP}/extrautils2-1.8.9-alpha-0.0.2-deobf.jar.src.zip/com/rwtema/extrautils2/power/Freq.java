/*    */ package com.rwtema.extrautils2.power;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*    */ import gnu.trove.map.hash.TIntObjectHashMap;
/*    */ import java.util.Objects;
/*    */ import java.util.Random;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraftforge.event.entity.player.PlayerEvent.LoadFromFile;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Freq
/*    */ {
/* 19 */   private static Random rand = new Random();
/*    */   
/*    */ 
/* 22 */   public static Freq INSTANCE = new Freq();
/*    */   private static final String XU_FREQ_TAG = "Frequency";
/*    */   private static final String XU_TAG = "XU2";
/*    */   
/*    */   public static int getBasePlayerFreq(EntityPlayerMP player) {
/* 27 */     NBTTagCompound entityData = NBTHelper.getPersistentTag(player);
/* 28 */     NBTTagCompound xu2Tag = NBTHelper.getOrInitTagCompound(entityData, "XU2");
/* 29 */     int i = xu2Tag.getInteger("Frequency");
/* 30 */     PowerSettings.instance.markDirty();
/*    */     
/* 32 */     GameProfile gameProfile = player.getGameProfile();
/* 33 */     if (i != 0) {
/* 34 */       PowerManager.instance.frequncies.putIfAbsent(i, gameProfile);
/* 35 */       return i;
/*    */     }
/* 37 */     synchronized (PowerManager.MUTEX) {
/* 38 */       UUID uuid = EntityPlayer.getUUID(gameProfile);
/*    */       
/* 40 */       rand.setSeed(uuid.getLeastSignificantBits() ^ uuid.getMostSignificantBits() ^ Objects.hashCode(gameProfile.getName()));
/*    */       do
/*    */       {
/* 43 */         i = rand.nextInt();
/* 44 */       } while ((i == 0) || (PowerManager.instance.frequncies.containsKey(i)));
/* 45 */       xu2Tag.setInteger("Frequency", i);
/* 46 */       PowerManager.instance.frequncies.put(i, gameProfile);
/* 47 */       PowerManager.instance.reassignValues();
/*    */     }
/* 49 */     return i;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void load(PlayerEvent.LoadFromFile event) {
/* 54 */     getBasePlayerFreq((EntityPlayerMP)event.entityPlayer);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\Freq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */