/*    */ package com.rwtema.extrautils2.power.player;
/*    */ 
/*    */ import com.rwtema.extrautils2.power.IWorldPowerMultiplier;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.server.management.ServerConfigurationManager;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public abstract class PlayerPower implements com.rwtema.extrautils2.power.IPower, IWorldPowerMultiplier
/*    */ {
/*    */   public final int freq;
/*    */   @Nonnull
/*    */   private final EntityPlayer player;
/* 17 */   public int cooldown = 20;
/*    */   public final int dimension;
/*    */   public boolean invalid;
/*    */   
/*    */   public PlayerPower(@Nonnull EntityPlayer player) {
/* 22 */     this.player = player;
/* 23 */     if ((player instanceof EntityPlayerMP)) {
/* 24 */       this.freq = com.rwtema.extrautils2.power.Freq.getBasePlayerFreq((EntityPlayerMP)player);
/*    */     } else
/* 26 */       this.freq = 0;
/* 27 */     this.dimension = player.worldObj.provider.func_177502_q();
/*    */   }
/*    */   
/*    */   public IWorldPowerMultiplier getMultiplier()
/*    */   {
/* 32 */     return this;
/*    */   }
/*    */   
/*    */   public int frequency()
/*    */   {
/* 37 */     return this.freq;
/*    */   }
/*    */   
/*    */   public World world()
/*    */   {
/* 42 */     return null;
/*    */   }
/*    */   
/*    */   public float multiplier(World world)
/*    */   {
/* 47 */     EntityPlayerMP playerMP = getPlayerMP();
/* 48 */     if ((this.invalid) || (!MinecraftServer.func_71276_C().func_71203_ab().playerEntityList.contains(playerMP))) {
/* 49 */       return 0.0F;
/*    */     }
/*    */     
/* 52 */     return power(playerMP);
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public EntityPlayer getPlayer() {
/* 57 */     return this.player;
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public EntityPlayerMP getPlayerMP() {
/* 62 */     return (EntityPlayerMP)this.player;
/*    */   }
/*    */   
/*    */   public abstract float power(EntityPlayer paramEntityPlayer);
/*    */   
/*    */   public final float getPower()
/*    */   {
/* 69 */     return 1.0F;
/*    */   }
/*    */   
/*    */   public void onAdd() {}
/*    */   
/*    */   public void onRemove() {}
/*    */   
/*    */   public void update(boolean selected, ItemStack params) {}
/*    */   
/*    */   public void tick() {}
/*    */   
/*    */   public void onAddClient() {}
/*    */   
/*    */   public void onRemoveClient() {}
/*    */   
/*    */   public void tickClient() {}
/*    */   
/*    */   public void updateClient(boolean selected, ItemStack params) {}
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\player\PlayerPower.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */