/*    */ package com.rwtema.extrautils2.power.player;
/*    */ 
/*    */ import com.rwtema.extrautils2.power.PowerManager;
/*    */ import com.rwtema.extrautils2.utils.datastructures.ID;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map.Entry;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent.ServerTickEvent;
/*    */ import org.apache.commons.lang3.tuple.Pair;
/*    */ 
/*    */ public class PlayerPowerManager
/*    */ {
/* 19 */   static HashMap<Pair<ID<EntityPlayer>, IPlayerPowerCreator>, PlayerPower> powerServer = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void clear()
/*    */   {
/* 26 */     powerServer.clear();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void tick(TickEvent.ServerTickEvent event) {
/* 31 */     if (event.phase == net.minecraftforge.fml.common.gameevent.TickEvent.Phase.END) { return;
/*    */     }
/* 33 */     HashSet<EntityPlayer> players = new HashSet(MinecraftServer.func_71276_C().func_71203_ab().playerEntityList);
/* 34 */     HashSet<PlayerPower> loadedPowers = new HashSet();
/* 35 */     HashSet<PlayerPower> addedPowers = new HashSet();
/*    */     
/* 37 */     for (EntityPlayer player : players) {
/* 38 */       ItemStack[] mainInventory = player.inventory.mainInventory;
/* 39 */       for (int i = 0; i < mainInventory.length; i++) {
/* 40 */         ItemStack stack = mainInventory[i];
/* 41 */         if ((stack != null) && ((stack.getItem() instanceof IPlayerPowerCreator))) {
/* 42 */           IPlayerPowerCreator creator = (IPlayerPowerCreator)stack.getItem();
/*    */           
/* 44 */           Pair<ID<EntityPlayer>, IPlayerPowerCreator> key = Pair.of(new ID(player), creator);
/* 45 */           PlayerPower playerPower = (PlayerPower)powerServer.get(key);
/* 46 */           if (playerPower == null) {
/* 47 */             playerPower = creator.createPower(player, stack);
/* 48 */             powerServer.put(key, playerPower);
/* 49 */             addedPowers.add(playerPower);
/*    */           }
/*    */           
/* 52 */           playerPower.update(player.inventory.currentItem == i, stack);
/* 53 */           playerPower.cooldown = 20;
/* 54 */           loadedPowers.add(playerPower);
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 59 */     for (Iterator<Map.Entry<Pair<ID<EntityPlayer>, IPlayerPowerCreator>, PlayerPower>> iterator = powerServer.entrySet().iterator(); iterator.hasNext();) {
/* 60 */       Map.Entry<Pair<ID<EntityPlayer>, IPlayerPowerCreator>, PlayerPower> entry = (Map.Entry)iterator.next();
/* 61 */       EntityPlayer player = (EntityPlayer)((ID)((Pair)entry.getKey()).getLeft()).object;
/* 62 */       PlayerPower power = (PlayerPower)entry.getValue();
/* 63 */       boolean playerIsLoaded = !players.contains(player);
/* 64 */       boolean incorrectDimension = player.worldObj.provider.func_177502_q() != power.dimension;
/* 65 */       boolean expired = !loadedPowers.contains(power);
/* 66 */       if ((playerIsLoaded) || (incorrectDimension) || (expired)) {
/* 67 */         removePlayer(power);
/* 68 */         iterator.remove();
/* 69 */       } else if (!addedPowers.contains(power)) {
/* 70 */         power.tick();
/*    */       }
/*    */     }
/* 73 */     for (PlayerPower playerPower : addedPowers) {
/* 74 */       playerPower.onAdd();
/* 75 */       PowerManager.instance.addPowerHandler(playerPower);
/*    */     }
/*    */   }
/*    */   
/*    */   public void removePlayer(PlayerPower power) {
/* 80 */     power.invalid = true;
/* 81 */     power.onRemove();
/* 82 */     PowerManager.instance.removePowerHandler(power);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\player\PlayerPowerManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */