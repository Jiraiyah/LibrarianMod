package com.rwtema.extrautils2.power.player;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public abstract interface IPlayerPowerCreator
{
  public abstract PlayerPower createPower(EntityPlayer paramEntityPlayer, ItemStack paramItemStack);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\player\IPlayerPowerCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */