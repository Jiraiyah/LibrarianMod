/*    */ package com.rwtema.extrautils2.power;
/*    */ 
/*    */ import com.rwtema.extrautils2.network.NetworkHandler;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ @com.rwtema.extrautils2.network.NetworkHandler.XUPacket
/*    */ public class PacketPowerInfo extends com.rwtema.extrautils2.network.XUPacketBase
/*    */ {
/*    */   BlockPos pos;
/* 15 */   float ePos = -1.0F;
/*    */   
/*    */   private EntityPlayer player;
/*    */   
/*    */   public PacketPowerInfo() {}
/*    */   
/*    */   public PacketPowerInfo(BlockPos pos)
/*    */   {
/* 23 */     this.pos = pos;
/*    */   }
/*    */   
/*    */   public PacketPowerInfo(float ePos, BlockPos pos) {
/* 27 */     this.ePos = ePos;
/* 28 */     this.pos = pos;
/*    */   }
/*    */   
/*    */   public void writeData() throws Exception
/*    */   {
/* 33 */     writeBlockPos(this.pos);
/* 34 */     writeFloat(this.ePos);
/*    */   }
/*    */   
/*    */   public void readData(EntityPlayer player)
/*    */   {
/* 39 */     this.player = player;
/* 40 */     this.pos = readBlockPos();
/* 41 */     this.ePos = readFloat();
/*    */   }
/*    */   
/*    */   public Runnable doStuffServer()
/*    */   {
/* 46 */     new Runnable()
/*    */     {
/*    */       public void run() {
/* 49 */         if (!(PacketPowerInfo.this.player instanceof EntityPlayerMP)) return;
/* 50 */         net.minecraft.tileentity.TileEntity tile = PacketPowerInfo.this.player.worldObj.getTileEntity(PacketPowerInfo.this.pos);
/* 51 */         if (!(tile instanceof IPower)) { return;
/*    */         }
/* 53 */         int freq = Freq.getBasePlayerFreq((EntityPlayerMP)PacketPowerInfo.this.player);
/*    */         
/* 55 */         IPower power = (IPower)tile;
/*    */         
/*    */ 
/* 58 */         int frequency = power.frequency();
/* 59 */         float v; if (PowerManager.areFreqOnSameGrid(freq, frequency)) {
/* 60 */           float v = PowerManager.getCurrentPower(power);
/* 61 */           if (v != PacketPowerInfo.this.ePos) {}
/*    */         } else {
/* 63 */           v = NaN.0F;
/*    */         }
/* 65 */         NetworkHandler.sendPacketToPlayer(new PacketPowerInfo(v, PacketPowerInfo.this.pos), PacketPowerInfo.this.player);
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public Runnable doStuffClient()
/*    */   {
/* 73 */     new Runnable()
/*    */     {
/*    */       public void run() {
/* 76 */         if ((ClientPower.currentPosition == PacketPowerInfo.this.pos) || ((ClientPower.currentPosition != null) && (ClientPower.currentPosition.equals(PacketPowerInfo.this.pos)))) {
/* 77 */           ClientPower.currentPositionEnergy = PacketPowerInfo.this.ePos;
/*    */         }
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   public boolean isValidSenderSide(Side properSenderSide)
/*    */   {
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\PacketPowerInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */