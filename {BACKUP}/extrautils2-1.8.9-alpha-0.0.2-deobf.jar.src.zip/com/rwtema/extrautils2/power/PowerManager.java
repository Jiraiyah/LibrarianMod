/*     */ package com.rwtema.extrautils2.power;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.rwtema.extrautils2.utils.datastructures.WeakLinkedSet;
/*     */ import com.rwtema.extrautils2.utils.helpers.DescribeHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.PlayerHelper;
/*     */ import gnu.trove.iterator.TIntObjectIterator;
/*     */ import gnu.trove.iterator.TObjectFloatIterator;
/*     */ import gnu.trove.list.linked.TIntLinkedList;
/*     */ import gnu.trove.map.hash.TIntIntHashMap;
/*     */ import gnu.trove.map.hash.TIntObjectHashMap;
/*     */ import gnu.trove.map.hash.TObjectFloatHashMap;
/*     */ import gnu.trove.procedure.TIntObjectProcedure;
/*     */ import gnu.trove.set.hash.TIntHashSet;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.WeakHashMap;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.management.ServerConfigurationManager;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerChangedDimensionEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent.ServerTickEvent;
/*     */ 
/*     */ public class PowerManager
/*     */ {
/*  37 */   public static final PowerManager instance = new PowerManager();
/*  38 */   public static final Object MUTEX = new Object();
/*     */   
/*  40 */   public PowerManager() { this.frequncies = new TIntObjectHashMap();
/*  41 */     this.assignedValuesPlayer = new WeakHashMap();
/*  42 */     this.alliances = new TIntObjectHashMap();
/*  43 */     this.weakPowersToRemove = new ReferenceQueue();
/*  44 */     this.links = new TIntIntHashMap();
/*  45 */     this.frequencyHolders = new TIntObjectHashMap();
/*  46 */     this.powersToAdd = new WeakLinkedSet();
/*  47 */     this.powersToRemove = new WeakLinkedSet();
/*  48 */     this.p = 0;
/*  49 */     this.dirty = true;
/*  50 */     this.playersDirty = true;
/*  51 */     this.assignedValues = new WeakHashMap(); }
/*     */   
/*     */   private static final int REFRESH_TIME = 600;
/*  54 */   public static void init() { MinecraftForge.EVENT_BUS.register(instance);
/*  55 */     MinecraftForge.EVENT_BUS.register(new com.rwtema.extrautils2.power.player.PlayerPowerManager()); }
/*     */   
/*     */   public final TIntObjectHashMap<GameProfile> frequncies;
/*     */   
/*  59 */   public static float getCurrentPower(IPower power) { return power.getPower() * power.getMultiplier().multiplier(power.world()); }
/*     */   
/*     */   public final WeakHashMap<EntityPlayerMP, PowerFreq> assignedValuesPlayer;
/*     */   
/*  63 */   public static boolean areFreqOnSameGrid(int freq, int frequency) { return (freq == frequency) || (instance.getPowerFreq(freq) == instance.getPowerFreq(frequency)); }
/*     */   
/*     */   public final TIntObjectHashMap<TIntHashSet> alliances;
/*     */   
/*  67 */   public static boolean canUse(EntityPlayer player, IPower power) { if (!(player instanceof EntityPlayerMP)) return false;
/*  68 */     int basePlayerFreq = Freq.getBasePlayerFreq((EntityPlayerMP)player);
/*  69 */     return (basePlayerFreq != 0) && (areFreqOnSameGrid(power.frequency(), basePlayerFreq)); }
/*     */   
/*     */   public final ReferenceQueue<Object> weakPowersToRemove;
/*     */   private final TIntIntHashMap links;
/*  73 */   public boolean sameTeam(int a, int b) { if (a == b) { return true;
/*     */     }
/*  75 */     if (this.links.containsKey(a)) a = this.links.get(a);
/*  76 */     if (this.links.containsKey(b)) { b = this.links.get(b);
/*     */     }
/*  78 */     return a == b;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  82 */     synchronized (MUTEX) {
/*  83 */       this.frequncies.clear();
/*     */       
/*  85 */       this.p = 0;
/*  86 */       while (this.weakPowersToRemove.poll() != null) {}
/*  87 */       this.links.clear();
/*  88 */       this.frequencyHolders.clear();
/*  89 */       this.powersToAdd.clear();
/*  90 */       this.powersToRemove.clear();
/*  91 */       this.assignedValuesPlayer.clear();
/*  92 */       this.playersDirty = true;
/*  93 */       this.assignedValues.clear();
/*  94 */       this.alliances.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void getDebug(final List<String> info) {
/*  99 */     TIntObjectProcedure<Object> procedure = new TIntObjectProcedure()
/*     */     {
/*     */       public boolean execute(int a, Object b) {
/* 102 */         info.add(a + "=" + b.toString());
/* 103 */         return true;
/*     */       }
/*     */       
/* 106 */     };
/* 107 */     DescribeHelper.addDescription(info, "Frequencies");
/* 108 */     this.frequncies.forEachEntry(procedure);
/* 109 */     DescribeHelper.addDescription(info, "Alliances");
/* 110 */     this.alliances.forEachEntry(procedure);
/* 111 */     DescribeHelper.addDescription(info, "AssignedValues");
/* 112 */     DescribeHelper.addDescription(info, this.assignedValues);
/* 113 */     DescribeHelper.addDescription(info, "Frequencie Holders");
/* 114 */     this.frequencyHolders.forEachEntry(new TIntObjectProcedure()
/*     */     {
/*     */       public boolean execute(int a, PowerManager.PowerFreq b) {
/* 117 */         DescribeHelper.addDescription(info, "Init");
/* 118 */         describe(a, b);
/* 119 */         DescribeHelper.addDescription(info, "QRefresh");
/* 120 */         b.quickRefresh();
/* 121 */         describe(a, b);
/* 122 */         DescribeHelper.addDescription(info, "FRefresh");
/* 123 */         b.refresh();
/* 124 */         describe(a, b);
/* 125 */         return true;
/*     */       }
/*     */       
/*     */       public void describe(int a, PowerManager.PowerFreq b) {
/* 129 */         DescribeHelper.addDescription(info, "Freq = " + a, 2);
/* 130 */         DescribeHelper.addDescription(info, "Power", 2);
/* 131 */         DescribeHelper.addDescription(info, b.powerDrained + " " + b.powerCreated, 3);
/* 132 */         DescribeHelper.addDescription(info, "Players", 2);
/* 133 */         DescribeHelper.addDescription(info, b.players, 3);
/* 134 */         DescribeHelper.addDescription(info, "Creators", 2);
/* 135 */         DescribeHelper.addDescription(info, b.worldPowerCreators, 3);
/* 136 */         DescribeHelper.addDescription(info, "Drainers", 2);
/* 137 */         DescribeHelper.addDescription(info, b.worldPowerDrainers, 3);
/* 138 */         DescribeHelper.addDescription(info, "IPowers", 2);
/* 139 */         DescribeHelper.addDescription(info, b.powerHandlers, 3);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void reassignValues() {
/* 145 */     this.dirty = true;
/*     */   }
/*     */   
/*     */   public void remake() {
/* 149 */     synchronized (MUTEX) {
/* 150 */       this.dirty = false;
/*     */       
/* 152 */       PowerSettings.instance.markDirty();
/* 153 */       this.links.clear();
/* 154 */       for (EntityPlayerMP entityPlayerMP : MinecraftServer.func_71276_C().func_71203_ab().playerEntityList) {
/* 155 */         this.frequncies.put(Freq.getBasePlayerFreq(entityPlayerMP), entityPlayerMP.getGameProfile());
/*     */       }
/*     */       
/* 158 */       int[] keys = this.frequncies.keys();
/*     */       
/* 160 */       TIntObjectHashMap<TIntHashSet> mutualAlliances = new TIntObjectHashMap();
/* 161 */       for (int a : keys) {
/* 162 */         TIntHashSet set = new TIntHashSet();
/*     */         
/* 164 */         for (int b : keys) {
/* 165 */           if (areAAndBMutualAllies(a, b)) {
/* 166 */             set.add(b);
/*     */           }
/*     */         }
/* 169 */         mutualAlliances.put(a, set);
/*     */       }
/*     */       
/*     */ 
/* 173 */       for (int a : keys) {
/* 174 */         if (!this.links.containsKey(a))
/*     */         {
/* 176 */           TIntLinkedList toProcess = new TIntLinkedList();
/* 177 */           toProcess.add(a);
/*     */           
/* 179 */           while (!toProcess.isEmpty()) {
/* 180 */             int b = toProcess.removeAt(0);
/* 181 */             if (!this.links.containsKey(b)) {
/* 182 */               this.links.put(b, a);
/* 183 */               TIntHashSet allies = (TIntHashSet)mutualAlliances.get(b);
/* 184 */               if (allies != null)
/* 185 */                 toProcess.addAll(allies);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 190 */       for (int key : keys) {
/* 191 */         if (this.links.get(key) == key) {
/* 192 */           this.links.remove(key);
/*     */         }
/*     */       }
/* 195 */       for (PowerFreq powerFreq : this.frequencyHolders.valueCollection()) {
/* 196 */         this.powersToAdd.addAll(powerFreq.powerHandlers);
/*     */       }
/*     */       
/* 199 */       this.frequencyHolders.clear();
/*     */     } }
/*     */   
/*     */   private final TIntObjectHashMap<PowerFreq> frequencyHolders;
/*     */   private final WeakLinkedSet<IPower> powersToAdd;
/*     */   private final WeakLinkedSet<IPower> powersToRemove;
/*     */   
/* 206 */   public void addPowerHandler(IPower needer) { synchronized (MUTEX) {
/* 207 */       this.powersToAdd.add(needer);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isPowered(EntityPlayerMP player) {
/* 212 */     PowerFreq powerFreq = (PowerFreq)this.assignedValuesPlayer.get(player);
/* 213 */     if (powerFreq == null) {
/* 214 */       if (!PlayerHelper.isPlayerReal(player)) return false;
/* 215 */       powerFreq = getPowerFreq(Freq.getBasePlayerFreq(player));
/*     */     }
/* 217 */     return (powerFreq != null) && (powerFreq.isPowered());
/*     */   }
/*     */   
/*     */   public PowerFreq getPowerFreq(int frequency) {
/* 221 */     int i = this.links.containsKey(frequency) ? this.links.get(frequency) : frequency;
/*     */     
/* 223 */     PowerFreq powerFreq = (PowerFreq)this.frequencyHolders.get(i);
/* 224 */     if (powerFreq == null) {
/* 225 */       powerFreq = new PowerFreq(i);
/* 226 */       powerFreq.dirty = true;
/* 227 */       this.frequencyHolders.put(i, powerFreq);
/*     */     }
/* 229 */     return powerFreq;
/*     */   }
/*     */   
/*     */   public boolean areAAndBMutualAllies(int a, int b) {
/* 233 */     return (doesAWishToAllyWithB(a, b)) && (doesAWishToAllyWithB(b, a));
/*     */   }
/*     */   
/*     */   public boolean doesAWishToAllyWithB(int a, int b) {
/* 237 */     TIntHashSet tIntHashSet = (TIntHashSet)this.alliances.get(a);
/* 238 */     return (tIntHashSet != null) && (tIntHashSet.contains(b));
/*     */   }
/*     */   
/*     */   public void removePowerHandler(IPower needer) {
/* 242 */     synchronized (MUTEX) {
/* 243 */       this.powersToRemove.add(needer);
/*     */     }
/*     */   }
/*     */   
/*     */   public void markDirty(IPower power) {
/* 248 */     PowerFreq powerFreq = (PowerFreq)this.assignedValues.get(power);
/* 249 */     if (powerFreq == null) powerFreq = getPowerFreq(power.frequency());
/* 250 */     powerFreq.dirty = true; }
/*     */   
/*     */   int p;
/*     */   boolean dirty;
/*     */   private boolean playersDirty;
/*     */   private WeakHashMap<IPower, PowerFreq> assignedValues;
/*     */   public void markDirty(EntityPlayerMP playerMP) {}
/*     */   
/*     */   @SubscribeEvent
/* 259 */   public void onPlayerJoin(PlayerEvent.PlayerChangedDimensionEvent event) { this.playersDirty = true; }
/*     */   
/*     */ 
/*     */   @SubscribeEvent
/*     */   public void onPlayerJoin(PlayerEvent.PlayerRespawnEvent event) {
/* 264 */     this.playersDirty = true;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
/* 269 */     this.playersDirty = true;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerJoin(PlayerEvent.PlayerLoggedOutEvent event) {
/* 274 */     this.playersDirty = true;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void tick(TickEvent.ServerTickEvent event) {
/* 279 */     this.p += 1;
/* 280 */     if (this.p > 600) { this.p = 0;
/*     */     }
/* 282 */     synchronized (MUTEX) {
/* 283 */       if (this.dirty)
/* 284 */         remake();
/*     */       Object x;
/* 286 */       while ((x = this.weakPowersToRemove.poll()) != null) {
/* 287 */         this.powersToRemove.add((IPower)x);
/*     */       }
/*     */       
/*     */ 
/* 291 */       if (!this.powersToRemove.isEmpty())
/*     */       {
/* 293 */         for (IPower iPower : this.powersToRemove) {
/* 294 */           PowerFreq powerFreq = (PowerFreq)this.assignedValues.get(iPower);
/* 295 */           if (powerFreq == null) powerFreq = getPowerFreq(iPower.frequency());
/* 296 */           powerFreq.powerHandlers.remove(iPower);
/* 297 */           powerFreq.dirty = true;
/*     */         }
/* 299 */         this.powersToRemove.clear();
/*     */       }
/*     */       
/*     */ 
/* 303 */       if (!this.powersToAdd.isEmpty())
/*     */       {
/* 305 */         for (IPower iPower : this.powersToAdd) {
/* 306 */           PowerFreq powerFreq = getPowerFreq(iPower.frequency());
/* 307 */           powerFreq.powerHandlers.add(iPower);
/* 308 */           if (this.assignedValues.containsKey(iPower)) {
/* 309 */             PowerFreq oldFreq = (PowerFreq)this.assignedValues.get(iPower);
/* 310 */             oldFreq.powerHandlers.remove(iPower);
/* 311 */             oldFreq.dirty = true;
/*     */           }
/* 313 */           this.assignedValues.put(iPower, powerFreq);
/* 314 */           powerFreq.dirty = true;
/*     */         }
/* 316 */         this.powersToAdd.clear();
/*     */       }
/*     */       
/*     */ 
/* 320 */       if (this.playersDirty) {
/* 321 */         this.assignedValuesPlayer.clear();
/*     */         
/* 323 */         TIntObjectIterator<PowerFreq> iterator = this.frequencyHolders.iterator();
/* 324 */         while (iterator.hasNext()) {
/* 325 */           iterator.advance();
/* 326 */           ((PowerFreq)iterator.value()).players.clear();
/*     */         }
/*     */         
/* 329 */         LinkedHashSet<PowerFreq> freqs = new LinkedHashSet();
/* 330 */         for (EntityPlayerMP entityPlayerMP : MinecraftServer.func_71276_C().func_71203_ab().playerEntityList) {
/* 331 */           PowerFreq freq = getPowerFreq(Freq.getBasePlayerFreq(entityPlayerMP));
/* 332 */           this.assignedValuesPlayer.put(entityPlayerMP, freq);
/* 333 */           freq.players.add(entityPlayerMP);
/* 334 */           freqs.add(freq);
/*     */         }
/*     */         
/* 337 */         for (PowerFreq freq : freqs) {
/* 338 */           freq.dirty = true;
/*     */         }
/*     */         
/* 341 */         this.playersDirty = false;
/*     */       }
/*     */       
/*     */ 
/* 345 */       TIntObjectIterator<PowerFreq> iterator = this.frequencyHolders.iterator();
/* 346 */       while (iterator.hasNext()) {
/* 347 */         iterator.advance();
/* 348 */         PowerFreq value = (PowerFreq)iterator.value();
/* 349 */         if ((value.dirty) || (value.refresh_delta == this.p)) {
/* 350 */           if (value.refresh()) {
/* 351 */             value.dirty = false;
/*     */           } else {
/* 353 */             iterator.remove();
/*     */           }
/*     */         } else {
/* 356 */           value.quickRefresh();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class PowerFreq {
/*     */     final int frequency;
/* 364 */     public WeakLinkedSet<IPower> powerHandlers = new WeakLinkedSet();
/*     */     float powerDrained;
/*     */     float powerCreated;
/* 367 */     WeakLinkedSet<EntityPlayerMP> players = new WeakLinkedSet();
/* 368 */     int refresh_delta = com.rwtema.extrautils2.utils.XURandom.rand.nextInt(600);
/* 369 */     boolean dirty = true;
/* 370 */     WeakHashMap<World, TObjectFloatHashMap<IWorldPowerMultiplier>> worldPowerCreators = new WeakHashMap();
/* 371 */     WeakHashMap<World, TObjectFloatHashMap<IWorldPowerMultiplier>> worldPowerDrainers = new WeakHashMap();
/*     */     
/*     */     public PowerFreq(int frequency) {
/* 374 */       this.frequency = frequency;
/*     */     }
/*     */     
/*     */     public boolean refresh() {
/* 378 */       this.worldPowerDrainers.clear();
/* 379 */       this.worldPowerCreators.clear();
/*     */       
/*     */ 
/* 382 */       for (IPower powerHandler : this.powerHandlers) {
/* 383 */         float i = powerHandler.getPower();
/* 384 */         IWorldPowerMultiplier multiplier = powerHandler.getMultiplier();
/*     */         WeakHashMap<World, TObjectFloatHashMap<IWorldPowerMultiplier>> type;
/* 386 */         WeakHashMap<World, TObjectFloatHashMap<IWorldPowerMultiplier>> type; if (i > 0.0F) {
/* 387 */           type = this.worldPowerDrainers;
/*     */         } else {
/* 389 */           type = this.worldPowerCreators;
/* 390 */           i = -i;
/*     */         }
/*     */         
/* 393 */         World world = powerHandler.world();
/* 394 */         TObjectFloatHashMap<IWorldPowerMultiplier> typeMap = (TObjectFloatHashMap)type.get(world);
/* 395 */         if (typeMap == null) {
/* 396 */           typeMap = new TObjectFloatHashMap();
/* 397 */           type.put(world, typeMap);
/*     */         }
/*     */         
/* 400 */         typeMap.adjustOrPutValue(multiplier, i, i);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 428 */       quickRefresh();
/*     */       
/* 430 */       return (!this.powerHandlers.isEmpty()) || (!this.players.isEmpty());
/*     */     }
/*     */     
/*     */     public void quickRefresh() {
/* 434 */       boolean oldPowered = this.powerDrained <= this.powerCreated;
/*     */       
/* 436 */       float prevCreated = this.powerCreated;
/* 437 */       float prevDrained = this.powerDrained;
/*     */       
/* 439 */       this.powerCreated = calcPower(this.worldPowerCreators);
/* 440 */       this.powerDrained = calcPower(this.worldPowerDrainers);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 445 */       boolean newPower = this.powerDrained <= this.powerCreated;
/*     */       
/* 447 */       if ((this.dirty) || (newPower != oldPowered)) {
/* 448 */         changeStatus(newPower);
/*     */       }
/*     */       
/* 451 */       if ((prevCreated != this.powerCreated) || (prevDrained != this.powerDrained))
/* 452 */         sendNetworkUpdates();
/*     */     }
/*     */     
/*     */     private float calcPower(WeakHashMap<World, TObjectFloatHashMap<IWorldPowerMultiplier>> multiplierCache) {
/* 456 */       float p = 0.0F;
/* 457 */       for (Map.Entry<World, TObjectFloatHashMap<IWorldPowerMultiplier>> entry : multiplierCache.entrySet()) {
/* 458 */         TObjectFloatIterator<IWorldPowerMultiplier> iterator = ((TObjectFloatHashMap)entry.getValue()).iterator();
/* 459 */         while (iterator.hasNext()) {
/* 460 */           iterator.advance();
/* 461 */           IWorldPowerMultiplier powerMultiplier = (IWorldPowerMultiplier)iterator.key();
/* 462 */           float multiplier = powerMultiplier.multiplier((World)entry.getKey());
/* 463 */           float value = iterator.value();
/* 464 */           p += multiplier * value;
/*     */         }
/*     */       }
/*     */       
/* 468 */       return p;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void sendNetworkUpdates()
/*     */     {
/* 488 */       for (EntityPlayerMP player : this.players) {
/* 489 */         com.rwtema.extrautils2.network.NetworkHandler.sendPacketToPlayer(new PowerManager.PacketPower(this.powerCreated, this.powerDrained), player);
/*     */       }
/*     */     }
/*     */     
/*     */     public void changeStatus(boolean powered) {
/* 494 */       for (IPower powerNeeder : this.powerHandlers) {
/* 495 */         powerNeeder.powerChanged(powered);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isPowered()
/*     */     {
/* 511 */       return this.powerDrained <= this.powerCreated;
/*     */     }
/*     */   }
/*     */   
/*     */   @com.rwtema.extrautils2.network.NetworkHandler.XUPacket
/*     */   public static class PacketPower extends com.rwtema.extrautils2.network.XUPacketServerToClient
/*     */   {
/*     */     float powerCreated;
/*     */     float powerUsed;
/*     */     
/*     */     public PacketPower() {}
/*     */     
/*     */     public PacketPower(float powerCreated, float powerUsed)
/*     */     {
/* 525 */       this.powerCreated = powerCreated;
/* 526 */       this.powerUsed = powerUsed;
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/* 531 */       writeFloat(this.powerCreated);
/* 532 */       writeFloat(this.powerUsed);
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player)
/*     */     {
/* 537 */       this.powerCreated = readFloat();
/* 538 */       this.powerUsed = readFloat();
/*     */     }
/*     */     
/*     */     @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*     */     public Runnable doStuffClient()
/*     */     {
/* 544 */       ClientPower.powerCreated = this.powerCreated;
/* 545 */       ClientPower.powerDrained = this.powerUsed;
/* 546 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\PowerManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */