/*    */ package com.rwtema.extrautils2.power;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*    */ import gnu.trove.map.hash.TIntObjectHashMap;
/*    */ import gnu.trove.set.hash.TIntHashSet;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ 
/*    */ public class PowerSettings extends com.rwtema.extrautils2.backend.save.SaveModule
/*    */ {
/* 12 */   public static PowerSettings instance = new PowerSettings();
/*    */   
/*    */   public PowerSettings() {
/* 15 */     super("PowerAlliances");
/*    */   }
/*    */   
/*    */   public void readFromNBT(NBTTagCompound nbt)
/*    */   {
/* 20 */     for (NBTTagCompound freqEntry : NBTHelper.iterateNBTTagList(nbt.getTagList("PlayerFreq", 10))) {
/* 21 */       int a = freqEntry.getInteger("Freq");
/* 22 */       GameProfile profile = NBTHelper.profileFromNBT(freqEntry.getCompoundTag("Profile"));
/* 23 */       if ((a != 0) && (profile != null)) {
/* 24 */         int[] b = freqEntry.getIntArray("Allies");
/* 25 */         PowerManager.instance.frequncies.put(a, profile);
/* 26 */         if ((b != null) && (b.length > 0)) {
/* 27 */           PowerManager.instance.alliances.put(a, new TIntHashSet(b));
/*    */         }
/*    */       }
/*    */     }
/* 31 */     PowerManager.instance.reassignValues();
/*    */   }
/*    */   
/*    */   public void writeToNBT(NBTTagCompound nbt)
/*    */   {
/* 36 */     final NBTTagList playerFreq = new NBTTagList();
/* 37 */     PowerManager.instance.frequncies.forEachEntry(new gnu.trove.procedure.TIntObjectProcedure()
/*    */     {
/*    */       public boolean execute(int a, GameProfile b) {
/* 40 */         NBTTagCompound tag = new NBTTagCompound();
/* 41 */         tag.setInteger("Freq", a);
/* 42 */         tag.setTag("Profile", NBTHelper.proifleToNBT(b));
/*    */         
/* 44 */         TIntHashSet set = (TIntHashSet)PowerManager.instance.alliances.get(a);
/* 45 */         if ((set != null) && (!set.isEmpty()))
/* 46 */           tag.setIntArray("Allies", set.toArray());
/* 47 */         playerFreq.appendTag(tag);
/* 48 */         return true;
/*    */       }
/*    */       
/* 51 */     });
/* 52 */     nbt.setTag("PlayerFreq", playerFreq);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void reset()
/*    */   {
/* 59 */     PowerManager.instance.frequncies.clear();
/* 60 */     PowerManager.instance.alliances.clear();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\PowerSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */