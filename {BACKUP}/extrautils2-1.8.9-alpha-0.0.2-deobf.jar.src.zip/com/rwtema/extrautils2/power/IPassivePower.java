package com.rwtema.extrautils2.power;

public abstract interface IPassivePower {}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\IPassivePower.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */