/*   */ package com.rwtema.extrautils2.power;
/*   */ 
/*   */ import net.minecraft.world.World;
/*   */ 
/*   */ public abstract interface IWorldPowerMultiplier {
/* 6 */   public static final IWorldPowerMultiplier CONSTANT = new IWorldPowerMultiplier()
/*   */   {
/*   */     public float multiplier(World world) {
/* 9 */       return 1.0F;
/*   */     }
/*   */   };
/*   */   
/*   */   public abstract float multiplier(World paramWorld);
/*   */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\power\IWorldPowerMultiplier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */