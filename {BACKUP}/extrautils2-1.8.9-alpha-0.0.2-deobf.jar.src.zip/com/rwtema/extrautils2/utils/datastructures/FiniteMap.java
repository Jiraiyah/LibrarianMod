/*   */ package com.rwtema.extrautils2.utils.datastructures;
/*   */ 
/*   */ import gnu.trove.set.hash.TIntHashSet;
/*   */ 
/*   */ public class FiniteMap<K, V> {
/*   */   public FiniteMap(K... keys) {
/* 7 */     TIntHashSet set = new TIntHashSet();
/* 8 */     K key; for (key : keys) {}
/*   */   }
/*   */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\FiniteMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */