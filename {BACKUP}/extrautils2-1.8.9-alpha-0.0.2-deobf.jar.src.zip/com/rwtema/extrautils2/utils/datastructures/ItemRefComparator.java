/*    */ package com.rwtema.extrautils2.utils.datastructures;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public abstract class ItemRefComparator implements Comparator<ItemRef>
/*    */ {
/*  8 */   public static final ItemRefComparator id = new ItemRefComparator()
/*    */   {
/*    */     public int doCompare(ItemRef o1, ItemRef o2) {
/* 11 */       int i = compareInt(Item.getIdFromItem(o1.getItem()), Item.getIdFromItem(o2.getItem()));
/* 12 */       if (i != 0) return i;
/* 13 */       i = compareInt(o1.getMeta(), o2.getMeta());
/* 14 */       if (i != 0) return i;
/* 15 */       return compareInt(o1.getTagHash(), o2.getTagHash());
/*    */     }
/*    */   };
/*    */   
/* 19 */   public static final ItemRefComparator names = new ItemRefComparator()
/*    */   {
/*    */     public int doCompare(ItemRef o1, ItemRef o2) {
/* 22 */       int i = o1.getDisplayName().compareTo(o2.getDisplayName());
/* 23 */       if (i != 0)
/* 24 */         return i;
/* 25 */       return id.doCompare(o1, o2);
/*    */     }
/*    */   };
/*    */   
/*    */   public int compare(ItemRef o1, ItemRef o2)
/*    */   {
/* 31 */     if (o1 == o2) return 0;
/* 32 */     if (o1 == ItemRef.NULL) return 1;
/* 33 */     if (o2 == ItemRef.NULL) { return -1;
/*    */     }
/* 35 */     return doCompare(o1, o2);
/*    */   }
/*    */   
/*    */   protected abstract int doCompare(ItemRef paramItemRef1, ItemRef paramItemRef2);
/*    */   
/*    */   public int compareInt(int a, int b) {
/* 41 */     return a == b ? 0 : a < b ? -1 : 1;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\ItemRefComparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */