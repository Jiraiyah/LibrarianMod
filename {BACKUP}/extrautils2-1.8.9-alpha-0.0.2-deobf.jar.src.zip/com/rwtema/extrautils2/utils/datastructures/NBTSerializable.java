/*     */ package com.rwtema.extrautils2.utils.datastructures;
/*     */ 
/*     */ import net.minecraft.nbt.NBTTagDouble;
/*     */ 
/*     */ public class NBTSerializable
/*     */ {
/*     */   public static class Text implements net.minecraftforge.common.util.INBTSerializable<net.minecraft.nbt.NBTTagString>
/*     */   {
/*     */     @javax.annotation.Nonnull
/*     */     String s;
/*     */     
/*     */     public Text(@javax.annotation.Nonnull String s)
/*     */     {
/*  14 */       this.s = s;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public net.minecraft.nbt.NBTTagString serializeNBT()
/*     */     {
/*  22 */       return new net.minecraft.nbt.NBTTagString(this.s);
/*     */     }
/*     */     
/*     */     public void deserializeNBT(net.minecraft.nbt.NBTTagString nbt)
/*     */     {
/*  27 */       this.s = nbt.getString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Int implements net.minecraftforge.common.util.INBTSerializable<net.minecraft.nbt.NBTTagInt> {
/*     */     public int value;
/*     */     
/*     */     public Int(int value) {
/*  35 */       this.value = value;
/*     */     }
/*     */     
/*     */ 
/*     */     public Int() {}
/*     */     
/*     */ 
/*     */     public net.minecraft.nbt.NBTTagInt serializeNBT()
/*     */     {
/*  44 */       return new net.minecraft.nbt.NBTTagInt(this.value);
/*     */     }
/*     */     
/*     */     public void deserializeNBT(net.minecraft.nbt.NBTTagInt nbt)
/*     */     {
/*  49 */       this.value = nbt.getInt();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Float implements net.minecraftforge.common.util.INBTSerializable<net.minecraft.nbt.NBTTagFloat>
/*     */   {
/*     */     public float value;
/*     */     
/*     */     public Float() {}
/*     */     
/*     */     public Float(float value)
/*     */     {
/*  61 */       this.value = value;
/*     */     }
/*     */     
/*     */     public net.minecraft.nbt.NBTTagFloat serializeNBT()
/*     */     {
/*  66 */       return new net.minecraft.nbt.NBTTagFloat(this.value);
/*     */     }
/*     */     
/*     */     public void deserializeNBT(net.minecraft.nbt.NBTTagFloat nbt)
/*     */     {
/*  71 */       this.value = nbt.getFloat();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Double implements net.minecraftforge.common.util.INBTSerializable<NBTTagDouble>
/*     */   {
/*     */     public double value;
/*     */     
/*     */     public Double(double value) {
/*  80 */       this.value = value;
/*     */     }
/*     */     
/*     */     public NBTTagDouble serializeNBT()
/*     */     {
/*  85 */       return new NBTTagDouble(this.value);
/*     */     }
/*     */     
/*     */     public void deserializeNBT(NBTTagDouble nbt)
/*     */     {
/*  90 */       this.value = nbt.getDouble();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Boolean implements net.minecraftforge.common.util.INBTSerializable<net.minecraft.nbt.NBTTagByte> {
/*     */     public boolean value;
/*     */     
/*     */     public Boolean(boolean value) {
/*  98 */       this.value = value;
/*     */     }
/*     */     
/*     */     public net.minecraft.nbt.NBTTagByte serializeNBT()
/*     */     {
/* 103 */       return new net.minecraft.nbt.NBTTagByte((byte)(this.value ? 1 : 0));
/*     */     }
/*     */     
/*     */     public void deserializeNBT(net.minecraft.nbt.NBTTagByte nbt)
/*     */     {
/* 108 */       this.value = (nbt.getByte() != 0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\NBTSerializable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */