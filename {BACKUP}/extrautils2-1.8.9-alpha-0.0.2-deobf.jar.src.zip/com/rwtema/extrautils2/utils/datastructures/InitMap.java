/*    */ package com.rwtema.extrautils2.utils.datastructures;
/*    */ 
/*    */ import com.google.common.collect.ForwardingMap;
/*    */ import java.util.Map;
/*    */ import java.util.WeakHashMap;
/*    */ 
/*    */ public abstract class InitMap<K, V> extends ForwardingMap<K, V>
/*    */ {
/*    */   final Map<K, V> base;
/*    */   
/*    */   public InitMap(Map base)
/*    */   {
/* 13 */     this.base = base;
/*    */   }
/*    */   
/*    */   public InitMap() {
/* 17 */     this(new WeakHashMap());
/*    */   }
/*    */   
/*    */   protected Map<K, V> delegate()
/*    */   {
/* 22 */     return this.base;
/*    */   }
/*    */   
/*    */ 
/*    */   protected abstract V initValue(K paramK);
/*    */   
/*    */   public V get(Object key)
/*    */   {
/* 30 */     V v = super.get(key);
/* 31 */     if (v == null) {
/* 32 */       K k = (K)key;
/* 33 */       v = initValue(k);
/* 34 */       put(k, v);
/*    */     }
/* 36 */     return v;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\InitMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */