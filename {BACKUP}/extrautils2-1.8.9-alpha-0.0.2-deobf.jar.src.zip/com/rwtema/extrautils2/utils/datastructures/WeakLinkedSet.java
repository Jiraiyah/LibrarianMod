/*     */ package com.rwtema.extrautils2.utils.datastructures;
/*     */ 
/*     */ import gnu.trove.list.linked.TLinkedList;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class WeakLinkedSet<E> extends java.util.AbstractSet<E>
/*     */ {
/*     */   private WeakLinkedSet<E>.WeakLinkTHashSet set;
/*     */   private TLinkedList<WeakLinkedSet<E>.WeakLink> order;
/*     */   private final ReferenceQueue<E> queue;
/*     */   
/*     */   public WeakLinkedSet()
/*     */   {
/*  16 */     this.set = new WeakLinkTHashSet();
/*  17 */     this.order = new TLinkedList();
/*  18 */     this.queue = new ReferenceQueue();
/*     */   }
/*     */   
/*     */   @javax.annotation.Nonnull
/*     */   public Iterator<E> iterator() {
/*  23 */     expungeStaleEntries();
/*  24 */     return new Iter(null);
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/*  29 */     expungeStaleEntries();
/*  30 */     return this.set.size();
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear()
/*     */   {
/*  36 */     while (this.queue.poll() != null) {}
/*  37 */     this.set.clear();
/*  38 */     this.order.clear();
/*  39 */     while (this.queue.poll() != null) {}
/*     */   }
/*     */   
/*     */   public boolean contains(Object o)
/*     */   {
/*  44 */     expungeStaleEntries();
/*  45 */     return this.set.contains(o);
/*     */   }
/*     */   
/*     */   public boolean add(E e)
/*     */   {
/*  50 */     expungeStaleEntries();
/*  51 */     if (this.set.contains(e)) {
/*  52 */       return false;
/*     */     }
/*  54 */     WeakLinkedSet<E>.WeakLink link = new WeakLink(e);
/*  55 */     if (this.set.add(link)) {
/*  56 */       this.order.add(link);
/*  57 */       return true;
/*     */     }
/*  59 */     return false;
/*     */   }
/*     */   
/*     */   public boolean remove(Object o)
/*     */   {
/*  64 */     expungeStaleEntries();
/*  65 */     WeakLinkedSet<E>.WeakLink weakLink = this.set.removeSpecial(o);
/*  66 */     if (weakLink != null) {
/*  67 */       this.order.remove(weakLink);
/*  68 */       return true;
/*     */     }
/*  70 */     return false;
/*     */   }
/*     */   
/*     */   private void expungeStaleEntries() {
/*     */     java.lang.ref.Reference poll;
/*  75 */     while ((poll = this.queue.poll()) != null) {
/*  76 */       synchronized (this.queue)
/*     */       {
/*  78 */         WeakLinkedSet<E>.WeakLink entry = (WeakLink)poll;
/*  79 */         entry.fallbackNext = entry.next;
/*  80 */         this.set.remove(entry);
/*  81 */         this.order.remove(entry);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class WeakLinkTHashSet extends gnu.trove.set.hash.THashSet<WeakLinkedSet<E>.WeakLink>
/*     */   {
/*     */     public WeakLinkTHashSet() {}
/*     */     
/*     */     public WeakLinkedSet<E>.WeakLink removeSpecial(Object obj)
/*     */     {
/*  92 */       int index = index(obj);
/*  93 */       if (index >= 0) {
/*  94 */         Object o = this._set[index];
/*  95 */         removeAt(index);
/*  96 */         return (WeakLinkedSet.WeakLink)o;
/*     */       }
/*  98 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     protected boolean equals(Object notnull, Object two)
/*     */     {
/* 104 */       return (two != null) && (two != REMOVED) && (two.equals(notnull));
/*     */     }
/*     */   }
/*     */   
/*     */   private class WeakLink extends WeakReference<E> implements gnu.trove.list.TLinkable<WeakLinkedSet<E>.WeakLink> {
/*     */     final int hash;
/*     */     WeakLinkedSet<E>.WeakLink next;
/*     */     WeakLinkedSet<E>.WeakLink previous;
/*     */     WeakLinkedSet<E>.WeakLink fallbackNext;
/*     */     
/*     */     public WeakLink() {
/* 115 */       super(WeakLinkedSet.this.queue);
/* 116 */       this.hash = referent.hashCode();
/*     */     }
/*     */     
/*     */     public WeakLinkedSet<E>.WeakLink getNext()
/*     */     {
/* 121 */       return this.next;
/*     */     }
/*     */     
/*     */     public void setNext(WeakLinkedSet<E>.WeakLink next)
/*     */     {
/* 126 */       this.next = next;
/*     */     }
/*     */     
/*     */     public WeakLinkedSet<E>.WeakLink getPrevious()
/*     */     {
/* 131 */       return this.previous;
/*     */     }
/*     */     
/*     */     public void setPrevious(WeakLinkedSet<E>.WeakLink previous)
/*     */     {
/* 136 */       this.previous = previous;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 141 */       return this.hash;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 147 */       if (this == obj) return true;
/* 148 */       if (obj == null) return false;
/* 149 */       E e1 = get();
/* 150 */       if (e1 == null) return false;
/* 151 */       if (e1 == obj) { return true;
/*     */       }
/* 153 */       if (obj.getClass() == WeakLink.class) {
/* 154 */         WeakLinkedSet<E>.WeakLink other = (WeakLink)obj;
/* 155 */         E e2 = other.get();
/* 156 */         return (e2 != null) && ((e1 == e2) || (e1.equals(e2)));
/*     */       }
/* 158 */       return obj.equals(e1);
/*     */     }
/*     */   }
/*     */   
/*     */   private class Iter implements Iterator<E>
/*     */   {
/* 164 */     private WeakLinkedSet<E>.WeakLink entry = (WeakLinkedSet.WeakLink)WeakLinkedSet.this.order.getFirst();
/* 165 */     private WeakLinkedSet<E>.WeakLink lastReturned = null;
/*     */     private E nextKey;
/*     */     private E curKey;
/*     */     
/*     */     private Iter() {}
/*     */     
/* 171 */     public boolean hasNext() { while (this.nextKey == null) {
/* 172 */         if (this.entry == null) {
/* 173 */           this.curKey = null;
/* 174 */           return false;
/*     */         }
/*     */         
/* 177 */         this.nextKey = this.entry.get();
/* 178 */         if (this.nextKey != null) {
/* 179 */           return true;
/*     */         }
/* 181 */         WeakLinkedSet<E>.WeakLink next = this.entry.next;
/* 182 */         if (next == null) {
/* 183 */           this.entry = this.entry.fallbackNext;
/*     */         } else
/* 185 */           this.entry = next;
/*     */       }
/* 187 */       return true;
/*     */     }
/*     */     
/*     */     public E next()
/*     */     {
/* 192 */       if ((this.nextKey == null) && (!hasNext())) { throw new java.util.NoSuchElementException();
/*     */       }
/* 194 */       this.lastReturned = this.entry;
/* 195 */       this.entry = this.entry.next;
/* 196 */       this.curKey = this.nextKey;
/* 197 */       this.nextKey = null;
/* 198 */       return (E)this.curKey;
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 203 */       if (this.lastReturned == null) {
/* 204 */         throw new IllegalStateException();
/*     */       }
/* 206 */       WeakLinkedSet.this.order.remove(this.lastReturned);
/* 207 */       WeakLinkedSet.this.set.remove(this.lastReturned);
/* 208 */       this.lastReturned = null;
/* 209 */       this.curKey = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\WeakLinkedSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */