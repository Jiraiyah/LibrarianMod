/*     */ package com.rwtema.extrautils2.utils.datastructures;
/*     */ 
/*     */ import com.rwtema.extrautils2.network.PacketBuffer;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTCopyHelper;
/*     */ import com.rwtema.extrautils2.utils.helpers.NBTCopyHelper.ResultNBT;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ 
/*     */ public abstract class ItemRef
/*     */ {
/*  13 */   public static final ItemRef NULL = new NullRef(null);
/*     */   
/*     */ 
/*     */ 
/*     */   String localName;
/*     */   
/*     */ 
/*     */ 
/*     */   public static ItemRef read(PacketBuffer buffer)
/*     */   {
/*  23 */     byte b = buffer.readByte();
/*  24 */     switch (b) {
/*     */     case 0: 
/*     */     default: 
/*  27 */       return NULL;
/*     */     case 1: 
/*  29 */       return Simple.readFromPacket(buffer);
/*     */     case 2: 
/*  31 */       return Meta.readFromPacket(buffer);
/*     */     case 3: 
/*  33 */       return SimpleNBT.readFromPacket(buffer);
/*     */     }
/*  35 */     return MetaNBT.readFromPacket(buffer);
/*     */   }
/*     */   
/*     */   public static ItemRef wrap(ItemStack stack)
/*     */   {
/*  40 */     if (stack == null) return NULL;
/*  41 */     Item item = stack.getItem();
/*  42 */     if (item == null) { return NULL;
/*     */     }
/*  44 */     if ((item.getHasSubtypes()) || (item.isDamageable())) {
/*  45 */       NBTTagCompound nbt = stack.getTagCompound();
/*  46 */       if (nbt == null) {
/*  47 */         return new Meta(item, stack.getItemDamage());
/*     */       }
/*  49 */       return new MetaNBT(item, stack.getItemDamage(), nbt);
/*     */     }
/*  51 */     NBTTagCompound nbt = stack.getTagCompound();
/*  52 */     if (nbt == null) {
/*  53 */       return new Simple(item);
/*     */     }
/*  55 */     return new SimpleNBT(item, nbt);
/*     */   }
/*     */   
/*     */   public ItemStack createItemStack(int amount)
/*     */   {
/*  60 */     ItemStack itemStack = new ItemStack(getItem(), amount, getMeta());
/*  61 */     itemStack.setTagCompound(getTagCompound());
/*  62 */     return itemStack;
/*     */   }
/*     */   
/*     */   public abstract Item getItem();
/*     */   
/*     */   public abstract int getMeta();
/*     */   
/*     */   public abstract NBTTagCompound getTagCompound();
/*     */   
/*     */   public abstract int getTagHash();
/*     */   
/*     */   public void write(PacketBuffer buffer) {
/*  74 */     writeToPacket(buffer);
/*     */   }
/*     */   
/*     */   protected abstract void writeToPacket(PacketBuffer paramPacketBuffer);
/*     */   
/*     */   public abstract boolean equalsItemStack(ItemStack paramItemStack);
/*     */   
/*     */   public String getDisplayName()
/*     */   {
/*  83 */     if (this.localName != null) return this.localName;
/*  84 */     ItemStack itemStack = createItemStack(1);
/*  85 */     return this.localName = itemStack.getDisplayName();
/*     */   }
/*     */   
/*     */   public int getMaxStackSize() {
/*  89 */     return createItemStack(1).getMaxStackSize();
/*     */   }
/*     */   
/*     */   private static final class Simple extends ItemRef {
/*     */     @Nonnull
/*     */     private final Item item;
/*     */     
/*     */     public Simple(@Nonnull Item item) {
/*  97 */       super();
/*  98 */       this.item = item;
/*     */     }
/*     */     
/*     */     public static ItemRef readFromPacket(PacketBuffer buffer) {
/* 102 */       Item item = Item.getItemById(buffer.readUnsignedShort());
/* 103 */       if (item == null) return NULL;
/* 104 */       return new Simple(item);
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 109 */       if (this == o) return true;
/* 110 */       if (o == null) { return false;
/*     */       }
/* 112 */       Class<?> aClass = o.getClass();
/* 113 */       if (aClass == ItemStack.class) {
/* 114 */         ItemStack stack = (ItemStack)o;
/* 115 */         return equalsItemStack(stack);
/*     */       }
/* 117 */       if (Simple.class != aClass) { return false;
/*     */       }
/* 119 */       Simple simple = (Simple)o;
/*     */       
/* 121 */       return this.item == simple.item;
/*     */     }
/*     */     
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 127 */       return System.identityHashCode(this.item);
/*     */     }
/*     */     
/*     */     @Nonnull
/*     */     public Item getItem()
/*     */     {
/* 133 */       return this.item;
/*     */     }
/*     */     
/*     */     public int getMeta()
/*     */     {
/* 138 */       return 0;
/*     */     }
/*     */     
/*     */     public NBTTagCompound getTagCompound()
/*     */     {
/* 143 */       return null;
/*     */     }
/*     */     
/*     */     public int getTagHash()
/*     */     {
/* 148 */       return 0;
/*     */     }
/*     */     
/*     */     protected void writeToPacket(PacketBuffer buffer)
/*     */     {
/* 153 */       buffer.writeByte(1);
/* 154 */       buffer.writeShort(Item.getIdFromItem(this.item));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 159 */     public boolean equalsItemStack(ItemStack stack) { return (stack != null) && (this.item == stack.getItem()) && (!stack.hasTagCompound()); }
/*     */   }
/*     */   
/*     */   private static final class Meta extends ItemRef {
/*     */     @Nonnull
/*     */     private final Item item;
/*     */     private final int meta;
/*     */     
/*     */     public Meta(@Nonnull Item item, int meta) {
/* 168 */       super();
/* 169 */       this.item = item;
/* 170 */       this.meta = meta;
/*     */     }
/*     */     
/*     */     public static ItemRef readFromPacket(PacketBuffer buffer) {
/* 174 */       Item item = Item.getItemById(buffer.readShort());
/* 175 */       int damage = buffer.readShort();
/* 176 */       if (item == null) return NULL;
/* 177 */       return new Meta(item, damage);
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 182 */       if (this == o) return true;
/* 183 */       if (o == null) return false;
/* 184 */       Class<?> aClass = o.getClass();
/* 185 */       if (aClass == ItemStack.class) {
/* 186 */         ItemStack itemStack = (ItemStack)o;
/* 187 */         return equalsItemStack(itemStack);
/*     */       }
/* 189 */       if (Meta.class != aClass) { return false;
/*     */       }
/* 191 */       Meta meta = (Meta)o;
/*     */       
/* 193 */       return (this.meta == meta.meta) && (this.item == meta.item);
/*     */     }
/*     */     
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 199 */       int result = System.identityHashCode(this.item);
/* 200 */       result = 31 * result + this.meta;
/* 201 */       return result;
/*     */     }
/*     */     
/*     */     public boolean equalsItemStack(ItemStack stack)
/*     */     {
/* 206 */       return (stack != null) && (this.item == stack.getItem()) && (this.meta == stack.getItemDamage()) && (!stack.hasTagCompound());
/*     */     }
/*     */     
/*     */     @Nonnull
/*     */     public Item getItem()
/*     */     {
/* 212 */       return this.item;
/*     */     }
/*     */     
/*     */     public int getMeta()
/*     */     {
/* 217 */       return this.meta;
/*     */     }
/*     */     
/*     */     public NBTTagCompound getTagCompound()
/*     */     {
/* 222 */       return null;
/*     */     }
/*     */     
/*     */     public int getTagHash()
/*     */     {
/* 227 */       return 0;
/*     */     }
/*     */     
/*     */     protected void writeToPacket(PacketBuffer buffer)
/*     */     {
/* 232 */       buffer.writeByte(2);
/* 233 */       buffer.writeShort(Item.getIdFromItem(this.item));
/* 234 */       buffer.writeShort(this.meta);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SimpleNBT extends ItemRef {
/*     */     @Nonnull
/*     */     protected final Item item;
/*     */     @Nonnull
/*     */     protected final NBTTagCompound tag;
/*     */     protected final int tagHash;
/* 244 */     byte[] packetBytes = null;
/*     */     
/* 246 */     public SimpleNBT(@Nonnull Item item, @Nonnull NBTTagCompound tag) { super();
/* 247 */       this.item = item;
/* 248 */       NBTCopyHelper.ResultNBT resultNBT = NBTCopyHelper.copyAndHashNBT(tag);
/* 249 */       this.tag = resultNBT.copy;
/* 250 */       this.tagHash = resultNBT.hash;
/*     */     }
/*     */     
/* 253 */     public SimpleNBT(@Nonnull Item item, @Nonnull NBTTagCompound tag, int tagHash) { super();
/* 254 */       this.item = item;
/* 255 */       this.tag = tag;
/* 256 */       this.tagHash = tagHash;
/*     */     }
/*     */     
/*     */     public static ItemRef readFromPacket(PacketBuffer buffer) {
/* 260 */       Item item = Item.getItemById(buffer.readUnsignedShort());
/* 261 */       int tagHash = buffer.readInt();
/* 262 */       NBTTagCompound nbt = buffer.readNBT();
/* 263 */       if (item == null) return NULL;
/* 264 */       return new SimpleNBT(item, nbt, tagHash);
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 269 */       if (this == o) return true;
/* 270 */       if (o == null) return false;
/* 271 */       Class<?> aClass = o.getClass();
/* 272 */       if (aClass == ItemStack.class) {
/* 273 */         ItemStack stack = (ItemStack)o;
/* 274 */         return equalsItemStack(stack);
/*     */       }
/* 276 */       if (SimpleNBT.class != aClass) { return false;
/*     */       }
/* 278 */       SimpleNBT simpleNbt = (SimpleNBT)o;
/*     */       
/* 280 */       return (this.item == simpleNbt.item) && (this.tagHash == simpleNbt.tagHash) && (tagEquals(simpleNbt.tag));
/*     */     }
/*     */     
/*     */     public boolean tagEquals(NBTTagCompound otherTag) {
/* 284 */       return (this.tag == otherTag) || (NBTCopyHelper.equalNBT(this.tag, otherTag));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 289 */       return System.identityHashCode(this.item) * 31 + this.tagHash;
/*     */     }
/*     */     
/*     */     public boolean equalsItemStack(ItemStack stack)
/*     */     {
/* 294 */       return (stack != null) && (this.item == stack.getItem()) && (stack.hasTagCompound()) && (tagEquals(stack.getTagCompound()));
/*     */     }
/*     */     
/*     */     @Nonnull
/*     */     public Item getItem()
/*     */     {
/* 300 */       return this.item;
/*     */     }
/*     */     
/*     */     public int getMeta()
/*     */     {
/* 305 */       return 0;
/*     */     }
/*     */     
/*     */     public NBTTagCompound getTagCompound()
/*     */     {
/* 310 */       return this.tag;
/*     */     }
/*     */     
/*     */     public int getTagHash()
/*     */     {
/* 315 */       return this.tagHash;
/*     */     }
/*     */     
/*     */     protected void writeToPacket(PacketBuffer buffer)
/*     */     {
/* 320 */       buffer.writeByte(3);
/* 321 */       buffer.writeShort(Item.getIdFromItem(this.item));
/* 322 */       writeNBT(buffer);
/*     */     }
/*     */     
/*     */     protected void writeNBT(PacketBuffer buffer) {
/* 326 */       buffer.writeInt(this.tagHash);
/*     */       
/* 328 */       if (this.packetBytes == null) {
/*     */         try {
/* 330 */           this.packetBytes = PacketBuffer.compress(this.tag);
/*     */         } catch (java.io.IOException e) {
/* 332 */           throw com.google.common.base.Throwables.propagate(e);
/*     */         }
/*     */         
/* 335 */         if (this.packetBytes == null) {
/* 336 */           buffer.writeShort(0);
/* 337 */           return;
/*     */         }
/*     */       }
/*     */       
/* 341 */       buffer.writeShort(this.packetBytes.length);
/* 342 */       buffer.writeBytes(this.packetBytes);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class MetaNBT extends ItemRef.SimpleNBT
/*     */   {
/*     */     private final int meta;
/*     */     
/*     */     public MetaNBT(@Nonnull Item item, int meta, @Nonnull NBTTagCompound tag) {
/* 351 */       super(tag);
/* 352 */       this.meta = meta;
/*     */     }
/*     */     
/*     */     public MetaNBT(@Nonnull Item item, int meta, @Nonnull NBTTagCompound tag, int tagHash) {
/* 356 */       super(tag, tagHash);
/* 357 */       this.meta = meta;
/*     */     }
/*     */     
/*     */     public static ItemRef readFromPacket(PacketBuffer buffer) {
/* 361 */       Item item = Item.getItemById(buffer.readUnsignedShort());
/* 362 */       int meta = buffer.readShort();
/* 363 */       int tagHash = buffer.readInt();
/* 364 */       NBTTagCompound nbt = buffer.readNBT();
/* 365 */       if (item == null) return NULL;
/* 366 */       return new MetaNBT(item, meta, nbt, tagHash);
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 371 */       if (this == o) return true;
/* 372 */       if (o == null) return false;
/* 373 */       Class<?> aClass = o.getClass();
/* 374 */       if (aClass == ItemStack.class) {
/* 375 */         ItemStack stack = (ItemStack)o;
/* 376 */         return equalsItemStack(stack);
/*     */       }
/* 378 */       if (getClass() != aClass) { return false;
/*     */       }
/* 380 */       MetaNBT metaNBT = (MetaNBT)o;
/*     */       
/* 382 */       return (this.meta == metaNBT.meta) && (this.tagHash == metaNBT.tagHash) && (this.item == metaNBT.item) && (tagEquals(metaNBT.tag));
/*     */     }
/*     */     
/*     */     public int getMeta()
/*     */     {
/* 387 */       return this.meta;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 392 */       int result = System.identityHashCode(this.item) + 1;
/* 393 */       result = 31 * result + this.tagHash;
/* 394 */       result = 31 * result + this.meta;
/* 395 */       return result;
/*     */     }
/*     */     
/*     */     public boolean equalsItemStack(ItemStack stack)
/*     */     {
/* 400 */       return (stack != null) && (this.item == stack.getItem()) && (this.meta == stack.getItemDamage()) && (stack.hasTagCompound()) && (tagEquals(stack.getTagCompound()));
/*     */     }
/*     */     
/*     */     protected void writeToPacket(PacketBuffer buffer)
/*     */     {
/* 405 */       buffer.writeByte(4);
/* 406 */       buffer.writeShort(Item.getIdFromItem(this.item));
/* 407 */       buffer.writeShort(this.meta);
/* 408 */       writeNBT(buffer);
/*     */     }
/*     */   }
/*     */   
/* 412 */   private static class NullRef extends ItemRef { private NullRef() { super(); }
/*     */     
/*     */     public int getMaxStackSize() {
/* 415 */       return 0;
/*     */     }
/*     */     
/*     */     public ItemStack createItemStack(int amount)
/*     */     {
/* 420 */       return null;
/*     */     }
/*     */     
/*     */     public String getDisplayName()
/*     */     {
/* 425 */       return "[Null]";
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 430 */       return 0;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 435 */       return this == obj;
/*     */     }
/*     */     
/*     */     public Item getItem()
/*     */     {
/* 440 */       return null;
/*     */     }
/*     */     
/*     */     public int getMeta()
/*     */     {
/* 445 */       return 0;
/*     */     }
/*     */     
/*     */     public NBTTagCompound getTagCompound()
/*     */     {
/* 450 */       return null;
/*     */     }
/*     */     
/*     */     public int getTagHash()
/*     */     {
/* 455 */       return 0;
/*     */     }
/*     */     
/*     */     protected void writeToPacket(PacketBuffer buffer)
/*     */     {
/* 460 */       buffer.writeByte(0);
/*     */     }
/*     */     
/*     */     public boolean equalsItemStack(ItemStack stack)
/*     */     {
/* 465 */       return (stack == null) || (stack.getItem() == null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\ItemRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */