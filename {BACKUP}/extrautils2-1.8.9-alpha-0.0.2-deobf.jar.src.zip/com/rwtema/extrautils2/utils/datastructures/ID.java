/*    */ package com.rwtema.extrautils2.utils.datastructures;
/*    */ 
/*    */ public final class ID<T> {
/*    */   public final T object;
/*    */   private final int hash;
/*    */   
/*    */   public ID(T object) {
/*  8 */     this.object = object;
/*  9 */     this.hash = System.identityHashCode(object);
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 14 */     return this.hash;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other)
/*    */   {
/* 19 */     return (other != null) && (other.getClass() == ID.class) && (this.hash == other.hashCode()) && (this.object == ((ID)other).object);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\ID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */