/*    */ package com.rwtema.extrautils2.utils.datastructures;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ConcatList<T> extends java.util.AbstractList<T>
/*    */ {
/*    */   public final List<List<T>> lists;
/*    */   public final List<T> modifiableList;
/*    */   
/*    */   public ConcatList()
/*    */   {
/* 14 */     this.lists = new ArrayList();
/* 15 */     this.modifiableList = new ArrayList();
/* 16 */     this.lists.add(this.modifiableList);
/*    */   }
/*    */   
/*    */   public void appendList(List<T> list)
/*    */   {
/* 21 */     this.lists.add(list);
/*    */   }
/*    */   
/*    */   public boolean add(T t)
/*    */   {
/* 26 */     return this.modifiableList.add(t);
/*    */   }
/*    */   
/*    */   public boolean addAll(@javax.annotation.Nonnull Collection<? extends T> c)
/*    */   {
/* 31 */     if ((c instanceof List)) {
/* 32 */       return this.lists.add((List)c);
/*    */     }
/* 34 */     return super.addAll(c);
/*    */   }
/*    */   
/*    */   public T get(int index)
/*    */   {
/* 39 */     for (List<T> list : this.lists) {
/* 40 */       int size = list.size();
/* 41 */       if (index < size) {
/* 42 */         return (T)list.get(index);
/*    */       }
/* 44 */       index -= size;
/*    */     }
/*    */     
/*    */ 
/* 48 */     return null;
/*    */   }
/*    */   
/*    */   public int size()
/*    */   {
/* 53 */     int size = 0;
/* 54 */     for (List<T> list : this.lists) {
/* 55 */       size += list.size();
/*    */     }
/* 57 */     return size;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\ConcatList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */