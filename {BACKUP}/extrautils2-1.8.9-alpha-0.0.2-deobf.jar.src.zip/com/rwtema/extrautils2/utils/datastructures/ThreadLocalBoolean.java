/*    */ package com.rwtema.extrautils2.utils.datastructures;
/*    */ 
/*    */ public class ThreadLocalBoolean extends ThreadLocal<Boolean> {
/*    */   public final boolean _default;
/*    */   
/*    */   public ThreadLocalBoolean(boolean aDefault) {
/*  7 */     this._default = aDefault;
/*    */   }
/*    */   
/*    */   protected Boolean initialValue()
/*    */   {
/* 12 */     return Boolean.valueOf(this._default);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\ThreadLocalBoolean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */