/*    */ package com.rwtema.extrautils2.utils.datastructures;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ 
/*    */ public class InitFlag {
/*  6 */   private AtomicBoolean flag = new AtomicBoolean();
/*    */   
/*    */   public boolean init() {
/*  9 */     AtomicBoolean flag = this.flag;
/* 10 */     if ((flag == null) || (flag.get()) || (!flag.compareAndSet(false, true))) return true;
/* 11 */     this.flag = null;
/* 12 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\InitFlag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */