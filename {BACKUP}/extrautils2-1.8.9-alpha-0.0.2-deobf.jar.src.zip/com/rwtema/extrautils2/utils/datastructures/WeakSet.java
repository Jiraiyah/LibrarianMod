/*    */ package com.rwtema.extrautils2.utils.datastructures;
/*    */ 
/*    */ import java.util.AbstractSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.WeakHashMap;
/*    */ import javax.annotation.Nonnull;
/*    */ 
/*    */ public class WeakSet<E> extends AbstractSet<E> implements Set<E>
/*    */ {
/*    */   private final transient Map<E, Object> map;
/* 13 */   private static final Object PRESENT = new Object();
/*    */   
/*    */   public WeakSet() {
/* 16 */     this(new WeakHashMap());
/*    */   }
/*    */   
/*    */   public WeakSet(WeakHashMap<E, Object> baseMap) {
/* 20 */     this.map = baseMap;
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public Iterator<E> iterator()
/*    */   {
/* 26 */     return this.map.keySet().iterator();
/*    */   }
/*    */   
/*    */   public int size() {
/* 30 */     return this.map.size();
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 34 */     return this.map.isEmpty();
/*    */   }
/*    */   
/*    */   public boolean contains(Object o) {
/* 38 */     return this.map.containsKey(o);
/*    */   }
/*    */   
/*    */   public boolean add(E e) {
/* 42 */     return this.map.put(e, PRESENT) == null;
/*    */   }
/*    */   
/*    */   public boolean remove(Object o) {
/* 46 */     return this.map.remove(o) == PRESENT;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 50 */     this.map.clear();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\WeakSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */