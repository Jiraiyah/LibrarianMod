/*    */ package com.rwtema.extrautils2.utils.datastructures;
/*    */ 
/*    */ import java.util.WeakHashMap;
/*    */ 
/*    */ public abstract class ClassCache<T> {
/*  6 */   WeakHashMap<Class, T> values = new WeakHashMap();
/*    */   
/*    */   public T getFromObject(Object object) {
/*  9 */     if (object == null) return (T)nullObjectValue();
/* 10 */     return (T)getClass(object.getClass());
/*    */   }
/*    */   
/*    */   public T getClass(Class clazz) {
/* 14 */     if (clazz == null) return (T)nullClassValue();
/* 15 */     if (this.values.containsKey(clazz)) {
/* 16 */       return (T)this.values.get(clazz);
/*    */     }
/* 18 */     T t = calc(clazz);
/* 19 */     this.values.put(clazz, t);
/* 20 */     return t;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 24 */     this.values.clear();
/*    */   }
/*    */   
/*    */   protected abstract T calc(Class paramClass);
/*    */   
/*    */   protected T nullClassValue() {
/* 30 */     throw new NullPointerException();
/*    */   }
/*    */   
/*    */   protected T nullObjectValue()
/*    */   {
/* 35 */     throw new NullPointerException();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\ClassCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */