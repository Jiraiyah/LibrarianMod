/*     */ package com.rwtema.extrautils2.utils.datastructures;
/*     */ 
/*     */ import gnu.trove.list.linked.TLinkedList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class WeakQueue<T> extends java.util.AbstractQueue<T>
/*     */ {
/*     */   final java.lang.ref.ReferenceQueue<T> q;
/*     */   TLinkedList<WeakQueue<T>.Node> list;
/*     */   
/*     */   public WeakQueue()
/*     */   {
/*  13 */     this.q = new java.lang.ref.ReferenceQueue();
/*  14 */     this.list = new TLinkedList();
/*     */   }
/*     */   
/*     */   public int size() {
/*  18 */     expungeStaleEntries();
/*  19 */     return this.list.size();
/*     */   }
/*     */   
/*     */   public boolean offer(T t)
/*     */   {
/*  24 */     expungeStaleEntries();
/*  25 */     return this.list.add(new Node(t));
/*     */   }
/*     */   
/*     */   public T poll()
/*     */   {
/*  30 */     expungeStaleEntries();
/*  31 */     return this.list.isEmpty() ? null : ((Node)this.list.remove(0)).get();
/*     */   }
/*     */   
/*     */   public T peek()
/*     */   {
/*  36 */     expungeStaleEntries();
/*  37 */     return this.list.isEmpty() ? null : ((Node)this.list.get(0)).get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  42 */   public void clear() { this.list.clear(); }
/*     */   
/*     */   private void expungeStaleEntries() {
/*     */     Object x;
/*  46 */     while ((x = this.q.poll()) != null) {
/*  47 */       synchronized (this.q)
/*     */       {
/*  49 */         WeakQueue<T>.Node e = (Node)x;
/*  50 */         this.list.remove(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @javax.annotation.Nonnull
/*     */   public Iterator<T> iterator()
/*     */   {
/*  58 */     expungeStaleEntries();
/*  59 */     return new NodeIterator();
/*     */   }
/*     */   
/*     */   private final class Node extends java.lang.ref.WeakReference<T> implements gnu.trove.list.TLinkable<WeakQueue<T>.Node> {
/*     */     private volatile WeakQueue<T>.Node next;
/*     */     private volatile WeakQueue<T>.Node prev;
/*     */     
/*     */     public Node() {
/*  67 */       super(WeakQueue.this.q);
/*     */     }
/*     */     
/*     */     public WeakQueue<T>.Node getNext()
/*     */     {
/*  72 */       return this.next;
/*     */     }
/*     */     
/*     */     public void setNext(WeakQueue<T>.Node linkable)
/*     */     {
/*  77 */       this.next = linkable;
/*     */     }
/*     */     
/*     */     public WeakQueue<T>.Node getPrevious()
/*     */     {
/*  82 */       return this.prev;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  87 */     public void setPrevious(WeakQueue<T>.Node linkable) { this.prev = linkable; } }
/*     */   
/*     */   private class NodeIterator implements Iterator<T> { Iterator<WeakQueue<T>.Node> iterator;
/*     */     WeakQueue<T>.Node curNode;
/*     */     T next;
/*     */     
/*  93 */     public NodeIterator() { this.iterator = new java.util.ArrayList(WeakQueue.this.list).iterator(); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void remove()
/*     */     {
/* 102 */       WeakQueue.this.list.remove(this.curNode);
/*     */     }
/*     */     
/*     */     public T next()
/*     */     {
/* 107 */       return (T)this.next;
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/*     */       do {
/* 113 */         if (!this.iterator.hasNext()) {
/* 114 */           this.next = null;
/* 115 */           return false;
/*     */         }
/*     */         
/* 118 */         this.curNode = ((WeakQueue.Node)this.iterator.next());
/* 119 */         this.next = this.curNode.get();
/* 120 */       } while (this.next == null);
/* 121 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\WeakQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */