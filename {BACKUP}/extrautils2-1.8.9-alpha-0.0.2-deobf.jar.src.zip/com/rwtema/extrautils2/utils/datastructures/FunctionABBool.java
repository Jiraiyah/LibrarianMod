package com.rwtema.extrautils2.utils.datastructures;

public abstract interface FunctionABBool<A, B>
{
  public abstract boolean apply(A paramA, B paramB);
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\FunctionABBool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */