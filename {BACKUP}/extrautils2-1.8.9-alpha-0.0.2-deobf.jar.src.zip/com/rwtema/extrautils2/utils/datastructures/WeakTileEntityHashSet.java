/*    */ package com.rwtema.extrautils2.utils.datastructures;
/*    */ 
/*    */ import com.rwtema.extrautils2.tile.XUTile;
/*    */ import java.util.Iterator;
/*    */ import java.util.WeakHashMap;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public class WeakTileEntityHashSet<T>
/*    */   extends WeakSet<T>
/*    */ {
/*    */   public WeakTileEntityHashSet() {}
/*    */   
/*    */   public WeakTileEntityHashSet(WeakHashMap<T, Object> baseMap)
/*    */   {
/* 16 */     super(baseMap);
/*    */   }
/*    */   
/*    */   @Nonnull
/*    */   public Iterator<T> iterator()
/*    */   {
/* 22 */     final Iterator<T> base = super.iterator();
/* 23 */     new Iterator()
/*    */     {
/*    */       T next;
/*    */       
/*    */       public boolean hasNext() {
/*    */         do {
/* 29 */           if (!base.hasNext()) return false;
/* 30 */           this.next = base.next();
/* 31 */         } while ((this.next == null) || (!XUTile.isLoaded((TileEntity)this.next)));
/* 32 */         return true;
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */       public T next()
/*    */       {
/* 39 */         return (T)this.next;
/*    */       }
/*    */       
/*    */       public void remove()
/*    */       {
/* 44 */         base.remove();
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\datastructures\WeakTileEntityHashSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */