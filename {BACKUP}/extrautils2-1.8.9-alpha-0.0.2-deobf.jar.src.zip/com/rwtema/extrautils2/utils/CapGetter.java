/*     */ package com.rwtema.extrautils2.utils;
/*     */ 
/*     */ import com.rwtema.extrautils2.fluids.FluidWrapper;
/*     */ import com.rwtema.extrautils2.fluids.IFluidInterface;
/*     */ import com.rwtema.extrautils2.transfernodes.IPipeConnect;
/*     */ import java.util.ArrayList;
/*     */ import java.util.IdentityHashMap;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.ISidedInventory;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraftforge.common.capabilities.Capability;
/*     */ import net.minecraftforge.common.capabilities.CapabilityManager;
/*     */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*     */ import net.minecraftforge.fluids.FluidTankInfo;
/*     */ import net.minecraftforge.fluids.IFluidHandler;
/*     */ import net.minecraftforge.fml.common.Loader;
/*     */ import net.minecraftforge.fml.common.LoaderState;
/*     */ import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
/*     */ import net.minecraftforge.items.IItemHandler;
/*     */ import net.minecraftforge.items.wrapper.InvWrapper;
/*     */ import net.minecraftforge.items.wrapper.SidedInvWrapper;
/*     */ 
/*     */ public class CapGetter<T>
/*     */ {
/*  25 */   public static CapGetter<IItemHandler> ItemHandler = new CapGetter(IItemHandler.class, new Converter[] { new Converter(ISidedInventory.class)new Converter
/*     */   {
/*     */     protected IItemHandler convertInstance(ISidedInventory type, EnumFacing side)
/*     */     {
/*  29 */       return side != null ? new SidedInvWrapper(type, side) : null;
/*     */     }
/*  25 */   }, new Converter(IInventory.class)
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     protected IItemHandler convertInstance(IInventory type, EnumFacing side)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  35 */       return new InvWrapper(type);
/*     */     }
/*  25 */   } });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   public static CapGetter<IPipeConnect> PipeConnect = new CapGetter(IPipeConnect.class, new Converter[0])
/*     */   {
/*     */     public boolean hasInterface(ICapabilityProvider provider, EnumFacing side) {
/*  43 */       return ((provider instanceof IPipeConnect)) && (((IPipeConnect)provider).forceConnect(side));
/*     */     }
/*     */     
/*     */     public IPipeConnect getInterface(ICapabilityProvider provider, EnumFacing side)
/*     */     {
/*  48 */       return null;
/*     */     }
/*     */   };
/*     */   
/*  52 */   public static CapGetter<IFluidInterface> fluids = new CapGetter(IFluidInterface.class, new Converter[] { new Converter(IFluidHandler.class)
/*     */   {
/*     */     public boolean canHandle(Object type, EnumFacing side)
/*     */     {
/*  56 */       if (!(type instanceof IFluidHandler)) return false;
/*  57 */       FluidTankInfo[] tankInfo = ((IFluidHandler)type).getTankInfo(side);
/*  58 */       return (tankInfo != null) && (tankInfo.length > 0);
/*     */     }
/*     */     
/*     */     protected IFluidInterface convertInstance(IFluidHandler type, EnumFacing side)
/*     */     {
/*  63 */       return new FluidWrapper(type, side);
/*     */     }
/*  52 */   } });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   public static ArrayList<CapGetter<?>> caps = com.google.common.collect.Lists.newArrayList(new CapGetter[] { ItemHandler, PipeConnect, fluids });
/*  68 */   private static IdentityHashMap<String, Capability<?>> providers = (IdentityHashMap)ObfuscationReflectionHelper.getPrivateValue(CapabilityManager.class, CapabilityManager.INSTANCE, new String[] { "providers" });
/*     */   final Class<T> clazz;
/*     */   final Converter<?, T>[] converters;
/*     */   boolean init;
/*     */   Capability<T> capability;
/*     */   
/*     */   public CapGetter(Class<T> clazz, Converter<?, T>... converters) {
/*  75 */     this.clazz = clazz;
/*  76 */     this.converters = converters;
/*     */   }
/*     */   
/*     */   static <T> Capability<T> getCapability(Class<T> clazz)
/*     */   {
/*  81 */     String intern = clazz.getName().intern();
/*  82 */     return (Capability)providers.get(intern);
/*     */   }
/*     */   
/*     */   public boolean hasInterface(ICapabilityProvider provider, EnumFacing side) {
/*  86 */     if (!this.init) {
/*  87 */       this.capability = getCapability(this.clazz);
/*  88 */       this.init = ((this.capability != null) || (Loader.instance().hasReachedState(LoaderState.AVAILABLE)));
/*     */     }
/*     */     
/*  91 */     if ((this.capability != null) && (provider.hasCapability(this.capability, side))) { return true;
/*     */     }
/*  93 */     if (this.clazz.isInstance(provider)) { return true;
/*     */     }
/*  95 */     for (Converter<?, T> converter : this.converters) {
/*  96 */       if (converter.canHandle(provider, side)) { return true;
/*     */       }
/*     */     }
/*     */     
/* 100 */     return false;
/*     */   }
/*     */   
/*     */   public T getInterface(ICapabilityProvider provider, EnumFacing side)
/*     */   {
/* 105 */     if (!this.init) {
/* 106 */       this.capability = getCapability(this.clazz);
/* 107 */       this.init = ((this.capability != null) || (Loader.instance().hasReachedState(LoaderState.AVAILABLE)));
/*     */     }
/*     */     
/* 110 */     if ((this.capability != null) && (provider.hasCapability(this.capability, side))) {
/* 111 */       return (T)provider.getCapability(this.capability, side);
/*     */     }
/* 113 */     if (this.clazz.isInstance(provider)) {
/* 114 */       return provider;
/*     */     }
/*     */     
/* 117 */     for (Converter<?, T> converter : this.converters) {
/* 118 */       T convert = converter.convert(provider, side);
/* 119 */       if (convert != null) { return convert;
/*     */       }
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */   
/*     */   public static abstract class Converter<S, T> {
/*     */     final Class<S> toConvert;
/*     */     
/*     */     protected Converter(Class<S> toConvert) {
/* 129 */       this.toConvert = toConvert;
/*     */     }
/*     */     
/*     */     public T convert(Object type, EnumFacing side) {
/* 133 */       return (T)(canHandle(type, side) ? convertInstance(type, side) : null);
/*     */     }
/*     */     
/*     */     public boolean canHandle(Object type, EnumFacing side) {
/* 137 */       return this.toConvert.isInstance(type);
/*     */     }
/*     */     
/*     */     protected abstract T convertInstance(S paramS, EnumFacing paramEnumFacing);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\CapGetter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */