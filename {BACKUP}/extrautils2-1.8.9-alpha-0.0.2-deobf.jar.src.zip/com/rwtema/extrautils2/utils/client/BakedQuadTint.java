/*    */ package com.rwtema.extrautils2.utils.client;
/*    */ 
/*    */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*    */ 
/*    */ public class BakedQuadTint extends BakedQuad
/*    */ {
/*    */   int tint;
/*    */   
/*    */   public BakedQuadTint(BakedQuad quad) {
/* 10 */     this(quad, quad.getTintIndex());
/*    */   }
/*    */   
/*    */   public BakedQuadTint(BakedQuad quad, int tintIndex) {
/* 14 */     super(quad.getVertexData(), tintIndex, quad.getFace());
/* 15 */     this.tint = tintIndex;
/*    */   }
/*    */   
/*    */   public BakedQuadTint(int[] vertexDataIn, int tintIndexIn, net.minecraft.util.EnumFacing faceIn) {
/* 19 */     super(vertexDataIn, tintIndexIn, faceIn);
/* 20 */     this.tint = tintIndexIn;
/*    */   }
/*    */   
/*    */   public BakedQuadTint setTint(int tint) {
/* 24 */     this.tint = tint;
/* 25 */     return this;
/*    */   }
/*    */   
/*    */   public int getTintIndex()
/*    */   {
/* 30 */     return this.tint;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\client\BakedQuadTint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */