/*     */ package com.rwtema.extrautils2.utils.client;
/*     */ 
/*     */ import gnu.trove.map.hash.TIntObjectHashMap;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.GlStateManager.BlendState;
/*     */ import net.minecraft.client.renderer.GlStateManager.BooleanState;
/*     */ import net.minecraft.client.renderer.GlStateManager.ClearState;
/*     */ import net.minecraft.client.renderer.GlStateManager.Color;
/*     */ import net.minecraft.client.renderer.GlStateManager.FogState;
/*     */ import net.minecraft.client.renderer.GlStateManager.PolygonOffsetState;
/*     */ import net.minecraft.client.renderer.GlStateManager.TexGen;
/*     */ import net.minecraft.client.renderer.GlStateManager.TexGenCoord;
/*     */ import net.minecraft.client.renderer.GlStateManager.TexGenState;
/*     */ 
/*     */ public class GLStateAttributes
/*     */ {
/*  19 */   static ArrayList<GlStateManager.BooleanState> booleanStates = com.google.common.collect.Lists.newArrayList(new GlStateManager.BooleanState[] { GlStateManager.alphaState.alphaTest, GlStateManager.colorMaterialState.colorMaterial, GlStateManager.blendState.blend, GlStateManager.depthState.depthTest, GlStateManager.fogState.fog, GlStateManager.cullState.cullFace, GlStateManager.polygonOffsetState.polygonOffsetFill, GlStateManager.polygonOffsetState.polygonOffsetLine, GlStateManager.colorLogicState.colorLogicOp, GlStateManager.rescaleNormalState, GlStateManager.normalizeState, GlStateManager.lightingState });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static TIntObjectHashMap<String> glAttrib;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  33 */     java.util.Collections.addAll(booleanStates, GlStateManager.lightState);
/*     */   }
/*     */   
/*  36 */   int alphaState_alphaFunc = GlStateManager.alphaState.func;
/*  37 */   float alphaState_alphaRef = GlStateManager.alphaState.ref;
/*  38 */   boolean textureState_enabled = GlStateManager.textureState[GlStateManager.activeTextureUnit].texture2DState.currentState;
/*  39 */   int textureState_name = GlStateManager.textureState[GlStateManager.activeTextureUnit].textureName;
/*  40 */   int colorMaterialState_face = GlStateManager.colorMaterialState.face;
/*  41 */   int colorMaterialState_mode = GlStateManager.colorMaterialState.mode;
/*  42 */   int blendState_srcFactor = GlStateManager.blendState.srcFactor;
/*  43 */   int blendState_dstFactor = GlStateManager.blendState.dstFactor;
/*  44 */   int blendState_srcFactorAlpha = GlStateManager.blendState.srcFactorAlpha;
/*  45 */   int blendState_dstFactorAlpha = GlStateManager.blendState.dstFactorAlpha;
/*  46 */   boolean depthState_maskEnabled = GlStateManager.depthState.maskEnabled;
/*  47 */   int depthState_depthFunc = GlStateManager.depthState.depthFunc;
/*  48 */   int fogState_field_179047_b = GlStateManager.fogState.mode;
/*  49 */   float fogState_field_179048_c = GlStateManager.fogState.density;
/*  50 */   float fogState_field_179045_d = GlStateManager.fogState.start;
/*  51 */   float fogState_field_179046_e = GlStateManager.fogState.end;
/*  52 */   int cullState_field_179053_b = GlStateManager.cullState.mode;
/*  53 */   float polygonOffsetState_field_179043_c = GlStateManager.polygonOffsetState.factor;
/*  54 */   float polygonOffsetState_field_179041_d = GlStateManager.polygonOffsetState.units;
/*  55 */   int colorLogicState_field_179196_b = GlStateManager.colorLogicState.opcode;
/*  56 */   double clearState_field_179205_a = GlStateManager.clearState.depth;
/*  57 */   float clearState_field_179203_b_r = GlStateManager.clearState.color.red;
/*  58 */   float clearState_field_179203_b_g = GlStateManager.clearState.color.green;
/*  59 */   float clearState_field_179203_b_b = GlStateManager.clearState.color.blue;
/*  60 */   float clearState_field_179203_b_a = GlStateManager.clearState.color.alpha;
/*  61 */   int activeTextureUnit = GlStateManager.activeTextureUnit;
/*  62 */   int activeShadeModel = GlStateManager.activeShadeModel;
/*  63 */   boolean colorMaskState_r = GlStateManager.colorMaskState.red;
/*  64 */   boolean colorMaskState_g = GlStateManager.colorMaskState.green;
/*  65 */   boolean colorMaskState_b = GlStateManager.colorMaskState.blue;
/*  66 */   boolean colorMaskState_a = GlStateManager.colorMaskState.alpha;
/*  67 */   float r = GlStateManager.colorState.red;
/*  68 */   float g = GlStateManager.colorState.green;
/*  69 */   float b = GlStateManager.colorState.blue;
/*  70 */   float a = GlStateManager.colorState.alpha;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */   boolean[] textureGen = new boolean[4];
/*  78 */   int[] coord = new int[4];
/*  79 */   int[] param = new int[4];
/*     */   
/*  81 */   private GLStateAttributes() { GlStateManager.TexGen[] values = GlStateManager.TexGen.values();
/*  82 */     for (int i = 0; i < values.length; i++) {
/*  83 */       GlStateManager.TexGenCoord texGenCoord = texGenCoord(values[i]);
/*  84 */       this.textureGen[i] = texGenCoord.textureGen.currentState;
/*  85 */       this.coord[i] = texGenCoord.coord;
/*  86 */       this.param[i] = texGenCoord.param;
/*     */     }
/*     */     
/*  89 */     this.boolStates = new boolean[booleanStates.size()];
/*  90 */     for (int i = 0; i < booleanStates.size(); i++) {
/*  91 */       this.boolStates[i] = ((GlStateManager.BooleanState)booleanStates.get(i)).currentState;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   boolean[] boolStates;
/*     */   
/*     */   private static GlStateManager.TexGenCoord texGenCoord(GlStateManager.TexGen p_179125_0_)
/*     */   {
/* 100 */     switch (p_179125_0_) {
/*     */     case S: 
/* 102 */       return GlStateManager.texGenState.s;
/*     */     case T: 
/* 104 */       return GlStateManager.texGenState.t;
/*     */     case R: 
/* 106 */       return GlStateManager.texGenState.r;
/*     */     case Q: 
/* 108 */       return GlStateManager.texGenState.q;
/*     */     }
/* 110 */     return GlStateManager.texGenState.s;
/*     */   }
/*     */   
/*     */   public static GLStateAttributes loadStates()
/*     */   {
/* 115 */     return new GLStateAttributes();
/*     */   }
/*     */   
/*     */   public String getBoolStatesString() {
/* 119 */     if (glAttrib == null) {
/* 120 */       glAttrib = new TIntObjectHashMap();
/* 121 */       for (Field field : org.lwjgl.opengl.GL11.class.getFields()) {
/* 122 */         if ((java.lang.reflect.Modifier.isStatic(field.getModifiers())) && (field.getType() == Integer.TYPE)) {
/*     */           try {
/* 124 */             int value = field.getInt(null);
/* 125 */             glAttrib.putIfAbsent(value, field.getName());
/*     */           } catch (IllegalAccessException e) {
/* 127 */             throw new RuntimeException(e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 133 */     StringBuilder builder = new StringBuilder("{");
/*     */     
/* 135 */     for (int i = 0; i < this.boolStates.length; i++) {
/* 136 */       if (i > 0) builder.append(", ");
/* 137 */       builder.append((String)glAttrib.get(((GlStateManager.BooleanState)booleanStates.get(i)).capability));
/* 138 */       builder.append("=");
/* 139 */       builder.append(this.boolStates[i]);
/*     */     }
/*     */     
/* 142 */     return builder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public void restore()
/*     */   {
/* 148 */     for (int i = 0; i < booleanStates.size(); i++) {
/* 149 */       ((GlStateManager.BooleanState)booleanStates.get(i)).setState(this.boolStates[i]);
/*     */     }
/*     */     
/* 152 */     GlStateManager.alphaFunc(this.alphaState_alphaFunc, this.alphaState_alphaRef);
/*     */     
/* 154 */     GlStateManager.setActiveTexture(this.activeTextureUnit + net.minecraft.client.renderer.OpenGlHelper.defaultTexUnit);
/*     */     
/* 156 */     if (this.textureState_enabled) {
/* 157 */       GlStateManager.enableTexture2D();
/*     */     } else
/* 159 */       GlStateManager.disableTexture2D();
/* 160 */     GlStateManager.bindTexture(this.textureState_name);
/*     */     
/*     */ 
/* 163 */     GlStateManager.tryBlendFuncSeparate(this.blendState_srcFactor, this.blendState_dstFactor, this.blendState_srcFactorAlpha, this.blendState_dstFactorAlpha);
/*     */     
/*     */ 
/* 166 */     GlStateManager.depthMask(this.depthState_maskEnabled);
/* 167 */     GlStateManager.depthFunc(this.depthState_depthFunc);
/*     */     
/* 169 */     GlStateManager.setFog(this.fogState_field_179047_b);
/* 170 */     GlStateManager.setFogDensity(this.fogState_field_179048_c);
/* 171 */     GlStateManager.setFogStart(this.fogState_field_179045_d);
/* 172 */     GlStateManager.setFogEnd(this.fogState_field_179046_e);
/*     */     
/* 174 */     GlStateManager.cullFace(this.cullState_field_179053_b);
/*     */     
/* 176 */     GlStateManager.doPolygonOffset(this.polygonOffsetState_field_179043_c, this.polygonOffsetState_field_179041_d);
/*     */     
/* 178 */     GlStateManager.colorLogicOp(this.colorLogicState_field_179196_b);
/*     */     
/* 180 */     GlStateManager.clearDepth(this.clearState_field_179205_a);
/*     */     
/* 182 */     GlStateManager.clearColor(this.clearState_field_179203_b_r, this.clearState_field_179203_b_g, this.clearState_field_179203_b_b, this.clearState_field_179203_b_a);
/*     */     
/* 184 */     GlStateManager.shadeModel(this.activeShadeModel);
/*     */     
/* 186 */     GlStateManager.colorMask(this.colorMaskState_r, this.colorMaskState_g, this.colorMaskState_b, this.colorMaskState_a);
/*     */     
/* 188 */     GlStateManager.color(this.r, this.g, this.b, this.a);
/*     */     
/* 190 */     GlStateManager.colorMaterial(this.colorMaterialState_face, this.colorMaterialState_mode);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 195 */     return "GLStateAttributes{boolStates=" + getBoolStatesString() + ", alphaState_alphaFunc=" + this.alphaState_alphaFunc + ", alphaState_alphaRef=" + this.alphaState_alphaRef + ", textureState_enabled=" + this.textureState_enabled + ", textureState_name=" + this.textureState_name + ", colorMaterialState_face=" + this.colorMaterialState_face + ", colorMaterialState_mode=" + this.colorMaterialState_mode + ", blendState_srcFactor=" + this.blendState_srcFactor + ", blendState_dstFactor=" + this.blendState_dstFactor + ", blendState_srcFactorAlpha=" + this.blendState_srcFactorAlpha + ", blendState_dstFactorAlpha=" + this.blendState_dstFactorAlpha + ", depthState_maskEnabled=" + this.depthState_maskEnabled + ", depthState_depthFunc=" + this.depthState_depthFunc + ", fogState_field_179047_b=" + this.fogState_field_179047_b + ", fogState_field_179048_c=" + this.fogState_field_179048_c + ", fogState_field_179045_d=" + this.fogState_field_179045_d + ", fogState_field_179046_e=" + this.fogState_field_179046_e + ", cullState_field_179053_b=" + this.cullState_field_179053_b + ", polygonOffsetState_field_179043_c=" + this.polygonOffsetState_field_179043_c + ", polygonOffsetState_field_179041_d=" + this.polygonOffsetState_field_179041_d + ", colorLogicState_field_179196_b=" + this.colorLogicState_field_179196_b + ", clearState_field_179205_a=" + this.clearState_field_179205_a + ", clearState_field_179203_b_r=" + this.clearState_field_179203_b_r + ", clearState_field_179203_b_g=" + this.clearState_field_179203_b_g + ", clearState_field_179203_b_b=" + this.clearState_field_179203_b_b + ", clearState_field_179203_b_a=" + this.clearState_field_179203_b_a + ", activeTextureUnit=" + this.activeTextureUnit + ", activeShadeModel=" + this.activeShadeModel + ", colorMaskState_r=" + this.colorMaskState_r + ", colorMaskState_g=" + this.colorMaskState_g + ", colorMaskState_b=" + this.colorMaskState_b + ", colorMaskState_a=" + this.colorMaskState_a + ", r=" + this.r + ", g=" + this.g + ", b=" + this.b + ", a=" + this.a + ", field_179067_a=" + java.util.Arrays.toString(this.textureGen) + ", field_179065_b=" + java.util.Arrays.toString(this.coord) + ", field_179066_c=" + java.util.Arrays.toString(this.param) + '}';
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\client\GLStateAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */