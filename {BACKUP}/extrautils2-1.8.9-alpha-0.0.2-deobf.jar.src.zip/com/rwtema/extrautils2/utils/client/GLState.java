/*    */ package com.rwtema.extrautils2.utils.client;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ 
/*    */ public abstract class GLState<T>
/*    */ {
/*  8 */   static final transient LinkedList<GLState<?>> toReset = new LinkedList();
/*    */   private final T value;
/*    */   private T oldValue;
/*    */   
/*    */   public GLState(T value)
/*    */   {
/* 14 */     this.value = value;
/*    */   }
/*    */   
/*    */   public static void resetStateQuads() {
/* 18 */     if (!toReset.isEmpty()) {
/* 19 */       synchronized (toReset) {
/*    */         GLState<?> poll;
/* 21 */         while ((poll = (GLState)toReset.poll()) != null) {
/* 22 */           poll.reset();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void setValue() {
/* 29 */     this.oldValue = getCachedState();
/* 30 */     if (!this.value.equals(this.oldValue)) {
/* 31 */       synchronized (toReset) {
/* 32 */         toReset.addFirst(this);
/*    */       }
/*    */     }
/* 35 */     setGLState(this.value);
/*    */   }
/*    */   
/*    */   public void reset() {
/* 39 */     setGLState(this.oldValue);
/*    */   }
/*    */   
/*    */   public abstract T getCachedState();
/*    */   
/*    */   public abstract void setGLState(T paramT);
/*    */   
/*    */   public static class DepthState extends GLState<Boolean>
/*    */   {
/*    */     public DepthState(boolean value) {
/* 49 */       super();
/*    */     }
/*    */     
/*    */     public Boolean getCachedState()
/*    */     {
/* 54 */       return Boolean.valueOf(GlStateManager.depthState.maskEnabled);
/*    */     }
/*    */     
/*    */     public void setGLState(Boolean value)
/*    */     {
/* 59 */       GlStateManager.depthMask(value.booleanValue());
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\client\GLState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */