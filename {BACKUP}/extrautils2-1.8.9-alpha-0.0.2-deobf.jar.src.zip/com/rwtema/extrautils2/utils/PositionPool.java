/*    */ package com.rwtema.extrautils2.utils;
/*    */ 
/*    */ import gnu.trove.map.hash.TLongObjectHashMap;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.Vec3i;
/*    */ 
/*    */ public class PositionPool
/*    */ {
/* 10 */   public static final BlockPos MID_HEIGHT = new BlockPos(0, 128, 0);
/*    */   
/* 12 */   TLongObjectHashMap<BlockPos> pool = new TLongObjectHashMap();
/*    */   
/*    */   public BlockPos getPos(int x, int y, int z)
/*    */   {
/* 16 */     long key = 128L + y | z + 33554432L << 9 | x + 33554432L << 37;
/*    */     
/* 18 */     BlockPos blockPos = (BlockPos)this.pool.get(key);
/* 19 */     if (blockPos != null) { return blockPos;
/*    */     }
/* 21 */     blockPos = new BlockPos(x, y, z);
/* 22 */     this.pool.put(key, blockPos);
/* 23 */     return blockPos;
/*    */   }
/*    */   
/*    */   public BlockPos add(BlockPos input, int x, int y, int z)
/*    */   {
/* 28 */     return (x == 0) && (y == 0) && (z == 0) ? input : getPos(input.getX() + x, input.getY() + y, input.getZ() + z);
/*    */   }
/*    */   
/*    */   public BlockPos add(BlockPos input, Vec3i vec) {
/* 32 */     return (vec.getX() == 0) && (vec.getY() == 0) && (vec.getZ() == 0) ? input : getPos(input.getX() + vec.getX(), input.getY() + vec.getY(), input.getZ() + vec.getZ());
/*    */   }
/*    */   
/*    */   public BlockPos subtract(BlockPos input, Vec3i vec) {
/* 36 */     return (vec.getX() == 0) && (vec.getY() == 0) && (vec.getZ() == 0) ? input : getPos(input.getX() - vec.getX(), input.getY() - vec.getY(), input.getZ() - vec.getZ());
/*    */   }
/*    */   
/*    */   public BlockPos subtract(BlockPos input, int x, int y, int z) {
/* 40 */     return (x == 0) && (y == 0) && (z == 0) ? input : getPos(input.getX() - x, input.getY() - y, input.getZ() - z);
/*    */   }
/*    */   
/*    */   public BlockPos offset(BlockPos input, EnumFacing facing) {
/* 44 */     return getPos(input.getX() + facing.getFrontOffsetX(), input.getY() + facing.getFrontOffsetY(), input.getZ() + facing.getFrontOffsetZ());
/*    */   }
/*    */   
/*    */   public BlockPos offset(BlockPos input, EnumFacing facing, int n) {
/* 48 */     return n == 0 ? input : getPos(input.getX() + facing.getFrontOffsetX() * n, input.getY() + facing.getFrontOffsetY() * n, input.getZ() + facing.getFrontOffsetZ() * n);
/*    */   }
/*    */   
/*    */   public BlockPos intern(BlockPos pos) {
/* 52 */     return getPos(pos.getX(), pos.getY(), pos.getZ());
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\PositionPool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */