/*    */ package com.rwtema.extrautils2.utils.errors;
/*    */ 
/*    */ public class LegalException extends RuntimeException {
/*    */   public LegalException(LawLevel lawLevel, String message) {
/*  5 */     super(message);
/*    */   }
/*    */   
/*    */   public static enum LawLevel {
/*  9 */     CONSTITUTIONAL, 
/* 10 */     FEDERAL, 
/* 11 */     STATE, 
/* 12 */     LOCAL;
/*    */     
/*    */     private LawLevel() {}
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\errors\LegalException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */