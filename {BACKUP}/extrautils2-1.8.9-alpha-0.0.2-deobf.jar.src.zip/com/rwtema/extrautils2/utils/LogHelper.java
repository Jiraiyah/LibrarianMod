/*    */ package com.rwtema.extrautils2.utils;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import java.util.HashSet;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class LogHelper
/*    */ {
/* 14 */   private static final ThreadLocal<HashSet<String>> one_time_strings_set = new ThreadLocal()
/*    */   {
/*    */     protected HashSet<String> initialValue() {
/* 17 */       return new HashSet();
/*    */     }
/*    */   };
/*    */   
/*    */   public static ArrayList<String> getOneTimeStrings() {
/* 22 */     return one_time_strings;
/*    */   }
/*    */   
/* 25 */   private static final ArrayList<String> one_time_strings = new ArrayList();
/*    */   
/* 27 */   public static Logger logger = LogManager.getLogger("ExtraUtils2");
/* 28 */   public static boolean isDeObf = false;
/*    */   
/*    */   static {
/*    */     try {
/* 32 */       World.class.getMethod("getBlockState", new Class[] { BlockPos.class });
/* 33 */       isDeObf = true;
/*    */     } catch (Throwable ex) {
/* 35 */       isDeObf = false;
/*    */     }
/*    */   }
/*    */   
/* 39 */   SimpleDateFormat format = new SimpleDateFormat();
/*    */   
/*    */   public static void debug(Object info, Object... info2) {
/* 42 */     if (isDeObf) {
/* 43 */       String temp = "Debug: " + info;
/* 44 */       for (Object t : info2) {
/* 45 */         temp = temp + " " + t;
/*    */       }
/* 47 */       logger.info(info);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void info(Object info, Object... info2) {
/* 52 */     String temp = "" + info;
/* 53 */     for (Object t : info2) {
/* 54 */       temp = temp + " " + t;
/*    */     }
/* 56 */     logger.info(info);
/*    */   }
/*    */   
/*    */   public static void fine(Object info, Object... info2) {
/* 60 */     String temp = "" + info;
/* 61 */     for (Object t : info2) {
/* 62 */       temp = temp + " " + t;
/*    */     }
/* 64 */     logger.debug(temp);
/*    */   }
/*    */   
/*    */   public static void errorThrowable(String message, Throwable t) {
/* 68 */     logger.error(message, t);
/*    */   }
/*    */   
/*    */   public static void error(Object info, Object... info2) {
/* 72 */     String temp = "" + info;
/* 73 */     for (Object t : info2) {
/* 74 */       temp = temp + " " + t;
/*    */     }
/* 76 */     logger.error(info);
/*    */   }
/*    */   
/*    */   public static void oneTimeInfo(String string) {
/* 80 */     if (((HashSet)one_time_strings_set.get()).add(string)) {
/* 81 */       synchronized (one_time_strings) {
/* 82 */         String now = new SimpleDateFormat("HH.mm.ss").format(new Date());
/* 83 */         one_time_strings.add("[" + Thread.currentThread().getName() + "](" + now + "): " + string);
/*    */       }
/* 85 */       fine("OTL: " + string, new Object[0]);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\LogHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */