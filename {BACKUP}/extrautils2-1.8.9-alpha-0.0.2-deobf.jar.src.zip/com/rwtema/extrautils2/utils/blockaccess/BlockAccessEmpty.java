/*    */ package com.rwtema.extrautils2.utils.blockaccess;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.WorldType;
/*    */ import net.minecraft.world.biome.BiomeGenBase;
/*    */ 
/*    */ public class BlockAccessEmpty implements net.minecraft.world.IBlockAccess
/*    */ {
/* 13 */   public static BlockAccessEmpty INSTANCE = new BlockAccessEmpty();
/*    */   
/*    */   public TileEntity getTileEntity(BlockPos pos)
/*    */   {
/* 17 */     return null;
/*    */   }
/*    */   
/*    */   public int getCombinedLight(BlockPos pos, int lightValue)
/*    */   {
/* 22 */     return 0;
/*    */   }
/*    */   
/*    */   public IBlockState getBlockState(BlockPos pos)
/*    */   {
/* 27 */     return net.minecraft.init.Blocks.air.getDefaultState();
/*    */   }
/*    */   
/*    */   public boolean isAirBlock(BlockPos pos)
/*    */   {
/* 32 */     return true;
/*    */   }
/*    */   
/*    */   public BiomeGenBase getBiomeGenForCoords(BlockPos pos)
/*    */   {
/* 37 */     return BiomeGenBase.plains;
/*    */   }
/*    */   
/*    */   public boolean extendedLevelsInChunkCache()
/*    */   {
/* 42 */     return false;
/*    */   }
/*    */   
/*    */   public int getStrongPower(BlockPos pos, EnumFacing direction)
/*    */   {
/* 47 */     return 0;
/*    */   }
/*    */   
/*    */   public WorldType getWorldType()
/*    */   {
/* 52 */     return WorldType.DEFAULT;
/*    */   }
/*    */   
/*    */   public boolean isSideSolid(BlockPos pos, EnumFacing side, boolean _default)
/*    */   {
/* 57 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\blockaccess\BlockAccessEmpty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */