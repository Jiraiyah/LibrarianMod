/*    */ package com.rwtema.extrautils2.utils.blockaccess;
/*    */ 
/*    */ import java.util.Map;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.LongHashMap;
/*    */ import net.minecraft.world.ChunkCoordIntPair;
/*    */ import net.minecraft.world.WorldServer;
/*    */ import net.minecraft.world.WorldType;
/*    */ import net.minecraft.world.biome.BiomeGenBase;
/*    */ import net.minecraft.world.chunk.Chunk;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class ThreadSafeBlockAccess implements net.minecraft.world.IBlockAccess
/*    */ {
/*    */   public final LongHashMap<Chunk> chunkMap;
/*    */   WorldServer world;
/*    */   
/*    */   public ThreadSafeBlockAccess(WorldServer world)
/*    */   {
/* 25 */     this.world = world;
/* 26 */     this.chunkMap = world.field_73059_b.id2ChunkMap;
/*    */   }
/*    */   
/*    */   public Chunk getChunk(BlockPos pos) {
/* 30 */     long p_76164_1_ = ChunkCoordIntPair.chunkXZ2Int(pos.getX() >> 4, pos.getZ() >> 4);
/* 31 */     return (Chunk)this.chunkMap.getValueByKey(p_76164_1_);
/*    */   }
/*    */   
/*    */   public TileEntity getTileEntity(BlockPos pos)
/*    */   {
/* 36 */     Chunk chunk = getChunk(pos);
/* 37 */     if (chunk == null) return null;
/* 38 */     Map<BlockPos, TileEntity> map = chunk.getTileEntityMap();
/* 39 */     TileEntity tileEntity = (TileEntity)map.get(pos);
/* 40 */     if ((tileEntity == null) || (tileEntity.isInvalid()) || (!pos.equals(tileEntity.getPos()))) return null;
/* 41 */     return tileEntity;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public int getCombinedLight(BlockPos pos, int lightValue)
/*    */   {
/* 47 */     return 0;
/*    */   }
/*    */   
/*    */   public IBlockState getBlockState(BlockPos pos)
/*    */   {
/* 52 */     Chunk chunk = getChunk(pos);
/* 53 */     if (chunk == null) return net.minecraft.init.Blocks.air.getDefaultState();
/* 54 */     return chunk.getBlockState(pos);
/*    */   }
/*    */   
/*    */   public boolean isAirBlock(BlockPos pos)
/*    */   {
/* 59 */     return getBlockState(pos).getBlock().isAir(this, pos);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public BiomeGenBase getBiomeGenForCoords(BlockPos pos)
/*    */   {
/* 65 */     return BiomeGenBase.forest;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean extendedLevelsInChunkCache()
/*    */   {
/* 71 */     return false;
/*    */   }
/*    */   
/*    */   public int getStrongPower(BlockPos pos, EnumFacing direction)
/*    */   {
/* 76 */     IBlockState iblockstate = getBlockState(pos);
/* 77 */     return iblockstate.getBlock().getStrongPower(this, pos, iblockstate, direction);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public WorldType getWorldType()
/*    */   {
/* 83 */     return this.world.getWorldType();
/*    */   }
/*    */   
/*    */   public boolean isSideSolid(BlockPos pos, EnumFacing side, boolean _default)
/*    */   {
/* 88 */     Chunk chunk = getChunk(pos);
/* 89 */     if ((chunk == null) || (chunk.isEmpty())) return _default;
/* 90 */     return getBlockState(pos).getBlock().isSideSolid(this, pos, side);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\blockaccess\ThreadSafeBlockAccess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */