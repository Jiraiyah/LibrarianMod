/*    */ package com.rwtema.extrautils2.utils.blockaccess;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.WorldType;
/*    */ import net.minecraft.world.biome.BiomeGenBase;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BlockAccessDelegate implements IBlockAccess
/*    */ {
/*    */   @Nullable
/*    */   public IBlockAccess base;
/*    */   
/*    */   public BlockAccessDelegate()
/*    */   {
/* 20 */     this(null);
/*    */   }
/*    */   
/*    */   public BlockAccessDelegate(@Nullable IBlockAccess base) {
/* 24 */     this.base = base;
/*    */   }
/*    */   
/*    */   public net.minecraft.tileentity.TileEntity getTileEntity(BlockPos pos)
/*    */   {
/* 29 */     if (this.base == null) return null;
/* 30 */     return this.base.getTileEntity(pos);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public int getCombinedLight(BlockPos pos, int lightValue)
/*    */   {
/* 36 */     if (this.base == null) return 0;
/* 37 */     return this.base.getCombinedLight(pos, lightValue);
/*    */   }
/*    */   
/*    */   public IBlockState getBlockState(BlockPos pos)
/*    */   {
/* 42 */     if (this.base == null) return net.minecraft.init.Blocks.air.getDefaultState();
/* 43 */     return this.base.getBlockState(pos);
/*    */   }
/*    */   
/*    */   public boolean isAirBlock(BlockPos pos)
/*    */   {
/* 48 */     return (this.base == null) || (this.base.isAirBlock(pos));
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public BiomeGenBase getBiomeGenForCoords(BlockPos pos)
/*    */   {
/* 54 */     if (this.base == null) return BiomeGenBase.plains;
/* 55 */     return this.base.getBiomeGenForCoords(pos);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean extendedLevelsInChunkCache()
/*    */   {
/* 61 */     return (this.base != null) && (this.base.extendedLevelsInChunkCache());
/*    */   }
/*    */   
/*    */   public int getStrongPower(BlockPos pos, EnumFacing direction)
/*    */   {
/* 66 */     if (this.base == null) return 0;
/* 67 */     return this.base.getStrongPower(pos, direction);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public WorldType getWorldType()
/*    */   {
/* 73 */     if (this.base == null) return WorldType.DEFAULT;
/* 74 */     return this.base.getWorldType();
/*    */   }
/*    */   
/*    */   public boolean isSideSolid(BlockPos pos, EnumFacing side, boolean _default)
/*    */   {
/* 79 */     return (this.base != null) && (this.base.isSideSolid(pos, side, _default));
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\blockaccess\BlockAccessDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */