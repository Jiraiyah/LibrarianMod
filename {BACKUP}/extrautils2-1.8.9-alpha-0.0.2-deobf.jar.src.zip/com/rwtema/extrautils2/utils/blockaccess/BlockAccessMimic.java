/*    */ package com.rwtema.extrautils2.utils.blockaccess;
/*    */ 
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockAccessMimic
/*    */   extends BlockAccessDelegate
/*    */ {
/*    */   public IBlockState state;
/*    */   public BlockPos myPos;
/*    */   
/*    */   public IBlockState getBlockState(BlockPos pos)
/*    */   {
/* 19 */     if ((this.state != null) && (pos.equals(this.myPos))) return this.state;
/* 20 */     return super.getBlockState(pos);
/*    */   }
/*    */   
/*    */   public boolean isAirBlock(BlockPos pos)
/*    */   {
/* 25 */     if ((this.state != null) && (pos.equals(this.myPos))) return this.state.getBlock() == Blocks.air;
/* 26 */     return super.isAirBlock(pos);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\blockaccess\BlockAccessMimic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */