/*   */ package com.rwtema.extrautils2.utils;
/*   */ 
/*   */ import java.util.Random;
/*   */ 
/*   */ public class XURandom {
/* 6 */   public static final Random rand = new Random();
/*   */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\XURandom.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */