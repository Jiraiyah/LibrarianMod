/*     */ package com.rwtema.extrautils2.utils;
/*     */ 
/*     */ import com.google.common.base.Throwables;
/*     */ import com.rwtema.extrautils2.ExtraUtils2;
/*     */ import com.rwtema.extrautils2.backend.ClientCallable;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.HashMap;
/*     */ import java.util.IllegalFormatException;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.TreeMap;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.resources.IResource;
/*     */ import net.minecraft.client.resources.IResourceManager;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraftforge.fml.relauncher.FMLLaunchHandler;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class Lang
/*     */ {
/*  35 */   private static final TreeMap<String, String> lang = ExtraUtils2.deobf_folder ? new TreeMap() : null;
/*  36 */   private static final HashMap<String, String> textKey = new HashMap();
/*     */   private static final int MAX_KEY_LEN = 32;
/*  38 */   private static final TObjectIntHashMap<String> numRandomEntries = new TObjectIntHashMap();
/*     */   
/*     */   static {
/*  41 */     if ((ExtraUtils2.deobf_folder) && (FMLLaunchHandler.side() == Side.CLIENT)) {
/*     */       try {
/*  43 */         FileInputStream fis = null;
/*     */         try {
/*  45 */           File file = getFile();
/*  46 */           fis = new FileInputStream(file);
/*  47 */           readStream(fis, true);
/*     */         } finally {
/*  49 */           if (fis != null) {
/*  50 */             fis.close();
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (FileNotFoundException ignore) {}catch (IOException e) {
/*  55 */         e.printStackTrace();
/*     */       }
/*     */       
/*  58 */       ExtraUtils2.proxy.run(new ClientCallable()
/*     */       {
/*     */         @SideOnly(Side.CLIENT)
/*     */         public void runClient() {
/*  62 */           ResourceLocation resourceLocation = new ResourceLocation("extrautils2", "lang/en_US.lang");
/*     */           try {
/*  64 */             IResource resource = Minecraft.getMinecraft().getResourceManager().getResource(resourceLocation);
/*  65 */             InputStream stream = null;
/*     */             try {
/*  67 */               stream = resource.getInputStream();
/*  68 */               Lang.readStream(stream, false);
/*     */             } finally {
/*  70 */               if (stream != null)
/*  71 */                 stream.close();
/*     */             }
/*     */           } catch (IOException e) {
/*  74 */             throw Throwables.propagate(e);
/*     */           }
/*     */           
/*  77 */           Lang.createMissedFile();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void readStream(InputStream stream, boolean safe)
/*     */   {
/*  89 */     HashMap<String, String> langMap = net.minecraft.util.StringTranslate.parseLangFile(stream);
/*  90 */     if (safe) {
/*  91 */       for (Map.Entry<String, String> entry : langMap.entrySet()) {
/*  92 */         String key = makeKey((String)entry.getValue());
/*  93 */         if (!key.equals(entry.getKey()))
/*  94 */           lang.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     } else {
/*  97 */       lang.putAll(langMap);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String translate(String text) {
/* 102 */     return translatePrefix(text);
/*     */   }
/*     */   
/*     */   public static String translatePrefix(String text) {
/* 106 */     String key = getKey(text);
/* 107 */     return translate(key, text);
/*     */   }
/*     */   
/*     */   public static String getKey(String text) {
/* 111 */     String key = (String)textKey.get(text);
/* 112 */     if (key == null) {
/* 113 */       key = makeKey(text);
/* 114 */       textKey.put(text, key);
/* 115 */       if (ExtraUtils2.deobf_folder) {
/* 116 */         translate(key, text);
/*     */       }
/*     */     }
/* 119 */     return key;
/*     */   }
/*     */   
/*     */   private static String makeKey(String text)
/*     */   {
/* 124 */     String t = stripText(text);
/* 125 */     String key = "extrautils2.text." + t;
/* 126 */     return key;
/*     */   }
/*     */   
/*     */   @Nonnull
/*     */   public static String stripText(String text) {
/* 131 */     String t = text.replaceAll("([^A-Za-z\\s])", "").trim();
/* 132 */     t = t.replaceAll("\\s+", ".").toLowerCase();
/* 133 */     if (t.length() > 32) {
/* 134 */       int n = t.indexOf('.', 32);
/* 135 */       if (n != -1)
/* 136 */         t = t.substring(0, n);
/*     */     }
/* 138 */     return t;
/*     */   }
/*     */   
/*     */   public static String translate(String key, String _default) {
/* 142 */     if (StatCollector.canTranslate(key))
/* 143 */       return StatCollector.translateToLocal(key);
/* 144 */     initKey(key, _default);
/* 145 */     return _default;
/*     */   }
/*     */   
/*     */   public static String initKey(String key, String _default) {
/* 149 */     if ((ExtraUtils2.deobf_folder) && (FMLLaunchHandler.side() == Side.CLIENT) && 
/* 150 */       (!_default.equals(lang.get(key)))) {
/* 151 */       lang.put(key, _default);
/* 152 */       createMissedFile();
/*     */     }
/*     */     
/* 155 */     return key;
/*     */   }
/*     */   
/*     */   public static void createMissedFile() {
/* 159 */     PrintWriter out = null;
/*     */     try {
/*     */       try {
/* 162 */         File file = getFile();
/* 163 */         if ((file.getParentFile() != null) && 
/* 164 */           (file.getParentFile().mkdirs())) {
/* 165 */           LogHelper.fine("Making Translation Directory", new Object[0]);
/*     */         }
/*     */         
/* 168 */         out = new PrintWriter(new java.io.BufferedWriter(new FileWriter(file)));
/* 169 */         t = null;
/* 170 */         for (Map.Entry<String, String> entry : lang.entrySet()) {
/* 171 */           int i = ((String)entry.getKey()).indexOf('.');
/* 172 */           if (i < 0) {
/* 173 */             i = 1;
/*     */           }
/*     */           
/* 176 */           String s = ((String)entry.getKey()).substring(0, i);
/* 177 */           if ((t != null) && 
/* 178 */             (!t.equals(s))) {
/* 179 */             out.println("");
/*     */           }
/*     */           
/* 182 */           t = s;
/*     */           
/* 184 */           out.println((String)entry.getKey() + "=" + (String)entry.getValue());
/*     */         }
/*     */       } finally {
/*     */         String t;
/* 188 */         if (out != null)
/* 189 */           out.close();
/*     */       }
/*     */     } catch (Exception err) {
/* 192 */       err.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private static File getFile() {
/* 197 */     return new File(new File(new File("."), "debug_text"), "missed_en_US.lang");
/*     */   }
/*     */   
/*     */   public static ChatComponentTranslation chat(String message, Object... args) {
/* 201 */     String key = getKey(message);
/* 202 */     if (StatCollector.canTranslate(key)) {
/* 203 */       return new ChatComponentTranslation(key, args);
/*     */     }
/* 205 */     return new ChatComponentTranslation(message, args);
/*     */   }
/*     */   
/*     */   public static String translateArgs(boolean dummy, String key, String _default, Object... args) {
/* 209 */     String translate = translate(key, _default);
/*     */     try {
/* 211 */       return String.format(translate, args);
/*     */     } catch (IllegalFormatException err) {
/* 213 */       throw new RuntimeException("Message: \"" + _default + "\" with key : \"" + key + "\" and translation: \"" + translate + "\"", err);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String translateArgs(String message, Object... args) {
/* 218 */     String translate = translate(message);
/*     */     try {
/* 220 */       return String.format(translate, args);
/*     */     } catch (IllegalFormatException err) {
/* 222 */       throw new RuntimeException("Message: \"" + message + "\" with key : \"" + getKey(message) + "\" and translation: \"" + translate + "\"", err);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getItemName(Block block) {
/* 227 */     return getItemName(new ItemStack(block));
/*     */   }
/*     */   
/*     */   public static String getItemName(Item item) {
/* 231 */     return getItemName(new ItemStack(item));
/*     */   }
/*     */   
/*     */   public static String getItemName(ItemStack stack) {
/* 235 */     return stack.getDisplayName();
/*     */   }
/*     */   
/*     */   public static String random(String key) {
/* 239 */     return random(key, XURandom.rand);
/*     */   }
/*     */   
/*     */   public static String random(String key, Random rand) {
/* 243 */     int n = getNumSelections(key);
/* 244 */     if (n == 0) {
/* 245 */       return StatCollector.translateToLocal(key);
/*     */     }
/* 247 */     return StatCollector.translateToLocal(key + "." + rand.nextInt(n));
/*     */   }
/*     */   
/*     */   public static String random(String key, int index)
/*     */   {
/* 252 */     int n = getNumSelections(key);
/* 253 */     int i = Math.abs(index) % n;
/* 254 */     return StatCollector.translateToLocal(key + "." + i);
/*     */   }
/*     */   
/*     */   private static int getNumSelections(String key) { int i;
/*     */     int i;
/* 259 */     if (numRandomEntries.containsKey(key)) {
/* 260 */       i = numRandomEntries.get(key);
/*     */     } else {
/* 262 */       i = 0;
/* 263 */       while (StatCollector.canTranslate(key + "." + i)) {
/* 264 */         i++;
/*     */       }
/* 266 */       i++;
/* 267 */       numRandomEntries.put(key, i);
/*     */     }
/* 269 */     return i;
/*     */   }
/*     */   
/*     */   public static void init() {}
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\Lang.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */