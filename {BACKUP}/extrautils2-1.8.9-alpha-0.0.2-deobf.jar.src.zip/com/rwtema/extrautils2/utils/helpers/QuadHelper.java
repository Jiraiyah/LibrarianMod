/*     */ package com.rwtema.extrautils2.utils.helpers;
/*     */ 
/*     */ import com.rwtema.extrautils2.backend.model.Textures;
/*     */ import com.rwtema.extrautils2.backend.model.UV;
/*     */ import java.util.HashMap;
/*     */ import javax.vecmath.Matrix4f;
/*     */ import javax.vecmath.Vector4f;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.vertex.VertexFormat;
/*     */ import net.minecraft.client.renderer.vertex.VertexFormatElement;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraftforge.client.ForgeHooksClient;
/*     */ import net.minecraftforge.client.model.TRSRTransformation;
/*     */ import net.minecraftforge.client.model.pipeline.UnpackedBakedQuad.Builder;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuadHelper
/*     */ {
/*     */   public static BakedQuad buildBoxQuad(VertexFormat format, float x0, float y0, float z0, float u0, float v0, float x1, float y1, float z1, float u1, float v1, float x2, float y2, float z2, float u2, float v2, float x3, float y3, float z3, float u3, float v3)
/*     */   {
/*  29 */     Vec3 c = new Vec3((x0 + x1) / 2.0F, (y0 + y1) / 2.0F, (y0 + y1) / 2.0F);
/*  30 */     Vec3 a = new Vec3(x0, y0, z0).subtract(c);
/*  31 */     Vec3 b = new Vec3(x1, y1, z1).subtract(c);
/*  32 */     Vec3 normal = a.crossProduct(b);
/*     */     
/*  34 */     EnumFacing side = EnumFacing.getFacingFromVector((float)normal.xCoord, (float)normal.yCoord, (float)normal.zCoord);
/*  35 */     return buildQuad(format, TRSRTransformation.identity(), side, -1, x0, y0, z0, u0, v0, x1, y1, z1, u1, v1, x2, y2, z2, u2, v2, x3, y3, z3, u3, v3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BakedQuad buildQuad(VertexFormat format, TRSRTransformation transform, EnumFacing side, int tint, float x0, float y0, float z0, float u0, float v0, int c0, float x1, float y1, float z1, float u1, float v1, int c1, float x2, float y2, float z2, float u2, float v2, int c2, float x3, float y3, float z3, float u3, float v3, int c3)
/*     */   {
/*  49 */     UnpackedBakedQuad.Builder builder = new UnpackedBakedQuad.Builder(format);
/*  50 */     putQuad(format, transform, side, tint, x0, y0, z0, u0, v0, c0, x1, y1, z1, u1, v1, c1, x2, y2, z2, u2, v2, c2, x3, y3, z3, u3, v3, c3, builder);
/*  51 */     return builder.build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void putQuad(VertexFormat format, TRSRTransformation transform, EnumFacing side, int tint, float x0, float y0, float z0, float u0, float v0, int c0, float x1, float y1, float z1, float u1, float v1, int c1, float x2, float y2, float z2, float u2, float v2, int c2, float x3, float y3, float z3, float u3, float v3, int c3, UnpackedBakedQuad.Builder builder)
/*     */   {
/*  60 */     builder.setQuadTint(tint);
/*  61 */     builder.setQuadOrientation(side);
/*  62 */     builder.setQuadColored();
/*  63 */     putVertex(builder, format, transform, side, x0, y0, z0, u0, v0, c0);
/*  64 */     putVertex(builder, format, transform, side, x1, y1, z1, u1, v1, c1);
/*  65 */     putVertex(builder, format, transform, side, x2, y2, z2, u2, v2, c2);
/*  66 */     putVertex(builder, format, transform, side, x3, y3, z3, u3, v3, c3);
/*     */   }
/*     */   
/*     */   public static void putVertex(UnpackedBakedQuad.Builder builder, VertexFormat format, TRSRTransformation transform, EnumFacing side, float x, float y, float z, float u, float v, int c) {
/*  70 */     Vector4f vec = new Vector4f();
/*  71 */     for (int e = 0; e < format.getElementCount(); e++) {
/*  72 */       switch (format.getElement(e).getUsage()) {
/*     */       case POSITION: 
/*  74 */         vec.x = x;
/*  75 */         vec.y = y;
/*  76 */         vec.z = z;
/*  77 */         vec.w = 1.0F;
/*  78 */         transform.getMatrix().transform(vec);
/*  79 */         builder.put(e, new float[] { vec.x, vec.y, vec.z, vec.w });
/*  80 */         break;
/*     */       case COLOR: 
/*  82 */         builder.put(e, new float[] { ColorHelper.getR(c) / 255.0F, ColorHelper.getG(c) / 255.0F, ColorHelper.getB(c) / 255.0F, ColorHelper.getA(c) / 255.0F });
/*  83 */         break;
/*     */       case UV: 
/*  85 */         if (format.getElement(e).getIndex() == 0)
/*  86 */           builder.put(e, new float[] { u, v, 0.0F, 1.0F });
/*  87 */         break;
/*     */       
/*     */       case NORMAL: 
/*  90 */         builder.put(e, new float[] { side.getFrontOffsetX(), side.getFrontOffsetY(), side.getFrontOffsetZ(), 0.0F });
/*  91 */         break;
/*     */       }
/*  93 */       builder.put(e, new float[0]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static TRSRTransformation rotate(float angle, Vector3f axis, TRSRTransformation transform)
/*     */   {
/* 100 */     Matrix4f matrix = transform.getMatrix();
/* 101 */     return new TRSRTransformation(rotate(angle, axis, matrix, matrix));
/*     */   }
/*     */   
/*     */   public static Matrix4f rotate(float angle, Vector3f axis, Matrix4f src, Matrix4f dest)
/*     */   {
/* 106 */     if (dest == null)
/* 107 */       dest = new Matrix4f();
/* 108 */     float c = (float)Math.cos(angle);
/* 109 */     float s = (float)Math.sin(angle);
/* 110 */     float oneminusc = 1.0F - c;
/* 111 */     float xy = axis.x * axis.y;
/* 112 */     float yz = axis.y * axis.z;
/* 113 */     float xz = axis.x * axis.z;
/* 114 */     float xs = axis.x * s;
/* 115 */     float ys = axis.y * s;
/* 116 */     float zs = axis.z * s;
/*     */     
/* 118 */     float f00 = axis.x * axis.x * oneminusc + c;
/* 119 */     float f01 = xy * oneminusc + zs;
/* 120 */     float f02 = xz * oneminusc - ys;
/*     */     
/* 122 */     float f10 = xy * oneminusc - zs;
/* 123 */     float f11 = axis.y * axis.y * oneminusc + c;
/* 124 */     float f12 = yz * oneminusc + xs;
/*     */     
/* 126 */     float f20 = xz * oneminusc + ys;
/* 127 */     float f21 = yz * oneminusc - xs;
/* 128 */     float f22 = axis.z * axis.z * oneminusc + c;
/*     */     
/* 130 */     float t00 = src.m00 * f00 + src.m10 * f01 + src.m20 * f02;
/* 131 */     float t01 = src.m01 * f00 + src.m11 * f01 + src.m21 * f02;
/* 132 */     float t02 = src.m02 * f00 + src.m12 * f01 + src.m22 * f02;
/* 133 */     float t03 = src.m03 * f00 + src.m13 * f01 + src.m23 * f02;
/* 134 */     float t10 = src.m00 * f10 + src.m10 * f11 + src.m20 * f12;
/* 135 */     float t11 = src.m01 * f10 + src.m11 * f11 + src.m21 * f12;
/* 136 */     float t12 = src.m02 * f10 + src.m12 * f11 + src.m22 * f12;
/* 137 */     float t13 = src.m03 * f10 + src.m13 * f11 + src.m23 * f12;
/* 138 */     dest.m20 = (src.m00 * f20 + src.m10 * f21 + src.m20 * f22);
/* 139 */     dest.m21 = (src.m01 * f20 + src.m11 * f21 + src.m21 * f22);
/* 140 */     dest.m22 = (src.m02 * f20 + src.m12 * f21 + src.m22 * f22);
/* 141 */     dest.m23 = (src.m03 * f20 + src.m13 * f21 + src.m23 * f22);
/* 142 */     dest.m00 = t00;
/* 143 */     dest.m01 = t01;
/* 144 */     dest.m02 = t02;
/* 145 */     dest.m03 = t03;
/* 146 */     dest.m10 = t10;
/* 147 */     dest.m11 = t11;
/* 148 */     dest.m12 = t12;
/* 149 */     dest.m13 = t13;
/* 150 */     return dest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BakedQuad buildQuad(VertexFormat format, TRSRTransformation transform, EnumFacing face, int tint, float x0, float y0, float z0, float u0, float v0, float x1, float y1, float z1, float u1, float v1, float x2, float y2, float z2, float u2, float v2, float x3, float y3, float z3, float u3, float v3)
/*     */   {
/* 158 */     return buildQuad(format, transform, face, tint, x0, y0, z0, u0, v0, x1, y1, z1, u1, v1, x2, y2, z2, u2, v2, x3, y3, z3, u3, v3, -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BakedQuad buildQuad(VertexFormat format, TRSRTransformation transform, EnumFacing face, int tint, float x0, float y0, float z0, float u0, float v0, float x1, float y1, float z1, float u1, float v1, float x2, float y2, float z2, float u2, float v2, float x3, float y3, float z3, float u3, float v3, int color)
/*     */   {
/* 166 */     return buildQuad(format, transform, face, tint, x0, y0, z0, u0, v0, color, x1, y1, z1, u1, v1, color, x2, y2, z2, u2, v2, color, x3, y3, z3, u3, v3, color);
/*     */   }
/*     */   
/*     */   public static BakedQuad reverse(BakedQuad input) {
/* 170 */     int[] vertexData = input.getVertexData();
/* 171 */     int[] v = new int[28];
/*     */     int col;
/*     */     int col;
/* 174 */     if (input.getFace() == EnumFacing.UP) {
/* 175 */       col = -8355712; } else { int col;
/* 176 */       if (input.getFace() == EnumFacing.DOWN) {
/* 177 */         col = -1;
/*     */       } else
/* 179 */         col = 0;
/*     */     }
/* 181 */     for (int i = 0; i < 4; i++) {
/* 182 */       System.arraycopy(vertexData, (3 - i) * 7, v, i * 7, 7);
/* 183 */       if (col != 0) {
/* 184 */         v[(i * 7 + 3)] = col;
/*     */       }
/*     */     }
/* 187 */     return new BakedQuad(v, input.getTintIndex(), input.getFace());
/*     */   }
/*     */   
/*     */   public static float getFaceBrightness(float x, float y, float z) {
/* 191 */     float[] norm = LightMathHelper.norm(x, y, z);
/* 192 */     return getFaceBrightnessNorm(norm[0], norm[1], norm[2]);
/*     */   }
/*     */   
/*     */   public static float getFaceBrightnessNorm(float a, float b, float c) {
/* 196 */     return a * a * 0.6F + b * b * 0.75F + 0.25F * b + c * c * 0.8F;
/*     */   }
/*     */   
/*     */   public static int getFaceShadeColor(float x, float y, float z) {
/* 200 */     float f = getFaceBrightness(x, y, z);
/* 201 */     int i = MathHelper.clamp_int((int)(f * 255.0F), 0, 255);
/* 202 */     return 0xFF000000 | i << 16 | i << 8 | i;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static BakedQuad createBakedQuad(UV[] vecs, String texture, boolean addShading, int tint) {
/* 207 */     Vector3f a = new Vector3f();Vector3f b = new Vector3f();Vector3f c = new Vector3f();
/* 208 */     Vector3f.sub(vecs[1].toVector3f(), vecs[0].toVector3f(), a);
/* 209 */     Vector3f.sub(vecs[2].toVector3f(), vecs[0].toVector3f(), b);
/* 210 */     Vector3f.cross(a, b, c);
/* 211 */     EnumFacing facing = EnumFacing.getFacingFromVector(c.x, c.y, c.z);
/*     */     
/* 213 */     TextureAtlasSprite sprite = (TextureAtlasSprite)Textures.sprites.get(texture);
/* 214 */     if (sprite == null) { sprite = Textures.MISSING_SPRITE;
/*     */     }
/* 216 */     int col = addShading ? getFaceShadeColor(c.x, c.y, c.z) : -1;
/*     */     
/* 218 */     int[] vertex = new int[28];
/*     */     
/* 220 */     for (int i = 0; i < 4; i++) {
/* 221 */       vertex[(i * 7)] = Float.floatToRawIntBits(vecs[i].x);
/* 222 */       vertex[(i * 7 + 1)] = Float.floatToRawIntBits(vecs[i].y);
/* 223 */       vertex[(i * 7 + 2)] = Float.floatToRawIntBits(vecs[i].z);
/* 224 */       vertex[(i * 7 + 3)] = col;
/* 225 */       vertex[(i * 7 + 4)] = Float.floatToRawIntBits(sprite.getInterpolatedU(vecs[i].u * 16.0F));
/* 226 */       vertex[(i * 7 + 5)] = Float.floatToRawIntBits(sprite.getInterpolatedV(16.0F - vecs[i].v * 16.0F));
/*     */     }
/*     */     
/* 229 */     ForgeHooksClient.fillNormal(vertex, facing);
/*     */     
/* 231 */     return new BakedQuad(vertex, tint, facing);
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\QuadHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */