/*    */ package com.rwtema.extrautils2.utils.helpers;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import java.util.Iterator;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.server.management.ServerConfigurationManager;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.util.Vec3;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class PlayerHelper
/*    */ {
/* 18 */   private static final UUID temaID = UUID.fromString("72ddaa05-7bbe-4ae2-9892-2c8d90ea0ad8");
/*    */   
/*    */   public static boolean isPlayerReal(EntityPlayer player) {
/* 21 */     return (player != null) && (player.worldObj != null) && (!player.worldObj.isRemote) && ((player.getClass() == EntityPlayerMP.class) || (MinecraftServer.func_71276_C().func_71203_ab().playerEntityList.contains((EntityPlayerMP)player)));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean isTema(GameProfile gameProfile)
/*    */   {
/* 31 */     return isTema(gameProfile.getName(), gameProfile.getId());
/*    */   }
/*    */   
/*    */   private static boolean isTema(String name, UUID id) {
/* 35 */     return ("RWTema".equals(name)) && (id.equals(temaID));
/*    */   }
/*    */   
/*    */   public static boolean isThisPlayerACheatyBastardOfCheatBastardness(EntityPlayer player) {
/* 39 */     return (isPlayerReal(player)) && (isTema(player.getGameProfile()));
/*    */   }
/*    */   
/*    */   public static Iterable<ItemStack> playerInv(EntityPlayer player)
/*    */   {
/* 44 */     com.google.common.collect.Iterables.concat(new Iterable()
/*    */     {
/*    */       public Iterator<ItemStack> iterator() {
/* 47 */         new Iterator() {
/* 48 */           int i = 0;
/* 49 */           InventoryPlayer p = PlayerHelper.1.this.val$player.inventory;
/*    */           
/*    */           public boolean hasNext()
/*    */           {
/* 53 */             return this.i < this.p.getSizeInventory();
/*    */           }
/*    */           
/*    */           public ItemStack next()
/*    */           {
/* 58 */             ItemStack stackInSlot = this.p.getStackInSlot(this.i);
/* 59 */             this.i += 1;
/* 60 */             return stackInSlot;
/*    */           }
/*    */           
/*    */           public void remove()
/*    */           {
/* 65 */             throw new UnsupportedOperationException();
/*    */           }
/*    */         };
/*    */       }
/* 47 */     }, com.google.common.collect.Lists.newArrayList(new ItemStack[] { player.inventory.getItemStack() }));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void syncInventory(EntityPlayerMP player)
/*    */   {
/* 74 */     player.inventory.markDirty();
/* 75 */     player.mcServer.func_71203_ab().syncPlayerInventory(player);
/*    */   }
/*    */   
/*    */   public static net.minecraft.util.MovingObjectPosition rayTrace(EntityPlayer player) {
/* 79 */     float pitch = player.rotationPitch;
/* 80 */     float yaw = player.rotationYaw;
/* 81 */     double dx = player.posX;double dy = player.posY + player.getEyeHeight();double dz = player.posZ;
/* 82 */     Vec3 vec3 = new Vec3(dx, dy, dz);
/* 83 */     float f2 = MathHelper.cos(-yaw * 0.017453292F - 3.1415927F);
/* 84 */     float f3 = MathHelper.sin(-yaw * 0.017453292F - 3.1415927F);
/* 85 */     float f4 = -MathHelper.cos(-pitch * 0.017453292F);
/* 86 */     float f5 = MathHelper.sin(-pitch * 0.017453292F);
/* 87 */     float f6 = f3 * f4;
/* 88 */     float f7 = f2 * f4;
/* 89 */     double d3 = 5.0D;
/* 90 */     if ((player instanceof EntityPlayerMP)) {
/* 91 */       d3 = ((EntityPlayerMP)player).interactionManager.getBlockReachDistance();
/*    */     }
/* 93 */     Vec3 vec31 = vec3.addVector(f6 * d3, f5 * d3, f7 * d3);
/* 94 */     return player.worldObj.rayTraceBlocks(vec3, vec31, false, false, true);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\PlayerHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */