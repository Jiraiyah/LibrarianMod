/*    */ package com.rwtema.extrautils2.utils.helpers;
/*    */ 
/*    */ import com.rwtema.extrautils2.backend.ISidedFunction;
/*    */ import java.util.Map;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.chunk.Chunk;
/*    */ 
/*    */ public class WorldHelper
/*    */ {
/* 13 */   private static final ISidedFunction<World, Float> getSunBrightness = new ISidedFunction()
/*    */   {
/*    */     public Float applyServer(World world) {
/* 16 */       float f = world.getCelestialAngle(0.0F);
/* 17 */       float f1 = 1.0F - (MathHelper.cos(f * 3.1415927F * 2.0F) * 2.0F + 0.2F);
/* 18 */       f1 = MathHelper.clamp_float(f1, 0.0F, 1.0F);
/* 19 */       f1 = 1.0F - f1;
/* 20 */       f1 = (float)(f1 * (1.0D - world.getRainStrength(0.0F) * 5.0F / 16.0D));
/* 21 */       f1 = (float)(f1 * (1.0D - world.getThunderStrength(0.0F) * 5.0F / 16.0D));
/* 22 */       return Float.valueOf(f1 * 0.8F + 0.2F);
/*    */     }
/*    */     
/*    */     public Float applyClient(World world)
/*    */     {
/* 27 */       return Float.valueOf(world.getSunBrightness(0.0F));
/*    */     }
/*    */   };
/*    */   
/*    */   public static float getSunBrightness(World world) {
/* 32 */     if (world.provider.getHasNoSky()) return 0.0F;
/* 33 */     return ((Float)com.rwtema.extrautils2.ExtraUtils2.proxy.apply(getSunBrightness, world)).floatValue();
/*    */   }
/*    */   
/*    */   public static float getMoonBrightness(World world) {
/* 37 */     float f = world.getCelestialAngle(0.0F);
/* 38 */     float f1 = -(MathHelper.cos(f * 3.1415927F * 2.0F) * 2.0F + 0.2F);
/* 39 */     return MathHelper.clamp_float(f1, 0.0F, 1.0F);
/*    */   }
/*    */   
/*    */   public static boolean isFullMoon(World world) {
/* 43 */     return world.getCurrentMoonPhaseFactor() >= 0.9F;
/*    */   }
/*    */   
/*    */   public static TileEntity getTileEntityThreadSafe(World world, BlockPos pos)
/*    */   {
/* 48 */     Chunk chunk = world.getChunkFromBlockCoords(pos);
/* 49 */     Map<BlockPos, TileEntity> map = chunk.getTileEntityMap();
/* 50 */     TileEntity tileEntity = (TileEntity)map.get(pos);
/* 51 */     if ((tileEntity == null) || (tileEntity.isInvalid())) return null;
/* 52 */     return tileEntity;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\WorldHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */