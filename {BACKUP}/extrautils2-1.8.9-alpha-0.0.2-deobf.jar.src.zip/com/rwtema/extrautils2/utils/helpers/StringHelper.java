/*     */ package com.rwtema.extrautils2.utils.helpers;
/*     */ 
/*     */ import gnu.trove.map.hash.TIntIntHashMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringHelper
/*     */ {
/*  13 */   private static final LinkedHashMap<String, Integer> roman_numerals = new LinkedHashMap();
/*     */   
/*  15 */   static { roman_numerals.put("M", Integer.valueOf(1000));
/*  16 */     roman_numerals.put("CM", Integer.valueOf(900));
/*  17 */     roman_numerals.put("D", Integer.valueOf(500));
/*  18 */     roman_numerals.put("CD", Integer.valueOf(400));
/*  19 */     roman_numerals.put("C", Integer.valueOf(100));
/*  20 */     roman_numerals.put("XC", Integer.valueOf(90));
/*  21 */     roman_numerals.put("L", Integer.valueOf(50));
/*  22 */     roman_numerals.put("XL", Integer.valueOf(40));
/*  23 */     roman_numerals.put("X", Integer.valueOf(10));
/*  24 */     roman_numerals.put("IX", Integer.valueOf(9));
/*  25 */     roman_numerals.put("V", Integer.valueOf(5));
/*  26 */     roman_numerals.put("IV", Integer.valueOf(4));
/*  27 */     roman_numerals.put("I", Integer.valueOf(1));
/*     */   }
/*     */   
/*     */   public static String capFirst(String s, boolean lowerCaseRest) {
/*  31 */     if (s == null) return null;
/*  32 */     int n = s.length();
/*  33 */     if (n == 0) return s;
/*  34 */     if (n == 1) { return s.toUpperCase();
/*     */     }
/*  36 */     return s.substring(0, 1).toUpperCase() + (lowerCaseRest ? s.substring(1).toLowerCase() : s.substring(1));
/*     */   }
/*     */   
/*     */   public static String sepWords(String input)
/*     */   {
/*  41 */     StringBuilder builder = new StringBuilder();
/*  42 */     boolean prevWasWhiteSpace = true;
/*  43 */     for (char c : input.toCharArray()) {
/*  44 */       if (Character.isWhitespace(c)) {
/*  45 */         prevWasWhiteSpace = true;
/*     */       } else {
/*  47 */         if ((Character.isUpperCase(c)) && 
/*  48 */           (!prevWasWhiteSpace)) {
/*  49 */           builder.append(" ");
/*     */         }
/*  51 */         prevWasWhiteSpace = false;
/*     */       }
/*  53 */       builder.append(c);
/*     */     }
/*  55 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public static String toRomanNumeral(int num) {
/*  59 */     int i = num;
/*  60 */     StringBuilder builder = new StringBuilder();
/*  61 */     for (Map.Entry<String, Integer> entry : roman_numerals.entrySet()) {
/*  62 */       int value = ((Integer)entry.getValue()).intValue();
/*  63 */       int mathes = i / value;
/*  64 */       for (int j = 0; j < mathes; j++) {
/*  65 */         builder.append((String)entry.getKey());
/*     */       }
/*  67 */       i %= value;
/*     */     }
/*  69 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public static ArrayList<String> formatTabsToTableSpaced(ArrayList<String> strings) {
/*  73 */     TIntIntHashMap lens = new TIntIntHashMap(10, 0.5F, 0, 0);
/*  74 */     for (String string : strings) {
/*  75 */       String[] split = string.split("\t");
/*     */       
/*  77 */       for (int i = 0; i < split.length; i++) {
/*  78 */         int n = split[i].length();
/*  79 */         if (lens.get(i) < n) {
/*  80 */           lens.put(i, n);
/*     */         }
/*     */       }
/*     */     }
/*  84 */     int n = 0;
/*  85 */     for (int i = 0; i < lens.size(); i++) {
/*  86 */       n += lens.get(i) + 2;
/*  87 */       lens.put(i, n);
/*     */     }
/*     */     
/*  90 */     ArrayList<String> result = new ArrayList();
/*  91 */     for (String string : strings) {
/*  92 */       StringBuilder builder = new StringBuilder();
/*  93 */       String[] split = string.split("\t");
/*  94 */       for (int i = 0; i < split.length; i++) {
/*  95 */         builder.append(split[i]);
/*  96 */         n = lens.get(i);
/*  97 */         while (builder.length() < n)
/*  98 */           builder.append(" ");
/*     */       }
/* 100 */       result.add(builder.toString());
/*     */     }
/* 102 */     return result;
/*     */   }
/*     */   
/*     */   public static String niceFormat(double v) { String format;
/*     */     String format;
/* 107 */     if (v == (int)v) {
/* 108 */       format = String.format(Locale.ENGLISH, "%d", new Object[] { Integer.valueOf((int)v) });
/*     */     } else
/* 110 */       format = String.format(Locale.ENGLISH, "%.2f", new Object[] { Double.valueOf(v) });
/* 111 */     return format;
/*     */   }
/*     */   
/*     */   public static String erasePrefix(String string, String prefix) {
/* 115 */     if (string.startsWith(prefix)) {
/* 116 */       return string.substring(prefix.length());
/*     */     }
/* 118 */     return string;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\StringHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */