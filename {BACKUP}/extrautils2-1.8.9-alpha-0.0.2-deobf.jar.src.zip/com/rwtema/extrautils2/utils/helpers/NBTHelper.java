/*     */ package com.rwtema.extrautils2.utils.helpers;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import java.util.Iterator;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraftforge.common.util.INBTSerializable;
/*     */ 
/*     */ public class NBTHelper
/*     */ {
/*     */   public static NBTTagCompound getPersistentTag(EntityPlayer player)
/*     */   {
/*  19 */     return getOrInitTagCompound(player.getEntityData(), "PlayerPersisted", null);
/*     */   }
/*     */   
/*     */   public static NBTTagCompound getOrInitTagCompound(NBTTagCompound parent, String key) {
/*  23 */     return getOrInitTagCompound(parent, key, null);
/*     */   }
/*     */   
/*     */   public static NBTTagCompound getOrInitTagCompound(NBTTagCompound parent, String key, NBTTagCompound defaultTag) {
/*  27 */     if (parent.hasKey(key, 10)) {
/*  28 */       return parent.getCompoundTag(key);
/*     */     }
/*  30 */     if (defaultTag == null) {
/*  31 */       defaultTag = new NBTTagCompound();
/*     */     } else {
/*  33 */       defaultTag = (NBTTagCompound)defaultTag.copy();
/*     */     }
/*  35 */     parent.setTag(key, defaultTag);
/*  36 */     return defaultTag;
/*     */   }
/*     */   
/*     */   public static NBTTagCompound proifleToNBT(GameProfile profile)
/*     */   {
/*  41 */     NBTTagCompound tag = new NBTTagCompound();
/*  42 */     tag.setString("Name", profile.getName());
/*  43 */     UUID id = profile.getId();
/*  44 */     if (id != null) {
/*  45 */       tag.setLong("UUIDL", id.getLeastSignificantBits());
/*  46 */       tag.setLong("UUIDU", id.getMostSignificantBits());
/*     */     }
/*  48 */     return tag;
/*     */   }
/*     */   
/*     */   public static GameProfile profileFromNBT(NBTTagCompound tag) {
/*  52 */     String name = tag.getString("Name");
/*  53 */     UUID uuid = null;
/*  54 */     if (tag.hasKey("UUIDL")) {
/*  55 */       uuid = new UUID(tag.getLong("UUIDU"), tag.getLong("UUIDL"));
/*     */     }
/*  57 */     else if (org.apache.commons.lang3.StringUtils.isBlank(name)) { return null;
/*     */     }
/*  59 */     return new GameProfile(uuid, name);
/*     */   }
/*     */   
/*     */ 
/*     */   public static Iterable<NBTTagCompound> iterateNBTTagList(NBTTagList list)
/*     */   {
/*  65 */     new Iterable()
/*     */     {
/*     */       public Iterator<NBTTagCompound> iterator() {
/*  68 */         new Iterator() {
/*  69 */           private int i = 0;
/*     */           
/*     */           public boolean hasNext()
/*     */           {
/*  73 */             return this.i < NBTHelper.1.this.val$list.tagCount();
/*     */           }
/*     */           
/*     */           public NBTTagCompound next()
/*     */           {
/*  78 */             return NBTHelper.1.this.val$list.getCompoundTagAt(this.i++);
/*     */           }
/*     */           
/*     */           public void remove()
/*     */           {
/*  83 */             NBTHelper.1.this.val$list.removeTag(this.i--);
/*     */           }
/*     */         };
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public static NBTTagCompound getOrInitTagCompound(ItemStack stack) {
/*  91 */     NBTTagCompound tags = stack.getTagCompound();
/*  92 */     if (tags != null) return tags;
/*  93 */     tags = new NBTTagCompound();
/*  94 */     stack.setTagCompound(tags);
/*  95 */     return tags;
/*     */   }
/*     */   
/*     */   public static boolean hasPersistantNBT(Entity entity) {
/*  99 */     return entity.getEntityData().hasKey("PlayerPersisted", 10);
/*     */   }
/*     */   
/*     */   public static NBTTagCompound getPersistantNBT(Entity entity) {
/* 103 */     NBTTagCompound t = entity.getEntityData();
/* 104 */     return getOrInitTagCompound(t, "PlayerPersisted");
/*     */   }
/*     */   
/*     */   public static NBTTagCompound blockPosToNBT(BlockPos pos) {
/* 108 */     NBTTagCompound nbt = new NBTTagCompound();
/* 109 */     nbt.setInteger("x", pos.getX());
/* 110 */     nbt.setByte("y", (byte)pos.getY());
/* 111 */     nbt.setInteger("z", pos.getZ());
/* 112 */     return nbt;
/*     */   }
/*     */   
/*     */   public static BlockPos nbtToBlockPos(NBTTagCompound nbt) {
/* 116 */     int x = nbt.getInteger("x");
/* 117 */     int y = nbt.getByte("y") & 0xFF;
/* 118 */     int z = nbt.getInteger("z");
/* 119 */     return new BlockPos(x, y, z);
/*     */   }
/*     */   
/*     */   public static <T extends NBTBase> void deserializeSubTag(INBTSerializable<T> serializable, NBTTagCompound parent, String key) {
/* 123 */     T tag = parent.getTag(key);
/* 124 */     if (tag != null) {
/* 125 */       serializable.deserializeNBT(tag);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\NBTHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */