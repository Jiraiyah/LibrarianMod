/*    */ package com.rwtema.extrautils2.utils.helpers;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.BlockState;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class ItemStackHelper
/*    */ {
/*    */   public static ItemStack addLore(ItemStack a, String... lore)
/*    */   {
/* 23 */     NBTTagCompound tag = a.getTagCompound();
/* 24 */     if (tag == null) {
/* 25 */       tag = new NBTTagCompound();
/*    */     }
/* 27 */     if (!tag.hasKey("display", 10)) {
/* 28 */       tag.setTag("display", new NBTTagCompound());
/*    */     }
/*    */     
/* 31 */     NBTTagList l = new NBTTagList();
/* 32 */     for (String s : lore) {
/* 33 */       l.appendTag(new net.minecraft.nbt.NBTTagString(s));
/*    */     }
/*    */     
/* 36 */     tag.getCompoundTag("display").setTag("Lore", l);
/*    */     
/* 38 */     a.setTagCompound(tag);
/*    */     
/* 40 */     return a;
/*    */   }
/*    */   
/*    */   public static void addBlockStates(String oreDictName, HashSet<IBlockState> stateList) {
/* 44 */     List<ItemStack> ores = net.minecraftforge.oredict.OreDictionary.getOres(oreDictName);
/* 45 */     for (ItemStack ore : ores) {
/* 46 */       addBlockStates(ore, stateList);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void addBlockStates(ItemStack stack, HashSet<IBlockState> stateList) {
/* 51 */     Item item = stack.getItem();
/* 52 */     if (!(item instanceof ItemBlock)) return;
/* 53 */     Block block = ((ItemBlock)item).getBlock();
/* 54 */     for (IBlockState iBlockState : block.getBlockState().getValidStates()) {
/* 55 */       if (!block.hasTileEntity(iBlockState)) {
/* 56 */         int itemDamage = stack.getItemDamage();
/* 57 */         if ((itemDamage == 32767) || (itemDamage == block.damageDropped(iBlockState)))
/* 58 */           stateList.add(iBlockState);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static boolean holdingWrench(EntityPlayer player) {
/* 64 */     return isWrench(player.func_70694_bm());
/*    */   }
/*    */   
/*    */   public static boolean isWrench(ItemStack wrench) {
/* 68 */     return (wrench != null) && (wrench.hasCapability(com.rwtema.extrautils2.api.IWrench.CAPABILITY, null));
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public static void addInfoWidth(List<String> list, ItemStack stack, String data) {
/* 73 */     addInfoWidth(list, stack, data, 180);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public static void addInfoWidth(List<String> list, ItemStack stack, String data, int weight) {
/* 78 */     FontRenderer fontRenderer = (stack == null) || (stack.getItem() == null) ? null : stack.getItem().getFontRenderer(stack);
/* 79 */     if (fontRenderer == null) fontRenderer = Minecraft.getMinecraft().fontRendererObj;
/* 80 */     list.addAll(fontRenderer.listFormattedStringToWidth(data, weight));
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\ItemStackHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */