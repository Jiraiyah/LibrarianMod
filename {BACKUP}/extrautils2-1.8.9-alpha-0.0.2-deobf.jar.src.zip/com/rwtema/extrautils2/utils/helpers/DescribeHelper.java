/*    */ package com.rwtema.extrautils2.utils.helpers;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.ForgeChunkManager.Ticket;
/*    */ 
/*    */ public class DescribeHelper
/*    */ {
/*    */   public static void addDescription(List<String> list, String name, Object object)
/*    */   {
/* 11 */     addDescription(list, name + " = ");
/* 12 */     addDescription(list, object, 1);
/*    */   }
/*    */   
/*    */   public static void addDescription(List<String> list, Object object) {
/* 16 */     addDescription(list, object, 0);
/*    */   }
/*    */   
/*    */   public static void addDescription(List<String> list, Object object, int i) {
/* 20 */     if (object == null) { list.add("[null]");
/* 21 */     } else if ((object instanceof String)) {
/* 22 */       StringBuilder builder = new StringBuilder();
/* 23 */       for (int j = 0; j < i; j++) {
/* 24 */         builder.append('\t');
/*    */       }
/* 26 */       builder.append(object);
/* 27 */       list.add(builder.toString());
/* 28 */     } else if ((object instanceof Iterable)) {
/* 29 */       if ((object instanceof java.util.Collection)) {
/* 30 */         addDescription(list, object.getClass().getSimpleName() + "_(size = " + ((java.util.Collection)object).size() + "){", i);
/*    */       } else
/* 32 */         addDescription(list, object.getClass().getSimpleName() + " {", i);
/* 33 */       for (Object o : (Iterable)object) {
/* 34 */         addDescription(list, o, i + 1);
/*    */       }
/*    */     }
/* 37 */     else if ((object instanceof java.util.Map)) {
/* 38 */       addDescription(list, object.getClass().getSimpleName() + "_(size = " + ((java.util.Map)object).size() + "){", i);
/*    */       
/* 40 */       for (java.util.Map.Entry entry : ((java.util.Map)object).entrySet()) {
/* 41 */         addDescription(list, entry.getKey(), i + 1);
/* 42 */         addDescription(list, "=", i + 1);
/* 43 */         addDescription(list, entry.getValue(), i + 1);
/*    */       }
/* 45 */       addDescription(list, "}", i);
/* 46 */     } else if ((object instanceof ForgeChunkManager.Ticket)) {
/* 47 */       ForgeChunkManager.Ticket ticket = (ForgeChunkManager.Ticket)object;
/* 48 */       addDescription(list, "Ticket[Player: " + ticket.getPlayerName() + " World:" + ticket.world.provider.func_177502_q() + "]", i);
/* 49 */       addDescription(list, ticket.getChunkList().toString(), i);
/* 50 */     } else if ((object instanceof World)) {
/* 51 */       World world = (World)object;
/* 52 */       addDescription(list, "World[Dim:" + world.provider.func_177502_q() + " isRemote:" + world.isRemote + "]");
/*    */     } else {
/* 54 */       String s = object.toString();
/* 55 */       int hash = object.hashCode();
/* 56 */       String s2 = object.getClass().getName() + "@" + Integer.toHexString(hash);
/* 57 */       if (s.equals(s2)) {
/* 58 */         addDescription(list, object.getClass().getSimpleName() + ":" + hash, i);
/*    */       } else {
/* 60 */         addDescription(list, object.getClass().getSimpleName() + ":" + s, i);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\DescribeHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */