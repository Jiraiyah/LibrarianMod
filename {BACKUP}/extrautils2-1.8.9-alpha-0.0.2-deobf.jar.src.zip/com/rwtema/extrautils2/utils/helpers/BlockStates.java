/*      */ package com.rwtema.extrautils2.utils.helpers;
/*      */ 
/*      */ import net.minecraft.block.Block;
/*      */ import net.minecraft.block.BlockAnvil;
/*      */ import net.minecraft.block.BlockBanner;
/*      */ import net.minecraft.block.BlockBeacon;
/*      */ import net.minecraft.block.BlockBed;
/*      */ import net.minecraft.block.BlockBed.EnumPartType;
/*      */ import net.minecraft.block.BlockBush;
/*      */ import net.minecraft.block.BlockButton;
/*      */ import net.minecraft.block.BlockCactus;
/*      */ import net.minecraft.block.BlockCake;
/*      */ import net.minecraft.block.BlockCarpet;
/*      */ import net.minecraft.block.BlockCauldron;
/*      */ import net.minecraft.block.BlockChest;
/*      */ import net.minecraft.block.BlockCocoa;
/*      */ import net.minecraft.block.BlockColored;
/*      */ import net.minecraft.block.BlockCommandBlock;
/*      */ import net.minecraft.block.BlockCrops;
/*      */ import net.minecraft.block.BlockDaylightDetector;
/*      */ import net.minecraft.block.BlockDeadBush;
/*      */ import net.minecraft.block.BlockDirt;
/*      */ import net.minecraft.block.BlockDirt.DirtType;
/*      */ import net.minecraft.block.BlockDispenser;
/*      */ import net.minecraft.block.BlockDoor;
/*      */ import net.minecraft.block.BlockDoor.EnumDoorHalf;
/*      */ import net.minecraft.block.BlockDoor.EnumHingePosition;
/*      */ import net.minecraft.block.BlockDoublePlant;
/*      */ import net.minecraft.block.BlockDoublePlant.EnumBlockHalf;
/*      */ import net.minecraft.block.BlockDoublePlant.EnumPlantType;
/*      */ import net.minecraft.block.BlockDynamicLiquid;
/*      */ import net.minecraft.block.BlockEndPortalFrame;
/*      */ import net.minecraft.block.BlockEnderChest;
/*      */ import net.minecraft.block.BlockFarmland;
/*      */ import net.minecraft.block.BlockFenceGate;
/*      */ import net.minecraft.block.BlockFire;
/*      */ import net.minecraft.block.BlockFlower;
/*      */ import net.minecraft.block.BlockFlower.EnumFlowerType;
/*      */ import net.minecraft.block.BlockFurnace;
/*      */ import net.minecraft.block.BlockGrass;
/*      */ import net.minecraft.block.BlockHopper;
/*      */ import net.minecraft.block.BlockHugeMushroom;
/*      */ import net.minecraft.block.BlockHugeMushroom.EnumType;
/*      */ import net.minecraft.block.BlockJukebox;
/*      */ import net.minecraft.block.BlockLadder;
/*      */ import net.minecraft.block.BlockLeaves;
/*      */ import net.minecraft.block.BlockLever;
/*      */ import net.minecraft.block.BlockLever.EnumOrientation;
/*      */ import net.minecraft.block.BlockLiquid;
/*      */ import net.minecraft.block.BlockLog;
/*      */ import net.minecraft.block.BlockLog.EnumAxis;
/*      */ import net.minecraft.block.BlockMycelium;
/*      */ import net.minecraft.block.BlockNetherWart;
/*      */ import net.minecraft.block.BlockNewLeaf;
/*      */ import net.minecraft.block.BlockNewLog;
/*      */ import net.minecraft.block.BlockOldLeaf;
/*      */ import net.minecraft.block.BlockOldLog;
/*      */ import net.minecraft.block.BlockPistonBase;
/*      */ import net.minecraft.block.BlockPistonExtension;
/*      */ import net.minecraft.block.BlockPistonExtension.EnumPistonType;
/*      */ import net.minecraft.block.BlockPistonMoving;
/*      */ import net.minecraft.block.BlockPlanks;
/*      */ import net.minecraft.block.BlockPlanks.EnumType;
/*      */ import net.minecraft.block.BlockPortal;
/*      */ import net.minecraft.block.BlockPressurePlate;
/*      */ import net.minecraft.block.BlockPressurePlateWeighted;
/*      */ import net.minecraft.block.BlockPrismarine;
/*      */ import net.minecraft.block.BlockPrismarine.EnumType;
/*      */ import net.minecraft.block.BlockQuartz;
/*      */ import net.minecraft.block.BlockQuartz.EnumType;
/*      */ import net.minecraft.block.BlockRail;
/*      */ import net.minecraft.block.BlockRailBase.EnumRailDirection;
/*      */ import net.minecraft.block.BlockRailDetector;
/*      */ import net.minecraft.block.BlockRailPowered;
/*      */ import net.minecraft.block.BlockRedSandstone;
/*      */ import net.minecraft.block.BlockRedSandstone.EnumType;
/*      */ import net.minecraft.block.BlockRedstoneComparator;
/*      */ import net.minecraft.block.BlockRedstoneComparator.Mode;
/*      */ import net.minecraft.block.BlockRedstoneRepeater;
/*      */ import net.minecraft.block.BlockRedstoneWire;
/*      */ import net.minecraft.block.BlockReed;
/*      */ import net.minecraft.block.BlockRotatedPillar;
/*      */ import net.minecraft.block.BlockSand;
/*      */ import net.minecraft.block.BlockSand.EnumType;
/*      */ import net.minecraft.block.BlockSandStone;
/*      */ import net.minecraft.block.BlockSandStone.EnumType;
/*      */ import net.minecraft.block.BlockSapling;
/*      */ import net.minecraft.block.BlockSilverfish;
/*      */ import net.minecraft.block.BlockSilverfish.EnumType;
/*      */ import net.minecraft.block.BlockSkull;
/*      */ import net.minecraft.block.BlockSlab;
/*      */ import net.minecraft.block.BlockSlab.EnumBlockHalf;
/*      */ import net.minecraft.block.BlockSnow;
/*      */ import net.minecraft.block.BlockSponge;
/*      */ import net.minecraft.block.BlockStainedGlass;
/*      */ import net.minecraft.block.BlockStainedGlassPane;
/*      */ import net.minecraft.block.BlockStairs;
/*      */ import net.minecraft.block.BlockStairs.EnumHalf;
/*      */ import net.minecraft.block.BlockStandingSign;
/*      */ import net.minecraft.block.BlockStaticLiquid;
/*      */ import net.minecraft.block.BlockStem;
/*      */ import net.minecraft.block.BlockStone;
/*      */ import net.minecraft.block.BlockStone.EnumType;
/*      */ import net.minecraft.block.BlockStoneBrick;
/*      */ import net.minecraft.block.BlockStoneBrick.EnumType;
/*      */ import net.minecraft.block.BlockStoneSlab;
/*      */ import net.minecraft.block.BlockStoneSlab.EnumType;
/*      */ import net.minecraft.block.BlockStoneSlabNew;
/*      */ import net.minecraft.block.BlockTNT;
/*      */ import net.minecraft.block.BlockTallGrass;
/*      */ import net.minecraft.block.BlockTallGrass.EnumType;
/*      */ import net.minecraft.block.BlockTorch;
/*      */ import net.minecraft.block.BlockTrapDoor;
/*      */ import net.minecraft.block.BlockTrapDoor.DoorHalf;
/*      */ import net.minecraft.block.BlockTripWire;
/*      */ import net.minecraft.block.BlockTripWireHook;
/*      */ import net.minecraft.block.BlockVine;
/*      */ import net.minecraft.block.BlockWall;
/*      */ import net.minecraft.block.BlockWall.EnumType;
/*      */ import net.minecraft.block.BlockWallSign;
/*      */ import net.minecraft.block.BlockWoodSlab;
/*      */ import net.minecraft.block.state.IBlockState;
/*      */ import net.minecraft.init.Blocks;
/*      */ import net.minecraft.item.EnumDyeColor;
/*      */ import net.minecraft.util.EnumFacing;
/*      */ import net.minecraft.util.EnumFacing.Axis;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BlockStates
/*      */ {
/* 1390 */   public static final IBlockState air = Blocks.air.getDefaultState();
/* 1391 */   public static final IBlockState stone = Blocks.stone.getDefaultState();
/* 1392 */   public static final IBlockState stone_granite = Blocks.stone.getDefaultState().withProperty(BlockStone.VARIANT, BlockStone.EnumType.GRANITE);
/* 1393 */   public static final IBlockState stone_smoothgranite = Blocks.stone.getDefaultState().withProperty(BlockStone.VARIANT, BlockStone.EnumType.GRANITE_SMOOTH);
/* 1394 */   public static final IBlockState stone_diorite = Blocks.stone.getDefaultState().withProperty(BlockStone.VARIANT, BlockStone.EnumType.DIORITE);
/* 1395 */   public static final IBlockState stone_smoothdiorite = Blocks.stone.getDefaultState().withProperty(BlockStone.VARIANT, BlockStone.EnumType.DIORITE_SMOOTH);
/* 1396 */   public static final IBlockState stone_andesite = Blocks.stone.getDefaultState().withProperty(BlockStone.VARIANT, BlockStone.EnumType.ANDESITE);
/* 1397 */   public static final IBlockState stone_smoothandesite = Blocks.stone.getDefaultState().withProperty(BlockStone.VARIANT, BlockStone.EnumType.ANDESITE_SMOOTH);
/* 1398 */   public static final IBlockState grass = Blocks.grass.getDefaultState();
/* 1399 */   public static final IBlockState dirt = Blocks.dirt.getDefaultState();
/* 1400 */   public static final IBlockState dirt_coarsedirt = Blocks.dirt.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.COARSE_DIRT);
/* 1401 */   public static final IBlockState dirt_podzol = Blocks.dirt.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.PODZOL);
/* 1402 */   public static final IBlockState cobblestone = Blocks.cobblestone.getDefaultState();
/* 1403 */   public static final IBlockState planks_oak = Blocks.planks.getDefaultState();
/* 1404 */   public static final IBlockState planks_spruce = Blocks.planks.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.SPRUCE);
/* 1405 */   public static final IBlockState planks_birch = Blocks.planks.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.BIRCH);
/* 1406 */   public static final IBlockState planks_jungle = Blocks.planks.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.JUNGLE);
/* 1407 */   public static final IBlockState planks_acacia = Blocks.planks.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.ACACIA);
/* 1408 */   public static final IBlockState planks_darkoak = Blocks.planks.getDefaultState().withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.DARK_OAK);
/* 1409 */   public static final IBlockState sapling_oak_stage_0 = Blocks.sapling.getDefaultState();
/* 1410 */   public static final IBlockState sapling_spruce_stage_0 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.SPRUCE);
/* 1411 */   public static final IBlockState sapling_birch_stage_0 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.BIRCH);
/* 1412 */   public static final IBlockState sapling_jungle_stage_0 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.JUNGLE);
/* 1413 */   public static final IBlockState sapling_acacia_stage_0 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.ACACIA);
/* 1414 */   public static final IBlockState sapling_darkoak_stage_0 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.DARK_OAK);
/* 1415 */   public static final IBlockState sapling_oak_stage_1 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.STAGE, Integer.valueOf(1));
/* 1416 */   public static final IBlockState sapling_spruce_stage_1 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.SPRUCE).withProperty(BlockSapling.STAGE, Integer.valueOf(1));
/* 1417 */   public static final IBlockState sapling_birch_stage_1 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.BIRCH).withProperty(BlockSapling.STAGE, Integer.valueOf(1));
/* 1418 */   public static final IBlockState sapling_jungle_stage_1 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.JUNGLE).withProperty(BlockSapling.STAGE, Integer.valueOf(1));
/* 1419 */   public static final IBlockState sapling_acacia_stage_1 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.ACACIA).withProperty(BlockSapling.STAGE, Integer.valueOf(1));
/* 1420 */   public static final IBlockState sapling_darkoak_stage_1 = Blocks.sapling.getDefaultState().withProperty(BlockSapling.TYPE, BlockPlanks.EnumType.DARK_OAK).withProperty(BlockSapling.STAGE, Integer.valueOf(1));
/* 1421 */   public static final IBlockState bedrock = Blocks.bedrock.getDefaultState();
/* 1422 */   public static final IBlockState flowing_water_level_0 = Blocks.flowing_water.getDefaultState();
/* 1423 */   public static final IBlockState flowing_water_level_1 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(1));
/* 1424 */   public static final IBlockState flowing_water_level_2 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(2));
/* 1425 */   public static final IBlockState flowing_water_level_3 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(3));
/* 1426 */   public static final IBlockState flowing_water_level_4 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(4));
/* 1427 */   public static final IBlockState flowing_water_level_5 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(5));
/* 1428 */   public static final IBlockState flowing_water_level_6 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(6));
/* 1429 */   public static final IBlockState flowing_water_level_7 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(7));
/* 1430 */   public static final IBlockState flowing_water_level_8 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(8));
/* 1431 */   public static final IBlockState flowing_water_level_9 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(9));
/* 1432 */   public static final IBlockState flowing_water_level_10 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(10));
/* 1433 */   public static final IBlockState flowing_water_level_11 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(11));
/* 1434 */   public static final IBlockState flowing_water_level_12 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(12));
/* 1435 */   public static final IBlockState flowing_water_level_13 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(13));
/* 1436 */   public static final IBlockState flowing_water_level_14 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(14));
/* 1437 */   public static final IBlockState flowing_water_level_15 = Blocks.flowing_water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(15));
/* 1438 */   public static final IBlockState water_level_0 = Blocks.water.getDefaultState();
/* 1439 */   public static final IBlockState water_level_1 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(1));
/* 1440 */   public static final IBlockState water_level_2 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(2));
/* 1441 */   public static final IBlockState water_level_3 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(3));
/* 1442 */   public static final IBlockState water_level_4 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(4));
/* 1443 */   public static final IBlockState water_level_5 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(5));
/* 1444 */   public static final IBlockState water_level_6 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(6));
/* 1445 */   public static final IBlockState water_level_7 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(7));
/* 1446 */   public static final IBlockState water_level_8 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(8));
/* 1447 */   public static final IBlockState water_level_9 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(9));
/* 1448 */   public static final IBlockState water_level_10 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(10));
/* 1449 */   public static final IBlockState water_level_11 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(11));
/* 1450 */   public static final IBlockState water_level_12 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(12));
/* 1451 */   public static final IBlockState water_level_13 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(13));
/* 1452 */   public static final IBlockState water_level_14 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(14));
/* 1453 */   public static final IBlockState water_level_15 = Blocks.water.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(15));
/* 1454 */   public static final IBlockState flowing_lava_level_0 = Blocks.flowing_lava.getDefaultState();
/* 1455 */   public static final IBlockState flowing_lava_level_1 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(1));
/* 1456 */   public static final IBlockState flowing_lava_level_2 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(2));
/* 1457 */   public static final IBlockState flowing_lava_level_3 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(3));
/* 1458 */   public static final IBlockState flowing_lava_level_4 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(4));
/* 1459 */   public static final IBlockState flowing_lava_level_5 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(5));
/* 1460 */   public static final IBlockState flowing_lava_level_6 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(6));
/* 1461 */   public static final IBlockState flowing_lava_level_7 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(7));
/* 1462 */   public static final IBlockState flowing_lava_level_8 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(8));
/* 1463 */   public static final IBlockState flowing_lava_level_9 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(9));
/* 1464 */   public static final IBlockState flowing_lava_level_10 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(10));
/* 1465 */   public static final IBlockState flowing_lava_level_11 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(11));
/* 1466 */   public static final IBlockState flowing_lava_level_12 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(12));
/* 1467 */   public static final IBlockState flowing_lava_level_13 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(13));
/* 1468 */   public static final IBlockState flowing_lava_level_14 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(14));
/* 1469 */   public static final IBlockState flowing_lava_level_15 = Blocks.flowing_lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(15));
/* 1470 */   public static final IBlockState lava_level_0 = Blocks.lava.getDefaultState();
/* 1471 */   public static final IBlockState lava_level_1 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(1));
/* 1472 */   public static final IBlockState lava_level_2 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(2));
/* 1473 */   public static final IBlockState lava_level_3 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(3));
/* 1474 */   public static final IBlockState lava_level_4 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(4));
/* 1475 */   public static final IBlockState lava_level_5 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(5));
/* 1476 */   public static final IBlockState lava_level_6 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(6));
/* 1477 */   public static final IBlockState lava_level_7 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(7));
/* 1478 */   public static final IBlockState lava_level_8 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(8));
/* 1479 */   public static final IBlockState lava_level_9 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(9));
/* 1480 */   public static final IBlockState lava_level_10 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(10));
/* 1481 */   public static final IBlockState lava_level_11 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(11));
/* 1482 */   public static final IBlockState lava_level_12 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(12));
/* 1483 */   public static final IBlockState lava_level_13 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(13));
/* 1484 */   public static final IBlockState lava_level_14 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(14));
/* 1485 */   public static final IBlockState lava_level_15 = Blocks.lava.getDefaultState().withProperty(BlockLiquid.LEVEL, Integer.valueOf(15));
/* 1486 */   public static final IBlockState sand = Blocks.sand.getDefaultState();
/* 1487 */   public static final IBlockState sand_redsand = Blocks.sand.getDefaultState().withProperty(BlockSand.VARIANT, BlockSand.EnumType.RED_SAND);
/* 1488 */   public static final IBlockState gravel = Blocks.gravel.getDefaultState();
/* 1489 */   public static final IBlockState gold_ore = Blocks.gold_ore.getDefaultState();
/* 1490 */   public static final IBlockState iron_ore = Blocks.iron_ore.getDefaultState();
/* 1491 */   public static final IBlockState coal_ore = Blocks.coal_ore.getDefaultState();
/* 1492 */   public static final IBlockState log_y_oak = Blocks.log.getDefaultState();
/* 1493 */   public static final IBlockState log_y_spruce = Blocks.log.getDefaultState().withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.SPRUCE);
/* 1494 */   public static final IBlockState log_y_birch = Blocks.log.getDefaultState().withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.BIRCH);
/* 1495 */   public static final IBlockState log_y_jungle = Blocks.log.getDefaultState().withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.JUNGLE);
/* 1496 */   public static final IBlockState log_x_oak = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.X);
/* 1497 */   public static final IBlockState log_x_spruce = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.X).withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.SPRUCE);
/* 1498 */   public static final IBlockState log_x_birch = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.X).withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.BIRCH);
/* 1499 */   public static final IBlockState log_x_jungle = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.X).withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.JUNGLE);
/* 1500 */   public static final IBlockState log_z_oak = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.Z);
/* 1501 */   public static final IBlockState log_z_spruce = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.Z).withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.SPRUCE);
/* 1502 */   public static final IBlockState log_z_birch = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.Z).withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.BIRCH);
/* 1503 */   public static final IBlockState log_z_jungle = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.Z).withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.JUNGLE);
/* 1504 */   public static final IBlockState log_none_oak = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.NONE);
/* 1505 */   public static final IBlockState log_none_spruce = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.NONE).withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.SPRUCE);
/* 1506 */   public static final IBlockState log_none_birch = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.NONE).withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.BIRCH);
/* 1507 */   public static final IBlockState log_none_jungle = Blocks.log.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.NONE).withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.JUNGLE);
/* 1508 */   public static final IBlockState log2_y_acacia = Blocks.log2.getDefaultState();
/* 1509 */   public static final IBlockState log2_y_darkoak = Blocks.log2.getDefaultState().withProperty(BlockNewLog.VARIANT, BlockPlanks.EnumType.DARK_OAK);
/* 1510 */   public static final IBlockState log2_x_acacia = Blocks.log2.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.X);
/* 1511 */   public static final IBlockState log2_x_darkoak = Blocks.log2.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.X).withProperty(BlockNewLog.VARIANT, BlockPlanks.EnumType.DARK_OAK);
/* 1512 */   public static final IBlockState log2_z_acacia = Blocks.log2.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.Z);
/* 1513 */   public static final IBlockState log2_z_darkoak = Blocks.log2.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.Z).withProperty(BlockNewLog.VARIANT, BlockPlanks.EnumType.DARK_OAK);
/* 1514 */   public static final IBlockState log2_none_acacia = Blocks.log2.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.NONE);
/* 1515 */   public static final IBlockState log2_none_darkoak = Blocks.log2.getDefaultState().withProperty(BlockLog.LOG_AXIS, BlockLog.EnumAxis.NONE).withProperty(BlockNewLog.VARIANT, BlockPlanks.EnumType.DARK_OAK);
/* 1516 */   public static final IBlockState leaves_oak_decayable = Blocks.leaves.getDefaultState().withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false));
/* 1517 */   public static final IBlockState leaves_spruce_decayable = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.SPRUCE).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false));
/* 1518 */   public static final IBlockState leaves_birch_decayable = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.BIRCH).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false));
/* 1519 */   public static final IBlockState leaves_jungle_decayable = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.JUNGLE).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false));
/* 1520 */   public static final IBlockState leaves_oak = Blocks.leaves.getDefaultState().withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false)).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1521 */   public static final IBlockState leaves_spruce = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.SPRUCE).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false)).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1522 */   public static final IBlockState leaves_birch = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.BIRCH).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false)).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1523 */   public static final IBlockState leaves_jungle = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.JUNGLE).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false)).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1524 */   public static final IBlockState leaves_oak_checkdecay_decayable = Blocks.leaves.getDefaultState();
/* 1525 */   public static final IBlockState leaves_spruce_checkdecay_decayable = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.SPRUCE);
/* 1526 */   public static final IBlockState leaves_birch_checkdecay_decayable = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.BIRCH);
/* 1527 */   public static final IBlockState leaves_jungle_checkdecay_decayable = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.JUNGLE);
/* 1528 */   public static final IBlockState leaves_oak_checkdecay = Blocks.leaves.getDefaultState().withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1529 */   public static final IBlockState leaves_spruce_checkdecay = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.SPRUCE).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1530 */   public static final IBlockState leaves_birch_checkdecay = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.BIRCH).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1531 */   public static final IBlockState leaves_jungle_checkdecay = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.JUNGLE).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1532 */   public static final IBlockState leaves2_acacia_decayable = Blocks.leaves2.getDefaultState().withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false));
/* 1533 */   public static final IBlockState leaves2_darkoak_decayable = Blocks.leaves2.getDefaultState().withProperty(BlockNewLeaf.VARIANT, BlockPlanks.EnumType.DARK_OAK).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false));
/* 1534 */   public static final IBlockState leaves2_acacia = Blocks.leaves2.getDefaultState().withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false)).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1535 */   public static final IBlockState leaves2_darkoak = Blocks.leaves2.getDefaultState().withProperty(BlockNewLeaf.VARIANT, BlockPlanks.EnumType.DARK_OAK).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(false)).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1536 */   public static final IBlockState leaves2_acacia_checkdecay_decayable = Blocks.leaves2.getDefaultState();
/* 1537 */   public static final IBlockState leaves2_darkoak_checkdecay_decayable = Blocks.leaves2.getDefaultState().withProperty(BlockNewLeaf.VARIANT, BlockPlanks.EnumType.DARK_OAK);
/* 1538 */   public static final IBlockState leaves2_acacia_checkdecay = Blocks.leaves2.getDefaultState().withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1539 */   public static final IBlockState leaves2_darkoak_checkdecay = Blocks.leaves2.getDefaultState().withProperty(BlockNewLeaf.VARIANT, BlockPlanks.EnumType.DARK_OAK).withProperty(BlockLeaves.DECAYABLE, Boolean.valueOf(false));
/* 1540 */   public static final IBlockState sponge = Blocks.sponge.getDefaultState();
/* 1541 */   public static final IBlockState sponge_wet = Blocks.sponge.getDefaultState().withProperty(BlockSponge.WET, Boolean.valueOf(true));
/* 1542 */   public static final IBlockState glass = Blocks.glass.getDefaultState();
/* 1543 */   public static final IBlockState lapis_ore = Blocks.lapis_ore.getDefaultState();
/* 1544 */   public static final IBlockState lapis_block = Blocks.lapis_block.getDefaultState();
/* 1545 */   public static final IBlockState dispenser_down = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.DOWN);
/* 1546 */   public static final IBlockState dispenser_up = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.UP);
/* 1547 */   public static final IBlockState dispenser_north = Blocks.dispenser.getDefaultState();
/* 1548 */   public static final IBlockState dispenser_south = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.SOUTH);
/* 1549 */   public static final IBlockState dispenser_west = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.WEST);
/* 1550 */   public static final IBlockState dispenser_east = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.EAST);
/* 1551 */   public static final IBlockState dispenser_down_triggered = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.DOWN).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 1552 */   public static final IBlockState dispenser_up_triggered = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.UP).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 1553 */   public static final IBlockState dispenser_north_triggered = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 1554 */   public static final IBlockState dispenser_south_triggered = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.SOUTH).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 1555 */   public static final IBlockState dispenser_west_triggered = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.WEST).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 1556 */   public static final IBlockState dispenser_east_triggered = Blocks.dispenser.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.EAST).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 1557 */   public static final IBlockState sandstone = Blocks.sandstone.getDefaultState();
/* 1558 */   public static final IBlockState sandstone_chiseledsandstone = Blocks.sandstone.getDefaultState().withProperty(BlockSandStone.TYPE, BlockSandStone.EnumType.CHISELED);
/* 1559 */   public static final IBlockState sandstone_smoothsandstone = Blocks.sandstone.getDefaultState().withProperty(BlockSandStone.TYPE, BlockSandStone.EnumType.SMOOTH);
/* 1560 */   public static final IBlockState noteblock = Blocks.noteblock.getDefaultState();
/* 1561 */   public static final IBlockState bed_foot_south = Blocks.bed.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 1562 */   public static final IBlockState bed_foot_west = Blocks.bed.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 1563 */   public static final IBlockState bed_foot_north = Blocks.bed.getDefaultState();
/* 1564 */   public static final IBlockState bed_foot_east = Blocks.bed.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 1565 */   public static final IBlockState bed_head_south = Blocks.bed.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.HEAD).withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 1566 */   public static final IBlockState bed_head_west = Blocks.bed.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.HEAD).withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 1567 */   public static final IBlockState bed_head_north = Blocks.bed.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.HEAD);
/* 1568 */   public static final IBlockState bed_head_east = Blocks.bed.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.HEAD).withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 1569 */   public static final IBlockState bed_head_south_occupied = Blocks.bed.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.HEAD).withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockBed.OCCUPIED, Boolean.valueOf(true));
/* 1570 */   public static final IBlockState bed_head_west_occupied = Blocks.bed.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.HEAD).withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockBed.OCCUPIED, Boolean.valueOf(true));
/* 1571 */   public static final IBlockState bed_head_north_occupied = Blocks.bed.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.HEAD).withProperty(BlockBed.OCCUPIED, Boolean.valueOf(true));
/* 1572 */   public static final IBlockState bed_head_east_occupied = Blocks.bed.getDefaultState().withProperty(BlockBed.PART, BlockBed.EnumPartType.HEAD).withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockBed.OCCUPIED, Boolean.valueOf(true));
/* 1573 */   public static final IBlockState golden_rail_northsouth = Blocks.golden_rail.getDefaultState();
/* 1574 */   public static final IBlockState golden_rail_eastwest = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
/* 1575 */   public static final IBlockState golden_rail_ascendingeast = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
/* 1576 */   public static final IBlockState golden_rail_ascendingwest = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
/* 1577 */   public static final IBlockState golden_rail_ascendingnorth = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
/* 1578 */   public static final IBlockState golden_rail_ascendingsouth = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
/* 1579 */   public static final IBlockState golden_rail_northsouth_powered = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 1580 */   public static final IBlockState golden_rail_eastwest_powered = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 1581 */   public static final IBlockState golden_rail_ascendingeast_powered = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 1582 */   public static final IBlockState golden_rail_ascendingwest_powered = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 1583 */   public static final IBlockState golden_rail_ascendingnorth_powered = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 1584 */   public static final IBlockState golden_rail_ascendingsouth_powered = Blocks.golden_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 1585 */   public static final IBlockState detector_rail_northsouth = Blocks.detector_rail.getDefaultState();
/* 1586 */   public static final IBlockState detector_rail_eastwest = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
/* 1587 */   public static final IBlockState detector_rail_ascendingeast = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
/* 1588 */   public static final IBlockState detector_rail_ascendingwest = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
/* 1589 */   public static final IBlockState detector_rail_ascendingnorth = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
/* 1590 */   public static final IBlockState detector_rail_ascendingsouth = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
/* 1591 */   public static final IBlockState detector_rail_northsouth_powered = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.POWERED, Boolean.valueOf(true));
/* 1592 */   public static final IBlockState detector_rail_eastwest_powered = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST).withProperty(BlockRailDetector.POWERED, Boolean.valueOf(true));
/* 1593 */   public static final IBlockState detector_rail_ascendingeast_powered = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST).withProperty(BlockRailDetector.POWERED, Boolean.valueOf(true));
/* 1594 */   public static final IBlockState detector_rail_ascendingwest_powered = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST).withProperty(BlockRailDetector.POWERED, Boolean.valueOf(true));
/* 1595 */   public static final IBlockState detector_rail_ascendingnorth_powered = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH).withProperty(BlockRailDetector.POWERED, Boolean.valueOf(true));
/* 1596 */   public static final IBlockState detector_rail_ascendingsouth_powered = Blocks.detector_rail.getDefaultState().withProperty(BlockRailDetector.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH).withProperty(BlockRailDetector.POWERED, Boolean.valueOf(true));
/* 1597 */   public static final IBlockState sticky_piston_down = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.DOWN);
/* 1598 */   public static final IBlockState sticky_piston_up = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.UP);
/* 1599 */   public static final IBlockState sticky_piston_north = Blocks.sticky_piston.getDefaultState();
/* 1600 */   public static final IBlockState sticky_piston_south = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.SOUTH);
/* 1601 */   public static final IBlockState sticky_piston_west = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.WEST);
/* 1602 */   public static final IBlockState sticky_piston_east = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.EAST);
/* 1603 */   public static final IBlockState sticky_piston_down_extended = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.DOWN).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1604 */   public static final IBlockState sticky_piston_up_extended = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.UP).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1605 */   public static final IBlockState sticky_piston_north_extended = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1606 */   public static final IBlockState sticky_piston_south_extended = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.SOUTH).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1607 */   public static final IBlockState sticky_piston_west_extended = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.WEST).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1608 */   public static final IBlockState sticky_piston_east_extended = Blocks.sticky_piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.EAST).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1609 */   public static final IBlockState web = Blocks.web.getDefaultState();
/* 1610 */   public static final IBlockState tallgrass_deadbush = Blocks.tallgrass.getDefaultState();
/* 1611 */   public static final IBlockState tallgrass_tallgrass = Blocks.tallgrass.getDefaultState().withProperty(BlockTallGrass.TYPE, BlockTallGrass.EnumType.GRASS);
/* 1612 */   public static final IBlockState tallgrass_fern = Blocks.tallgrass.getDefaultState().withProperty(BlockTallGrass.TYPE, BlockTallGrass.EnumType.FERN);
/* 1613 */   public static final IBlockState deadbush = Blocks.deadbush.getDefaultState();
/* 1614 */   public static final IBlockState piston_down = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.DOWN);
/* 1615 */   public static final IBlockState piston_up = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.UP);
/* 1616 */   public static final IBlockState piston_north = Blocks.piston.getDefaultState();
/* 1617 */   public static final IBlockState piston_south = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.SOUTH);
/* 1618 */   public static final IBlockState piston_west = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.WEST);
/* 1619 */   public static final IBlockState piston_east = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.EAST);
/* 1620 */   public static final IBlockState piston_down_extended = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.DOWN).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1621 */   public static final IBlockState piston_up_extended = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.UP).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1622 */   public static final IBlockState piston_north_extended = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1623 */   public static final IBlockState piston_south_extended = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.SOUTH).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1624 */   public static final IBlockState piston_west_extended = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.WEST).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1625 */   public static final IBlockState piston_east_extended = Blocks.piston.getDefaultState().withProperty(BlockPistonBase.field_176321_a, EnumFacing.EAST).withProperty(BlockPistonBase.EXTENDED, Boolean.valueOf(true));
/* 1626 */   public static final IBlockState piston_head_normal_down = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.DOWN);
/* 1627 */   public static final IBlockState piston_head_normal_up = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.UP);
/* 1628 */   public static final IBlockState piston_head_normal_north = Blocks.piston_head.getDefaultState();
/* 1629 */   public static final IBlockState piston_head_normal_south = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.SOUTH);
/* 1630 */   public static final IBlockState piston_head_normal_west = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.WEST);
/* 1631 */   public static final IBlockState piston_head_normal_east = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.EAST);
/* 1632 */   public static final IBlockState piston_head_sticky_down = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.DOWN);
/* 1633 */   public static final IBlockState piston_head_sticky_up = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.UP);
/* 1634 */   public static final IBlockState piston_head_sticky_north = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY);
/* 1635 */   public static final IBlockState piston_head_sticky_south = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.SOUTH);
/* 1636 */   public static final IBlockState piston_head_sticky_west = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.WEST);
/* 1637 */   public static final IBlockState piston_head_sticky_east = Blocks.piston_head.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.EAST);
/* 1638 */   public static final IBlockState wool_white = Blocks.wool.getDefaultState();
/* 1639 */   public static final IBlockState wool_orange = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.ORANGE);
/* 1640 */   public static final IBlockState wool_magenta = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.MAGENTA);
/* 1641 */   public static final IBlockState wool_lightblue = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.LIGHT_BLUE);
/* 1642 */   public static final IBlockState wool_yellow = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.YELLOW);
/* 1643 */   public static final IBlockState wool_lime = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.LIME);
/* 1644 */   public static final IBlockState wool_pink = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.PINK);
/* 1645 */   public static final IBlockState wool_gray = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.GRAY);
/* 1646 */   public static final IBlockState wool_silver = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.SILVER);
/* 1647 */   public static final IBlockState wool_cyan = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.CYAN);
/* 1648 */   public static final IBlockState wool_purple = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.PURPLE);
/* 1649 */   public static final IBlockState wool_blue = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.BLUE);
/* 1650 */   public static final IBlockState wool_brown = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.BROWN);
/* 1651 */   public static final IBlockState wool_green = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.GREEN);
/* 1652 */   public static final IBlockState wool_red = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.RED);
/* 1653 */   public static final IBlockState wool_black = Blocks.wool.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.BLACK);
/* 1654 */   public static final IBlockState piston_extension_normal_down = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.DOWN);
/* 1655 */   public static final IBlockState piston_extension_normal_up = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.UP);
/* 1656 */   public static final IBlockState piston_extension_normal_north = Blocks.piston_extension.getDefaultState();
/* 1657 */   public static final IBlockState piston_extension_normal_south = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.SOUTH);
/* 1658 */   public static final IBlockState piston_extension_normal_west = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.WEST);
/* 1659 */   public static final IBlockState piston_extension_normal_east = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.FACING, EnumFacing.EAST);
/* 1660 */   public static final IBlockState piston_extension_sticky_down = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.DOWN);
/* 1661 */   public static final IBlockState piston_extension_sticky_up = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.UP);
/* 1662 */   public static final IBlockState piston_extension_sticky_north = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY);
/* 1663 */   public static final IBlockState piston_extension_sticky_south = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.SOUTH);
/* 1664 */   public static final IBlockState piston_extension_sticky_west = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.WEST);
/* 1665 */   public static final IBlockState piston_extension_sticky_east = Blocks.piston_extension.getDefaultState().withProperty(BlockPistonMoving.TYPE, BlockPistonExtension.EnumPistonType.STICKY).withProperty(BlockPistonMoving.FACING, EnumFacing.EAST);
/* 1666 */   public static final IBlockState yellow_flower = Blocks.yellow_flower.getDefaultState();
/* 1667 */   public static final IBlockState red_flower_poppy = Blocks.red_flower.getDefaultState();
/* 1668 */   public static final IBlockState red_flower_blueorchid = Blocks.red_flower.getDefaultState().withProperty(Blocks.red_flower.getTypeProperty(), BlockFlower.EnumFlowerType.BLUE_ORCHID);
/* 1669 */   public static final IBlockState red_flower_allium = Blocks.red_flower.getDefaultState().withProperty(Blocks.red_flower.getTypeProperty(), BlockFlower.EnumFlowerType.ALLIUM);
/* 1670 */   public static final IBlockState red_flower_houstonia = Blocks.red_flower.getDefaultState().withProperty(Blocks.red_flower.getTypeProperty(), BlockFlower.EnumFlowerType.HOUSTONIA);
/* 1671 */   public static final IBlockState red_flower_redtulip = Blocks.red_flower.getDefaultState().withProperty(Blocks.red_flower.getTypeProperty(), BlockFlower.EnumFlowerType.RED_TULIP);
/* 1672 */   public static final IBlockState red_flower_orangetulip = Blocks.red_flower.getDefaultState().withProperty(Blocks.red_flower.getTypeProperty(), BlockFlower.EnumFlowerType.ORANGE_TULIP);
/* 1673 */   public static final IBlockState red_flower_whitetulip = Blocks.red_flower.getDefaultState().withProperty(Blocks.red_flower.getTypeProperty(), BlockFlower.EnumFlowerType.WHITE_TULIP);
/* 1674 */   public static final IBlockState red_flower_pinktulip = Blocks.red_flower.getDefaultState().withProperty(Blocks.red_flower.getTypeProperty(), BlockFlower.EnumFlowerType.PINK_TULIP);
/* 1675 */   public static final IBlockState red_flower_oxeyedaisy = Blocks.red_flower.getDefaultState().withProperty(Blocks.red_flower.getTypeProperty(), BlockFlower.EnumFlowerType.OXEYE_DAISY);
/* 1676 */   public static final IBlockState brown_mushroom = Blocks.brown_mushroom.getDefaultState();
/* 1677 */   public static final IBlockState red_mushroom = Blocks.red_mushroom.getDefaultState();
/* 1678 */   public static final IBlockState gold_block = Blocks.gold_block.getDefaultState();
/* 1679 */   public static final IBlockState iron_block = Blocks.iron_block.getDefaultState();
/* 1680 */   public static final IBlockState double_stone_slab_stone = Blocks.double_stone_slab.getDefaultState();
/* 1681 */   public static final IBlockState double_stone_slab_sandstone = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.SAND);
/* 1682 */   public static final IBlockState double_stone_slab_woodold = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.WOOD);
/* 1683 */   public static final IBlockState double_stone_slab_cobblestone = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.COBBLESTONE);
/* 1684 */   public static final IBlockState double_stone_slab_brick = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.BRICK);
/* 1685 */   public static final IBlockState double_stone_slab_stonebrick = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.SMOOTHBRICK);
/* 1686 */   public static final IBlockState double_stone_slab_netherbrick = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.NETHERBRICK);
/* 1687 */   public static final IBlockState double_stone_slab_quartz = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.QUARTZ);
/* 1688 */   public static final IBlockState double_stone_slab_stone_seamless = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.SEAMLESS, Boolean.valueOf(true));
/* 1689 */   public static final IBlockState double_stone_slab_sandstone_seamless = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.SAND).withProperty(BlockStoneSlab.SEAMLESS, Boolean.valueOf(true));
/* 1690 */   public static final IBlockState double_stone_slab_woodold_seamless = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.WOOD).withProperty(BlockStoneSlab.SEAMLESS, Boolean.valueOf(true));
/* 1691 */   public static final IBlockState double_stone_slab_cobblestone_seamless = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.COBBLESTONE).withProperty(BlockStoneSlab.SEAMLESS, Boolean.valueOf(true));
/* 1692 */   public static final IBlockState double_stone_slab_brick_seamless = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.BRICK).withProperty(BlockStoneSlab.SEAMLESS, Boolean.valueOf(true));
/* 1693 */   public static final IBlockState double_stone_slab_stonebrick_seamless = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.SMOOTHBRICK).withProperty(BlockStoneSlab.SEAMLESS, Boolean.valueOf(true));
/* 1694 */   public static final IBlockState double_stone_slab_netherbrick_seamless = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.NETHERBRICK).withProperty(BlockStoneSlab.SEAMLESS, Boolean.valueOf(true));
/* 1695 */   public static final IBlockState double_stone_slab_quartz_seamless = Blocks.double_stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.QUARTZ).withProperty(BlockStoneSlab.SEAMLESS, Boolean.valueOf(true));
/* 1696 */   public static final IBlockState stone_slab_bottom_stone = Blocks.stone_slab.getDefaultState();
/* 1697 */   public static final IBlockState stone_slab_bottom_sandstone = Blocks.stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.SAND);
/* 1698 */   public static final IBlockState stone_slab_bottom_woodold = Blocks.stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.WOOD);
/* 1699 */   public static final IBlockState stone_slab_bottom_cobblestone = Blocks.stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.COBBLESTONE);
/* 1700 */   public static final IBlockState stone_slab_bottom_brick = Blocks.stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.BRICK);
/* 1701 */   public static final IBlockState stone_slab_bottom_stonebrick = Blocks.stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.SMOOTHBRICK);
/* 1702 */   public static final IBlockState stone_slab_bottom_netherbrick = Blocks.stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.NETHERBRICK);
/* 1703 */   public static final IBlockState stone_slab_bottom_quartz = Blocks.stone_slab.getDefaultState().withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.QUARTZ);
/* 1704 */   public static final IBlockState stone_slab_top_stone = Blocks.stone_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP);
/* 1705 */   public static final IBlockState stone_slab_top_sandstone = Blocks.stone_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.SAND);
/* 1706 */   public static final IBlockState stone_slab_top_woodold = Blocks.stone_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.WOOD);
/* 1707 */   public static final IBlockState stone_slab_top_cobblestone = Blocks.stone_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.COBBLESTONE);
/* 1708 */   public static final IBlockState stone_slab_top_brick = Blocks.stone_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.BRICK);
/* 1709 */   public static final IBlockState stone_slab_top_stonebrick = Blocks.stone_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.SMOOTHBRICK);
/* 1710 */   public static final IBlockState stone_slab_top_netherbrick = Blocks.stone_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.NETHERBRICK);
/* 1711 */   public static final IBlockState stone_slab_top_quartz = Blocks.stone_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockStoneSlab.VARIANT, BlockStoneSlab.EnumType.QUARTZ);
/* 1712 */   public static final IBlockState brick_block = Blocks.brick_block.getDefaultState();
/* 1713 */   public static final IBlockState tnt = Blocks.tnt.getDefaultState();
/* 1714 */   public static final IBlockState tnt_explode = Blocks.tnt.getDefaultState().withProperty(BlockTNT.EXPLODE, Boolean.valueOf(true));
/* 1715 */   public static final IBlockState bookshelf = Blocks.bookshelf.getDefaultState();
/* 1716 */   public static final IBlockState mossy_cobblestone = Blocks.mossy_cobblestone.getDefaultState();
/* 1717 */   public static final IBlockState obsidian = Blocks.obsidian.getDefaultState();
/* 1718 */   public static final IBlockState torch_east = Blocks.torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.EAST);
/* 1719 */   public static final IBlockState torch_west = Blocks.torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.WEST);
/* 1720 */   public static final IBlockState torch_south = Blocks.torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.SOUTH);
/* 1721 */   public static final IBlockState torch_north = Blocks.torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.NORTH);
/* 1722 */   public static final IBlockState torch_up = Blocks.torch.getDefaultState();
/* 1723 */   public static final IBlockState fire_age_0 = Blocks.fire.getDefaultState();
/* 1724 */   public static final IBlockState fire_age_1 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(1));
/* 1725 */   public static final IBlockState fire_age_2 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(2));
/* 1726 */   public static final IBlockState fire_age_3 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(3));
/* 1727 */   public static final IBlockState fire_age_4 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(4));
/* 1728 */   public static final IBlockState fire_age_5 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(5));
/* 1729 */   public static final IBlockState fire_age_6 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(6));
/* 1730 */   public static final IBlockState fire_age_7 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(7));
/* 1731 */   public static final IBlockState fire_age_8 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(8));
/* 1732 */   public static final IBlockState fire_age_9 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(9));
/* 1733 */   public static final IBlockState fire_age_10 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(10));
/* 1734 */   public static final IBlockState fire_age_11 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(11));
/* 1735 */   public static final IBlockState fire_age_12 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(12));
/* 1736 */   public static final IBlockState fire_age_13 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(13));
/* 1737 */   public static final IBlockState fire_age_14 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(14));
/* 1738 */   public static final IBlockState fire_age_15 = Blocks.fire.getDefaultState().withProperty(BlockFire.AGE, Integer.valueOf(15));
/* 1739 */   public static final IBlockState mob_spawner = Blocks.mob_spawner.getDefaultState();
/* 1740 */   public static final IBlockState oak_stairs_bottom_east = Blocks.oak_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 1741 */   public static final IBlockState oak_stairs_bottom_west = Blocks.oak_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 1742 */   public static final IBlockState oak_stairs_bottom_south = Blocks.oak_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 1743 */   public static final IBlockState oak_stairs_bottom_north = Blocks.oak_stairs.getDefaultState();
/* 1744 */   public static final IBlockState oak_stairs_top_east = Blocks.oak_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 1745 */   public static final IBlockState oak_stairs_top_west = Blocks.oak_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 1746 */   public static final IBlockState oak_stairs_top_south = Blocks.oak_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 1747 */   public static final IBlockState oak_stairs_top_north = Blocks.oak_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 1748 */   public static final IBlockState chest_north = Blocks.chest.getDefaultState();
/* 1749 */   public static final IBlockState chest_south = Blocks.chest.getDefaultState().withProperty(BlockChest.FACING, EnumFacing.SOUTH);
/* 1750 */   public static final IBlockState chest_west = Blocks.chest.getDefaultState().withProperty(BlockChest.FACING, EnumFacing.WEST);
/* 1751 */   public static final IBlockState chest_east = Blocks.chest.getDefaultState().withProperty(BlockChest.FACING, EnumFacing.EAST);
/* 1752 */   public static final IBlockState redstone_wire_power_0 = Blocks.redstone_wire.getDefaultState();
/* 1753 */   public static final IBlockState redstone_wire_power_1 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(1));
/* 1754 */   public static final IBlockState redstone_wire_power_2 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(2));
/* 1755 */   public static final IBlockState redstone_wire_power_3 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(3));
/* 1756 */   public static final IBlockState redstone_wire_power_4 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(4));
/* 1757 */   public static final IBlockState redstone_wire_power_5 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(5));
/* 1758 */   public static final IBlockState redstone_wire_power_6 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(6));
/* 1759 */   public static final IBlockState redstone_wire_power_7 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(7));
/* 1760 */   public static final IBlockState redstone_wire_power_8 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(8));
/* 1761 */   public static final IBlockState redstone_wire_power_9 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(9));
/* 1762 */   public static final IBlockState redstone_wire_power_10 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(10));
/* 1763 */   public static final IBlockState redstone_wire_power_11 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(11));
/* 1764 */   public static final IBlockState redstone_wire_power_12 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(12));
/* 1765 */   public static final IBlockState redstone_wire_power_13 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(13));
/* 1766 */   public static final IBlockState redstone_wire_power_14 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(14));
/* 1767 */   public static final IBlockState redstone_wire_power_15 = Blocks.redstone_wire.getDefaultState().withProperty(BlockRedstoneWire.POWER, Integer.valueOf(15));
/* 1768 */   public static final IBlockState diamond_ore = Blocks.diamond_ore.getDefaultState();
/* 1769 */   public static final IBlockState diamond_block = Blocks.diamond_block.getDefaultState();
/* 1770 */   public static final IBlockState crafting_table = Blocks.crafting_table.getDefaultState();
/* 1771 */   public static final IBlockState wheat_age_0 = Blocks.wheat.getDefaultState();
/* 1772 */   public static final IBlockState wheat_age_1 = Blocks.wheat.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(1));
/* 1773 */   public static final IBlockState wheat_age_2 = Blocks.wheat.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(2));
/* 1774 */   public static final IBlockState wheat_age_3 = Blocks.wheat.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(3));
/* 1775 */   public static final IBlockState wheat_age_4 = Blocks.wheat.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(4));
/* 1776 */   public static final IBlockState wheat_age_5 = Blocks.wheat.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(5));
/* 1777 */   public static final IBlockState wheat_age_6 = Blocks.wheat.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(6));
/* 1778 */   public static final IBlockState wheat_age_7 = Blocks.wheat.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7));
/* 1779 */   public static final IBlockState farmland_moisture_0 = Blocks.farmland.getDefaultState();
/* 1780 */   public static final IBlockState farmland_moisture_1 = Blocks.farmland.getDefaultState().withProperty(BlockFarmland.MOISTURE, Integer.valueOf(1));
/* 1781 */   public static final IBlockState farmland_moisture_2 = Blocks.farmland.getDefaultState().withProperty(BlockFarmland.MOISTURE, Integer.valueOf(2));
/* 1782 */   public static final IBlockState farmland_moisture_3 = Blocks.farmland.getDefaultState().withProperty(BlockFarmland.MOISTURE, Integer.valueOf(3));
/* 1783 */   public static final IBlockState farmland_moisture_4 = Blocks.farmland.getDefaultState().withProperty(BlockFarmland.MOISTURE, Integer.valueOf(4));
/* 1784 */   public static final IBlockState farmland_moisture_5 = Blocks.farmland.getDefaultState().withProperty(BlockFarmland.MOISTURE, Integer.valueOf(5));
/* 1785 */   public static final IBlockState farmland_moisture_6 = Blocks.farmland.getDefaultState().withProperty(BlockFarmland.MOISTURE, Integer.valueOf(6));
/* 1786 */   public static final IBlockState farmland_moisture_7 = Blocks.farmland.getDefaultState().withProperty(BlockFarmland.MOISTURE, Integer.valueOf(7));
/* 1787 */   public static final IBlockState furnace_north = Blocks.furnace.getDefaultState();
/* 1788 */   public static final IBlockState furnace_south = Blocks.furnace.getDefaultState().withProperty(BlockFurnace.FACING, EnumFacing.SOUTH);
/* 1789 */   public static final IBlockState furnace_west = Blocks.furnace.getDefaultState().withProperty(BlockFurnace.FACING, EnumFacing.WEST);
/* 1790 */   public static final IBlockState furnace_east = Blocks.furnace.getDefaultState().withProperty(BlockFurnace.FACING, EnumFacing.EAST);
/* 1791 */   public static final IBlockState lit_furnace_north = Blocks.lit_furnace.getDefaultState();
/* 1792 */   public static final IBlockState lit_furnace_south = Blocks.lit_furnace.getDefaultState().withProperty(BlockFurnace.FACING, EnumFacing.SOUTH);
/* 1793 */   public static final IBlockState lit_furnace_west = Blocks.lit_furnace.getDefaultState().withProperty(BlockFurnace.FACING, EnumFacing.WEST);
/* 1794 */   public static final IBlockState lit_furnace_east = Blocks.lit_furnace.getDefaultState().withProperty(BlockFurnace.FACING, EnumFacing.EAST);
/* 1795 */   public static final IBlockState standing_sign_rotation_0 = Blocks.standing_sign.getDefaultState();
/* 1796 */   public static final IBlockState standing_sign_rotation_1 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(1));
/* 1797 */   public static final IBlockState standing_sign_rotation_2 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(2));
/* 1798 */   public static final IBlockState standing_sign_rotation_3 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(3));
/* 1799 */   public static final IBlockState standing_sign_rotation_4 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(4));
/* 1800 */   public static final IBlockState standing_sign_rotation_5 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(5));
/* 1801 */   public static final IBlockState standing_sign_rotation_6 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(6));
/* 1802 */   public static final IBlockState standing_sign_rotation_7 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(7));
/* 1803 */   public static final IBlockState standing_sign_rotation_8 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(8));
/* 1804 */   public static final IBlockState standing_sign_rotation_9 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(9));
/* 1805 */   public static final IBlockState standing_sign_rotation_10 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(10));
/* 1806 */   public static final IBlockState standing_sign_rotation_11 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(11));
/* 1807 */   public static final IBlockState standing_sign_rotation_12 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(12));
/* 1808 */   public static final IBlockState standing_sign_rotation_13 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(13));
/* 1809 */   public static final IBlockState standing_sign_rotation_14 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(14));
/* 1810 */   public static final IBlockState standing_sign_rotation_15 = Blocks.standing_sign.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(15));
/* 1811 */   public static final IBlockState oak_door_lower_left_east = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST);
/* 1812 */   public static final IBlockState oak_door_lower_left_south = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH);
/* 1813 */   public static final IBlockState oak_door_lower_left_west = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST);
/* 1814 */   public static final IBlockState oak_door_lower_left_north = Blocks.oak_door.getDefaultState();
/* 1815 */   public static final IBlockState oak_door_lower_left_east_open = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1816 */   public static final IBlockState oak_door_lower_left_south_open = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1817 */   public static final IBlockState oak_door_lower_left_west_open = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1818 */   public static final IBlockState oak_door_lower_left_north_open = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1819 */   public static final IBlockState oak_door_upper_left_north = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER);
/* 1820 */   public static final IBlockState oak_door_upper_right_north = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT);
/* 1821 */   public static final IBlockState oak_door_upper_left_north_powered = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1822 */   public static final IBlockState oak_door_upper_right_north_powered = Blocks.oak_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1823 */   public static final IBlockState spruce_door_lower_left_east = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST);
/* 1824 */   public static final IBlockState spruce_door_lower_left_south = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH);
/* 1825 */   public static final IBlockState spruce_door_lower_left_west = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST);
/* 1826 */   public static final IBlockState spruce_door_lower_left_north = Blocks.spruce_door.getDefaultState();
/* 1827 */   public static final IBlockState spruce_door_lower_left_east_open = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1828 */   public static final IBlockState spruce_door_lower_left_south_open = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1829 */   public static final IBlockState spruce_door_lower_left_west_open = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1830 */   public static final IBlockState spruce_door_lower_left_north_open = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1831 */   public static final IBlockState spruce_door_upper_left_north = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER);
/* 1832 */   public static final IBlockState spruce_door_upper_right_north = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT);
/* 1833 */   public static final IBlockState spruce_door_upper_left_north_powered = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1834 */   public static final IBlockState spruce_door_upper_right_north_powered = Blocks.spruce_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1835 */   public static final IBlockState birch_door_lower_left_east = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST);
/* 1836 */   public static final IBlockState birch_door_lower_left_south = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH);
/* 1837 */   public static final IBlockState birch_door_lower_left_west = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST);
/* 1838 */   public static final IBlockState birch_door_lower_left_north = Blocks.birch_door.getDefaultState();
/* 1839 */   public static final IBlockState birch_door_lower_left_east_open = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1840 */   public static final IBlockState birch_door_lower_left_south_open = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1841 */   public static final IBlockState birch_door_lower_left_west_open = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1842 */   public static final IBlockState birch_door_lower_left_north_open = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1843 */   public static final IBlockState birch_door_upper_left_north = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER);
/* 1844 */   public static final IBlockState birch_door_upper_right_north = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT);
/* 1845 */   public static final IBlockState birch_door_upper_left_north_powered = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1846 */   public static final IBlockState birch_door_upper_right_north_powered = Blocks.birch_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1847 */   public static final IBlockState jungle_door_lower_left_east = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST);
/* 1848 */   public static final IBlockState jungle_door_lower_left_south = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH);
/* 1849 */   public static final IBlockState jungle_door_lower_left_west = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST);
/* 1850 */   public static final IBlockState jungle_door_lower_left_north = Blocks.jungle_door.getDefaultState();
/* 1851 */   public static final IBlockState jungle_door_lower_left_east_open = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1852 */   public static final IBlockState jungle_door_lower_left_south_open = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1853 */   public static final IBlockState jungle_door_lower_left_west_open = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1854 */   public static final IBlockState jungle_door_lower_left_north_open = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1855 */   public static final IBlockState jungle_door_upper_left_north = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER);
/* 1856 */   public static final IBlockState jungle_door_upper_right_north = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT);
/* 1857 */   public static final IBlockState jungle_door_upper_left_north_powered = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1858 */   public static final IBlockState jungle_door_upper_right_north_powered = Blocks.jungle_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1859 */   public static final IBlockState acacia_door_lower_left_east = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST);
/* 1860 */   public static final IBlockState acacia_door_lower_left_south = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH);
/* 1861 */   public static final IBlockState acacia_door_lower_left_west = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST);
/* 1862 */   public static final IBlockState acacia_door_lower_left_north = Blocks.acacia_door.getDefaultState();
/* 1863 */   public static final IBlockState acacia_door_lower_left_east_open = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1864 */   public static final IBlockState acacia_door_lower_left_south_open = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1865 */   public static final IBlockState acacia_door_lower_left_west_open = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1866 */   public static final IBlockState acacia_door_lower_left_north_open = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1867 */   public static final IBlockState acacia_door_upper_left_north = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER);
/* 1868 */   public static final IBlockState acacia_door_upper_right_north = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT);
/* 1869 */   public static final IBlockState acacia_door_upper_left_north_powered = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1870 */   public static final IBlockState acacia_door_upper_right_north_powered = Blocks.acacia_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1871 */   public static final IBlockState dark_oak_door_lower_left_east = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST);
/* 1872 */   public static final IBlockState dark_oak_door_lower_left_south = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH);
/* 1873 */   public static final IBlockState dark_oak_door_lower_left_west = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST);
/* 1874 */   public static final IBlockState dark_oak_door_lower_left_north = Blocks.dark_oak_door.getDefaultState();
/* 1875 */   public static final IBlockState dark_oak_door_lower_left_east_open = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1876 */   public static final IBlockState dark_oak_door_lower_left_south_open = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1877 */   public static final IBlockState dark_oak_door_lower_left_west_open = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1878 */   public static final IBlockState dark_oak_door_lower_left_north_open = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1879 */   public static final IBlockState dark_oak_door_upper_left_north = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER);
/* 1880 */   public static final IBlockState dark_oak_door_upper_right_north = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT);
/* 1881 */   public static final IBlockState dark_oak_door_upper_left_north_powered = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1882 */   public static final IBlockState dark_oak_door_upper_right_north_powered = Blocks.dark_oak_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1883 */   public static final IBlockState ladder_north = Blocks.ladder.getDefaultState();
/* 1884 */   public static final IBlockState ladder_south = Blocks.ladder.getDefaultState().withProperty(BlockLadder.FACING, EnumFacing.SOUTH);
/* 1885 */   public static final IBlockState ladder_west = Blocks.ladder.getDefaultState().withProperty(BlockLadder.FACING, EnumFacing.WEST);
/* 1886 */   public static final IBlockState ladder_east = Blocks.ladder.getDefaultState().withProperty(BlockLadder.FACING, EnumFacing.EAST);
/* 1887 */   public static final IBlockState rail_northsouth = Blocks.rail.getDefaultState();
/* 1888 */   public static final IBlockState rail_eastwest = Blocks.rail.getDefaultState().withProperty(BlockRail.SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
/* 1889 */   public static final IBlockState rail_ascendingeast = Blocks.rail.getDefaultState().withProperty(BlockRail.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
/* 1890 */   public static final IBlockState rail_ascendingwest = Blocks.rail.getDefaultState().withProperty(BlockRail.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
/* 1891 */   public static final IBlockState rail_ascendingnorth = Blocks.rail.getDefaultState().withProperty(BlockRail.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
/* 1892 */   public static final IBlockState rail_ascendingsouth = Blocks.rail.getDefaultState().withProperty(BlockRail.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
/* 1893 */   public static final IBlockState rail_southeast = Blocks.rail.getDefaultState().withProperty(BlockRail.SHAPE, BlockRailBase.EnumRailDirection.SOUTH_EAST);
/* 1894 */   public static final IBlockState rail_southwest = Blocks.rail.getDefaultState().withProperty(BlockRail.SHAPE, BlockRailBase.EnumRailDirection.SOUTH_WEST);
/* 1895 */   public static final IBlockState rail_northwest = Blocks.rail.getDefaultState().withProperty(BlockRail.SHAPE, BlockRailBase.EnumRailDirection.NORTH_WEST);
/* 1896 */   public static final IBlockState rail_northeast = Blocks.rail.getDefaultState().withProperty(BlockRail.SHAPE, BlockRailBase.EnumRailDirection.NORTH_EAST);
/* 1897 */   public static final IBlockState stone_stairs_bottom_east = Blocks.stone_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 1898 */   public static final IBlockState stone_stairs_bottom_west = Blocks.stone_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 1899 */   public static final IBlockState stone_stairs_bottom_south = Blocks.stone_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 1900 */   public static final IBlockState stone_stairs_bottom_north = Blocks.stone_stairs.getDefaultState();
/* 1901 */   public static final IBlockState stone_stairs_top_east = Blocks.stone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 1902 */   public static final IBlockState stone_stairs_top_west = Blocks.stone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 1903 */   public static final IBlockState stone_stairs_top_south = Blocks.stone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 1904 */   public static final IBlockState stone_stairs_top_north = Blocks.stone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 1905 */   public static final IBlockState wall_sign_north = Blocks.wall_sign.getDefaultState();
/* 1906 */   public static final IBlockState wall_sign_south = Blocks.wall_sign.getDefaultState().withProperty(BlockWallSign.FACING, EnumFacing.SOUTH);
/* 1907 */   public static final IBlockState wall_sign_west = Blocks.wall_sign.getDefaultState().withProperty(BlockWallSign.FACING, EnumFacing.WEST);
/* 1908 */   public static final IBlockState wall_sign_east = Blocks.wall_sign.getDefaultState().withProperty(BlockWallSign.FACING, EnumFacing.EAST);
/* 1909 */   public static final IBlockState lever_downx = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.DOWN_X);
/* 1910 */   public static final IBlockState lever_east = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.EAST);
/* 1911 */   public static final IBlockState lever_west = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.WEST);
/* 1912 */   public static final IBlockState lever_south = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.SOUTH);
/* 1913 */   public static final IBlockState lever_north = Blocks.lever.getDefaultState();
/* 1914 */   public static final IBlockState lever_upz = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.UP_Z);
/* 1915 */   public static final IBlockState lever_upx = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.UP_X);
/* 1916 */   public static final IBlockState lever_downz = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.DOWN_Z);
/* 1917 */   public static final IBlockState lever_downx_powered = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.DOWN_X).withProperty(BlockLever.POWERED, Boolean.valueOf(true));
/* 1918 */   public static final IBlockState lever_east_powered = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.EAST).withProperty(BlockLever.POWERED, Boolean.valueOf(true));
/* 1919 */   public static final IBlockState lever_west_powered = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.WEST).withProperty(BlockLever.POWERED, Boolean.valueOf(true));
/* 1920 */   public static final IBlockState lever_south_powered = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.SOUTH).withProperty(BlockLever.POWERED, Boolean.valueOf(true));
/* 1921 */   public static final IBlockState lever_north_powered = Blocks.lever.getDefaultState().withProperty(BlockLever.POWERED, Boolean.valueOf(true));
/* 1922 */   public static final IBlockState lever_upz_powered = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.UP_Z).withProperty(BlockLever.POWERED, Boolean.valueOf(true));
/* 1923 */   public static final IBlockState lever_upx_powered = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.UP_X).withProperty(BlockLever.POWERED, Boolean.valueOf(true));
/* 1924 */   public static final IBlockState lever_downz_powered = Blocks.lever.getDefaultState().withProperty(BlockLever.FACING, BlockLever.EnumOrientation.DOWN_Z).withProperty(BlockLever.POWERED, Boolean.valueOf(true));
/* 1925 */   public static final IBlockState stone_pressure_plate = Blocks.stone_pressure_plate.getDefaultState();
/* 1926 */   public static final IBlockState stone_pressure_plate_powered = Blocks.stone_pressure_plate.getDefaultState().withProperty(BlockPressurePlate.POWERED, Boolean.valueOf(true));
/* 1927 */   public static final IBlockState iron_door_lower_left_east = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST);
/* 1928 */   public static final IBlockState iron_door_lower_left_south = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH);
/* 1929 */   public static final IBlockState iron_door_lower_left_west = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST);
/* 1930 */   public static final IBlockState iron_door_lower_left_north = Blocks.iron_door.getDefaultState();
/* 1931 */   public static final IBlockState iron_door_lower_left_east_open = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.EAST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1932 */   public static final IBlockState iron_door_lower_left_south_open = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.SOUTH).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1933 */   public static final IBlockState iron_door_lower_left_west_open = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.FACING, EnumFacing.WEST).withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1934 */   public static final IBlockState iron_door_lower_left_north_open = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.OPEN, Boolean.valueOf(true));
/* 1935 */   public static final IBlockState iron_door_upper_left_north = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER);
/* 1936 */   public static final IBlockState iron_door_upper_right_north = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT);
/* 1937 */   public static final IBlockState iron_door_upper_left_north_powered = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1938 */   public static final IBlockState iron_door_upper_right_north_powered = Blocks.iron_door.getDefaultState().withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER).withProperty(BlockDoor.HINGE, BlockDoor.EnumHingePosition.RIGHT).withProperty(BlockDoor.POWERED, Boolean.valueOf(true));
/* 1939 */   public static final IBlockState wooden_pressure_plate = Blocks.wooden_pressure_plate.getDefaultState();
/* 1940 */   public static final IBlockState wooden_pressure_plate_powered = Blocks.wooden_pressure_plate.getDefaultState().withProperty(BlockPressurePlate.POWERED, Boolean.valueOf(true));
/* 1941 */   public static final IBlockState redstone_ore = Blocks.redstone_ore.getDefaultState();
/* 1942 */   public static final IBlockState lit_redstone_ore = Blocks.lit_redstone_ore.getDefaultState();
/* 1943 */   public static final IBlockState unlit_redstone_torch_east = Blocks.unlit_redstone_torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.EAST);
/* 1944 */   public static final IBlockState unlit_redstone_torch_west = Blocks.unlit_redstone_torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.WEST);
/* 1945 */   public static final IBlockState unlit_redstone_torch_south = Blocks.unlit_redstone_torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.SOUTH);
/* 1946 */   public static final IBlockState unlit_redstone_torch_north = Blocks.unlit_redstone_torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.NORTH);
/* 1947 */   public static final IBlockState unlit_redstone_torch_up = Blocks.unlit_redstone_torch.getDefaultState();
/* 1948 */   public static final IBlockState redstone_torch_east = Blocks.redstone_torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.EAST);
/* 1949 */   public static final IBlockState redstone_torch_west = Blocks.redstone_torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.WEST);
/* 1950 */   public static final IBlockState redstone_torch_south = Blocks.redstone_torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.SOUTH);
/* 1951 */   public static final IBlockState redstone_torch_north = Blocks.redstone_torch.getDefaultState().withProperty(BlockTorch.FACING, EnumFacing.NORTH);
/* 1952 */   public static final IBlockState redstone_torch_up = Blocks.redstone_torch.getDefaultState();
/* 1953 */   public static final IBlockState stone_button_down = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.DOWN);
/* 1954 */   public static final IBlockState stone_button_east = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.EAST);
/* 1955 */   public static final IBlockState stone_button_west = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.WEST);
/* 1956 */   public static final IBlockState stone_button_south = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.SOUTH);
/* 1957 */   public static final IBlockState stone_button_north = Blocks.stone_button.getDefaultState();
/* 1958 */   public static final IBlockState stone_button_up = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.UP);
/* 1959 */   public static final IBlockState stone_button_down_powered = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.DOWN).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 1960 */   public static final IBlockState stone_button_east_powered = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.EAST).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 1961 */   public static final IBlockState stone_button_west_powered = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.WEST).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 1962 */   public static final IBlockState stone_button_south_powered = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.SOUTH).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 1963 */   public static final IBlockState stone_button_north_powered = Blocks.stone_button.getDefaultState().withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 1964 */   public static final IBlockState stone_button_up_powered = Blocks.stone_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.UP).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 1965 */   public static final IBlockState snow_layer_layers_1 = Blocks.snow_layer.getDefaultState();
/* 1966 */   public static final IBlockState snow_layer_layers_2 = Blocks.snow_layer.getDefaultState().withProperty(BlockSnow.LAYERS, Integer.valueOf(2));
/* 1967 */   public static final IBlockState snow_layer_layers_3 = Blocks.snow_layer.getDefaultState().withProperty(BlockSnow.LAYERS, Integer.valueOf(3));
/* 1968 */   public static final IBlockState snow_layer_layers_4 = Blocks.snow_layer.getDefaultState().withProperty(BlockSnow.LAYERS, Integer.valueOf(4));
/* 1969 */   public static final IBlockState snow_layer_layers_5 = Blocks.snow_layer.getDefaultState().withProperty(BlockSnow.LAYERS, Integer.valueOf(5));
/* 1970 */   public static final IBlockState snow_layer_layers_6 = Blocks.snow_layer.getDefaultState().withProperty(BlockSnow.LAYERS, Integer.valueOf(6));
/* 1971 */   public static final IBlockState snow_layer_layers_7 = Blocks.snow_layer.getDefaultState().withProperty(BlockSnow.LAYERS, Integer.valueOf(7));
/* 1972 */   public static final IBlockState snow_layer_layers_8 = Blocks.snow_layer.getDefaultState().withProperty(BlockSnow.LAYERS, Integer.valueOf(8));
/* 1973 */   public static final IBlockState ice = Blocks.ice.getDefaultState();
/* 1974 */   public static final IBlockState snow = Blocks.snow.getDefaultState();
/* 1975 */   public static final IBlockState cactus_age_0 = Blocks.cactus.getDefaultState();
/* 1976 */   public static final IBlockState cactus_age_1 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(1));
/* 1977 */   public static final IBlockState cactus_age_2 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(2));
/* 1978 */   public static final IBlockState cactus_age_3 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(3));
/* 1979 */   public static final IBlockState cactus_age_4 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(4));
/* 1980 */   public static final IBlockState cactus_age_5 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(5));
/* 1981 */   public static final IBlockState cactus_age_6 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(6));
/* 1982 */   public static final IBlockState cactus_age_7 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(7));
/* 1983 */   public static final IBlockState cactus_age_8 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(8));
/* 1984 */   public static final IBlockState cactus_age_9 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(9));
/* 1985 */   public static final IBlockState cactus_age_10 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(10));
/* 1986 */   public static final IBlockState cactus_age_11 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(11));
/* 1987 */   public static final IBlockState cactus_age_12 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(12));
/* 1988 */   public static final IBlockState cactus_age_13 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(13));
/* 1989 */   public static final IBlockState cactus_age_14 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(14));
/* 1990 */   public static final IBlockState cactus_age_15 = Blocks.cactus.getDefaultState().withProperty(BlockCactus.AGE, Integer.valueOf(15));
/* 1991 */   public static final IBlockState clay = Blocks.clay.getDefaultState();
/* 1992 */   public static final IBlockState reeds_age_0 = Blocks.reeds.getDefaultState();
/* 1993 */   public static final IBlockState reeds_age_1 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(1));
/* 1994 */   public static final IBlockState reeds_age_2 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(2));
/* 1995 */   public static final IBlockState reeds_age_3 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(3));
/* 1996 */   public static final IBlockState reeds_age_4 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(4));
/* 1997 */   public static final IBlockState reeds_age_5 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(5));
/* 1998 */   public static final IBlockState reeds_age_6 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(6));
/* 1999 */   public static final IBlockState reeds_age_7 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(7));
/* 2000 */   public static final IBlockState reeds_age_8 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(8));
/* 2001 */   public static final IBlockState reeds_age_9 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(9));
/* 2002 */   public static final IBlockState reeds_age_10 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(10));
/* 2003 */   public static final IBlockState reeds_age_11 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(11));
/* 2004 */   public static final IBlockState reeds_age_12 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(12));
/* 2005 */   public static final IBlockState reeds_age_13 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(13));
/* 2006 */   public static final IBlockState reeds_age_14 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(14));
/* 2007 */   public static final IBlockState reeds_age_15 = Blocks.reeds.getDefaultState().withProperty(BlockReed.AGE, Integer.valueOf(15));
/* 2008 */   public static final IBlockState jukebox = Blocks.jukebox.getDefaultState();
/* 2009 */   public static final IBlockState jukebox_hasrecord = Blocks.jukebox.getDefaultState().withProperty(BlockJukebox.HAS_RECORD, Boolean.valueOf(true));
/* 2010 */   public static final IBlockState oak_fence = Blocks.oak_fence.getDefaultState();
/* 2011 */   public static final IBlockState spruce_fence = Blocks.spruce_fence.getDefaultState();
/* 2012 */   public static final IBlockState birch_fence = Blocks.birch_fence.getDefaultState();
/* 2013 */   public static final IBlockState jungle_fence = Blocks.jungle_fence.getDefaultState();
/* 2014 */   public static final IBlockState dark_oak_fence = Blocks.dark_oak_fence.getDefaultState();
/* 2015 */   public static final IBlockState acacia_fence = Blocks.acacia_fence.getDefaultState();
/* 2016 */   public static final IBlockState pumpkin_south = Blocks.pumpkin.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2017 */   public static final IBlockState pumpkin_west = Blocks.pumpkin.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2018 */   public static final IBlockState pumpkin_north = Blocks.pumpkin.getDefaultState();
/* 2019 */   public static final IBlockState pumpkin_east = Blocks.pumpkin.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2020 */   public static final IBlockState netherrack = Blocks.netherrack.getDefaultState();
/* 2021 */   public static final IBlockState soul_sand = Blocks.soul_sand.getDefaultState();
/* 2022 */   public static final IBlockState glowstone = Blocks.glowstone.getDefaultState();
/* 2023 */   public static final IBlockState portal_x = Blocks.portal.getDefaultState();
/* 2024 */   public static final IBlockState portal_z = Blocks.portal.getDefaultState().withProperty(BlockPortal.AXIS, EnumFacing.Axis.Z);
/* 2025 */   public static final IBlockState lit_pumpkin_south = Blocks.lit_pumpkin.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2026 */   public static final IBlockState lit_pumpkin_west = Blocks.lit_pumpkin.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2027 */   public static final IBlockState lit_pumpkin_north = Blocks.lit_pumpkin.getDefaultState();
/* 2028 */   public static final IBlockState lit_pumpkin_east = Blocks.lit_pumpkin.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2029 */   public static final IBlockState cake_bites_0 = Blocks.cake.getDefaultState();
/* 2030 */   public static final IBlockState cake_bites_1 = Blocks.cake.getDefaultState().withProperty(BlockCake.BITES, Integer.valueOf(1));
/* 2031 */   public static final IBlockState cake_bites_2 = Blocks.cake.getDefaultState().withProperty(BlockCake.BITES, Integer.valueOf(2));
/* 2032 */   public static final IBlockState cake_bites_3 = Blocks.cake.getDefaultState().withProperty(BlockCake.BITES, Integer.valueOf(3));
/* 2033 */   public static final IBlockState cake_bites_4 = Blocks.cake.getDefaultState().withProperty(BlockCake.BITES, Integer.valueOf(4));
/* 2034 */   public static final IBlockState cake_bites_5 = Blocks.cake.getDefaultState().withProperty(BlockCake.BITES, Integer.valueOf(5));
/* 2035 */   public static final IBlockState cake_bites_6 = Blocks.cake.getDefaultState().withProperty(BlockCake.BITES, Integer.valueOf(6));
/* 2036 */   public static final IBlockState unpowered_repeater_south_delay_1 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2037 */   public static final IBlockState unpowered_repeater_west_delay_1 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2038 */   public static final IBlockState unpowered_repeater_north_delay_1 = Blocks.unpowered_repeater.getDefaultState();
/* 2039 */   public static final IBlockState unpowered_repeater_east_delay_1 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2040 */   public static final IBlockState unpowered_repeater_south_delay_2 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(2));
/* 2041 */   public static final IBlockState unpowered_repeater_west_delay_2 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(2));
/* 2042 */   public static final IBlockState unpowered_repeater_north_delay_2 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(2));
/* 2043 */   public static final IBlockState unpowered_repeater_east_delay_2 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(2));
/* 2044 */   public static final IBlockState unpowered_repeater_south_delay_3 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(3));
/* 2045 */   public static final IBlockState unpowered_repeater_west_delay_3 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(3));
/* 2046 */   public static final IBlockState unpowered_repeater_north_delay_3 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(3));
/* 2047 */   public static final IBlockState unpowered_repeater_east_delay_3 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(3));
/* 2048 */   public static final IBlockState unpowered_repeater_south_delay_4 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(4));
/* 2049 */   public static final IBlockState unpowered_repeater_west_delay_4 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(4));
/* 2050 */   public static final IBlockState unpowered_repeater_north_delay_4 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(4));
/* 2051 */   public static final IBlockState unpowered_repeater_east_delay_4 = Blocks.unpowered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(4));
/* 2052 */   public static final IBlockState powered_repeater_south_delay_1 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2053 */   public static final IBlockState powered_repeater_west_delay_1 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2054 */   public static final IBlockState powered_repeater_north_delay_1 = Blocks.powered_repeater.getDefaultState();
/* 2055 */   public static final IBlockState powered_repeater_east_delay_1 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2056 */   public static final IBlockState powered_repeater_south_delay_2 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(2));
/* 2057 */   public static final IBlockState powered_repeater_west_delay_2 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(2));
/* 2058 */   public static final IBlockState powered_repeater_north_delay_2 = Blocks.powered_repeater.getDefaultState().withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(2));
/* 2059 */   public static final IBlockState powered_repeater_east_delay_2 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(2));
/* 2060 */   public static final IBlockState powered_repeater_south_delay_3 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(3));
/* 2061 */   public static final IBlockState powered_repeater_west_delay_3 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(3));
/* 2062 */   public static final IBlockState powered_repeater_north_delay_3 = Blocks.powered_repeater.getDefaultState().withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(3));
/* 2063 */   public static final IBlockState powered_repeater_east_delay_3 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(3));
/* 2064 */   public static final IBlockState powered_repeater_south_delay_4 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(4));
/* 2065 */   public static final IBlockState powered_repeater_west_delay_4 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(4));
/* 2066 */   public static final IBlockState powered_repeater_north_delay_4 = Blocks.powered_repeater.getDefaultState().withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(4));
/* 2067 */   public static final IBlockState powered_repeater_east_delay_4 = Blocks.powered_repeater.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneRepeater.DELAY, Integer.valueOf(4));
/* 2068 */   public static final IBlockState trapdoor_bottom_north = Blocks.trapdoor.getDefaultState();
/* 2069 */   public static final IBlockState trapdoor_bottom_south = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.SOUTH);
/* 2070 */   public static final IBlockState trapdoor_bottom_west = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.WEST);
/* 2071 */   public static final IBlockState trapdoor_bottom_east = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.EAST);
/* 2072 */   public static final IBlockState trapdoor_bottom_north_open = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2073 */   public static final IBlockState trapdoor_bottom_south_open = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.SOUTH).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2074 */   public static final IBlockState trapdoor_bottom_west_open = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.WEST).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2075 */   public static final IBlockState trapdoor_bottom_east_open = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.EAST).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2076 */   public static final IBlockState trapdoor_top_north = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP);
/* 2077 */   public static final IBlockState trapdoor_top_south = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.SOUTH);
/* 2078 */   public static final IBlockState trapdoor_top_west = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.WEST);
/* 2079 */   public static final IBlockState trapdoor_top_east = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.EAST);
/* 2080 */   public static final IBlockState trapdoor_top_north_open = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2081 */   public static final IBlockState trapdoor_top_south_open = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.SOUTH).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2082 */   public static final IBlockState trapdoor_top_west_open = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.WEST).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2083 */   public static final IBlockState trapdoor_top_east_open = Blocks.trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.EAST).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2084 */   public static final IBlockState monster_egg_stone = Blocks.monster_egg.getDefaultState();
/* 2085 */   public static final IBlockState monster_egg_cobblestone = Blocks.monster_egg.getDefaultState().withProperty(BlockSilverfish.VARIANT, BlockSilverfish.EnumType.COBBLESTONE);
/* 2086 */   public static final IBlockState monster_egg_stonebrick = Blocks.monster_egg.getDefaultState().withProperty(BlockSilverfish.VARIANT, BlockSilverfish.EnumType.STONEBRICK);
/* 2087 */   public static final IBlockState monster_egg_mossybrick = Blocks.monster_egg.getDefaultState().withProperty(BlockSilverfish.VARIANT, BlockSilverfish.EnumType.MOSSY_STONEBRICK);
/* 2088 */   public static final IBlockState monster_egg_crackedbrick = Blocks.monster_egg.getDefaultState().withProperty(BlockSilverfish.VARIANT, BlockSilverfish.EnumType.CRACKED_STONEBRICK);
/* 2089 */   public static final IBlockState monster_egg_chiseledbrick = Blocks.monster_egg.getDefaultState().withProperty(BlockSilverfish.VARIANT, BlockSilverfish.EnumType.CHISELED_STONEBRICK);
/* 2090 */   public static final IBlockState stonebrick = Blocks.stonebrick.getDefaultState();
/* 2091 */   public static final IBlockState stonebrick_mossystonebrick = Blocks.stonebrick.getDefaultState().withProperty(BlockStoneBrick.VARIANT, BlockStoneBrick.EnumType.MOSSY);
/* 2092 */   public static final IBlockState stonebrick_crackedstonebrick = Blocks.stonebrick.getDefaultState().withProperty(BlockStoneBrick.VARIANT, BlockStoneBrick.EnumType.CRACKED);
/* 2093 */   public static final IBlockState stonebrick_chiseledstonebrick = Blocks.stonebrick.getDefaultState().withProperty(BlockStoneBrick.VARIANT, BlockStoneBrick.EnumType.CHISELED);
/* 2094 */   public static final IBlockState brown_mushroom_block_allinside = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.ALL_INSIDE);
/* 2095 */   public static final IBlockState brown_mushroom_block_northwest = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.NORTH_WEST);
/* 2096 */   public static final IBlockState brown_mushroom_block_north = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.NORTH);
/* 2097 */   public static final IBlockState brown_mushroom_block_northeast = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.NORTH_EAST);
/* 2098 */   public static final IBlockState brown_mushroom_block_west = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.WEST);
/* 2099 */   public static final IBlockState brown_mushroom_block_center = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.CENTER);
/* 2100 */   public static final IBlockState brown_mushroom_block_east = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.EAST);
/* 2101 */   public static final IBlockState brown_mushroom_block_southwest = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.SOUTH_WEST);
/* 2102 */   public static final IBlockState brown_mushroom_block_south = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.SOUTH);
/* 2103 */   public static final IBlockState brown_mushroom_block_southeast = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.SOUTH_EAST);
/* 2104 */   public static final IBlockState brown_mushroom_block_stem = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.STEM);
/* 2105 */   public static final IBlockState brown_mushroom_block_alloutside = Blocks.brown_mushroom_block.getDefaultState();
/* 2106 */   public static final IBlockState brown_mushroom_block_allstem = Blocks.brown_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.ALL_STEM);
/* 2107 */   public static final IBlockState red_mushroom_block_allinside = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.ALL_INSIDE);
/* 2108 */   public static final IBlockState red_mushroom_block_northwest = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.NORTH_WEST);
/* 2109 */   public static final IBlockState red_mushroom_block_north = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.NORTH);
/* 2110 */   public static final IBlockState red_mushroom_block_northeast = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.NORTH_EAST);
/* 2111 */   public static final IBlockState red_mushroom_block_west = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.WEST);
/* 2112 */   public static final IBlockState red_mushroom_block_center = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.CENTER);
/* 2113 */   public static final IBlockState red_mushroom_block_east = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.EAST);
/* 2114 */   public static final IBlockState red_mushroom_block_southwest = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.SOUTH_WEST);
/* 2115 */   public static final IBlockState red_mushroom_block_south = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.SOUTH);
/* 2116 */   public static final IBlockState red_mushroom_block_southeast = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.SOUTH_EAST);
/* 2117 */   public static final IBlockState red_mushroom_block_stem = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.STEM);
/* 2118 */   public static final IBlockState red_mushroom_block_alloutside = Blocks.red_mushroom_block.getDefaultState();
/* 2119 */   public static final IBlockState red_mushroom_block_allstem = Blocks.red_mushroom_block.getDefaultState().withProperty(BlockHugeMushroom.VARIANT, BlockHugeMushroom.EnumType.ALL_STEM);
/* 2120 */   public static final IBlockState iron_bars = Blocks.iron_bars.getDefaultState();
/* 2121 */   public static final IBlockState glass_pane = Blocks.glass_pane.getDefaultState();
/* 2122 */   public static final IBlockState melon_block = Blocks.melon_block.getDefaultState();
/* 2123 */   public static final IBlockState pumpkin_stem_age_0 = Blocks.pumpkin_stem.getDefaultState();
/* 2124 */   public static final IBlockState pumpkin_stem_age_1 = Blocks.pumpkin_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(1));
/* 2125 */   public static final IBlockState pumpkin_stem_age_2 = Blocks.pumpkin_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(2));
/* 2126 */   public static final IBlockState pumpkin_stem_age_3 = Blocks.pumpkin_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(3));
/* 2127 */   public static final IBlockState pumpkin_stem_age_4 = Blocks.pumpkin_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(4));
/* 2128 */   public static final IBlockState pumpkin_stem_age_5 = Blocks.pumpkin_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(5));
/* 2129 */   public static final IBlockState pumpkin_stem_age_6 = Blocks.pumpkin_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(6));
/* 2130 */   public static final IBlockState pumpkin_stem_age_7 = Blocks.pumpkin_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(7));
/* 2131 */   public static final IBlockState melon_stem_age_0 = Blocks.melon_stem.getDefaultState();
/* 2132 */   public static final IBlockState melon_stem_age_1 = Blocks.melon_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(1));
/* 2133 */   public static final IBlockState melon_stem_age_2 = Blocks.melon_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(2));
/* 2134 */   public static final IBlockState melon_stem_age_3 = Blocks.melon_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(3));
/* 2135 */   public static final IBlockState melon_stem_age_4 = Blocks.melon_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(4));
/* 2136 */   public static final IBlockState melon_stem_age_5 = Blocks.melon_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(5));
/* 2137 */   public static final IBlockState melon_stem_age_6 = Blocks.melon_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(6));
/* 2138 */   public static final IBlockState melon_stem_age_7 = Blocks.melon_stem.getDefaultState().withProperty(BlockStem.AGE, Integer.valueOf(7));
/* 2139 */   public static final IBlockState vine = Blocks.vine.getDefaultState();
/* 2140 */   public static final IBlockState vine_south = Blocks.vine.getDefaultState().withProperty(BlockVine.SOUTH, Boolean.valueOf(true));
/* 2141 */   public static final IBlockState vine_west = Blocks.vine.getDefaultState().withProperty(BlockVine.WEST, Boolean.valueOf(true));
/* 2142 */   public static final IBlockState vine_south_west = Blocks.vine.getDefaultState().withProperty(BlockVine.SOUTH, Boolean.valueOf(true)).withProperty(BlockVine.WEST, Boolean.valueOf(true));
/* 2143 */   public static final IBlockState vine_north = Blocks.vine.getDefaultState().withProperty(BlockVine.NORTH, Boolean.valueOf(true));
/* 2144 */   public static final IBlockState vine_north_south = Blocks.vine.getDefaultState().withProperty(BlockVine.NORTH, Boolean.valueOf(true)).withProperty(BlockVine.SOUTH, Boolean.valueOf(true));
/* 2145 */   public static final IBlockState vine_north_west = Blocks.vine.getDefaultState().withProperty(BlockVine.NORTH, Boolean.valueOf(true)).withProperty(BlockVine.WEST, Boolean.valueOf(true));
/* 2146 */   public static final IBlockState vine_north_south_west = Blocks.vine.getDefaultState().withProperty(BlockVine.NORTH, Boolean.valueOf(true)).withProperty(BlockVine.SOUTH, Boolean.valueOf(true)).withProperty(BlockVine.WEST, Boolean.valueOf(true));
/* 2147 */   public static final IBlockState vine_east = Blocks.vine.getDefaultState().withProperty(BlockVine.EAST, Boolean.valueOf(true));
/* 2148 */   public static final IBlockState vine_east_south = Blocks.vine.getDefaultState().withProperty(BlockVine.EAST, Boolean.valueOf(true)).withProperty(BlockVine.SOUTH, Boolean.valueOf(true));
/* 2149 */   public static final IBlockState vine_east_west = Blocks.vine.getDefaultState().withProperty(BlockVine.EAST, Boolean.valueOf(true)).withProperty(BlockVine.WEST, Boolean.valueOf(true));
/* 2150 */   public static final IBlockState vine_east_south_west = Blocks.vine.getDefaultState().withProperty(BlockVine.EAST, Boolean.valueOf(true)).withProperty(BlockVine.SOUTH, Boolean.valueOf(true)).withProperty(BlockVine.WEST, Boolean.valueOf(true));
/* 2151 */   public static final IBlockState vine_east_north = Blocks.vine.getDefaultState().withProperty(BlockVine.EAST, Boolean.valueOf(true)).withProperty(BlockVine.NORTH, Boolean.valueOf(true));
/* 2152 */   public static final IBlockState vine_east_north_south = Blocks.vine.getDefaultState().withProperty(BlockVine.EAST, Boolean.valueOf(true)).withProperty(BlockVine.NORTH, Boolean.valueOf(true)).withProperty(BlockVine.SOUTH, Boolean.valueOf(true));
/* 2153 */   public static final IBlockState vine_east_north_west = Blocks.vine.getDefaultState().withProperty(BlockVine.EAST, Boolean.valueOf(true)).withProperty(BlockVine.NORTH, Boolean.valueOf(true)).withProperty(BlockVine.WEST, Boolean.valueOf(true));
/* 2154 */   public static final IBlockState vine_east_north_south_west = Blocks.vine.getDefaultState().withProperty(BlockVine.EAST, Boolean.valueOf(true)).withProperty(BlockVine.NORTH, Boolean.valueOf(true)).withProperty(BlockVine.SOUTH, Boolean.valueOf(true)).withProperty(BlockVine.WEST, Boolean.valueOf(true));
/* 2155 */   public static final IBlockState oak_fence_gate_south = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2156 */   public static final IBlockState oak_fence_gate_west = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2157 */   public static final IBlockState oak_fence_gate_north = Blocks.oak_fence_gate.getDefaultState();
/* 2158 */   public static final IBlockState oak_fence_gate_east = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2159 */   public static final IBlockState oak_fence_gate_south_open = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2160 */   public static final IBlockState oak_fence_gate_west_open = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2161 */   public static final IBlockState oak_fence_gate_north_open = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2162 */   public static final IBlockState oak_fence_gate_east_open = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2163 */   public static final IBlockState oak_fence_gate_south_powered = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2164 */   public static final IBlockState oak_fence_gate_west_powered = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2165 */   public static final IBlockState oak_fence_gate_north_powered = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2166 */   public static final IBlockState oak_fence_gate_east_powered = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2167 */   public static final IBlockState oak_fence_gate_south_open_powered = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2168 */   public static final IBlockState oak_fence_gate_west_open_powered = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2169 */   public static final IBlockState oak_fence_gate_north_open_powered = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2170 */   public static final IBlockState oak_fence_gate_east_open_powered = Blocks.oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2171 */   public static final IBlockState spruce_fence_gate_south = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2172 */   public static final IBlockState spruce_fence_gate_west = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2173 */   public static final IBlockState spruce_fence_gate_north = Blocks.spruce_fence_gate.getDefaultState();
/* 2174 */   public static final IBlockState spruce_fence_gate_east = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2175 */   public static final IBlockState spruce_fence_gate_south_open = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2176 */   public static final IBlockState spruce_fence_gate_west_open = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2177 */   public static final IBlockState spruce_fence_gate_north_open = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2178 */   public static final IBlockState spruce_fence_gate_east_open = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2179 */   public static final IBlockState spruce_fence_gate_south_powered = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2180 */   public static final IBlockState spruce_fence_gate_west_powered = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2181 */   public static final IBlockState spruce_fence_gate_north_powered = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2182 */   public static final IBlockState spruce_fence_gate_east_powered = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2183 */   public static final IBlockState spruce_fence_gate_south_open_powered = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2184 */   public static final IBlockState spruce_fence_gate_west_open_powered = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2185 */   public static final IBlockState spruce_fence_gate_north_open_powered = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2186 */   public static final IBlockState spruce_fence_gate_east_open_powered = Blocks.spruce_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2187 */   public static final IBlockState birch_fence_gate_south = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2188 */   public static final IBlockState birch_fence_gate_west = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2189 */   public static final IBlockState birch_fence_gate_north = Blocks.birch_fence_gate.getDefaultState();
/* 2190 */   public static final IBlockState birch_fence_gate_east = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2191 */   public static final IBlockState birch_fence_gate_south_open = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2192 */   public static final IBlockState birch_fence_gate_west_open = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2193 */   public static final IBlockState birch_fence_gate_north_open = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2194 */   public static final IBlockState birch_fence_gate_east_open = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2195 */   public static final IBlockState birch_fence_gate_south_powered = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2196 */   public static final IBlockState birch_fence_gate_west_powered = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2197 */   public static final IBlockState birch_fence_gate_north_powered = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2198 */   public static final IBlockState birch_fence_gate_east_powered = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2199 */   public static final IBlockState birch_fence_gate_south_open_powered = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2200 */   public static final IBlockState birch_fence_gate_west_open_powered = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2201 */   public static final IBlockState birch_fence_gate_north_open_powered = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2202 */   public static final IBlockState birch_fence_gate_east_open_powered = Blocks.birch_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2203 */   public static final IBlockState jungle_fence_gate_south = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2204 */   public static final IBlockState jungle_fence_gate_west = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2205 */   public static final IBlockState jungle_fence_gate_north = Blocks.jungle_fence_gate.getDefaultState();
/* 2206 */   public static final IBlockState jungle_fence_gate_east = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2207 */   public static final IBlockState jungle_fence_gate_south_open = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2208 */   public static final IBlockState jungle_fence_gate_west_open = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2209 */   public static final IBlockState jungle_fence_gate_north_open = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2210 */   public static final IBlockState jungle_fence_gate_east_open = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2211 */   public static final IBlockState jungle_fence_gate_south_powered = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2212 */   public static final IBlockState jungle_fence_gate_west_powered = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2213 */   public static final IBlockState jungle_fence_gate_north_powered = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2214 */   public static final IBlockState jungle_fence_gate_east_powered = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2215 */   public static final IBlockState jungle_fence_gate_south_open_powered = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2216 */   public static final IBlockState jungle_fence_gate_west_open_powered = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2217 */   public static final IBlockState jungle_fence_gate_north_open_powered = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2218 */   public static final IBlockState jungle_fence_gate_east_open_powered = Blocks.jungle_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2219 */   public static final IBlockState dark_oak_fence_gate_south = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2220 */   public static final IBlockState dark_oak_fence_gate_west = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2221 */   public static final IBlockState dark_oak_fence_gate_north = Blocks.dark_oak_fence_gate.getDefaultState();
/* 2222 */   public static final IBlockState dark_oak_fence_gate_east = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2223 */   public static final IBlockState dark_oak_fence_gate_south_open = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2224 */   public static final IBlockState dark_oak_fence_gate_west_open = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2225 */   public static final IBlockState dark_oak_fence_gate_north_open = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2226 */   public static final IBlockState dark_oak_fence_gate_east_open = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2227 */   public static final IBlockState dark_oak_fence_gate_south_powered = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2228 */   public static final IBlockState dark_oak_fence_gate_west_powered = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2229 */   public static final IBlockState dark_oak_fence_gate_north_powered = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2230 */   public static final IBlockState dark_oak_fence_gate_east_powered = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2231 */   public static final IBlockState dark_oak_fence_gate_south_open_powered = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2232 */   public static final IBlockState dark_oak_fence_gate_west_open_powered = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2233 */   public static final IBlockState dark_oak_fence_gate_north_open_powered = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2234 */   public static final IBlockState dark_oak_fence_gate_east_open_powered = Blocks.dark_oak_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2235 */   public static final IBlockState acacia_fence_gate_south = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2236 */   public static final IBlockState acacia_fence_gate_west = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2237 */   public static final IBlockState acacia_fence_gate_north = Blocks.acacia_fence_gate.getDefaultState();
/* 2238 */   public static final IBlockState acacia_fence_gate_east = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2239 */   public static final IBlockState acacia_fence_gate_south_open = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2240 */   public static final IBlockState acacia_fence_gate_west_open = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2241 */   public static final IBlockState acacia_fence_gate_north_open = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2242 */   public static final IBlockState acacia_fence_gate_east_open = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true));
/* 2243 */   public static final IBlockState acacia_fence_gate_south_powered = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2244 */   public static final IBlockState acacia_fence_gate_west_powered = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2245 */   public static final IBlockState acacia_fence_gate_north_powered = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2246 */   public static final IBlockState acacia_fence_gate_east_powered = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2247 */   public static final IBlockState acacia_fence_gate_south_open_powered = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2248 */   public static final IBlockState acacia_fence_gate_west_open_powered = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2249 */   public static final IBlockState acacia_fence_gate_north_open_powered = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2250 */   public static final IBlockState acacia_fence_gate_east_open_powered = Blocks.acacia_fence_gate.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockFenceGate.OPEN, Boolean.valueOf(true)).withProperty(BlockFenceGate.POWERED, Boolean.valueOf(true));
/* 2251 */   public static final IBlockState brick_stairs_bottom_east = Blocks.brick_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2252 */   public static final IBlockState brick_stairs_bottom_west = Blocks.brick_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2253 */   public static final IBlockState brick_stairs_bottom_south = Blocks.brick_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2254 */   public static final IBlockState brick_stairs_bottom_north = Blocks.brick_stairs.getDefaultState();
/* 2255 */   public static final IBlockState brick_stairs_top_east = Blocks.brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2256 */   public static final IBlockState brick_stairs_top_west = Blocks.brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2257 */   public static final IBlockState brick_stairs_top_south = Blocks.brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2258 */   public static final IBlockState brick_stairs_top_north = Blocks.brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2259 */   public static final IBlockState stone_brick_stairs_bottom_east = Blocks.stone_brick_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2260 */   public static final IBlockState stone_brick_stairs_bottom_west = Blocks.stone_brick_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2261 */   public static final IBlockState stone_brick_stairs_bottom_south = Blocks.stone_brick_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2262 */   public static final IBlockState stone_brick_stairs_bottom_north = Blocks.stone_brick_stairs.getDefaultState();
/* 2263 */   public static final IBlockState stone_brick_stairs_top_east = Blocks.stone_brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2264 */   public static final IBlockState stone_brick_stairs_top_west = Blocks.stone_brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2265 */   public static final IBlockState stone_brick_stairs_top_south = Blocks.stone_brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2266 */   public static final IBlockState stone_brick_stairs_top_north = Blocks.stone_brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2267 */   public static final IBlockState mycelium = Blocks.mycelium.getDefaultState();
/* 2268 */   public static final IBlockState waterlily = Blocks.waterlily.getDefaultState();
/* 2269 */   public static final IBlockState nether_brick = Blocks.nether_brick.getDefaultState();
/* 2270 */   public static final IBlockState nether_brick_fence = Blocks.nether_brick_fence.getDefaultState();
/* 2271 */   public static final IBlockState nether_brick_stairs_bottom_east = Blocks.nether_brick_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2272 */   public static final IBlockState nether_brick_stairs_bottom_west = Blocks.nether_brick_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2273 */   public static final IBlockState nether_brick_stairs_bottom_south = Blocks.nether_brick_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2274 */   public static final IBlockState nether_brick_stairs_bottom_north = Blocks.nether_brick_stairs.getDefaultState();
/* 2275 */   public static final IBlockState nether_brick_stairs_top_east = Blocks.nether_brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2276 */   public static final IBlockState nether_brick_stairs_top_west = Blocks.nether_brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2277 */   public static final IBlockState nether_brick_stairs_top_south = Blocks.nether_brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2278 */   public static final IBlockState nether_brick_stairs_top_north = Blocks.nether_brick_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2279 */   public static final IBlockState nether_wart_age_0 = Blocks.nether_wart.getDefaultState();
/* 2280 */   public static final IBlockState nether_wart_age_1 = Blocks.nether_wart.getDefaultState().withProperty(BlockNetherWart.AGE, Integer.valueOf(1));
/* 2281 */   public static final IBlockState nether_wart_age_2 = Blocks.nether_wart.getDefaultState().withProperty(BlockNetherWart.AGE, Integer.valueOf(2));
/* 2282 */   public static final IBlockState nether_wart_age_3 = Blocks.nether_wart.getDefaultState().withProperty(BlockNetherWart.AGE, Integer.valueOf(3));
/* 2283 */   public static final IBlockState enchanting_table = Blocks.enchanting_table.getDefaultState();
/* 2284 */   public static final IBlockState brewing_stand = Blocks.brewing_stand.getDefaultState();
/* 2285 */   public static final IBlockState brewing_stand_hasbottle0 = Blocks.brewing_stand.getDefaultState().withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[0], Boolean.valueOf(true));
/* 2286 */   public static final IBlockState brewing_stand_hasbottle1 = Blocks.brewing_stand.getDefaultState().withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[1], Boolean.valueOf(true));
/* 2287 */   public static final IBlockState brewing_stand_hasbottle0_hasbottle1 = Blocks.brewing_stand.getDefaultState().withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[0], Boolean.valueOf(true)).withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[1], Boolean.valueOf(true));
/* 2288 */   public static final IBlockState brewing_stand_hasbottle2 = Blocks.brewing_stand.getDefaultState().withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[2], Boolean.valueOf(true));
/* 2289 */   public static final IBlockState brewing_stand_hasbottle0_hasbottle2 = Blocks.brewing_stand.getDefaultState().withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[0], Boolean.valueOf(true)).withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[2], Boolean.valueOf(true));
/* 2290 */   public static final IBlockState brewing_stand_hasbottle1_hasbottle2 = Blocks.brewing_stand.getDefaultState().withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[1], Boolean.valueOf(true)).withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[2], Boolean.valueOf(true));
/* 2291 */   public static final IBlockState brewing_stand_hasbottle0_hasbottle1_hasbottle2 = Blocks.brewing_stand.getDefaultState().withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[0], Boolean.valueOf(true)).withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[1], Boolean.valueOf(true)).withProperty(net.minecraft.block.BlockBrewingStand.HAS_BOTTLE[2], Boolean.valueOf(true));
/* 2292 */   public static final IBlockState cauldron_level_0 = Blocks.cauldron.getDefaultState();
/* 2293 */   public static final IBlockState cauldron_level_1 = Blocks.cauldron.getDefaultState().withProperty(BlockCauldron.LEVEL, Integer.valueOf(1));
/* 2294 */   public static final IBlockState cauldron_level_2 = Blocks.cauldron.getDefaultState().withProperty(BlockCauldron.LEVEL, Integer.valueOf(2));
/* 2295 */   public static final IBlockState cauldron_level_3 = Blocks.cauldron.getDefaultState().withProperty(BlockCauldron.LEVEL, Integer.valueOf(3));
/* 2296 */   public static final IBlockState end_portal = Blocks.end_portal.getDefaultState();
/* 2297 */   public static final IBlockState end_portal_frame_south = Blocks.end_portal_frame.getDefaultState().withProperty(BlockEndPortalFrame.FACING, EnumFacing.SOUTH);
/* 2298 */   public static final IBlockState end_portal_frame_west = Blocks.end_portal_frame.getDefaultState().withProperty(BlockEndPortalFrame.FACING, EnumFacing.WEST);
/* 2299 */   public static final IBlockState end_portal_frame_north = Blocks.end_portal_frame.getDefaultState();
/* 2300 */   public static final IBlockState end_portal_frame_east = Blocks.end_portal_frame.getDefaultState().withProperty(BlockEndPortalFrame.FACING, EnumFacing.EAST);
/* 2301 */   public static final IBlockState end_portal_frame_south_eye = Blocks.end_portal_frame.getDefaultState().withProperty(BlockEndPortalFrame.FACING, EnumFacing.SOUTH).withProperty(BlockEndPortalFrame.EYE, Boolean.valueOf(true));
/* 2302 */   public static final IBlockState end_portal_frame_west_eye = Blocks.end_portal_frame.getDefaultState().withProperty(BlockEndPortalFrame.FACING, EnumFacing.WEST).withProperty(BlockEndPortalFrame.EYE, Boolean.valueOf(true));
/* 2303 */   public static final IBlockState end_portal_frame_north_eye = Blocks.end_portal_frame.getDefaultState().withProperty(BlockEndPortalFrame.EYE, Boolean.valueOf(true));
/* 2304 */   public static final IBlockState end_portal_frame_east_eye = Blocks.end_portal_frame.getDefaultState().withProperty(BlockEndPortalFrame.FACING, EnumFacing.EAST).withProperty(BlockEndPortalFrame.EYE, Boolean.valueOf(true));
/* 2305 */   public static final IBlockState end_stone = Blocks.end_stone.getDefaultState();
/* 2306 */   public static final IBlockState dragon_egg = Blocks.dragon_egg.getDefaultState();
/* 2307 */   public static final IBlockState redstone_lamp = Blocks.redstone_lamp.getDefaultState();
/* 2308 */   public static final IBlockState lit_redstone_lamp = Blocks.lit_redstone_lamp.getDefaultState();
/* 2309 */   public static final IBlockState double_wooden_slab_oak = Blocks.double_wooden_slab.getDefaultState();
/* 2310 */   public static final IBlockState double_wooden_slab_spruce = Blocks.double_wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.SPRUCE);
/* 2311 */   public static final IBlockState double_wooden_slab_birch = Blocks.double_wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.BIRCH);
/* 2312 */   public static final IBlockState double_wooden_slab_jungle = Blocks.double_wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.JUNGLE);
/* 2313 */   public static final IBlockState double_wooden_slab_acacia = Blocks.double_wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.ACACIA);
/* 2314 */   public static final IBlockState double_wooden_slab_darkoak = Blocks.double_wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.DARK_OAK);
/* 2315 */   public static final IBlockState wooden_slab_bottom_oak = Blocks.wooden_slab.getDefaultState();
/* 2316 */   public static final IBlockState wooden_slab_bottom_spruce = Blocks.wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.SPRUCE);
/* 2317 */   public static final IBlockState wooden_slab_bottom_birch = Blocks.wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.BIRCH);
/* 2318 */   public static final IBlockState wooden_slab_bottom_jungle = Blocks.wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.JUNGLE);
/* 2319 */   public static final IBlockState wooden_slab_bottom_acacia = Blocks.wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.ACACIA);
/* 2320 */   public static final IBlockState wooden_slab_bottom_darkoak = Blocks.wooden_slab.getDefaultState().withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.DARK_OAK);
/* 2321 */   public static final IBlockState wooden_slab_top_oak = Blocks.wooden_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP);
/* 2322 */   public static final IBlockState wooden_slab_top_spruce = Blocks.wooden_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.SPRUCE);
/* 2323 */   public static final IBlockState wooden_slab_top_birch = Blocks.wooden_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.BIRCH);
/* 2324 */   public static final IBlockState wooden_slab_top_jungle = Blocks.wooden_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.JUNGLE);
/* 2325 */   public static final IBlockState wooden_slab_top_acacia = Blocks.wooden_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.ACACIA);
/* 2326 */   public static final IBlockState wooden_slab_top_darkoak = Blocks.wooden_slab.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP).withProperty(BlockWoodSlab.VARIANT, BlockPlanks.EnumType.DARK_OAK);
/* 2327 */   public static final IBlockState cocoa_south_age_0 = Blocks.cocoa.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2328 */   public static final IBlockState cocoa_west_age_0 = Blocks.cocoa.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2329 */   public static final IBlockState cocoa_north_age_0 = Blocks.cocoa.getDefaultState();
/* 2330 */   public static final IBlockState cocoa_east_age_0 = Blocks.cocoa.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2331 */   public static final IBlockState cocoa_south_age_1 = Blocks.cocoa.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockCocoa.AGE, Integer.valueOf(1));
/* 2332 */   public static final IBlockState cocoa_west_age_1 = Blocks.cocoa.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockCocoa.AGE, Integer.valueOf(1));
/* 2333 */   public static final IBlockState cocoa_north_age_1 = Blocks.cocoa.getDefaultState().withProperty(BlockCocoa.AGE, Integer.valueOf(1));
/* 2334 */   public static final IBlockState cocoa_east_age_1 = Blocks.cocoa.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockCocoa.AGE, Integer.valueOf(1));
/* 2335 */   public static final IBlockState cocoa_south_age_2 = Blocks.cocoa.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockCocoa.AGE, Integer.valueOf(2));
/* 2336 */   public static final IBlockState cocoa_west_age_2 = Blocks.cocoa.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockCocoa.AGE, Integer.valueOf(2));
/* 2337 */   public static final IBlockState cocoa_north_age_2 = Blocks.cocoa.getDefaultState().withProperty(BlockCocoa.AGE, Integer.valueOf(2));
/* 2338 */   public static final IBlockState cocoa_east_age_2 = Blocks.cocoa.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockCocoa.AGE, Integer.valueOf(2));
/* 2339 */   public static final IBlockState sandstone_stairs_bottom_east = Blocks.sandstone_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2340 */   public static final IBlockState sandstone_stairs_bottom_west = Blocks.sandstone_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2341 */   public static final IBlockState sandstone_stairs_bottom_south = Blocks.sandstone_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2342 */   public static final IBlockState sandstone_stairs_bottom_north = Blocks.sandstone_stairs.getDefaultState();
/* 2343 */   public static final IBlockState sandstone_stairs_top_east = Blocks.sandstone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2344 */   public static final IBlockState sandstone_stairs_top_west = Blocks.sandstone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2345 */   public static final IBlockState sandstone_stairs_top_south = Blocks.sandstone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2346 */   public static final IBlockState sandstone_stairs_top_north = Blocks.sandstone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2347 */   public static final IBlockState emerald_ore = Blocks.emerald_ore.getDefaultState();
/* 2348 */   public static final IBlockState ender_chest_north = Blocks.ender_chest.getDefaultState();
/* 2349 */   public static final IBlockState ender_chest_south = Blocks.ender_chest.getDefaultState().withProperty(BlockEnderChest.FACING, EnumFacing.SOUTH);
/* 2350 */   public static final IBlockState ender_chest_west = Blocks.ender_chest.getDefaultState().withProperty(BlockEnderChest.FACING, EnumFacing.WEST);
/* 2351 */   public static final IBlockState ender_chest_east = Blocks.ender_chest.getDefaultState().withProperty(BlockEnderChest.FACING, EnumFacing.EAST);
/* 2352 */   public static final IBlockState tripwire_hook_south = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.SOUTH);
/* 2353 */   public static final IBlockState tripwire_hook_west = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.WEST);
/* 2354 */   public static final IBlockState tripwire_hook_north = Blocks.tripwire_hook.getDefaultState();
/* 2355 */   public static final IBlockState tripwire_hook_east = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.EAST);
/* 2356 */   public static final IBlockState tripwire_hook_south_attached = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.SOUTH).withProperty(BlockTripWireHook.ATTACHED, Boolean.valueOf(true));
/* 2357 */   public static final IBlockState tripwire_hook_west_attached = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.WEST).withProperty(BlockTripWireHook.ATTACHED, Boolean.valueOf(true));
/* 2358 */   public static final IBlockState tripwire_hook_north_attached = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.ATTACHED, Boolean.valueOf(true));
/* 2359 */   public static final IBlockState tripwire_hook_east_attached = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.EAST).withProperty(BlockTripWireHook.ATTACHED, Boolean.valueOf(true));
/* 2360 */   public static final IBlockState tripwire_hook_south_powered = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.SOUTH).withProperty(BlockTripWireHook.POWERED, Boolean.valueOf(true));
/* 2361 */   public static final IBlockState tripwire_hook_west_powered = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.WEST).withProperty(BlockTripWireHook.POWERED, Boolean.valueOf(true));
/* 2362 */   public static final IBlockState tripwire_hook_north_powered = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.POWERED, Boolean.valueOf(true));
/* 2363 */   public static final IBlockState tripwire_hook_east_powered = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.EAST).withProperty(BlockTripWireHook.POWERED, Boolean.valueOf(true));
/* 2364 */   public static final IBlockState tripwire_hook_south_attached_powered = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.SOUTH).withProperty(BlockTripWireHook.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWireHook.POWERED, Boolean.valueOf(true));
/* 2365 */   public static final IBlockState tripwire_hook_west_attached_powered = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.WEST).withProperty(BlockTripWireHook.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWireHook.POWERED, Boolean.valueOf(true));
/* 2366 */   public static final IBlockState tripwire_hook_north_attached_powered = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWireHook.POWERED, Boolean.valueOf(true));
/* 2367 */   public static final IBlockState tripwire_hook_east_attached_powered = Blocks.tripwire_hook.getDefaultState().withProperty(BlockTripWireHook.FACING, EnumFacing.EAST).withProperty(BlockTripWireHook.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWireHook.POWERED, Boolean.valueOf(true));
/* 2368 */   public static final IBlockState tripwire = Blocks.tripwire.getDefaultState();
/* 2369 */   public static final IBlockState tripwire_powered = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.POWERED, Boolean.valueOf(true));
/* 2370 */   public static final IBlockState tripwire_suspended = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.field_176290_b, Boolean.valueOf(true));
/* 2371 */   public static final IBlockState tripwire_powered_suspended = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.POWERED, Boolean.valueOf(true)).withProperty(BlockTripWire.field_176290_b, Boolean.valueOf(true));
/* 2372 */   public static final IBlockState tripwire_attached = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.ATTACHED, Boolean.valueOf(true));
/* 2373 */   public static final IBlockState tripwire_attached_powered = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWire.POWERED, Boolean.valueOf(true));
/* 2374 */   public static final IBlockState tripwire_attached_suspended = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWire.field_176290_b, Boolean.valueOf(true));
/* 2375 */   public static final IBlockState tripwire_attached_powered_suspended = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWire.POWERED, Boolean.valueOf(true)).withProperty(BlockTripWire.field_176290_b, Boolean.valueOf(true));
/* 2376 */   public static final IBlockState tripwire_disarmed = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.DISARMED, Boolean.valueOf(true));
/* 2377 */   public static final IBlockState tripwire_disarmed_powered = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.DISARMED, Boolean.valueOf(true)).withProperty(BlockTripWire.POWERED, Boolean.valueOf(true));
/* 2378 */   public static final IBlockState tripwire_disarmed_suspended = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.DISARMED, Boolean.valueOf(true)).withProperty(BlockTripWire.field_176290_b, Boolean.valueOf(true));
/* 2379 */   public static final IBlockState tripwire_disarmed_powered_suspended = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.DISARMED, Boolean.valueOf(true)).withProperty(BlockTripWire.POWERED, Boolean.valueOf(true)).withProperty(BlockTripWire.field_176290_b, Boolean.valueOf(true));
/* 2380 */   public static final IBlockState tripwire_attached_disarmed = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWire.DISARMED, Boolean.valueOf(true));
/* 2381 */   public static final IBlockState tripwire_attached_disarmed_powered = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWire.DISARMED, Boolean.valueOf(true)).withProperty(BlockTripWire.POWERED, Boolean.valueOf(true));
/* 2382 */   public static final IBlockState tripwire_attached_disarmed_suspended = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWire.DISARMED, Boolean.valueOf(true)).withProperty(BlockTripWire.field_176290_b, Boolean.valueOf(true));
/* 2383 */   public static final IBlockState tripwire_attached_disarmed_powered_suspended = Blocks.tripwire.getDefaultState().withProperty(BlockTripWire.ATTACHED, Boolean.valueOf(true)).withProperty(BlockTripWire.DISARMED, Boolean.valueOf(true)).withProperty(BlockTripWire.POWERED, Boolean.valueOf(true)).withProperty(BlockTripWire.field_176290_b, Boolean.valueOf(true));
/* 2384 */   public static final IBlockState emerald_block = Blocks.emerald_block.getDefaultState();
/* 2385 */   public static final IBlockState spruce_stairs_bottom_east = Blocks.spruce_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2386 */   public static final IBlockState spruce_stairs_bottom_west = Blocks.spruce_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2387 */   public static final IBlockState spruce_stairs_bottom_south = Blocks.spruce_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2388 */   public static final IBlockState spruce_stairs_bottom_north = Blocks.spruce_stairs.getDefaultState();
/* 2389 */   public static final IBlockState spruce_stairs_top_east = Blocks.spruce_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2390 */   public static final IBlockState spruce_stairs_top_west = Blocks.spruce_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2391 */   public static final IBlockState spruce_stairs_top_south = Blocks.spruce_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2392 */   public static final IBlockState spruce_stairs_top_north = Blocks.spruce_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2393 */   public static final IBlockState birch_stairs_bottom_east = Blocks.birch_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2394 */   public static final IBlockState birch_stairs_bottom_west = Blocks.birch_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2395 */   public static final IBlockState birch_stairs_bottom_south = Blocks.birch_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2396 */   public static final IBlockState birch_stairs_bottom_north = Blocks.birch_stairs.getDefaultState();
/* 2397 */   public static final IBlockState birch_stairs_top_east = Blocks.birch_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2398 */   public static final IBlockState birch_stairs_top_west = Blocks.birch_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2399 */   public static final IBlockState birch_stairs_top_south = Blocks.birch_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2400 */   public static final IBlockState birch_stairs_top_north = Blocks.birch_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2401 */   public static final IBlockState jungle_stairs_bottom_east = Blocks.jungle_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2402 */   public static final IBlockState jungle_stairs_bottom_west = Blocks.jungle_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2403 */   public static final IBlockState jungle_stairs_bottom_south = Blocks.jungle_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2404 */   public static final IBlockState jungle_stairs_bottom_north = Blocks.jungle_stairs.getDefaultState();
/* 2405 */   public static final IBlockState jungle_stairs_top_east = Blocks.jungle_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2406 */   public static final IBlockState jungle_stairs_top_west = Blocks.jungle_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2407 */   public static final IBlockState jungle_stairs_top_south = Blocks.jungle_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2408 */   public static final IBlockState jungle_stairs_top_north = Blocks.jungle_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2409 */   public static final IBlockState command_block = Blocks.command_block.getDefaultState();
/* 2410 */   public static final IBlockState command_block_triggered = Blocks.command_block.getDefaultState().withProperty(BlockCommandBlock.field_176452_a, Boolean.valueOf(true));
/* 2411 */   public static final IBlockState beacon = Blocks.beacon.getDefaultState();
/* 2412 */   public static final IBlockState cobblestone_wall_cobblestone = Blocks.cobblestone_wall.getDefaultState();
/* 2413 */   public static final IBlockState cobblestone_wall_mossycobblestone = Blocks.cobblestone_wall.getDefaultState().withProperty(BlockWall.VARIANT, BlockWall.EnumType.MOSSY);
/* 2414 */   public static final IBlockState flower_pot = Blocks.flower_pot.getDefaultState();
/* 2415 */   public static final IBlockState carrots_age_0 = Blocks.carrots.getDefaultState();
/* 2416 */   public static final IBlockState carrots_age_1 = Blocks.carrots.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(1));
/* 2417 */   public static final IBlockState carrots_age_2 = Blocks.carrots.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(2));
/* 2418 */   public static final IBlockState carrots_age_3 = Blocks.carrots.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(3));
/* 2419 */   public static final IBlockState carrots_age_4 = Blocks.carrots.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(4));
/* 2420 */   public static final IBlockState carrots_age_5 = Blocks.carrots.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(5));
/* 2421 */   public static final IBlockState carrots_age_6 = Blocks.carrots.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(6));
/* 2422 */   public static final IBlockState carrots_age_7 = Blocks.carrots.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7));
/* 2423 */   public static final IBlockState potatoes_age_0 = Blocks.potatoes.getDefaultState();
/* 2424 */   public static final IBlockState potatoes_age_1 = Blocks.potatoes.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(1));
/* 2425 */   public static final IBlockState potatoes_age_2 = Blocks.potatoes.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(2));
/* 2426 */   public static final IBlockState potatoes_age_3 = Blocks.potatoes.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(3));
/* 2427 */   public static final IBlockState potatoes_age_4 = Blocks.potatoes.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(4));
/* 2428 */   public static final IBlockState potatoes_age_5 = Blocks.potatoes.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(5));
/* 2429 */   public static final IBlockState potatoes_age_6 = Blocks.potatoes.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(6));
/* 2430 */   public static final IBlockState potatoes_age_7 = Blocks.potatoes.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7));
/* 2431 */   public static final IBlockState wooden_button_down = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.DOWN);
/* 2432 */   public static final IBlockState wooden_button_east = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.EAST);
/* 2433 */   public static final IBlockState wooden_button_west = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.WEST);
/* 2434 */   public static final IBlockState wooden_button_south = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.SOUTH);
/* 2435 */   public static final IBlockState wooden_button_north = Blocks.wooden_button.getDefaultState();
/* 2436 */   public static final IBlockState wooden_button_up = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.UP);
/* 2437 */   public static final IBlockState wooden_button_down_powered = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.DOWN).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 2438 */   public static final IBlockState wooden_button_east_powered = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.EAST).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 2439 */   public static final IBlockState wooden_button_west_powered = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.WEST).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 2440 */   public static final IBlockState wooden_button_south_powered = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.SOUTH).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 2441 */   public static final IBlockState wooden_button_north_powered = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 2442 */   public static final IBlockState wooden_button_up_powered = Blocks.wooden_button.getDefaultState().withProperty(BlockButton.field_176585_a, EnumFacing.UP).withProperty(BlockButton.POWERED, Boolean.valueOf(true));
/* 2443 */   public static final IBlockState skull_down = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.DOWN);
/* 2444 */   public static final IBlockState skull_up = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.UP);
/* 2445 */   public static final IBlockState skull_north = Blocks.skull.getDefaultState();
/* 2446 */   public static final IBlockState skull_south = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.SOUTH);
/* 2447 */   public static final IBlockState skull_west = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.WEST);
/* 2448 */   public static final IBlockState skull_east = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.EAST);
/* 2449 */   public static final IBlockState skull_down_nodrop = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.DOWN).withProperty(BlockSkull.NODROP, Boolean.valueOf(true));
/* 2450 */   public static final IBlockState skull_up_nodrop = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.UP).withProperty(BlockSkull.NODROP, Boolean.valueOf(true));
/* 2451 */   public static final IBlockState skull_north_nodrop = Blocks.skull.getDefaultState().withProperty(BlockSkull.NODROP, Boolean.valueOf(true));
/* 2452 */   public static final IBlockState skull_south_nodrop = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.SOUTH).withProperty(BlockSkull.NODROP, Boolean.valueOf(true));
/* 2453 */   public static final IBlockState skull_west_nodrop = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.WEST).withProperty(BlockSkull.NODROP, Boolean.valueOf(true));
/* 2454 */   public static final IBlockState skull_east_nodrop = Blocks.skull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.EAST).withProperty(BlockSkull.NODROP, Boolean.valueOf(true));
/* 2455 */   public static final IBlockState anvil_south_damage_0 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.FACING, EnumFacing.SOUTH);
/* 2456 */   public static final IBlockState anvil_west_damage_0 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.FACING, EnumFacing.WEST);
/* 2457 */   public static final IBlockState anvil_north_damage_0 = Blocks.anvil.getDefaultState();
/* 2458 */   public static final IBlockState anvil_east_damage_0 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.FACING, EnumFacing.EAST);
/* 2459 */   public static final IBlockState anvil_south_damage_1 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.FACING, EnumFacing.SOUTH).withProperty(BlockAnvil.DAMAGE, Integer.valueOf(1));
/* 2460 */   public static final IBlockState anvil_west_damage_1 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.FACING, EnumFacing.WEST).withProperty(BlockAnvil.DAMAGE, Integer.valueOf(1));
/* 2461 */   public static final IBlockState anvil_north_damage_1 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.DAMAGE, Integer.valueOf(1));
/* 2462 */   public static final IBlockState anvil_east_damage_1 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.FACING, EnumFacing.EAST).withProperty(BlockAnvil.DAMAGE, Integer.valueOf(1));
/* 2463 */   public static final IBlockState anvil_south_damage_2 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.FACING, EnumFacing.SOUTH).withProperty(BlockAnvil.DAMAGE, Integer.valueOf(2));
/* 2464 */   public static final IBlockState anvil_west_damage_2 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.FACING, EnumFacing.WEST).withProperty(BlockAnvil.DAMAGE, Integer.valueOf(2));
/* 2465 */   public static final IBlockState anvil_north_damage_2 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.DAMAGE, Integer.valueOf(2));
/* 2466 */   public static final IBlockState anvil_east_damage_2 = Blocks.anvil.getDefaultState().withProperty(BlockAnvil.FACING, EnumFacing.EAST).withProperty(BlockAnvil.DAMAGE, Integer.valueOf(2));
/* 2467 */   public static final IBlockState trapped_chest_north = Blocks.trapped_chest.getDefaultState();
/* 2468 */   public static final IBlockState trapped_chest_south = Blocks.trapped_chest.getDefaultState().withProperty(BlockChest.FACING, EnumFacing.SOUTH);
/* 2469 */   public static final IBlockState trapped_chest_west = Blocks.trapped_chest.getDefaultState().withProperty(BlockChest.FACING, EnumFacing.WEST);
/* 2470 */   public static final IBlockState trapped_chest_east = Blocks.trapped_chest.getDefaultState().withProperty(BlockChest.FACING, EnumFacing.EAST);
/* 2471 */   public static final IBlockState light_weighted_pressure_plate_power_0 = Blocks.light_weighted_pressure_plate.getDefaultState();
/* 2472 */   public static final IBlockState light_weighted_pressure_plate_power_1 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(1));
/* 2473 */   public static final IBlockState light_weighted_pressure_plate_power_2 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(2));
/* 2474 */   public static final IBlockState light_weighted_pressure_plate_power_3 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(3));
/* 2475 */   public static final IBlockState light_weighted_pressure_plate_power_4 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(4));
/* 2476 */   public static final IBlockState light_weighted_pressure_plate_power_5 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(5));
/* 2477 */   public static final IBlockState light_weighted_pressure_plate_power_6 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(6));
/* 2478 */   public static final IBlockState light_weighted_pressure_plate_power_7 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(7));
/* 2479 */   public static final IBlockState light_weighted_pressure_plate_power_8 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(8));
/* 2480 */   public static final IBlockState light_weighted_pressure_plate_power_9 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(9));
/* 2481 */   public static final IBlockState light_weighted_pressure_plate_power_10 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(10));
/* 2482 */   public static final IBlockState light_weighted_pressure_plate_power_11 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(11));
/* 2483 */   public static final IBlockState light_weighted_pressure_plate_power_12 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(12));
/* 2484 */   public static final IBlockState light_weighted_pressure_plate_power_13 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(13));
/* 2485 */   public static final IBlockState light_weighted_pressure_plate_power_14 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(14));
/* 2486 */   public static final IBlockState light_weighted_pressure_plate_power_15 = Blocks.light_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(15));
/* 2487 */   public static final IBlockState heavy_weighted_pressure_plate_power_0 = Blocks.heavy_weighted_pressure_plate.getDefaultState();
/* 2488 */   public static final IBlockState heavy_weighted_pressure_plate_power_1 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(1));
/* 2489 */   public static final IBlockState heavy_weighted_pressure_plate_power_2 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(2));
/* 2490 */   public static final IBlockState heavy_weighted_pressure_plate_power_3 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(3));
/* 2491 */   public static final IBlockState heavy_weighted_pressure_plate_power_4 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(4));
/* 2492 */   public static final IBlockState heavy_weighted_pressure_plate_power_5 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(5));
/* 2493 */   public static final IBlockState heavy_weighted_pressure_plate_power_6 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(6));
/* 2494 */   public static final IBlockState heavy_weighted_pressure_plate_power_7 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(7));
/* 2495 */   public static final IBlockState heavy_weighted_pressure_plate_power_8 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(8));
/* 2496 */   public static final IBlockState heavy_weighted_pressure_plate_power_9 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(9));
/* 2497 */   public static final IBlockState heavy_weighted_pressure_plate_power_10 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(10));
/* 2498 */   public static final IBlockState heavy_weighted_pressure_plate_power_11 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(11));
/* 2499 */   public static final IBlockState heavy_weighted_pressure_plate_power_12 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(12));
/* 2500 */   public static final IBlockState heavy_weighted_pressure_plate_power_13 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(13));
/* 2501 */   public static final IBlockState heavy_weighted_pressure_plate_power_14 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(14));
/* 2502 */   public static final IBlockState heavy_weighted_pressure_plate_power_15 = Blocks.heavy_weighted_pressure_plate.getDefaultState().withProperty(BlockPressurePlateWeighted.POWER, Integer.valueOf(15));
/* 2503 */   public static final IBlockState unpowered_comparator_compare_south = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2504 */   public static final IBlockState unpowered_comparator_compare_west = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2505 */   public static final IBlockState unpowered_comparator_compare_north = Blocks.unpowered_comparator.getDefaultState();
/* 2506 */   public static final IBlockState unpowered_comparator_compare_east = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2507 */   public static final IBlockState unpowered_comparator_subtract_south = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2508 */   public static final IBlockState unpowered_comparator_subtract_west = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2509 */   public static final IBlockState unpowered_comparator_subtract_north = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT);
/* 2510 */   public static final IBlockState unpowered_comparator_subtract_east = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2511 */   public static final IBlockState unpowered_comparator_compare_south_powered = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2512 */   public static final IBlockState unpowered_comparator_compare_west_powered = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2513 */   public static final IBlockState unpowered_comparator_compare_north_powered = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2514 */   public static final IBlockState unpowered_comparator_compare_east_powered = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2515 */   public static final IBlockState unpowered_comparator_subtract_south_powered = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2516 */   public static final IBlockState unpowered_comparator_subtract_west_powered = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2517 */   public static final IBlockState unpowered_comparator_subtract_north_powered = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2518 */   public static final IBlockState unpowered_comparator_subtract_east_powered = Blocks.unpowered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2519 */   public static final IBlockState powered_comparator_compare_south = Blocks.powered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2520 */   public static final IBlockState powered_comparator_compare_west = Blocks.powered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2521 */   public static final IBlockState powered_comparator_compare_north = Blocks.powered_comparator.getDefaultState();
/* 2522 */   public static final IBlockState powered_comparator_compare_east = Blocks.powered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2523 */   public static final IBlockState powered_comparator_subtract_south = Blocks.powered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH);
/* 2524 */   public static final IBlockState powered_comparator_subtract_west = Blocks.powered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.WEST);
/* 2525 */   public static final IBlockState powered_comparator_subtract_north = Blocks.powered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT);
/* 2526 */   public static final IBlockState powered_comparator_subtract_east = Blocks.powered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.EAST);
/* 2527 */   public static final IBlockState powered_comparator_compare_south_powered = Blocks.powered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2528 */   public static final IBlockState powered_comparator_compare_west_powered = Blocks.powered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2529 */   public static final IBlockState powered_comparator_compare_north_powered = Blocks.powered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2530 */   public static final IBlockState powered_comparator_compare_east_powered = Blocks.powered_comparator.getDefaultState().withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2531 */   public static final IBlockState powered_comparator_subtract_south_powered = Blocks.powered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.SOUTH).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2532 */   public static final IBlockState powered_comparator_subtract_west_powered = Blocks.powered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.WEST).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2533 */   public static final IBlockState powered_comparator_subtract_north_powered = Blocks.powered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2534 */   public static final IBlockState powered_comparator_subtract_east_powered = Blocks.powered_comparator.getDefaultState().withProperty(BlockRedstoneComparator.MODE, BlockRedstoneComparator.Mode.SUBTRACT).withProperty(BlockDoublePlant.FACING, EnumFacing.EAST).withProperty(BlockRedstoneComparator.POWERED, Boolean.valueOf(true));
/* 2535 */   public static final IBlockState daylight_detector_power_0 = Blocks.daylight_detector.getDefaultState();
/* 2536 */   public static final IBlockState daylight_detector_power_1 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(1));
/* 2537 */   public static final IBlockState daylight_detector_power_2 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(2));
/* 2538 */   public static final IBlockState daylight_detector_power_3 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(3));
/* 2539 */   public static final IBlockState daylight_detector_power_4 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(4));
/* 2540 */   public static final IBlockState daylight_detector_power_5 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(5));
/* 2541 */   public static final IBlockState daylight_detector_power_6 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(6));
/* 2542 */   public static final IBlockState daylight_detector_power_7 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(7));
/* 2543 */   public static final IBlockState daylight_detector_power_8 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(8));
/* 2544 */   public static final IBlockState daylight_detector_power_9 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(9));
/* 2545 */   public static final IBlockState daylight_detector_power_10 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(10));
/* 2546 */   public static final IBlockState daylight_detector_power_11 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(11));
/* 2547 */   public static final IBlockState daylight_detector_power_12 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(12));
/* 2548 */   public static final IBlockState daylight_detector_power_13 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(13));
/* 2549 */   public static final IBlockState daylight_detector_power_14 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(14));
/* 2550 */   public static final IBlockState daylight_detector_power_15 = Blocks.daylight_detector.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(15));
/* 2551 */   public static final IBlockState daylight_detector_inverted_power_0 = Blocks.daylight_detector_inverted.getDefaultState();
/* 2552 */   public static final IBlockState daylight_detector_inverted_power_1 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(1));
/* 2553 */   public static final IBlockState daylight_detector_inverted_power_2 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(2));
/* 2554 */   public static final IBlockState daylight_detector_inverted_power_3 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(3));
/* 2555 */   public static final IBlockState daylight_detector_inverted_power_4 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(4));
/* 2556 */   public static final IBlockState daylight_detector_inverted_power_5 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(5));
/* 2557 */   public static final IBlockState daylight_detector_inverted_power_6 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(6));
/* 2558 */   public static final IBlockState daylight_detector_inverted_power_7 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(7));
/* 2559 */   public static final IBlockState daylight_detector_inverted_power_8 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(8));
/* 2560 */   public static final IBlockState daylight_detector_inverted_power_9 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(9));
/* 2561 */   public static final IBlockState daylight_detector_inverted_power_10 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(10));
/* 2562 */   public static final IBlockState daylight_detector_inverted_power_11 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(11));
/* 2563 */   public static final IBlockState daylight_detector_inverted_power_12 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(12));
/* 2564 */   public static final IBlockState daylight_detector_inverted_power_13 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(13));
/* 2565 */   public static final IBlockState daylight_detector_inverted_power_14 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(14));
/* 2566 */   public static final IBlockState daylight_detector_inverted_power_15 = Blocks.daylight_detector_inverted.getDefaultState().withProperty(BlockDaylightDetector.POWER, Integer.valueOf(15));
/* 2567 */   public static final IBlockState redstone_block = Blocks.redstone_block.getDefaultState();
/* 2568 */   public static final IBlockState quartz_ore = Blocks.quartz_ore.getDefaultState();
/* 2569 */   public static final IBlockState hopper_down_enabled = Blocks.hopper.getDefaultState();
/* 2570 */   public static final IBlockState hopper_north_enabled = Blocks.hopper.getDefaultState().withProperty(BlockHopper.FACING, EnumFacing.NORTH);
/* 2571 */   public static final IBlockState hopper_south_enabled = Blocks.hopper.getDefaultState().withProperty(BlockHopper.FACING, EnumFacing.SOUTH);
/* 2572 */   public static final IBlockState hopper_west_enabled = Blocks.hopper.getDefaultState().withProperty(BlockHopper.FACING, EnumFacing.WEST);
/* 2573 */   public static final IBlockState hopper_east_enabled = Blocks.hopper.getDefaultState().withProperty(BlockHopper.FACING, EnumFacing.EAST);
/* 2574 */   public static final IBlockState hopper_down = Blocks.hopper.getDefaultState().withProperty(BlockHopper.ENABLED, Boolean.valueOf(false));
/* 2575 */   public static final IBlockState hopper_north = Blocks.hopper.getDefaultState().withProperty(BlockHopper.FACING, EnumFacing.NORTH).withProperty(BlockHopper.ENABLED, Boolean.valueOf(false));
/* 2576 */   public static final IBlockState hopper_south = Blocks.hopper.getDefaultState().withProperty(BlockHopper.FACING, EnumFacing.SOUTH).withProperty(BlockHopper.ENABLED, Boolean.valueOf(false));
/* 2577 */   public static final IBlockState hopper_west = Blocks.hopper.getDefaultState().withProperty(BlockHopper.FACING, EnumFacing.WEST).withProperty(BlockHopper.ENABLED, Boolean.valueOf(false));
/* 2578 */   public static final IBlockState hopper_east = Blocks.hopper.getDefaultState().withProperty(BlockHopper.FACING, EnumFacing.EAST).withProperty(BlockHopper.ENABLED, Boolean.valueOf(false));
/* 2579 */   public static final IBlockState quartz_block_default = Blocks.quartz_block.getDefaultState();
/* 2580 */   public static final IBlockState quartz_block_chiseled = Blocks.quartz_block.getDefaultState().withProperty(BlockQuartz.VARIANT, BlockQuartz.EnumType.CHISELED);
/* 2581 */   public static final IBlockState quartz_block_linesy = Blocks.quartz_block.getDefaultState().withProperty(BlockQuartz.VARIANT, BlockQuartz.EnumType.LINES_Y);
/* 2582 */   public static final IBlockState quartz_block_linesx = Blocks.quartz_block.getDefaultState().withProperty(BlockQuartz.VARIANT, BlockQuartz.EnumType.LINES_X);
/* 2583 */   public static final IBlockState quartz_block_linesz = Blocks.quartz_block.getDefaultState().withProperty(BlockQuartz.VARIANT, BlockQuartz.EnumType.LINES_Z);
/* 2584 */   public static final IBlockState quartz_stairs_bottom_east = Blocks.quartz_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2585 */   public static final IBlockState quartz_stairs_bottom_west = Blocks.quartz_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2586 */   public static final IBlockState quartz_stairs_bottom_south = Blocks.quartz_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2587 */   public static final IBlockState quartz_stairs_bottom_north = Blocks.quartz_stairs.getDefaultState();
/* 2588 */   public static final IBlockState quartz_stairs_top_east = Blocks.quartz_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2589 */   public static final IBlockState quartz_stairs_top_west = Blocks.quartz_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2590 */   public static final IBlockState quartz_stairs_top_south = Blocks.quartz_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2591 */   public static final IBlockState quartz_stairs_top_north = Blocks.quartz_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2592 */   public static final IBlockState activator_rail_northsouth = Blocks.activator_rail.getDefaultState();
/* 2593 */   public static final IBlockState activator_rail_eastwest = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST);
/* 2594 */   public static final IBlockState activator_rail_ascendingeast = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST);
/* 2595 */   public static final IBlockState activator_rail_ascendingwest = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST);
/* 2596 */   public static final IBlockState activator_rail_ascendingnorth = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH);
/* 2597 */   public static final IBlockState activator_rail_ascendingsouth = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH);
/* 2598 */   public static final IBlockState activator_rail_northsouth_powered = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 2599 */   public static final IBlockState activator_rail_eastwest_powered = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.EAST_WEST).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 2600 */   public static final IBlockState activator_rail_ascendingeast_powered = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_EAST).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 2601 */   public static final IBlockState activator_rail_ascendingwest_powered = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_WEST).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 2602 */   public static final IBlockState activator_rail_ascendingnorth_powered = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_NORTH).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 2603 */   public static final IBlockState activator_rail_ascendingsouth_powered = Blocks.activator_rail.getDefaultState().withProperty(BlockRailPowered.SHAPE, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH).withProperty(BlockRailPowered.POWERED, Boolean.valueOf(true));
/* 2604 */   public static final IBlockState dropper_down = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.DOWN);
/* 2605 */   public static final IBlockState dropper_up = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.UP);
/* 2606 */   public static final IBlockState dropper_north = Blocks.dropper.getDefaultState();
/* 2607 */   public static final IBlockState dropper_south = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.SOUTH);
/* 2608 */   public static final IBlockState dropper_west = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.WEST);
/* 2609 */   public static final IBlockState dropper_east = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.EAST);
/* 2610 */   public static final IBlockState dropper_down_triggered = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.DOWN).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 2611 */   public static final IBlockState dropper_up_triggered = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.UP).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 2612 */   public static final IBlockState dropper_north_triggered = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 2613 */   public static final IBlockState dropper_south_triggered = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.SOUTH).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 2614 */   public static final IBlockState dropper_west_triggered = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.WEST).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 2615 */   public static final IBlockState dropper_east_triggered = Blocks.dropper.getDefaultState().withProperty(BlockDispenser.FACING, EnumFacing.EAST).withProperty(BlockDispenser.TRIGGERED, Boolean.valueOf(true));
/* 2616 */   public static final IBlockState stained_hardened_clay_white = Blocks.stained_hardened_clay.getDefaultState();
/* 2617 */   public static final IBlockState stained_hardened_clay_orange = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.ORANGE);
/* 2618 */   public static final IBlockState stained_hardened_clay_magenta = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.MAGENTA);
/* 2619 */   public static final IBlockState stained_hardened_clay_lightblue = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.LIGHT_BLUE);
/* 2620 */   public static final IBlockState stained_hardened_clay_yellow = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.YELLOW);
/* 2621 */   public static final IBlockState stained_hardened_clay_lime = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.LIME);
/* 2622 */   public static final IBlockState stained_hardened_clay_pink = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.PINK);
/* 2623 */   public static final IBlockState stained_hardened_clay_gray = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.GRAY);
/* 2624 */   public static final IBlockState stained_hardened_clay_silver = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.SILVER);
/* 2625 */   public static final IBlockState stained_hardened_clay_cyan = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.CYAN);
/* 2626 */   public static final IBlockState stained_hardened_clay_purple = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.PURPLE);
/* 2627 */   public static final IBlockState stained_hardened_clay_blue = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.BLUE);
/* 2628 */   public static final IBlockState stained_hardened_clay_brown = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.BROWN);
/* 2629 */   public static final IBlockState stained_hardened_clay_green = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.GREEN);
/* 2630 */   public static final IBlockState stained_hardened_clay_red = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.RED);
/* 2631 */   public static final IBlockState stained_hardened_clay_black = Blocks.stained_hardened_clay.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.BLACK);
/* 2632 */   public static final IBlockState barrier = Blocks.barrier.getDefaultState();
/* 2633 */   public static final IBlockState iron_trapdoor_bottom_north = Blocks.iron_trapdoor.getDefaultState();
/* 2634 */   public static final IBlockState iron_trapdoor_bottom_south = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.SOUTH);
/* 2635 */   public static final IBlockState iron_trapdoor_bottom_west = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.WEST);
/* 2636 */   public static final IBlockState iron_trapdoor_bottom_east = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.EAST);
/* 2637 */   public static final IBlockState iron_trapdoor_bottom_north_open = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2638 */   public static final IBlockState iron_trapdoor_bottom_south_open = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.SOUTH).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2639 */   public static final IBlockState iron_trapdoor_bottom_west_open = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.WEST).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2640 */   public static final IBlockState iron_trapdoor_bottom_east_open = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.FACING, EnumFacing.EAST).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2641 */   public static final IBlockState iron_trapdoor_top_north = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP);
/* 2642 */   public static final IBlockState iron_trapdoor_top_south = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.SOUTH);
/* 2643 */   public static final IBlockState iron_trapdoor_top_west = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.WEST);
/* 2644 */   public static final IBlockState iron_trapdoor_top_east = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.EAST);
/* 2645 */   public static final IBlockState iron_trapdoor_top_north_open = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2646 */   public static final IBlockState iron_trapdoor_top_south_open = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.SOUTH).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2647 */   public static final IBlockState iron_trapdoor_top_west_open = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.WEST).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2648 */   public static final IBlockState iron_trapdoor_top_east_open = Blocks.iron_trapdoor.getDefaultState().withProperty(BlockTrapDoor.HALF, BlockTrapDoor.DoorHalf.TOP).withProperty(BlockTrapDoor.FACING, EnumFacing.EAST).withProperty(BlockTrapDoor.OPEN, Boolean.valueOf(true));
/* 2649 */   public static final IBlockState hay_block_y = Blocks.hay_block.getDefaultState();
/* 2650 */   public static final IBlockState hay_block_x = Blocks.hay_block.getDefaultState().withProperty(BlockRotatedPillar.AXIS, EnumFacing.Axis.X);
/* 2651 */   public static final IBlockState hay_block_z = Blocks.hay_block.getDefaultState().withProperty(BlockRotatedPillar.AXIS, EnumFacing.Axis.Z);
/* 2652 */   public static final IBlockState carpet_white = Blocks.carpet.getDefaultState();
/* 2653 */   public static final IBlockState carpet_orange = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.ORANGE);
/* 2654 */   public static final IBlockState carpet_magenta = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.MAGENTA);
/* 2655 */   public static final IBlockState carpet_lightblue = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.LIGHT_BLUE);
/* 2656 */   public static final IBlockState carpet_yellow = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.YELLOW);
/* 2657 */   public static final IBlockState carpet_lime = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.LIME);
/* 2658 */   public static final IBlockState carpet_pink = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.PINK);
/* 2659 */   public static final IBlockState carpet_gray = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.GRAY);
/* 2660 */   public static final IBlockState carpet_silver = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.SILVER);
/* 2661 */   public static final IBlockState carpet_cyan = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.CYAN);
/* 2662 */   public static final IBlockState carpet_purple = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.PURPLE);
/* 2663 */   public static final IBlockState carpet_blue = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.BLUE);
/* 2664 */   public static final IBlockState carpet_brown = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.BROWN);
/* 2665 */   public static final IBlockState carpet_green = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.GREEN);
/* 2666 */   public static final IBlockState carpet_red = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.RED);
/* 2667 */   public static final IBlockState carpet_black = Blocks.carpet.getDefaultState().withProperty(BlockCarpet.COLOR, EnumDyeColor.BLACK);
/* 2668 */   public static final IBlockState hardened_clay = Blocks.hardened_clay.getDefaultState();
/* 2669 */   public static final IBlockState coal_block = Blocks.coal_block.getDefaultState();
/* 2670 */   public static final IBlockState packed_ice = Blocks.packed_ice.getDefaultState();
/* 2671 */   public static final IBlockState acacia_stairs_bottom_east = Blocks.acacia_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2672 */   public static final IBlockState acacia_stairs_bottom_west = Blocks.acacia_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2673 */   public static final IBlockState acacia_stairs_bottom_south = Blocks.acacia_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2674 */   public static final IBlockState acacia_stairs_bottom_north = Blocks.acacia_stairs.getDefaultState();
/* 2675 */   public static final IBlockState acacia_stairs_top_east = Blocks.acacia_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2676 */   public static final IBlockState acacia_stairs_top_west = Blocks.acacia_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2677 */   public static final IBlockState acacia_stairs_top_south = Blocks.acacia_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2678 */   public static final IBlockState acacia_stairs_top_north = Blocks.acacia_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2679 */   public static final IBlockState dark_oak_stairs_bottom_east = Blocks.dark_oak_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2680 */   public static final IBlockState dark_oak_stairs_bottom_west = Blocks.dark_oak_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2681 */   public static final IBlockState dark_oak_stairs_bottom_south = Blocks.dark_oak_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2682 */   public static final IBlockState dark_oak_stairs_bottom_north = Blocks.dark_oak_stairs.getDefaultState();
/* 2683 */   public static final IBlockState dark_oak_stairs_top_east = Blocks.dark_oak_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2684 */   public static final IBlockState dark_oak_stairs_top_west = Blocks.dark_oak_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2685 */   public static final IBlockState dark_oak_stairs_top_south = Blocks.dark_oak_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2686 */   public static final IBlockState dark_oak_stairs_top_north = Blocks.dark_oak_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2687 */   public static final IBlockState slime_block = Blocks.slime_block.getDefaultState();
/* 2688 */   public static final IBlockState double_plant_lower_sunflower = Blocks.double_plant.getDefaultState();
/* 2689 */   public static final IBlockState double_plant_lower_syringa = Blocks.double_plant.getDefaultState().withProperty(BlockDoublePlant.VARIANT, BlockDoublePlant.EnumPlantType.SYRINGA);
/* 2690 */   public static final IBlockState double_plant_lower_doublegrass = Blocks.double_plant.getDefaultState().withProperty(BlockDoublePlant.VARIANT, BlockDoublePlant.EnumPlantType.GRASS);
/* 2691 */   public static final IBlockState double_plant_lower_doublefern = Blocks.double_plant.getDefaultState().withProperty(BlockDoublePlant.VARIANT, BlockDoublePlant.EnumPlantType.FERN);
/* 2692 */   public static final IBlockState double_plant_lower_doublerose = Blocks.double_plant.getDefaultState().withProperty(BlockDoublePlant.VARIANT, BlockDoublePlant.EnumPlantType.ROSE);
/* 2693 */   public static final IBlockState double_plant_lower_paeonia = Blocks.double_plant.getDefaultState().withProperty(BlockDoublePlant.VARIANT, BlockDoublePlant.EnumPlantType.PAEONIA);
/* 2694 */   public static final IBlockState double_plant_upper_sunflower = Blocks.double_plant.getDefaultState().withProperty(BlockDoublePlant.HALF, BlockDoublePlant.EnumBlockHalf.UPPER);
/* 2695 */   public static final IBlockState stained_glass_white = Blocks.stained_glass.getDefaultState();
/* 2696 */   public static final IBlockState stained_glass_orange = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.ORANGE);
/* 2697 */   public static final IBlockState stained_glass_magenta = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.MAGENTA);
/* 2698 */   public static final IBlockState stained_glass_lightblue = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.LIGHT_BLUE);
/* 2699 */   public static final IBlockState stained_glass_yellow = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.YELLOW);
/* 2700 */   public static final IBlockState stained_glass_lime = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.LIME);
/* 2701 */   public static final IBlockState stained_glass_pink = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.PINK);
/* 2702 */   public static final IBlockState stained_glass_gray = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.GRAY);
/* 2703 */   public static final IBlockState stained_glass_silver = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.SILVER);
/* 2704 */   public static final IBlockState stained_glass_cyan = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.CYAN);
/* 2705 */   public static final IBlockState stained_glass_purple = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.PURPLE);
/* 2706 */   public static final IBlockState stained_glass_blue = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.BLUE);
/* 2707 */   public static final IBlockState stained_glass_brown = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.BROWN);
/* 2708 */   public static final IBlockState stained_glass_green = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.GREEN);
/* 2709 */   public static final IBlockState stained_glass_red = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.RED);
/* 2710 */   public static final IBlockState stained_glass_black = Blocks.stained_glass.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.BLACK);
/* 2711 */   public static final IBlockState stained_glass_pane_white = Blocks.stained_glass_pane.getDefaultState();
/* 2712 */   public static final IBlockState stained_glass_pane_orange = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.ORANGE);
/* 2713 */   public static final IBlockState stained_glass_pane_magenta = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.MAGENTA);
/* 2714 */   public static final IBlockState stained_glass_pane_lightblue = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.LIGHT_BLUE);
/* 2715 */   public static final IBlockState stained_glass_pane_yellow = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.YELLOW);
/* 2716 */   public static final IBlockState stained_glass_pane_lime = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.LIME);
/* 2717 */   public static final IBlockState stained_glass_pane_pink = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.PINK);
/* 2718 */   public static final IBlockState stained_glass_pane_gray = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.GRAY);
/* 2719 */   public static final IBlockState stained_glass_pane_silver = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.SILVER);
/* 2720 */   public static final IBlockState stained_glass_pane_cyan = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.CYAN);
/* 2721 */   public static final IBlockState stained_glass_pane_purple = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.PURPLE);
/* 2722 */   public static final IBlockState stained_glass_pane_blue = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.BLUE);
/* 2723 */   public static final IBlockState stained_glass_pane_brown = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.BROWN);
/* 2724 */   public static final IBlockState stained_glass_pane_green = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.GREEN);
/* 2725 */   public static final IBlockState stained_glass_pane_red = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.RED);
/* 2726 */   public static final IBlockState stained_glass_pane_black = Blocks.stained_glass_pane.getDefaultState().withProperty(BlockStainedGlassPane.COLOR, EnumDyeColor.BLACK);
/* 2727 */   public static final IBlockState prismarine = Blocks.prismarine.getDefaultState();
/* 2728 */   public static final IBlockState prismarine_prismarinebricks = Blocks.prismarine.getDefaultState().withProperty(BlockPrismarine.VARIANT, BlockPrismarine.EnumType.BRICKS);
/* 2729 */   public static final IBlockState prismarine_darkprismarine = Blocks.prismarine.getDefaultState().withProperty(BlockPrismarine.VARIANT, BlockPrismarine.EnumType.DARK);
/* 2730 */   public static final IBlockState sea_lantern = Blocks.sea_lantern.getDefaultState();
/* 2731 */   public static final IBlockState standing_banner_rotation_0 = Blocks.standing_banner.getDefaultState();
/* 2732 */   public static final IBlockState standing_banner_rotation_1 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(1));
/* 2733 */   public static final IBlockState standing_banner_rotation_2 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(2));
/* 2734 */   public static final IBlockState standing_banner_rotation_3 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(3));
/* 2735 */   public static final IBlockState standing_banner_rotation_4 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(4));
/* 2736 */   public static final IBlockState standing_banner_rotation_5 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(5));
/* 2737 */   public static final IBlockState standing_banner_rotation_6 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(6));
/* 2738 */   public static final IBlockState standing_banner_rotation_7 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(7));
/* 2739 */   public static final IBlockState standing_banner_rotation_8 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(8));
/* 2740 */   public static final IBlockState standing_banner_rotation_9 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(9));
/* 2741 */   public static final IBlockState standing_banner_rotation_10 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(10));
/* 2742 */   public static final IBlockState standing_banner_rotation_11 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(11));
/* 2743 */   public static final IBlockState standing_banner_rotation_12 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(12));
/* 2744 */   public static final IBlockState standing_banner_rotation_13 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(13));
/* 2745 */   public static final IBlockState standing_banner_rotation_14 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(14));
/* 2746 */   public static final IBlockState standing_banner_rotation_15 = Blocks.standing_banner.getDefaultState().withProperty(BlockBanner.ROTATION, Integer.valueOf(15));
/* 2747 */   public static final IBlockState wall_banner_north = Blocks.wall_banner.getDefaultState();
/* 2748 */   public static final IBlockState wall_banner_south = Blocks.wall_banner.getDefaultState().withProperty(BlockBanner.FACING, EnumFacing.SOUTH);
/* 2749 */   public static final IBlockState wall_banner_west = Blocks.wall_banner.getDefaultState().withProperty(BlockBanner.FACING, EnumFacing.WEST);
/* 2750 */   public static final IBlockState wall_banner_east = Blocks.wall_banner.getDefaultState().withProperty(BlockBanner.FACING, EnumFacing.EAST);
/* 2751 */   public static final IBlockState red_sandstone_redsandstone = Blocks.red_sandstone.getDefaultState();
/* 2752 */   public static final IBlockState red_sandstone_chiseledredsandstone = Blocks.red_sandstone.getDefaultState().withProperty(BlockRedSandstone.TYPE, BlockRedSandstone.EnumType.CHISELED);
/* 2753 */   public static final IBlockState red_sandstone_smoothredsandstone = Blocks.red_sandstone.getDefaultState().withProperty(BlockRedSandstone.TYPE, BlockRedSandstone.EnumType.SMOOTH);
/* 2754 */   public static final IBlockState red_sandstone_stairs_bottom_east = Blocks.red_sandstone_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2755 */   public static final IBlockState red_sandstone_stairs_bottom_west = Blocks.red_sandstone_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2756 */   public static final IBlockState red_sandstone_stairs_bottom_south = Blocks.red_sandstone_stairs.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2757 */   public static final IBlockState red_sandstone_stairs_bottom_north = Blocks.red_sandstone_stairs.getDefaultState();
/* 2758 */   public static final IBlockState red_sandstone_stairs_top_east = Blocks.red_sandstone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.EAST);
/* 2759 */   public static final IBlockState red_sandstone_stairs_top_west = Blocks.red_sandstone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.WEST);
/* 2760 */   public static final IBlockState red_sandstone_stairs_top_south = Blocks.red_sandstone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP).withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
/* 2761 */   public static final IBlockState red_sandstone_stairs_top_north = Blocks.red_sandstone_stairs.getDefaultState().withProperty(BlockStairs.HALF, BlockStairs.EnumHalf.TOP);
/* 2762 */   public static final IBlockState double_stone_slab2 = Blocks.double_stone_slab2.getDefaultState();
/* 2763 */   public static final IBlockState double_stone_slab2_seamless = Blocks.double_stone_slab2.getDefaultState().withProperty(BlockStoneSlabNew.SEAMLESS, Boolean.valueOf(true));
/* 2764 */   public static final IBlockState stone_slab2_bottom = Blocks.stone_slab2.getDefaultState();
/* 2765 */   public static final IBlockState stone_slab2_top = Blocks.stone_slab2.getDefaultState().withProperty(BlockSlab.HALF, BlockSlab.EnumBlockHalf.TOP);
/*      */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\BlockStates.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */