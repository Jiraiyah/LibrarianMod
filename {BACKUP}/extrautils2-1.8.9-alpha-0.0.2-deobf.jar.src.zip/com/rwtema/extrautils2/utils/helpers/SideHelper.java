/*    */ package com.rwtema.extrautils2.utils.helpers;
/*    */ 
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ public class SideHelper
/*    */ {
/*  7 */   public static EnumFacing[][] edges = { { EnumFacing.UP, EnumFacing.WEST, EnumFacing.NORTH }, { EnumFacing.UP, EnumFacing.EAST, EnumFacing.NORTH }, { EnumFacing.UP, EnumFacing.NORTH, EnumFacing.WEST }, { EnumFacing.UP, EnumFacing.SOUTH, EnumFacing.WEST }, { EnumFacing.DOWN, EnumFacing.WEST, EnumFacing.NORTH }, { EnumFacing.DOWN, EnumFacing.EAST, EnumFacing.NORTH }, { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.WEST }, { EnumFacing.DOWN, EnumFacing.SOUTH, EnumFacing.WEST }, { EnumFacing.WEST, EnumFacing.NORTH, EnumFacing.UP }, { EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.UP }, { EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.UP }, { EnumFacing.SOUTH, EnumFacing.WEST, EnumFacing.UP } };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 21 */   public static EnumFacing[][] corners = { { EnumFacing.UP, EnumFacing.WEST, EnumFacing.NORTH }, { EnumFacing.UP, EnumFacing.WEST, EnumFacing.SOUTH }, { EnumFacing.UP, EnumFacing.EAST, EnumFacing.NORTH }, { EnumFacing.UP, EnumFacing.EAST, EnumFacing.SOUTH }, { EnumFacing.DOWN, EnumFacing.WEST, EnumFacing.NORTH }, { EnumFacing.DOWN, EnumFacing.WEST, EnumFacing.SOUTH }, { EnumFacing.DOWN, EnumFacing.EAST, EnumFacing.NORTH }, { EnumFacing.DOWN, EnumFacing.EAST, EnumFacing.SOUTH } };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 32 */   public static EnumFacing[][] perp_sides = { { EnumFacing.WEST, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.NORTH }, { EnumFacing.WEST, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.NORTH }, { EnumFacing.UP, EnumFacing.DOWN, EnumFacing.WEST, EnumFacing.EAST }, { EnumFacing.UP, EnumFacing.DOWN, EnumFacing.WEST, EnumFacing.EAST }, { EnumFacing.UP, EnumFacing.DOWN, EnumFacing.SOUTH, EnumFacing.NORTH }, { EnumFacing.UP, EnumFacing.DOWN, EnumFacing.SOUTH, EnumFacing.NORTH } };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 44 */   public static EnumFacing[][] crossProd = new EnumFacing[6][6];
/* 45 */   static { net.minecraft.util.BlockPos zero = new net.minecraft.util.BlockPos(0, 0, 0);
/* 46 */     for (int i = 0; i < EnumFacing.values().length; i++) {
/* 47 */       for (int j = 0; j < EnumFacing.values().length; j++) {
/* 48 */         EnumFacing a = EnumFacing.values()[i];
/* 49 */         EnumFacing b = EnumFacing.values()[j];
/* 50 */         net.minecraft.util.BlockPos crossP = zero.offset(a).crossProduct(zero.offset(b));
/* 51 */         if (!crossP.equals(zero)) {
/* 52 */           crossProd[i][j] = EnumFacing.getFacingFromVector(crossP.getX(), crossP.getY(), crossP.getZ());
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\SideHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */