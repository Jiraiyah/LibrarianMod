/*    */ package com.rwtema.extrautils2.utils.helpers;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.WeightedRandomChestContent;
/*    */ 
/*    */ public class DungeonHelper
/*    */ {
/*    */   public static void addDungeonItem(ItemStack item, int min, int max, String category, double probability)
/*    */   {
/* 11 */     int n = getWeightTotal(net.minecraftforge.common.ChestGenHooks.getItems(category, com.rwtema.extrautils2.ExtraUtils2.RANDOM));
/* 12 */     int a = (int)Math.ceil(probability * n);
/* 13 */     net.minecraftforge.common.ChestGenHooks.addItem(category, new WeightedRandomChestContent(item, min, max, a));
/*    */   }
/*    */   
/*    */   private static int getWeightTotal(List<WeightedRandomChestContent> items) {
/* 17 */     if ((items == null) || (items.size() == 0)) {
/* 18 */       return 1;
/*    */     }
/*    */     
/* 21 */     int weight = 0;
/*    */     
/* 23 */     for (WeightedRandomChestContent item : items) {
/* 24 */       weight += item.itemWeight;
/*    */     }
/*    */     
/* 27 */     return weight;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\DungeonHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */