/*    */ package com.rwtema.extrautils2.utils.helpers;
/*    */ 
/*    */ import net.minecraft.util.MathHelper;
/*    */ 
/*    */ public class ColorHelper {
/*    */   public static int getA(int col) {
/*  7 */     return (col & 0xFF000000) >>> 24;
/*    */   }
/*    */   
/*    */   public static int getR(int col) {
/* 11 */     return (col & 0xFF0000) >> 16;
/*    */   }
/*    */   
/*    */   public static int getG(int col) {
/* 15 */     return (col & 0xFF00) >> 8;
/*    */   }
/*    */   
/*    */   public static int getB(int col) {
/* 19 */     return col & 0xFF;
/*    */   }
/*    */   
/*    */   public static float getRF(int col) {
/* 23 */     return getR(col) / 255.0F;
/*    */   }
/*    */   
/*    */   public static float getGF(int col) {
/* 27 */     return getG(col) / 255.0F;
/*    */   }
/*    */   
/*    */   public static float getBF(int col) {
/* 31 */     return getB(col) / 255.0F;
/*    */   }
/*    */   
/*    */   public static float getAF(int col) {
/* 35 */     return getA(col) / 255.0F;
/*    */   }
/*    */   
/*    */   public static int makeAlphaWhite(int alpha) {
/* 39 */     if (alpha <= 0) return 0;
/* 40 */     if (alpha >= 255) return -1;
/* 41 */     return (alpha & 0xFF) << 24 | 0xFFFFFF;
/*    */   }
/*    */   
/*    */   public static int color(int r, int g, int b, int a) {
/* 45 */     return (a & 0xFF) << 24 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
/*    */   }
/*    */   
/*    */   public static float[] colToFloat(int rgb) {
/* 49 */     return new float[] { getA(rgb) / 255.0F, getR(rgb) / 255.0F, getG(rgb) / 255.0F, getB(rgb) / 255.0F };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static int floatsToCol(float[] rgb)
/*    */   {
/* 57 */     return color((int)(rgb[1] * 255.0F), (int)(rgb[2] * 255.0F), (int)(rgb[3] * 255.0F), (int)(rgb[0] * 255.0F));
/*    */   }
/*    */   
/*    */   public static int brightness(int col) {
/* 61 */     return brightness(getR(col), getG(col), getB(col));
/*    */   }
/*    */   
/*    */   public static int brightness(int r, int g, int b) {
/* 65 */     return r * 109 + g * 366 + b * 37 >> 9;
/*    */   }
/*    */   
/*    */   public static int makeGray(int b) {
/* 69 */     return color(b, b, b, 255);
/*    */   }
/*    */   
/*    */   public static int clamp(float f) {
/* 73 */     return MathHelper.clamp_int((int)(f * 255.0F), 0, 255);
/*    */   }
/*    */   
/*    */   public static int multShade(int input, float perc) {
/* 77 */     if ((perc >= 1.0F) || (input == 0)) return input;
/* 78 */     if (perc <= 0.0F) return input & 0xFF000000;
/* 79 */     return color((int)(getR(input) * perc), (int)(getG(input) * perc), (int)(getB(input) * perc), getA(input));
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\ColorHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */