/*     */ package com.rwtema.extrautils2.utils.helpers;
/*     */ 
/*     */ import com.google.common.base.Function;
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import com.google.common.collect.ImmutableMap.Builder;
/*     */ import com.rwtema.extrautils2.utils.datastructures.FunctionABBool;
/*     */ import gnu.trove.list.array.TCharArrayList;
/*     */ import gnu.trove.strategy.HashingStrategy;
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ 
/*     */ public class CollectionHelper
/*     */ {
/*     */   public static final char[] CHAR_DIGITS;
/*     */   public static final String[] STRING_DIGITS;
/*  21 */   public static HashingStrategy<ItemStack> HASHING_STRATEGY_ITEMSTACK_ITEM = new HashingStrategy()
/*     */   {
/*     */     public int computeHashCode(ItemStack object) {
/*  24 */       if ((object == null) || (object.getItem() == null)) return 0;
/*  25 */       return object.getItem().hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(ItemStack o1, ItemStack o2)
/*     */     {
/*  30 */       return (o1 == o2) || ((o1 != null) && (o2 != null) && (o1.getItem() == o2.getItem()));
/*     */     }
/*     */   };
/*  33 */   public static HashingStrategy<ItemStack> HASHING_STRATEGY_ITEMSTACK = new HashingStrategy()
/*     */   {
/*     */     public int computeHashCode(ItemStack object) {
/*  36 */       if ((object == null) || (object.getItem() == null)) return 0;
/*  37 */       return object.getItem().hashCode() * 31 + object.getItemDamage();
/*     */     }
/*     */     
/*     */     public boolean equals(ItemStack o1, ItemStack o2)
/*     */     {
/*  42 */       return (o1 == o2) || ((o1 != null) && (o2 != null) && (o1.getItem() == o2.getItem()) && (o1.getItemDamage() == o2.getItemDamage()));
/*     */     }
/*     */   };
/*     */   
/*     */   static {
/*  47 */     TCharArrayList chars = new TCharArrayList(62);
/*  48 */     for (int i = 0; i < 10; i++) {
/*  49 */       chars.add((char)(48 + i));
/*     */     }
/*     */     
/*  52 */     for (int i = 0; i < 26; i++) {
/*  53 */       chars.add((char)(97 + i));
/*     */     }
/*     */     
/*  56 */     for (int i = 0; i < 26; i++) {
/*  57 */       chars.add((char)(65 + i));
/*     */     }
/*     */     
/*  60 */     chars.addAll(new char[] { '_', '-', '=', '+', '%', '@', '!', '?', '*', '^', '$', '&', '#', '~', ':', ';' });
/*     */     
/*  62 */     CHAR_DIGITS = chars.toArray();
/*  63 */     STRING_DIGITS = new String[CHAR_DIGITS.length];
/*  64 */     for (int i = 0; i < STRING_DIGITS.length; i++) {
/*  65 */       STRING_DIGITS[i] = String.valueOf(CHAR_DIGITS[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static <K, V> HashMap<K, V> newHashMap(Object... objects)
/*     */   {
/*  71 */     HashMap<K, V> map = new HashMap();
/*  72 */     for (int i = 0; i < objects.length; i += 2) {
/*  73 */       map.put(objects[i], objects[(i + 1)]);
/*     */     }
/*     */     
/*  76 */     return map;
/*     */   }
/*     */   
/*     */   public static <K, V> ImmutableMap<K, V> newConstMap(Object... objects)
/*     */   {
/*  81 */     ImmutableMap.Builder<K, V> builder = ImmutableMap.builder();
/*  82 */     for (int i = 0; i < objects.length; i += 2) {
/*  83 */       builder.put(objects[i], objects[(i + 1)]);
/*     */     }
/*     */     
/*  86 */     return builder.build();
/*     */   }
/*     */   
/*     */   public static <T> Iterable<T> removeNulls(Iterable<T> iterable) {
/*  90 */     new Iterable()
/*     */     {
/*     */       public Iterator<T> iterator() {
/*  93 */         new Iterator() {
/*  94 */           Iterator<T> iterator = CollectionHelper.3.this.val$iterable.iterator();
/*     */           
/*     */           T next;
/*     */           
/*     */           public boolean hasNext()
/*     */           {
/* 100 */             while (this.next == null) {
/* 101 */               if (!this.iterator.hasNext()) return false;
/* 102 */               this.next = this.iterator.next();
/*     */             }
/* 104 */             return true;
/*     */           }
/*     */           
/*     */           public T next()
/*     */           {
/* 109 */             return (T)this.next;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */           public void remove() {}
/*     */         };
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static <K, V, T extends Map<K, V>> T populateMap(T map, Object... objects)
/*     */   {
/* 124 */     for (int i = 0; i < objects.length; i += 2) {
/* 125 */       map.put(objects[i], objects[(i + 1)]);
/*     */     }
/* 127 */     return map;
/*     */   }
/*     */   
/*     */   public static <K extends Enum<K>, V> EnumMap<K, V> populateEnumMap(Class<K> clazz, Function<K, V> function)
/*     */   {
/* 132 */     EnumMap<K, V> map = new EnumMap(clazz);
/* 133 */     for (K k : (Enum[])clazz.getEnumConstants()) {
/* 134 */       map.put(k, function.apply(k));
/*     */     }
/* 136 */     return map;
/*     */   }
/*     */   
/*     */   public static <K extends Enum<K>> EnumMap<K, EnumSet<K>> populateEnumMultiMap(Class<K> clazz, FunctionABBool<K, K> function) {
/* 140 */     EnumMap<K, EnumSet<K>> map = new EnumMap(clazz);
/* 141 */     for (K input : (Enum[])clazz.getEnumConstants()) {
/* 142 */       EnumSet<K> set = EnumSet.noneOf(clazz);
/* 143 */       for (K k2 : (Enum[])clazz.getEnumConstants()) {
/* 144 */         if (function.apply(input, k2)) {
/* 145 */           set.add(k2);
/*     */         }
/*     */       }
/* 148 */       map.put(input, set);
/*     */     }
/* 150 */     return map;
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\CollectionHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */