/*    */ package com.rwtema.extrautils2.utils.helpers;
/*    */ 
/*    */ import net.minecraft.util.MathHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LightMathHelper
/*    */ {
/*  9 */   static float[] APPROX_SQRT = new float['က'];
/* 10 */   static { for (int i = 0; i < APPROX_SQRT.length; i++) {
/* 11 */       APPROX_SQRT[i] = MathHelper.sqrt_float(i / 4096.0F);
/*    */     }
/*    */   }
/*    */   
/*    */   public static float approxSqrt(float v, float r) {
/* 16 */     if (v <= 0.0F) return 0.0F;
/* 17 */     if (v >= r) return 1.0F;
/* 18 */     return APPROX_SQRT[((int)(v / r * 4096.0F) & 0xFFF)];
/*    */   }
/*    */   
/*    */   public static float[] norm(float a, float b, float c) {
/* 22 */     float a2 = a * a;
/* 23 */     float b2 = b * b;
/* 24 */     float c2 = c * c;
/* 25 */     float r = a2 + b2 + c2;
/* 26 */     return new float[] { approxSqrt(a2, r) * Math.signum(a), approxSqrt(b2, r) * Math.signum(b), approxSqrt(c2, r) * Math.signum(c) };
/*    */   }
/*    */   
/*    */   public static float partialDist(float x, float y, float z, float r) {
/* 30 */     return approxSqrt(x * x + y * y + z * z, r * r);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\LightMathHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */