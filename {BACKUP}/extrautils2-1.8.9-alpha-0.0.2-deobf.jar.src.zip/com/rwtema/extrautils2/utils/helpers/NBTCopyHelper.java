/*     */ package com.rwtema.extrautils2.utils.helpers;
/*     */ 
/*     */ import java.util.Set;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ 
/*     */ public class NBTCopyHelper
/*     */ {
/*     */   public static boolean isMutable(int type)
/*     */   {
/*  12 */     return (type == 7) || (type == 9) || (type == 10) || (type == 11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResultNBT copyAndHashNBT(NBTTagCompound tag)
/*     */   {
/*  20 */     int hash = 10;
/*  21 */     NBTTagCompound copy = new NBTTagCompound();
/*  22 */     for (String s : tag.getKeySet()) {
/*  23 */       Result result = copyAndHash(tag.getTag(s));
/*  24 */       hash += (s.hashCode() ^ result.hash);
/*  25 */       copy.setTag(s, result.base);
/*     */     }
/*     */     
/*  28 */     return new ResultNBT(copy, hash);
/*     */   }
/*     */   
/*     */   public static Result copyAndHash(NBTBase base) {
/*  32 */     if (base.getId() == 10) {
/*  33 */       int hash = 10;
/*  34 */       NBTTagCompound copy = new NBTTagCompound();
/*  35 */       for (String s : ((NBTTagCompound)base).getKeySet()) {
/*  36 */         byte tagType = base.getId();
/*  37 */         if ((tagType == 10) || (tagType == 9)) {
/*  38 */           Result result = copyAndHash(((NBTTagCompound)base).getTag(s));
/*  39 */           hash += (s.hashCode() ^ result.hash);
/*  40 */           copy.setTag(s, result.base);
/*     */         } else {
/*  42 */           hash += (s.hashCode() ^ base.hashCode());
/*  43 */           if (isMutable(base.getId())) {
/*  44 */             copy.setTag(s, base.copy());
/*     */           } else {
/*  46 */             copy.setTag(s, base);
/*     */           }
/*     */         }
/*     */       }
/*  50 */       return new Result(copy, hash); }
/*  51 */     if (base.getId() == 9) {
/*  52 */       NBTTagList list = (NBTTagList)base;
/*  53 */       int tagType = list.getTagType();
/*  54 */       if (tagType == 0)
/*  55 */         return new Result(list.copy(), list.hashCode());
/*  56 */       if ((tagType == 10) || (tagType == 9)) {
/*  57 */         NBTTagList copy = new NBTTagList();
/*  58 */         int hash = 1;
/*  59 */         for (int i = 0; i < list.tagCount(); i++) {
/*  60 */           Result result = copyAndHash(list.get(i));
/*  61 */           hash = hash * 31 + result.hash;
/*  62 */           copy.appendTag(result.base);
/*     */         }
/*  64 */         return new Result(copy, hash);
/*     */       }
/*  66 */       NBTTagList copy = new NBTTagList();
/*  67 */       int hash = 1;
/*  68 */       for (int i = 0; i < list.tagCount(); i++) {
/*  69 */         NBTBase nbtBase = list.get(i);
/*  70 */         hash = hash * 31 + nbtBase.hashCode();
/*  71 */         if (isMutable(tagType)) {
/*  72 */           copy.appendTag(nbtBase.copy());
/*     */         } else
/*  74 */           copy.appendTag(nbtBase);
/*     */       }
/*  76 */       return new Result(copy, hash);
/*     */     }
/*     */     
/*     */ 
/*  80 */     if (isMutable(base.getId())) {
/*  81 */       return new Result(base.copy(), base.hashCode());
/*     */     }
/*  83 */     return new Result(base, base.hashCode());
/*     */   }
/*     */   
/*     */   public static boolean equal(NBTBase a, NBTBase b)
/*     */   {
/*  88 */     if (a == b) return true;
/*  89 */     if ((a == null) || (b == null)) return false;
/*  90 */     byte id = a.getId();
/*  91 */     if (id != b.getId()) return false;
/*  92 */     if (id == 10)
/*  93 */       return equalNBT((NBTTagCompound)a, (NBTTagCompound)b);
/*  94 */     if (id == 9) {
/*  95 */       return equalTagList((NBTTagList)a, (NBTTagList)b);
/*     */     }
/*  97 */     return a.equals(b);
/*     */   }
/*     */   
/*     */   public static boolean equalTagList(NBTTagList a, NBTTagList b)
/*     */   {
/* 102 */     if (a == b) return true;
/* 103 */     if ((a == null) || (b == null)) return false;
/* 104 */     int tagCount = a.tagCount();
/* 105 */     if (tagCount != b.tagCount()) return false;
/* 106 */     if (a.getTagType() != b.getTagType()) return false;
/* 107 */     for (int i = 0; i < tagCount; i++) {
/* 108 */       if (!equal(a.get(i), b.get(i))) return false;
/*     */     }
/* 110 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean equalNBT(NBTTagCompound a, NBTTagCompound b) {
/* 114 */     if (a == b) return true;
/* 115 */     if ((a == null) || (b == null)) { return false;
/*     */     }
/* 117 */     Set<String> aKeys = a.getKeySet();
/* 118 */     Set<String> bKeys = b.getKeySet();
/* 119 */     if (aKeys.size() != bKeys.size()) { return false;
/*     */     }
/* 121 */     for (String aKey : aKeys) {
/* 122 */       if (!equal(a.getTag(aKey), b.getTag(aKey))) return false;
/*     */     }
/* 124 */     return true;
/*     */   }
/*     */   
/*     */   public static class ResultNBT {
/*     */     public final NBTTagCompound copy;
/*     */     public final int hash;
/*     */     
/*     */     public ResultNBT(NBTTagCompound copy, int hash) {
/* 132 */       this.copy = copy;
/* 133 */       this.hash = hash;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Result {
/*     */     public final NBTBase base;
/*     */     public final int hash;
/*     */     
/*     */     public Result(NBTBase base, int hash) {
/* 142 */       this.base = base;
/* 143 */       this.hash = hash;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\helpers\NBTCopyHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */