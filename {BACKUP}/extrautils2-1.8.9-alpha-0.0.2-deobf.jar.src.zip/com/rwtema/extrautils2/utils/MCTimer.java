/*    */ package com.rwtema.extrautils2.utils;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class MCTimer
/*    */ {
/*    */   public static int clientTimer;
/*    */   public static float renderTimer;
/*    */   public static float renderPartialTickTime;
/*    */   public static int serverTimer;
/*    */   
/*    */   static
/*    */   {
/* 16 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new MCTimer());
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void serverTick(net.minecraftforge.fml.common.gameevent.TickEvent.ServerTickEvent event) {
/* 22 */     if (event.phase == net.minecraftforge.fml.common.gameevent.TickEvent.Phase.START) serverTimer += 1;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void clientTick(TickEvent.ClientTickEvent event) {
/* 28 */     if (event.phase == net.minecraftforge.fml.common.gameevent.TickEvent.Phase.START) clientTimer += 1;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public void renderTick(net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent event) {
/* 34 */     renderPartialTickTime = event.renderTickTime;
/* 35 */     renderTimer = clientTimer + renderPartialTickTime;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\utils\MCTimer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */