/*    */ package com.rwtema.extrautils2.banner;
/*    */ 
/*    */ import com.google.common.collect.Sets;
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import com.rwtema.extrautils2.XUProxy;
/*    */ import com.rwtema.extrautils2.backend.RedirectResourcePack;
/*    */ import com.rwtema.extrautils2.backend.entries.BlockEntry;
/*    */ import net.minecraft.tileentity.TileEntityBanner.EnumBannerPattern;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class Banner
/*    */ {
/*    */   public static void init()
/*    */   {
/* 16 */     ExtraUtils2.proxy.run(new com.rwtema.extrautils2.backend.ClientCallable()
/*    */     {
/*    */       @SideOnly(Side.CLIENT)
/*    */       public void runClient() {
/* 20 */         new RedirectResourcePack("Banner", Sets.newHashSet(new String[] { "minecraft" }), "textures/entity/banner/").register();
/*    */       }
/*    */       
/* 23 */     });
/* 24 */     Class<?>[] paramClasses = { String.class, String.class, net.minecraft.item.ItemStack.class };
/* 25 */     Object[] paramValues = { "angel", "ang", com.rwtema.extrautils2.backend.entries.XU2Entries.angelBlock.newStack() };
/* 26 */     net.minecraftforge.common.util.EnumHelper.addEnum(TileEntityBanner.EnumBannerPattern.class, "ANGEL", paramClasses, paramValues);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\banner\Banner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */