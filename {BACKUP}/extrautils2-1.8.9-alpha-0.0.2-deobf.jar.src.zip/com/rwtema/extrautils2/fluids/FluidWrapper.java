/*    */ package com.rwtema.extrautils2.fluids;
/*    */ 
/*    */ import net.minecraftforge.fluids.FluidStack;
/*    */ import net.minecraftforge.fluids.IFluidHandler;
/*    */ 
/*    */ public class FluidWrapper implements IFluidInterface
/*    */ {
/*    */   final IFluidHandler handler;
/*    */   final net.minecraft.util.EnumFacing side;
/*    */   
/*    */   public FluidWrapper(IFluidHandler handler, net.minecraft.util.EnumFacing side)
/*    */   {
/* 13 */     this.handler = handler;
/* 14 */     this.side = side;
/*    */   }
/*    */   
/*    */ 
/*    */   public int fill(FluidStack resource, boolean doFill)
/*    */   {
/* 20 */     return this.handler.fill(this.side, resource, doFill);
/*    */   }
/*    */   
/*    */   public FluidStack drain(FluidStack resource, boolean doDrain)
/*    */   {
/* 25 */     return this.handler.drain(this.side, resource, doDrain);
/*    */   }
/*    */   
/*    */   public FluidStack drain(int maxDrain, boolean doDrain)
/*    */   {
/* 30 */     return this.handler.drain(this.side, maxDrain, doDrain);
/*    */   }
/*    */   
/*    */   public net.minecraftforge.fluids.FluidTankInfo[] getTankInfo()
/*    */   {
/* 35 */     return this.handler.getTankInfo(this.side);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\fluids\FluidWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */