/*    */ package com.rwtema.extrautils2.fluids;
/*    */ 
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraftforge.fluids.Fluid;
/*    */ import net.minecraftforge.fluids.FluidStack;
/*    */ import net.minecraftforge.fluids.FluidTank;
/*    */ import net.minecraftforge.fluids.FluidTankInfo;
/*    */ 
/*    */ public class FluidTankSerial extends FluidTank implements net.minecraftforge.common.util.INBTSerializable<NBTTagCompound>, IFluidInterface
/*    */ {
/*    */   public FluidTankSerial(int capacity)
/*    */   {
/* 13 */     super(capacity);
/*    */   }
/*    */   
/*    */   public FluidTankSerial(FluidStack stack, int capacity) {
/* 17 */     super(stack, capacity);
/*    */   }
/*    */   
/*    */   public FluidTankSerial(Fluid fluid, int amount, int capacity) {
/* 21 */     super(fluid, amount, capacity);
/*    */   }
/*    */   
/*    */   public NBTTagCompound serializeNBT()
/*    */   {
/* 26 */     NBTTagCompound nbt = new NBTTagCompound();
/* 27 */     writeToNBT(nbt);
/* 28 */     return nbt;
/*    */   }
/*    */   
/*    */   public void deserializeNBT(NBTTagCompound nbt)
/*    */   {
/* 33 */     readFromNBT(nbt);
/*    */   }
/*    */   
/*    */ 
/*    */   public FluidStack drain(FluidStack resource, boolean doDrain)
/*    */   {
/* 39 */     if ((resource == null) || (!resource.isFluidEqual(getFluid())))
/*    */     {
/* 41 */       return null;
/*    */     }
/* 43 */     return drain(resource.amount, doDrain);
/*    */   }
/*    */   
/*    */ 
/*    */   public FluidTankInfo[] getTankInfo()
/*    */   {
/* 49 */     return new FluidTankInfo[] { getInfo() };
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 53 */     return (this.fluid == null) || (this.fluid.amount == 0);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\fluids\FluidTankSerial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */