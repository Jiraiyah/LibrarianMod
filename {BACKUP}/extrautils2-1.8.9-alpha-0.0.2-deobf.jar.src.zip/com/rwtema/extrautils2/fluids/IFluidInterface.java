package com.rwtema.extrautils2.fluids;

import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidTankInfo;

public abstract interface IFluidInterface
{
  public abstract int fill(FluidStack paramFluidStack, boolean paramBoolean);
  
  public abstract FluidStack drain(FluidStack paramFluidStack, boolean paramBoolean);
  
  public abstract FluidStack drain(int paramInt, boolean paramBoolean);
  
  public abstract FluidTankInfo[] getTankInfo();
}


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\fluids\IFluidInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */