/*    */ package com.rwtema.extrautils2.particles;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.helpers.ColorHelper;
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.util.Vec3;
/*    */ 
/*    */ public class ParticleLightning extends EntityFX
/*    */ {
/*    */   private static float rotX;
/*    */   private static float rotXZ;
/*    */   private static float rotZ;
/*    */   private static float rotYZ;
/*    */   private static float rotXY;
/*    */   
/*    */   public ParticleLightning(net.minecraft.world.World worldIn, Vec3 start, Vec3 end, int color)
/*    */   {
/* 19 */     super(worldIn, start.xCoord, start.yCoord, start.zCoord, 0.0D, 0.0D, 0.0D);
/* 20 */     this.motionX = 0.0D;
/* 21 */     this.motionY = 0.0D;
/* 22 */     this.motionZ = 0.0D;
/* 23 */     this.noClip = true;
/*    */     
/* 25 */     this.particleRed = (ColorHelper.getR(color) / 255.0F);
/* 26 */     this.particleGreen = (ColorHelper.getG(color) / 255.0F);
/* 27 */     this.particleBlue = (ColorHelper.getB(color) / 255.0F);
/*    */   }
/*    */   
/*    */   public void onUpdate()
/*    */   {
/* 32 */     if (this.particleAge++ >= this.particleMaxAge)
/* 33 */       setDead();
/*    */   }
/*    */   
/*    */   public int getBrightnessForRender(float partialTicks) {
/* 37 */     float f = (this.particleAge + partialTicks) / this.particleMaxAge;
/* 38 */     f = net.minecraft.util.MathHelper.clamp_float(f, 0.0F, 1.0F);
/* 39 */     int i = super.getBrightnessForRender(partialTicks);
/* 40 */     int j = 240;
/* 41 */     int k = i >> 16 & 0xFF;
/* 42 */     return j | k << 16;
/*    */   }
/*    */   
/*    */ 
/*    */   public void renderParticle(WorldRenderer worldRendererIn, net.minecraft.entity.Entity entityIn, float partialTicks, float rotX, float rotXZ, float rotZ, float rotYZ, float rotXY)
/*    */   {
/* 48 */     rotX = rotX;
/* 49 */     rotXZ = rotXZ;
/* 50 */     rotZ = rotZ;
/* 51 */     rotYZ = rotYZ;
/* 52 */     rotXY = rotXY;
/* 53 */     float u0 = this.particleTextureIndexX / 16.0F;
/* 54 */     float u1 = u0 + 0.0624375F;
/* 55 */     float v0 = this.particleTextureIndexY / 16.0F;
/* 56 */     float v1 = v0 + 0.0624375F;
/* 57 */     float s = 0.1F * this.particleScale;
/*    */     
/* 59 */     if (this.field_70550_a != null) {
/* 60 */       u0 = this.field_70550_a.getMinU();
/* 61 */       u1 = this.field_70550_a.getMaxU();
/* 62 */       v0 = this.field_70550_a.getMinV();
/* 63 */       v1 = this.field_70550_a.getMaxV();
/*    */     }
/*    */     
/* 66 */     float x = (float)(this.prevPosX + (this.posX - this.prevPosX) * partialTicks - interpPosX);
/* 67 */     float y = (float)(this.prevPosY + (this.posY - this.prevPosY) * partialTicks - interpPosY);
/* 68 */     float z = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * partialTicks - interpPosZ);
/* 69 */     int i = getBrightnessForRender(partialTicks);
/* 70 */     int j = i >> 16 & 0xFFFF;
/* 71 */     int k = i & 0xFFFF;
/* 72 */     addColor(addPoint(worldRendererIn, x, y, z, -s, -s)).func_181673_a(u1, v1).func_181671_a(j, k).endVertex();
/* 73 */     addColor(addPoint(worldRendererIn, x, y, z, -s, s)).func_181673_a(u1, v0).func_181671_a(j, k).endVertex();
/* 74 */     addColor(addPoint(worldRendererIn, x, y, z, s, s)).func_181673_a(u0, v0).func_181671_a(j, k).endVertex();
/* 75 */     addColor(addPoint(worldRendererIn, x, y, z, s, -s)).func_181673_a(u0, v1).func_181671_a(j, k).endVertex();
/*    */   }
/*    */   
/*    */   public WorldRenderer addColor(WorldRenderer worldRenderer) {
/* 79 */     return worldRenderer.color(this.particleRed, this.particleGreen, this.particleBlue, this.particleAlpha);
/*    */   }
/*    */   
/*    */   public WorldRenderer addPoint(WorldRenderer worldRenderer, float x, float y, float z, float dx, float dy) {
/* 83 */     return worldRenderer.pos(x + rotX * dx + rotYZ * dy, y + rotXZ * dy, z - rotZ * dx + rotXY * dy);
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\particles\ParticleLightning.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */