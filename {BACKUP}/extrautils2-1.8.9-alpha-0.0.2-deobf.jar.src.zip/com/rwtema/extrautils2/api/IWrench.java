/*    */ package com.rwtema.extrautils2.api;
/*    */ 
/*    */ import net.minecraft.nbt.NBTBase;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraftforge.common.capabilities.Capability;
/*    */ import net.minecraftforge.common.capabilities.CapabilityInject;
/*    */ import net.minecraftforge.common.capabilities.CapabilityManager;
/*    */ import net.minecraftforge.items.IItemHandler;
/*    */ 
/*    */ public abstract interface IWrench
/*    */ {
/*    */   @CapabilityInject(IWrench.class)
/* 13 */   public static final Capability<IWrench> CAPABILITY = null;
/*    */   
/*    */   public static class InitClass {
/*    */     @CapabilityInject(IItemHandler.class)
/*    */     public static void initializeMe(Capability capability) {
/* 18 */       CapabilityManager.INSTANCE.register(IWrench.class, new net.minecraftforge.common.capabilities.Capability.IStorage()
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 26 */         new java.util.concurrent.Callable
/*    */         {
/*    */           public NBTBase writeNBT(Capability<IWrench> capability, IWrench instance, EnumFacing side) {
/* 21 */             throw new UnsupportedOperationException();
/*    */           }
/*    */           
/*    */ 
/*    */ 
/* 26 */           public void readNBT(Capability<IWrench> capability, IWrench instance, EnumFacing side, NBTBase nbt) { throw new UnsupportedOperationException(); } }, new java.util.concurrent.Callable()
/*    */         {
/*    */           public IWrench call()
/*    */             throws Exception
/*    */           {
/* 31 */             new IWrench() {};
/*    */           }
/*    */         });
/*    */       }
/*    */     }
/*    */   }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\api\IWrench.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */