/*     */ package com.rwtema.extrautils2.book;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonDeserializer;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.rwtema.extrautils2.backend.entries.Entry;
/*     */ import com.rwtema.extrautils2.backend.entries.EntryHandler;
/*     */ import com.rwtema.extrautils2.utils.LogHelper;
/*     */ import gnu.trove.map.hash.TIntObjectHashMap;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.resources.IResource;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class BookHandler
/*     */ {
/*     */   public static final Book book;
/*     */   
/*     */   static
/*     */   {
/*  39 */     Gson DES = new GsonBuilder().registerTypeAdapter(Entry.class, new EntryDeserializer()).create();
/*     */     
/*     */ 
/*     */     Book b;
/*     */     
/*     */     try
/*     */     {
/*  46 */       IResource resource = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("extrautils2", "lang/book/en_US.json"));
/*  47 */       InputStreamReader reader = new InputStreamReader(resource.getInputStream());
/*  48 */       b = (Book)DES.fromJson(reader, Book.class);
/*     */     }
/*     */     catch (IOException e) {
/*  51 */       b = null;
/*     */     }
/*  53 */     book = b;
/*     */     
/*  55 */     if ((com.rwtema.extrautils2.ExtraUtils2.deobf_folder) && (book != null)) {
/*  56 */       HashSet<Entry> entries = com.google.common.collect.Sets.newHashSet(EntryHandler.entries);
/*  57 */       for (BookHandler.Book.Page page : book.pages) {
/*  58 */         entries.remove(page.entry);
/*     */       }
/*  60 */       for (Entry entry : entries) {
/*  61 */         LogHelper.info("Missing Book Data: " + entry.name, new Object[0]);
/*     */       }
/*  63 */       LogHelper.info("Missing Book Count: ", new Object[] { Integer.valueOf(entries.size()) });
/*     */     }
/*     */   }
/*     */   
/*     */   public static ItemStack newStack() {
/*  68 */     if (book == null) return null;
/*  69 */     NBTTagCompound tags = new NBTTagCompound();
/*     */     
/*  71 */     List<NBTTagString> pages = new ArrayList();
/*  72 */     FontRenderer fontRendererObj = Minecraft.getMinecraft().fontRendererObj;
/*  73 */     TIntObjectHashMap<String> contents = new TIntObjectHashMap();
/*     */     
/*  75 */     for (BookHandler.Book.Page page : book.pages)
/*     */     {
/*  77 */       StringBuilder builder = new StringBuilder();
/*  78 */       String title = null;
/*  79 */       if (page.entry != null) {
/*  80 */         ItemStack itemStack = page.entry.newStack(1, page.meta);
/*  81 */         if (itemStack != null) { title = itemStack.getDisplayName();
/*     */         } else
/*  83 */           title = page.entry.name;
/*     */       }
/*  85 */       if (page.title != null) {
/*  86 */         title = page.title;
/*     */       }
/*     */       
/*  89 */       if (title != null) {
/*  90 */         contents.put(pages.size(), title);
/*  91 */         builder.append(EnumChatFormatting.UNDERLINE).append(title).append(EnumChatFormatting.RESET).append("\n\n");
/*     */       }
/*     */       
/*  94 */       builder.append(page.text);
/*  95 */       String string = builder.toString();
/*     */       
/*  97 */       List<String> strings = fontRendererObj.listFormattedStringToWidth(string, 116);
/*  98 */       StringBuilder builder1 = new StringBuilder();
/*  99 */       int k = 0;
/* 100 */       for (String s : strings) {
/* 101 */         builder1.append(s).append('\n');
/* 102 */         k++;
/* 103 */         if (k >= 13) {
/* 104 */           pages.add(new NBTTagString(builder1.toString()));
/* 105 */           builder1 = new StringBuilder();
/* 106 */           k = 0;
/*     */         }
/*     */       }
/* 109 */       if (k != 0) {
/* 110 */         pages.add(new NBTTagString(builder1.toString()));
/*     */       }
/*     */     }
/* 113 */     NBTTagList pageList = new NBTTagList();
/* 114 */     pageList.appendTag(new NBTTagString("Extra Utilities 2\nManual\n(temp GUI stand in)"));
/*     */     
/* 116 */     int offset = 3 + contents.size() / 13;
/*     */     
/* 118 */     int[] keys = contents.keys();
/* 119 */     Arrays.sort(keys);
/* 120 */     StringBuilder builder = new StringBuilder("Table of Contents\n\n");
/* 121 */     int k = 2;
/* 122 */     for (int key : keys) {
/* 123 */       String line = (String)contents.get(key);
/* 124 */       int a = key + offset;
/* 125 */       while (fontRendererObj.listFormattedStringToWidth(line + " " + a, 116).size() > 1) {
/* 126 */         line = line.substring(0, line.length() - 1);
/*     */       }
/*     */       
/* 129 */       line = line + " ";
/*     */       
/* 131 */       while (fontRendererObj.listFormattedStringToWidth(line + " " + a, 116).size() == 1) {
/* 132 */         line = line + " ";
/*     */       }
/*     */       
/* 135 */       line = line + a;
/* 136 */       builder.append(line).append('\n');
/* 137 */       k++;
/* 138 */       if (k >= 13) {
/* 139 */         k = 0;
/* 140 */         pageList.appendTag(new NBTTagString(builder.toString()));
/* 141 */         builder = new StringBuilder();
/*     */       }
/*     */     }
/*     */     
/* 145 */     if (k != 0) {
/* 146 */       pageList.appendTag(new NBTTagString(builder.toString()));
/*     */     }
/* 148 */     for (NBTTagString page : pages) {
/* 149 */       pageList.appendTag(page);
/*     */     }
/*     */     
/* 152 */     tags.setTag("pages", pageList);
/* 153 */     tags.setString("title", book.title);
/* 154 */     tags.setString("author", "RWTema");
/*     */     
/* 156 */     ItemStack stack = new ItemStack(Items.written_book);
/* 157 */     stack.setTagCompound(tags);
/* 158 */     return stack;
/*     */   }
/*     */   
/*     */   public static class Book {
/*     */     public String id;
/*     */     public String title;
/*     */     public List<Page> pages;
/*     */     
/*     */     public static class Page {
/*     */       String title;
/*     */       @Nullable
/*     */       Entry entry;
/*     */       String text;
/* 171 */       int meta = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class EntryDeserializer implements JsonDeserializer<Entry>
/*     */   {
/*     */     public Entry deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws com.google.gson.JsonParseException
/*     */     {
/* 179 */       String asString = json.getAsString().toLowerCase();
/* 180 */       Entry entry = (Entry)EntryHandler.entryHashMap.get(asString);
/* 181 */       if (entry != null) {
/* 182 */         return entry;
/*     */       }
/* 184 */       for (Map.Entry<String, Entry> e : EntryHandler.entryHashMap.entrySet()) {
/* 185 */         String key = ((String)e.getKey()).toLowerCase();
/* 186 */         if ((key.contains(asString)) || (asString.contains(key))) {
/* 187 */           return (Entry)e.getValue();
/*     */         }
/*     */       }
/*     */       
/* 191 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\book\BookHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */