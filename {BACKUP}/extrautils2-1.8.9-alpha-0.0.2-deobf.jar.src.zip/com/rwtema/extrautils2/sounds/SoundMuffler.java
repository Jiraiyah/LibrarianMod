/*    */ package com.rwtema.extrautils2.sounds;
/*    */ 
/*    */ import net.minecraft.client.audio.ISound;
/*    */ 
/*    */ public class SoundMuffler implements ISound
/*    */ {
/*    */   final ISound original;
/*    */   final float volModifier;
/*    */   
/*    */   public SoundMuffler(ISound original, float volModifier) {
/* 11 */     this.original = original;
/* 12 */     this.volModifier = volModifier;
/*    */   }
/*    */   
/*    */   public net.minecraft.util.ResourceLocation getSoundLocation()
/*    */   {
/* 17 */     return this.original.getSoundLocation();
/*    */   }
/*    */   
/*    */   public boolean canRepeat()
/*    */   {
/* 22 */     return this.original.canRepeat();
/*    */   }
/*    */   
/*    */   public int getRepeatDelay()
/*    */   {
/* 27 */     return this.original.getRepeatDelay();
/*    */   }
/*    */   
/*    */   public float getVolume()
/*    */   {
/* 32 */     return this.original.getVolume() * this.volModifier;
/*    */   }
/*    */   
/*    */   public float getPitch()
/*    */   {
/* 37 */     return this.original.getPitch();
/*    */   }
/*    */   
/*    */   public float getXPosF()
/*    */   {
/* 42 */     return this.original.getXPosF();
/*    */   }
/*    */   
/*    */   public float getYPosF()
/*    */   {
/* 47 */     return this.original.getYPosF();
/*    */   }
/*    */   
/*    */   public float getZPosF()
/*    */   {
/* 52 */     return this.original.getZPosF();
/*    */   }
/*    */   
/*    */   public net.minecraft.client.audio.ISound.AttenuationType getAttenuationType()
/*    */   {
/* 57 */     return this.original.getAttenuationType();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\sounds\SoundMuffler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */