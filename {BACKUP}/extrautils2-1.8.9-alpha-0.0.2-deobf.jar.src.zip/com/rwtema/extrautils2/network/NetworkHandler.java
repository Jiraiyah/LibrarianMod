/*     */ package com.rwtema.extrautils2.network;
/*     */ 
/*     */ import com.google.common.base.Throwables;
/*     */ import com.rwtema.extrautils2.utils.LogHelper;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.util.Attribute;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Map.Entry;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.world.ChunkCoordIntPair;
/*     */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*     */ import net.minecraftforge.fml.common.discovery.ASMDataTable;
/*     */ import net.minecraftforge.fml.common.discovery.ASMDataTable.ASMData;
/*     */ import net.minecraftforge.fml.common.network.FMLEmbeddedChannel;
/*     */ import net.minecraftforge.fml.common.network.FMLOutboundHandler;
/*     */ import net.minecraftforge.fml.common.network.FMLOutboundHandler.OutboundTarget;
/*     */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*     */ import net.minecraftforge.fml.common.network.NetworkRegistry.TargetPoint;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class NetworkHandler
/*     */ {
/*     */   public static EnumMap<Side, FMLEmbeddedChannel> channels;
/*     */   
/*     */   static
/*     */   {
/*  31 */     LogHelper.oneTimeInfo("Network Handler Static Init");
/*     */   }
/*     */   
/*     */   public static void init(ASMDataTable asmData) {
/*  35 */     for (ASMDataTable.ASMData data : asmData.getAll(XUPacket.class.getName())) {
/*  36 */       registerPacket(data.getClassName());
/*     */     }
/*     */     
/*  39 */     channels = NetworkRegistry.INSTANCE.newChannel("XU2", new io.netty.channel.ChannelHandler[] { new PacketCodec(), com.rwtema.extrautils2.ExtraUtils2.proxy.getNewPacketHandler() });
/*     */     
/*  41 */     LogHelper.oneTimeInfo("Network Init");
/*  42 */     LogHelper.oneTimeInfo("Start " + channels);
/*  43 */     for (Map.Entry<Side, FMLEmbeddedChannel> entry : channels.entrySet()) {
/*  44 */       FMLEmbeddedChannel value = (FMLEmbeddedChannel)entry.getValue();
/*  45 */       if (value != null) {
/*  46 */         Side side = (Side)entry.getKey();
/*  47 */         LogHelper.oneTimeInfo("Start Side:  " + side + " ");
/*  48 */         Map.Entry[] array = (Map.Entry[])com.google.common.collect.Iterables.toArray(value.pipeline(), Map.Entry.class);
/*  49 */         int i = 0; for (int arrayLength = array.length; i < arrayLength; i++) {
/*  50 */           Map.Entry handlerEntry = array[i];
/*  51 */           LogHelper.oneTimeInfo("Start Channel Handler: (" + side + ")(" + i + ") " + handlerEntry.getKey() + " - " + handlerEntry.getValue());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void checkPacket(XUPacketBase packet, Side properSenderSide) {
/*  58 */     LogHelper.oneTimeInfo("Check Packet " + properSenderSide);
/*  59 */     if (!packet.isValidSenderSide(properSenderSide))
/*  60 */       throw new RuntimeException("Sending packet class" + packet.getClass().getSimpleName() + " from wrong side");
/*     */   }
/*     */   
/*     */   public static void sendToAllPlayers(XUPacketBase packet) {
/*  64 */     checkPacket(packet, Side.SERVER);
/*  65 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.ALL);
/*  66 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).writeOutbound(new Object[] { packet });
/*     */   }
/*     */   
/*     */   public static void sendPacketToPlayer(XUPacketBase packet, EntityPlayer player)
/*     */   {
/*  71 */     checkPacket(packet, Side.SERVER);
/*  72 */     if (!com.rwtema.extrautils2.utils.helpers.PlayerHelper.isPlayerReal(player)) return;
/*  73 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.PLAYER);
/*  74 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGETARGS).set(player);
/*  75 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).writeOutbound(new Object[] { packet });
/*     */   }
/*     */   
/*     */   public static void sendToAllAround(XUPacketBase packet, int dimension, double x, double y, double z, double range) {
/*  79 */     sendToAllAround(packet, new NetworkRegistry.TargetPoint(dimension, x, y, z, range));
/*     */   }
/*     */   
/*     */   public static void sendToAllAround(XUPacketBase packet, NetworkRegistry.TargetPoint point) {
/*  83 */     checkPacket(packet, Side.SERVER);
/*  84 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.ALLAROUNDPOINT);
/*  85 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGETARGS).set(point);
/*  86 */     ((FMLEmbeddedChannel)channels.get(Side.SERVER)).writeAndFlush(packet).addListener(ChannelFutureListener.FIRE_EXCEPTION_ON_FAILURE);
/*     */   }
/*     */   
/*     */   public static void sendPacketToServer(XUPacketBase packet)
/*     */   {
/*  91 */     checkPacket(packet, Side.CLIENT);
/*  92 */     ((FMLEmbeddedChannel)channels.get(Side.CLIENT)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.TOSERVER);
/*  93 */     ((FMLEmbeddedChannel)channels.get(Side.CLIENT)).writeOutbound(new Object[] { packet });
/*     */   }
/*     */   
/*     */   public static void sendToAllAround(XUPacketBase packet, int chunkX, int chunkZ)
/*     */   {
/*  98 */     ChunkCoordIntPair chunkCoordIntPair = new ChunkCoordIntPair(chunkX, chunkZ);
/*  99 */     for (EntityPlayerMP player : FMLCommonHandler.instance().getMinecraftServerInstance().func_71203_ab().playerEntityList) {
/* 100 */       if (player.field_71129_f.contains(chunkCoordIntPair)) {
/* 101 */         sendPacketToPlayer(packet, player);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void registerPacket(String s) {
/*     */     try {
/* 108 */       Class<?> clazz = Class.forName(s);
/* 109 */       if (XUPacketBase.class.isAssignableFrom(clazz)) {
/* 110 */         LogHelper.oneTimeInfo("Register Packet");
/*     */         try {
/* 112 */           clazz.newInstance();
/*     */         } catch (Throwable throwable) {
/* 114 */           throw Throwables.propagate(throwable);
/*     */         }
/* 116 */         PacketCodec.addClass(clazz);
/*     */       } else {
/* 118 */         throw new RuntimeException("Invalid Class for packet: " + s);
/*     */       }
/* 120 */     } catch (ClassNotFoundException e) { throw new RuntimeException("Presented class (" + s + ") missing, FML Bug?", e);
/*     */     } catch (NoClassDefFoundError e) {
/* 122 */       throw new RuntimeException(s + " can't be created", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void sendCrash(Throwable throwable, EntityPlayer callback) {
/* 127 */     LogHelper.oneTimeInfo("Sending Crash");
/*     */     try {
/* 129 */       StringWriter sw = new StringWriter();
/* 130 */       PrintWriter pw = new PrintWriter(sw);
/* 131 */       throwable.printStackTrace(pw);
/* 132 */       String s = sw.toString();
/* 133 */       sendPacketToPlayer(new PacketCrashLog(s), callback);
/*     */     }
/*     */     catch (Throwable ignore) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @NetworkHandler.XUPacket
/*     */   public static class PacketCrashLog
/*     */     extends XUPacketServerToClient
/*     */   {
/* 145 */     static Logger logger = org.apache.logging.log4j.LogManager.getLogger("ExtraUtils2_Crash");
/*     */     
/*     */     String string;
/*     */     
/*     */     public PacketCrashLog() {}
/*     */     
/*     */     public PacketCrashLog(String string)
/*     */     {
/* 153 */       this.string = string;
/*     */     }
/*     */     
/*     */     public void writeData() throws Exception
/*     */     {
/* 158 */       writeString(this.string);
/*     */     }
/*     */     
/*     */     public void readData(EntityPlayer player)
/*     */     {
/* 163 */       this.string = readString();
/*     */     }
/*     */     
/*     */     @net.minecraftforge.fml.relauncher.SideOnly(Side.CLIENT)
/*     */     public Runnable doStuffClient()
/*     */     {
/* 169 */       logger.info("Server Packet Crash");
/* 170 */       logger.info(this.string);
/* 171 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static @interface XUPacket {}
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\NetworkHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */