/*    */ package com.rwtema.extrautils2.network;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiIngame;
/*    */ import net.minecraft.client.gui.GuiNewChat;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.IChatComponent;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ @NetworkHandler.XUPacket
/*    */ public class SpecialChat extends XUPacketServerToClient
/*    */ {
/*    */   static final int BASE_LINE_ID = -357962104;
/*    */   IChatComponent chat;
/*    */   int id;
/*    */   
/*    */   public SpecialChat() {}
/*    */   
/*    */   public SpecialChat(IChatComponent chat, int id)
/*    */   {
/* 23 */     this.chat = chat;
/* 24 */     this.id = id;
/*    */   }
/*    */   
/*    */   public static void sendChat(EntityPlayer player, IChatComponent chat) {
/* 28 */     sendChat(player, chat, -357962104);
/*    */   }
/*    */   
/*    */   public static void sendChat(EntityPlayer player, IChatComponent chat, final int id) {
/* 32 */     if (player.worldObj.isRemote) {
/* 33 */       ExtraUtils2.proxy.run(new com.rwtema.extrautils2.backend.ClientCallable()
/*    */       {
/*    */         public void runClient() {
/* 36 */           GuiNewChat chatGUI = Minecraft.getMinecraft().ingameGUI.getChatGUI();
/* 37 */           if (this.val$chat == null) {
/* 38 */             chatGUI.deleteChatLine(id);
/*    */           } else {
/* 40 */             chatGUI.printChatMessageWithOptionalDeletion(this.val$chat, id);
/*    */           }
/*    */         }
/*    */       });
/*    */     } else {
/* 45 */       NetworkHandler.sendPacketToPlayer(new SpecialChat(chat, id), player);
/*    */     }
/*    */   }
/*    */   
/*    */   public void writeData() throws Exception
/*    */   {
/* 51 */     writeInt(this.id);
/* 52 */     if (this.chat != null) {
/* 53 */       writeBoolean(false);
/* 54 */       writeChatComponent(this.chat);
/*    */     } else {
/* 56 */       writeBoolean(true);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void readData(EntityPlayer player)
/*    */   {
/* 63 */     this.id = readInt();
/* 64 */     if (readBoolean()) {
/* 65 */       this.chat = null;
/*    */     } else {
/* 67 */       this.chat = readChatComponent();
/*    */     }
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public Runnable doStuffClient()
/*    */   {
/* 74 */     new Runnable()
/*    */     {
/*    */       @SideOnly(Side.CLIENT)
/*    */       public void run() {
/* 78 */         GuiNewChat chatGUI = Minecraft.getMinecraft().ingameGUI.getChatGUI();
/* 79 */         if (SpecialChat.this.chat == null) {
/* 80 */           chatGUI.deleteChatLine(SpecialChat.this.id);
/*    */         } else {
/* 82 */           chatGUI.printChatMessageWithOptionalDeletion(SpecialChat.this.chat, SpecialChat.this.id);
/*    */         }
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\SpecialChat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */