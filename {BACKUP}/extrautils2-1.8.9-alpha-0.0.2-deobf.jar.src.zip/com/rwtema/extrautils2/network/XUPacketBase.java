/*    */ package com.rwtema.extrautils2.network;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ public abstract class XUPacketBase extends PacketBuffer
/*    */ {
/*    */   EntityPlayer callback;
/*    */   
/*    */   public XUPacketBase()
/*    */   {
/* 12 */     super(null);
/*    */   }
/*    */   
/*    */   public abstract void writeData()
/*    */     throws Exception;
/*    */   
/*    */   public abstract void readData(EntityPlayer paramEntityPlayer);
/*    */   
/*    */   public abstract Runnable doStuffServer();
/*    */   
/*    */   @net.minecraftforge.fml.relauncher.SideOnly(Side.CLIENT)
/*    */   public abstract Runnable doStuffClient();
/*    */   
/*    */   public abstract boolean isValidSenderSide(Side paramSide);
/*    */   
/*    */   public void loadAdditonalData(Side server, io.netty.channel.ChannelHandlerContext ctx) {}
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\XUPacketBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */