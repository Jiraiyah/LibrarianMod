/*    */ package com.rwtema.extrautils2.network;
/*    */ 
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XUPacketServerToClient
/*    */   extends XUPacketBase
/*    */ {
/*    */   public final Runnable doStuffServer()
/*    */   {
/* 13 */     throw new RuntimeException("Wrong Side");
/*    */   }
/*    */   
/*    */   public final boolean isValidSenderSide(Side properSenderSide)
/*    */   {
/* 18 */     return properSenderSide.isServer();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\XUPacketServerToClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */