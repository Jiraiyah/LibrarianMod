/*     */ package com.rwtema.extrautils2.network;
/*     */ 
/*     */ import com.google.common.base.Throwables;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.ScatteringByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.UUID;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.CompressedStreamTools;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.IChatComponent.Serializer;
/*     */ import net.minecraft.util.Vec3;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ public class PacketBuffer
/*     */ {
/*     */   public ByteBuf data;
/*     */   
/*     */   public PacketBuffer()
/*     */   {
/*  34 */     this.data = Unpooled.buffer();
/*     */   }
/*     */   
/*     */   public PacketBuffer(ByteBuf data) {
/*  38 */     this.data = data;
/*     */   }
/*     */   
/*     */   public static byte[] compress(NBTTagCompound p_74798_0_) throws IOException {
/*  42 */     ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
/*  43 */     DataOutputStream dataoutputstream = null;
/*     */     try {
/*  45 */       dataoutputstream = new DataOutputStream(new java.util.zip.GZIPOutputStream(bytearrayoutputstream));
/*  46 */       CompressedStreamTools.writeCompressed(p_74798_0_, dataoutputstream);
/*     */     } finally {
/*  48 */       if (dataoutputstream != null) {
/*  49 */         dataoutputstream.close();
/*     */       }
/*     */     }
/*  52 */     return bytearrayoutputstream.toByteArray();
/*     */   }
/*     */   
/*     */   public static NBTTagCompound readCompressed(byte[] p_152457_0_) throws IOException {
/*  56 */     DataInputStream datainputstream = new DataInputStream(new java.io.BufferedInputStream(new GZIPInputStream(new java.io.ByteArrayInputStream(p_152457_0_))));
/*     */     NBTTagCompound nbttagcompound;
/*     */     try
/*     */     {
/*  60 */       nbttagcompound = CompressedStreamTools.readCompressed(datainputstream);
/*     */     } finally {
/*  62 */       datainputstream.close();
/*     */     }
/*     */     
/*  65 */     return nbttagcompound;
/*     */   }
/*     */   
/*     */   public ByteBuf writeBoolean(boolean value) {
/*  69 */     return this.data.writeBoolean(value);
/*     */   }
/*     */   
/*     */   public ByteBuf writeByte(int value) {
/*  73 */     return this.data.writeByte(value);
/*     */   }
/*     */   
/*     */   public ByteBuf writeShort(int value) {
/*  77 */     return this.data.writeShort(value);
/*     */   }
/*     */   
/*     */   public ByteBuf writeMedium(int value) {
/*  81 */     return this.data.writeMedium(value);
/*     */   }
/*     */   
/*     */   public ByteBuf writeInt(int value) {
/*  85 */     return this.data.writeInt(value);
/*     */   }
/*     */   
/*     */   public ByteBuf writeLong(long value) {
/*  89 */     return this.data.writeLong(value);
/*     */   }
/*     */   
/*     */   public ByteBuf writeChar(int value) {
/*  93 */     return this.data.writeChar(value);
/*     */   }
/*     */   
/*     */   public ByteBuf writeFloat(float value) {
/*  97 */     return this.data.writeFloat(value);
/*     */   }
/*     */   
/*     */   public ByteBuf writeDouble(double value) {
/* 101 */     return this.data.writeDouble(value);
/*     */   }
/*     */   
/*     */   public ByteBuf writeBytes(ByteBuf src) {
/* 105 */     return this.data.writeBytes(src);
/*     */   }
/*     */   
/*     */   public ByteBuf writeBytes(ByteBuf src, int length) {
/* 109 */     return this.data.writeBytes(src, length);
/*     */   }
/*     */   
/*     */   public ByteBuf writeBytes(ByteBuf src, int srcIndex, int length) {
/* 113 */     return this.data.writeBytes(src, srcIndex, length);
/*     */   }
/*     */   
/*     */   public ByteBuf writeBytes(byte[] src) {
/* 117 */     return this.data.writeBytes(src);
/*     */   }
/*     */   
/*     */   public ByteBuf writeBytes(byte[] src, int srcIndex, int length) {
/* 121 */     return this.data.writeBytes(src, srcIndex, length);
/*     */   }
/*     */   
/*     */   public ByteBuf writeBytes(ByteBuffer src) {
/* 125 */     return this.data.writeBytes(src);
/*     */   }
/*     */   
/*     */   public int writeBytes(InputStream in, int length) throws IOException {
/* 129 */     return this.data.writeBytes(in, length);
/*     */   }
/*     */   
/*     */   public int writeBytes(ScatteringByteChannel in, int length) throws IOException {
/* 133 */     return this.data.writeBytes(in, length);
/*     */   }
/*     */   
/*     */   public ByteBuf writeZero(int length) {
/* 137 */     return this.data.writeZero(length);
/*     */   }
/*     */   
/*     */   public boolean readBoolean() {
/* 141 */     return this.data.readBoolean();
/*     */   }
/*     */   
/*     */   public byte readByte() {
/* 145 */     return this.data.readByte();
/*     */   }
/*     */   
/*     */   public short readUnsignedByte() {
/* 149 */     return this.data.readUnsignedByte();
/*     */   }
/*     */   
/*     */   public short readShort() {
/* 153 */     return this.data.readShort();
/*     */   }
/*     */   
/*     */   public int readUnsignedShort() {
/* 157 */     return this.data.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public int readMedium() {
/* 161 */     return this.data.readMedium();
/*     */   }
/*     */   
/*     */   public int readUnsignedMedium() {
/* 165 */     return this.data.readUnsignedMedium();
/*     */   }
/*     */   
/*     */   public int readInt() {
/* 169 */     return this.data.readInt();
/*     */   }
/*     */   
/*     */   public long readUnsignedInt() {
/* 173 */     return this.data.readUnsignedInt();
/*     */   }
/*     */   
/*     */   public long readLong() {
/* 177 */     return this.data.readLong();
/*     */   }
/*     */   
/*     */   public char readChar() {
/* 181 */     return this.data.readChar();
/*     */   }
/*     */   
/*     */   public float readFloat() {
/* 185 */     return this.data.readFloat();
/*     */   }
/*     */   
/*     */   public double readDouble() {
/* 189 */     return this.data.readDouble();
/*     */   }
/*     */   
/*     */   public ByteBuf readBytes(int length) {
/* 193 */     return this.data.readBytes(length);
/*     */   }
/*     */   
/*     */   public void writeVec(Vec3 vec3) {
/* 197 */     this.data.writeFloat((float)vec3.xCoord);
/* 198 */     this.data.writeFloat((float)vec3.yCoord);
/* 199 */     this.data.writeFloat((float)vec3.zCoord);
/*     */   }
/*     */   
/*     */   public void writeChatComponent(IChatComponent chatComponent) {
/* 203 */     writeString(IChatComponent.Serializer.componentToJson(chatComponent));
/*     */   }
/*     */   
/*     */   public IChatComponent readChatComponent() {
/* 207 */     return IChatComponent.Serializer.jsonToComponent(readString());
/*     */   }
/*     */   
/*     */   public Vec3 readVec() {
/* 211 */     return new Vec3(this.data.readFloat(), this.data.readFloat(), this.data.readFloat());
/*     */   }
/*     */   
/*     */   public void writeString(String string) {
/* 215 */     if (string == null) {
/* 216 */       this.data.writeShort(0);
/*     */     } else {
/* 218 */       byte[] stringData = string.getBytes(Charset.forName("UTF-8"));
/* 219 */       this.data.writeShort(stringData.length);
/* 220 */       this.data.writeBytes(stringData);
/*     */     }
/*     */   }
/*     */   
/*     */   public String readString() {
/* 225 */     short length = this.data.readShort();
/* 226 */     if (length == 0) return "";
/* 227 */     byte[] bytes = new byte[length];
/*     */     
/* 229 */     this.data.readBytes(bytes);
/* 230 */     return new String(bytes, Charset.forName("UTF-8"));
/*     */   }
/*     */   
/*     */   public void writeNBT(NBTTagCompound tag) {
/* 234 */     if (tag == null) {
/* 235 */       this.data.writeShort(0);
/* 236 */       return;
/*     */     }
/*     */     try {
/* 239 */       byte[] compressed = compress(tag);
/*     */       
/* 241 */       this.data.writeShort(compressed.length);
/* 242 */       this.data.writeBytes(compressed);
/*     */     } catch (IOException e) {
/* 244 */       throw Throwables.propagate(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public NBTTagCompound readNBT() {
/* 249 */     int length = this.data.readUnsignedShort();
/* 250 */     if (length <= 0) return null;
/* 251 */     byte[] bytes = new byte[length];
/* 252 */     this.data.readBytes(bytes);
/*     */     try {
/* 254 */       return readCompressed(bytes);
/*     */     } catch (IOException e) {
/* 256 */       throw Throwables.propagate(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeItemStack(ItemStack item) {
/* 261 */     if ((item == null) || (item.getItem() == null)) {
/* 262 */       this.data.writeByte(0);
/*     */     } else {
/* 264 */       this.data.writeByte(item.stackSize);
/* 265 */       this.data.writeShort(Item.getIdFromItem(item.getItem()));
/* 266 */       this.data.writeShort(item.getItemDamage());
/*     */       
/* 268 */       NBTTagCompound nbttagcompound = null;
/*     */       
/* 270 */       if ((item.getItem().getShareTag()) || (item.getItem().isDamageable())) {
/* 271 */         nbttagcompound = item.getTagCompound();
/*     */       }
/*     */       
/* 274 */       writeNBT(nbttagcompound);
/*     */     }
/*     */   }
/*     */   
/*     */   public ItemStack readItemStack()
/*     */   {
/* 280 */     short stackSize = this.data.readUnsignedByte();
/*     */     
/* 282 */     if (stackSize == 0) { return null;
/*     */     }
/* 284 */     short id = this.data.readShort();
/* 285 */     short metadata = this.data.readShort();
/*     */     
/* 287 */     Item itemById = Item.getItemById(id);
/* 288 */     if (itemById == null) return null;
/* 289 */     ItemStack itemstack = new ItemStack(itemById, stackSize, metadata);
/* 290 */     itemstack.setTagCompound(readNBT());
/*     */     
/* 292 */     return itemstack;
/*     */   }
/*     */   
/*     */   public void writeBlockPos(BlockPos pos) {
/* 296 */     this.data.writeInt(pos.getX());
/* 297 */     this.data.writeByte(pos.getY());
/* 298 */     this.data.writeInt(pos.getZ());
/*     */   }
/*     */   
/*     */   public BlockPos readBlockPos() {
/* 302 */     return new BlockPos(this.data.readInt(), this.data.readUnsignedByte(), this.data.readInt());
/*     */   }
/*     */   
/*     */   public void writeSide(EnumFacing e) {
/* 306 */     this.data.writeByte(e.ordinal());
/*     */   }
/*     */   
/*     */   public EnumFacing readSide() {
/* 310 */     return EnumFacing.values()[this.data.readByte()];
/*     */   }
/*     */   
/*     */   public void writePacketBuffer(PacketBuffer packetBuffer) {
/* 314 */     writeInt(packetBuffer.data.readableBytes());
/* 315 */     this.data.writeBytes(packetBuffer.data);
/*     */   }
/*     */   
/*     */   public PacketBuffer readPacketBuffer() {
/* 319 */     int len = readInt();
/* 320 */     ByteBuf buffer = Unpooled.buffer(len);
/* 321 */     this.data.readBytes(buffer, len);
/* 322 */     return new PacketBuffer(buffer);
/*     */   }
/*     */   
/*     */   public GameProfile readProfile() {
/* 326 */     byte b = readByte();
/* 327 */     if (b == 0) return null;
/*     */     String name;
/* 329 */     String name; if ((b & 0x1) != 0) {
/* 330 */       name = readString();
/*     */     } else
/* 332 */       name = null;
/*     */     UUID id;
/*     */     UUID id;
/* 335 */     if ((b & 0x2) != 0) {
/* 336 */       long low = readLong();
/* 337 */       long upp = readLong();
/* 338 */       id = new UUID(upp, low);
/*     */     } else {
/* 340 */       id = null;
/*     */     }
/* 342 */     return new GameProfile(id, name);
/*     */   }
/*     */   
/*     */   public void writeProfile(GameProfile profile)
/*     */   {
/* 347 */     UUID id = profile.getId();
/* 348 */     String name = profile.getName();
/* 349 */     if (id == null) {
/* 350 */       if (StringUtils.isBlank(name)) {
/* 351 */         writeByte(0);
/*     */       } else {
/* 353 */         writeByte(1);
/* 354 */         writeString(name);
/*     */       }
/*     */     } else {
/* 357 */       long low = id.getLeastSignificantBits();
/* 358 */       long upp = id.getMostSignificantBits();
/* 359 */       if (StringUtils.isBlank(name)) {
/* 360 */         writeByte(2);
/* 361 */         writeLong(low);
/* 362 */         writeLong(upp);
/*     */       } else {
/* 364 */         writeByte(3);
/* 365 */         writeString(name);
/* 366 */         writeLong(low);
/* 367 */         writeLong(upp);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\PacketBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */