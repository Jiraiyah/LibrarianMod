/*    */ package com.rwtema.extrautils2.network.packets;
/*    */ 
/*    */ import com.rwtema.extrautils2.keyhandler.KeyAlt;
/*    */ import com.rwtema.extrautils2.network.NetworkHandler.XUPacket;
/*    */ import com.rwtema.extrautils2.network.XUPacketClientToServer;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ @NetworkHandler.XUPacket
/*    */ public class PacketUseItemAlt
/*    */   extends XUPacketClientToServer
/*    */ {
/*    */   private boolean sprint;
/*    */   private EntityPlayer player;
/*    */   
/*    */   public PacketUseItemAlt() {}
/*    */   
/*    */   public PacketUseItemAlt(boolean sprint)
/*    */   {
/* 19 */     this.sprint = sprint;
/*    */   }
/*    */   
/*    */   public void writeData() throws Exception
/*    */   {
/* 24 */     writeBoolean(this.sprint);
/*    */   }
/*    */   
/*    */   public void readData(EntityPlayer player)
/*    */   {
/* 29 */     this.sprint = readBoolean();
/* 30 */     this.player = player;
/*    */   }
/*    */   
/*    */   public Runnable doStuffServer()
/*    */   {
/* 35 */     new Runnable()
/*    */     {
/*    */       public void run() {
/* 38 */         KeyAlt.setValue(PacketUseItemAlt.this.player, PacketUseItemAlt.this.sprint);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\packets\PacketUseItemAlt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */