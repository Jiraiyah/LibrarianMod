/*    */ package com.rwtema.extrautils2.network;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import com.rwtema.extrautils2.utils.LogHelper;
/*    */ import com.rwtema.extrautils2.utils.helpers.PlayerHelper;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.Channel;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.util.Attribute;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.network.INetHandler;
/*    */ import net.minecraftforge.fml.common.network.FMLIndexedMessageToMessageCodec;
/*    */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*    */ 
/*    */ @ChannelHandler.Sharable
/*    */ public class PacketCodec extends FMLIndexedMessageToMessageCodec<XUPacketBase>
/*    */ {
/* 20 */   public static HashMap<String, Class<? extends XUPacketBase>> classes = new HashMap();
/*    */   
/*    */   public PacketCodec() {
/* 23 */     ArrayList<String> t = new ArrayList();
/* 24 */     t.addAll(classes.keySet());
/*    */     
/* 26 */     java.util.Collections.sort(t);
/*    */     
/* 28 */     for (int i = 0; i < t.size(); i++) {
/* 29 */       LogHelper.fine("Registering Packet class " + (String)t.get(i) + " with discriminator: " + i, new Object[0]);
/* 30 */       addDiscriminator(i, (Class)classes.get(t.get(i)));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public static void addClass(Class clazz)
/*    */   {
/* 37 */     classes.put(clazz.getSimpleName(), clazz);
/*    */   }
/*    */   
/*    */   public void encodeInto(ChannelHandlerContext ctx, XUPacketBase msg, ByteBuf target) throws Exception
/*    */   {
/* 42 */     LogHelper.oneTimeInfo("Encode Packet: " + msg.getClass().getName());
/* 43 */     INetHandler netHandler = (INetHandler)ctx.channel().attr(NetworkRegistry.NET_HANDLER).get();
/* 44 */     msg.data = target;
/* 45 */     msg.writeData();
/* 46 */     msg.data = null;
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf source, XUPacketBase msg)
/*    */   {
/* 51 */     LogHelper.oneTimeInfo("Decode Packet: " + msg.getClass().getName());
/* 52 */     INetHandler netHandler = (INetHandler)ctx.channel().attr(NetworkRegistry.NET_HANDLER).get();
/* 53 */     net.minecraft.entity.player.EntityPlayer player = ExtraUtils2.proxy.getPlayerFromNetHandler(netHandler);
/* 54 */     msg.data = source;
/* 55 */     if (PlayerHelper.isThisPlayerACheatyBastardOfCheatBastardness(player))
/* 56 */       msg.callback = player;
/* 57 */     msg.readData(player);
/* 58 */     msg.data = null;
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\PacketCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */