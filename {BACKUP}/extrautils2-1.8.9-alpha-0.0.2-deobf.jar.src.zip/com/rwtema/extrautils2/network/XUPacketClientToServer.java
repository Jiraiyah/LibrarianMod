/*    */ package com.rwtema.extrautils2.network;
/*    */ 
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XUPacketClientToServer
/*    */   extends XUPacketBase
/*    */ {
/*    */   @SideOnly(Side.CLIENT)
/*    */   public final Runnable doStuffClient()
/*    */   {
/* 14 */     throw new RuntimeException("Wrong Side");
/*    */   }
/*    */   
/*    */   public final boolean isValidSenderSide(Side properSenderSide)
/*    */   {
/* 19 */     return properSenderSide.isClient();
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\XUPacketClientToServer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */