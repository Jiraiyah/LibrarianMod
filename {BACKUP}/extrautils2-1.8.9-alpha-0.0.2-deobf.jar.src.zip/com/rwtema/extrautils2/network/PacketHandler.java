/*    */ package com.rwtema.extrautils2.network;
/*    */ 
/*    */ import com.google.common.base.Throwables;
/*    */ import com.rwtema.extrautils2.utils.LogHelper;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.SimpleChannelInboundHandler;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ @ChannelHandler.Sharable
/*    */ public class PacketHandler extends SimpleChannelInboundHandler<XUPacketBase>
/*    */ {
/*    */   protected void channelRead0(ChannelHandlerContext ctx, XUPacketBase msg) throws Exception
/*    */   {
/* 18 */     Side effectiveSide = FMLCommonHandler.instance().getEffectiveSide();
/* 19 */     LogHelper.oneTimeInfo("Handle Packet: " + msg.getClass().getName() + " : " + effectiveSide);
/*    */     
/* 21 */     msg.loadAdditonalData(Side.SERVER, ctx);
/*    */     
/* 23 */     Runnable runnableToSchedule = null;
/* 24 */     final EntityPlayer callback = msg.callback;
/*    */     try {
/* 26 */       runnableToSchedule = msg.doStuffServer();
/*    */     } catch (Throwable throwable) {
/* 28 */       LogHelper.oneTimeInfo("Error Packet: " + msg.getClass().getName() + " : " + effectiveSide);
/* 29 */       if (callback != null)
/* 30 */         NetworkHandler.sendCrash(throwable, callback);
/* 31 */       throw Throwables.propagate(throwable);
/*    */     }
/*    */     
/* 34 */     if (runnableToSchedule != null) {
/* 35 */       LogHelper.oneTimeInfo("Scheduling Packet: " + msg.getClass().getName() + " : " + effectiveSide);
/*    */       
/* 37 */       if (callback == null) {
/* 38 */         MinecraftServer.func_71276_C().addScheduledTask(runnableToSchedule);
/*    */       } else {
/* 40 */         LogHelper.oneTimeInfo("Scheduling Callback Packet: " + msg.getClass().getName() + " : " + effectiveSide);
/* 41 */         final Runnable finalRunnableToSchedule = runnableToSchedule;
/* 42 */         MinecraftServer.func_71276_C().addScheduledTask(new Runnable()
/*    */         {
/*    */           public void run() {
/*    */             try {
/* 46 */               finalRunnableToSchedule.run();
/*    */             } catch (Throwable throwable) {
/* 48 */               NetworkHandler.sendCrash(throwable, callback);
/* 49 */               throw Throwables.propagate(throwable);
/*    */             }
/*    */           }
/*    */         });
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\PacketHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */