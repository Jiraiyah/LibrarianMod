/*    */ package com.rwtema.extrautils2.network;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.LogHelper;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ @ChannelHandler.Sharable
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class PacketHandlerClient
/*    */   extends PacketHandler
/*    */ {
/*    */   protected void channelRead0(ChannelHandlerContext ctx, XUPacketBase msg)
/*    */     throws Exception
/*    */   {
/* 20 */     Side side = FMLCommonHandler.instance().getEffectiveSide();
/* 21 */     LogHelper.oneTimeInfo("Handle Packet: " + msg.getClass().getName() + " : " + side);
/* 22 */     msg.loadAdditonalData(side, ctx);
/*    */     
/* 24 */     if (side == Side.SERVER) {
/* 25 */       Runnable runnableToSchedule = msg.doStuffServer();
/* 26 */       if (runnableToSchedule != null)
/* 27 */         MinecraftServer.func_71276_C().addScheduledTask(runnableToSchedule);
/*    */     } else {
/* 29 */       Runnable runnable = msg.doStuffClient();
/* 30 */       if (runnable != null) {
/* 31 */         Minecraft.getMinecraft().addScheduledTask(runnable);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\network\PacketHandlerClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */