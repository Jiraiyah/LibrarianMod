/*    */ package com.rwtema.extrautils2.worldgen;
/*    */ 
/*    */ import com.rwtema.extrautils2.utils.helpers.NBTHelper;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.WorldServer;
/*    */ import net.minecraft.world.chunk.Chunk;
/*    */ import net.minecraft.world.chunk.IChunkProvider;
/*    */ import net.minecraftforge.event.world.ChunkDataEvent.Load;
/*    */ import net.minecraftforge.event.world.ChunkDataEvent.Save;
/*    */ import net.minecraftforge.fml.common.IWorldGenerator;
/*    */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class SingleChunkWorldGenManager implements IWorldGenerator
/*    */ {
/* 20 */   public static SingleChunkWorldGenManager INSTANCE = new SingleChunkWorldGenManager();
/* 21 */   List<SingleChunkGen> chunkGens = new ArrayList();
/* 22 */   public static ThreadLocal<Boolean> isRetrogen = new com.rwtema.extrautils2.utils.datastructures.ThreadLocalBoolean(false);
/*    */   
/*    */   private SingleChunkWorldGenManager() {
/* 25 */     net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);
/*    */   }
/*    */   
/*    */   public static void register(SingleChunkGen singleChunkGen) {
/* 29 */     INSTANCE.chunkGens.add(singleChunkGen);
/*    */   }
/*    */   
/*    */   public void generate(Random random, int chunkX, int chunkZ, World world, IChunkProvider chunkGenerator, IChunkProvider chunkProvider)
/*    */   {
/* 34 */     Chunk chunk = world.getChunkFromChunkCoords(chunkX, chunkZ);
/* 35 */     isRetrogen.set(Boolean.valueOf(false));
/* 36 */     for (SingleChunkGen chunkGen : this.chunkGens) {
/* 37 */       chunkGen.genChunk(chunk, chunkGenerator, random);
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void saveChunk(ChunkDataEvent.Save event) {
/* 43 */     if (!event.getChunk().isTerrainPopulated()) {
/* 44 */       return;
/*    */     }
/* 46 */     NBTTagCompound data = event.getData();
/* 47 */     NBTTagCompound tag = NBTHelper.getOrInitTagCompound(data, "XU2Generation");
/*    */     
/* 49 */     for (SingleChunkGen chunkGen : this.chunkGens) {
/* 50 */       tag.setInteger(chunkGen.name, chunkGen.version);
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void loadChunk(ChunkDataEvent.Load event) {
/* 56 */     World world = event.world;
/* 57 */     if (world.isRemote) return;
/* 58 */     long chunkSeed = -1L;
/* 59 */     Chunk chunk = event.getChunk();
/* 60 */     Random random = null;
/* 61 */     IChunkProvider chunkProvider = null;
/* 62 */     NBTTagCompound data = event.getData();
/* 63 */     NBTTagCompound tag = NBTHelper.getOrInitTagCompound(data, "XU2Generation");
/*    */     
/* 65 */     for (SingleChunkGen chunkGen : this.chunkGens) {
/*    */       int v;
/* 67 */       if ((chunkGen != null) && ((!tag.hasKey(chunkGen.name, 3)) || (((v = tag.getInteger(chunkGen.name)) != chunkGen.version) && (chunkGen.shouldRegenOldVersion(v)))))
/*    */       {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 73 */         if (chunkSeed == -1L) {
/* 74 */           long worldSeed = world.getSeed();
/*    */           
/* 76 */           random = new Random(worldSeed);
/* 77 */           long xSeed = random.nextLong() >> 3;
/* 78 */           long zSeed = random.nextLong() >> 3;
/*    */           
/* 80 */           chunkSeed = xSeed * chunk.xPosition + zSeed * chunk.zPosition ^ worldSeed;
/* 81 */           chunkProvider = ((WorldServer)world).field_73059_b.field_73246_d;
/*    */         }
/*    */         
/*    */ 
/* 85 */         isRetrogen.set(Boolean.valueOf(true));
/* 86 */         random.setSeed(chunkSeed);
/* 87 */         chunkGen.genChunk(chunk, chunkProvider, random);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\worldgen\SingleChunkWorldGenManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */