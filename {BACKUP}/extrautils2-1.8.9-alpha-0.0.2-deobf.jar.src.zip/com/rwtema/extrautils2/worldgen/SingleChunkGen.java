/*    */ package com.rwtema.extrautils2.worldgen;
/*    */ 
/*    */ import com.rwtema.extrautils2.ExtraUtils2;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.BlockPos.MutableBlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.chunk.Chunk;
/*    */ import net.minecraft.world.chunk.IChunkProvider;
/*    */ import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
/*    */ 
/*    */ public abstract class SingleChunkGen
/*    */ {
/* 17 */   static ThreadLocal<BlockPos.MutableBlockPos> mutableBlockPos = new ThreadLocal()
/*    */   {
/*    */     protected BlockPos.MutableBlockPos initialValue() {
/* 20 */       return new BlockPos.MutableBlockPos();
/*    */     }
/*    */   };
/* 23 */   static IBlockState air = Blocks.air.getDefaultState();
/*    */   public final int version;
/*    */   public final String name;
/*    */   
/*    */   protected SingleChunkGen(String name, int version) {
/* 28 */     this.name = name;
/* 29 */     this.version = version;
/*    */   }
/*    */   
/*    */   public abstract void genChunk(Chunk paramChunk, IChunkProvider paramIChunkProvider, Random paramRandom);
/*    */   
/*    */   public boolean shouldRegenOldVersion(int v) {
/* 35 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isAir(Chunk chunk, BlockPos pos) {
/* 39 */     return chunk.getBlockState(pos) == air;
/*    */   }
/*    */   
/*    */   public boolean isAir(Chunk chunk, BlockPos pos, EnumFacing side) {
/* 43 */     return isAir(chunk, pos.getX() + side.getFrontOffsetX(), pos.getY() + side.getFrontOffsetY(), pos.getZ() + side.getFrontOffsetZ());
/*    */   }
/*    */   
/*    */   public boolean isAir(Chunk chunk, int dx, int dy, int dz)
/*    */   {
/* 48 */     BlockPos.MutableBlockPos pos = (BlockPos.MutableBlockPos)mutableBlockPos.get();
/* 49 */     pos.set(dx, dy, dz);
/* 50 */     return isAir(chunk, pos);
/*    */   }
/*    */   
/*    */   public void report(Chunk chunk, int dx, int dy, int dz)
/*    */   {
/* 55 */     if (!ExtraUtils2.deobf_folder) return;
/* 56 */     com.rwtema.extrautils2.utils.LogHelper.debug(this.name + " " + new BlockPos((chunk.xPosition << 4) + dx, dy, (chunk.zPosition << 4) + dz), new Object[0]);
/*    */   }
/*    */   
/*    */   public void setBlockState(Chunk chunk, BlockPos pos, IBlockState state) {
/* 60 */     if (((Boolean)SingleChunkWorldGenManager.isRetrogen.get()).booleanValue()) {
/* 61 */       int i = pos.getX() & 0xF;
/* 62 */       int j = pos.getY();
/* 63 */       int k = pos.getZ() & 0xF;
/* 64 */       int l = k << 4 | i;
/* 65 */       ExtendedBlockStorage[] storageArrays = chunk.getBlockStorageArray();
/* 66 */       ExtendedBlockStorage extendedblockstorage = storageArrays[(j >> 4)];
/* 67 */       Block block = state.getBlock();
/* 68 */       if (extendedblockstorage == null) {
/* 69 */         if (block == Blocks.air) return;
/* 70 */         extendedblockstorage = storageArrays[(j >> 4)] = new ExtendedBlockStorage(j & 0xFFFFFFF0, !chunk.getWorld().provider.getHasNoSky());
/*    */       }
/*    */       
/* 73 */       extendedblockstorage.set(i, j & 0xF, k, state);
/*    */     } else {
/* 75 */       chunk.setBlockState(pos, state);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\worldgen\SingleChunkGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */