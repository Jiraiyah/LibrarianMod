/*     */ package com.rwtema.extrautils2.achievements;
/*     */ 
/*     */ import com.google.common.collect.HashMultimap;
/*     */ import com.rwtema.extrautils2.backend.entries.IItemStackMaker;
/*     */ import com.rwtema.extrautils2.utils.Lang;
/*     */ import com.rwtema.extrautils2.utils.LogHelper;
/*     */ import com.rwtema.extrautils2.utils.datastructures.ItemRef;
/*     */ import gnu.trove.list.array.TIntArrayList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.stats.Achievement;
/*     */ import net.minecraftforge.common.AchievementPage;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemCraftedEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemPickupEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemSmeltedEvent;
/*     */ import net.minecraftforge.fml.common.toposort.TopologicalSort.DirectedGraph;
/*     */ 
/*     */ public class AchievementHelper
/*     */ {
/*  31 */   private static HashMultimap<ItemRef, XUAchievement> dropMap = ;
/*  32 */   private static HashMultimap<XUAchievement, XUAchievement> achievementChildren = HashMultimap.create();
/*     */   private static AchievementPage page;
/*     */   private static List<Achievement> achievements;
/*  35 */   private static HashMap<IItemStackMaker, XUAchievement> map = new HashMap();
/*  36 */   private static boolean built = false;
/*     */   
/*  38 */   private static HashSet<String> names = new HashSet();
/*     */   
/*     */   public static XUAchievement addAchievement(String name, String description, @Nonnull IItemStackMaker entry, @Nullable IItemStackMaker parent) {
/*  41 */     if (!names.add(name))
/*  42 */       throw new RuntimeException("Duplicate Name " + name);
/*  43 */     XUAchievement achievement = new XUAchievement(name, description, entry, parent);
/*  44 */     map.put(entry, achievement);
/*  45 */     return achievement;
/*     */   }
/*     */   
/*     */   public static void bake() {
/*  49 */     if (page == null) {
/*  50 */       page = new AchievementPage("ExtraUtils 2", new Achievement[0]);
/*  51 */       AchievementPage.registerAchievementPage(page);
/*  52 */       achievements = page.getAchievements();
/*     */     } else {
/*  54 */       achievements.clear();
/*  55 */       achievementChildren.clear();
/*  56 */       dropMap.clear();
/*     */     }
/*     */     
/*  59 */     TopologicalSort.DirectedGraph<XUAchievement> graph = new TopologicalSort.DirectedGraph();
/*     */     
/*  61 */     for (XUAchievement xuAchievement : map.values()) {
/*  62 */       graph.addNode(xuAchievement);
/*     */     }
/*     */     
/*  65 */     for (XUAchievement xuAchievement : map.values()) {
/*  66 */       if (xuAchievement.parent == null) {
/*  67 */         achievementChildren.put(null, xuAchievement);
/*     */       }
/*     */       else
/*     */       {
/*  71 */         xuAchievement.achParent = ((XUAchievement)map.get(xuAchievement.parent));
/*     */         
/*  73 */         achievementChildren.put(xuAchievement.achParent, xuAchievement);
/*  74 */         if (xuAchievement.achParent != null) {
/*  75 */           graph.addEdge(xuAchievement.achParent, xuAchievement);
/*     */         } else {
/*  77 */           xuAchievement.achParent = null;
/*     */         }
/*     */       }
/*     */     }
/*  81 */     List<XUAchievement> sort = net.minecraftforge.fml.common.toposort.TopologicalSort.topologicalSort(graph);
/*     */     Iterator i$;
/*  83 */     XUAchievement a; for (int i = 0; i < 100; i++) {
/*  84 */       new Layout(null).buildTree();
/*     */       
/*  86 */       for (i$ = sort.iterator(); i$.hasNext();) { a = (XUAchievement)i$.next();
/*  87 */         for (XUAchievement b : sort) {
/*  88 */           if ((a != b) && (a.x == b.x) && (a.y == b.y)) {
/*  89 */             LogHelper.info(a + " " + b, new Object[0]);
/*  90 */             throw new RuntimeException("Overlay\n " + a + "\n " + b);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  97 */     int minx = Integer.MAX_VALUE;int miny = Integer.MAX_VALUE;int maxx = Integer.MIN_VALUE;int maxy = Integer.MIN_VALUE;
/*     */     
/*  99 */     int xc = 0;
/* 100 */     int yc = 0;
/*     */     
/*     */ 
/* 103 */     for (XUAchievement xuAchievement : sort) {
/* 104 */       minx = Math.min(minx, xuAchievement.x);
/* 105 */       miny = Math.min(miny, xuAchievement.y);
/* 106 */       maxx = Math.max(maxx, xuAchievement.x);
/* 107 */       maxy = Math.max(maxy, xuAchievement.y);
/*     */       
/* 109 */       xc += xuAchievement.x;
/* 110 */       yc += xuAchievement.y;
/*     */     }
/*     */     
/* 113 */     xc /= sort.size();
/* 114 */     yc /= sort.size();
/*     */     
/* 116 */     int scale = 2;
/* 117 */     char[][] chars = new char[(maxx - minx) * scale + 1][(maxy - miny) * scale + 1];
/*     */     
/* 119 */     for (XUAchievement achievement : sort) {
/* 120 */       char ch = 'A';
/* 121 */       XUAchievement a = achievement.achParent;
/* 122 */       if (a != null) {
/* 123 */         for (int dx = (Math.min(a.x, achievement.x) - minx) * scale; dx <= (Math.max(a.x, achievement.x) - minx) * scale; dx++) {
/* 124 */           char c = chars[dx][((a.y - miny) * scale)];
/* 125 */           if (c == 0) {
/* 126 */             chars[dx][((a.y - miny) * scale)] = 124;
/*     */           }
/*     */           
/* 129 */           if (c == '-') {
/* 130 */             chars[dx][((a.y - miny) * scale)] = 42;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 135 */         for (int dy = (Math.min(a.y, achievement.y) - miny) * scale; dy <= (Math.max(a.y, achievement.y) - miny) * scale; dy++) {
/* 136 */           char c = chars[((achievement.x - minx) * scale)][dy];
/* 137 */           if (c == 0) {
/* 138 */             chars[((achievement.x - minx) * scale)][dy] = 45;
/*     */           }
/* 140 */           if (c == '|') {
/* 141 */             chars[((achievement.x - minx) * scale)][dy] = 42;
/*     */           }
/*     */         }
/*     */         
/* 145 */         ch = (char)(ch + '\001');
/* 146 */         while (a.achParent != null) {
/* 147 */           a = a.achParent;
/* 148 */           ch = (char)(ch + '\001');
/*     */         }
/*     */       }
/*     */       
/* 152 */       chars[((achievement.x - minx) * scale)][((achievement.y - miny) * scale)] = ch;
/*     */     }
/*     */     
/* 155 */     StringBuilder builder = new StringBuilder();
/* 156 */     for (char[] aChar : chars) {
/* 157 */       builder.append('\n');
/* 158 */       for (char c : aChar) {
/* 159 */         builder.append(c);
/*     */       }
/*     */     }
/* 162 */     builder.append('\n');
/* 163 */     LogHelper.info(builder.toString(), new Object[0]);
/*     */     
/* 165 */     for (XUAchievement xuAchievement : sort) {
/* 166 */       String key = Lang.stripText(xuAchievement.name);
/* 167 */       String achKey = "achievement.xu2." + key;
/* 168 */       Lang.translate(achKey, xuAchievement.name);
/* 169 */       Lang.translate(achKey + ".desc", xuAchievement.description);
/* 170 */       Achievement parentAch = xuAchievement.achParent != null ? xuAchievement.achParent.achievement : null;
/* 171 */       ItemStack stack = xuAchievement.entry.newStack();
/* 172 */       if (stack == null) {
/* 173 */         stack = com.rwtema.extrautils2.items.ItemIngredients.Type.SYMBOL_NOCRAFT.newStack();
/*     */       } else {
/* 175 */         dropMap.put(ItemRef.wrap(stack), xuAchievement);
/* 176 */         if (stack.getItemDamage() == 32767) {
/* 177 */           stack.setItemDamage(0);
/*     */         }
/*     */       }
/*     */       
/* 181 */       int y = xuAchievement.x - xc;
/* 182 */       int x = xuAchievement.y - yc;
/*     */       
/* 184 */       LogHelper.debug(achKey + " - " + (parentAch == null ? "[null]" : parentAch.getStatName().getUnformattedText()), new Object[0]);
/*     */       
/* 186 */       Achievement achievement = new Achievement("achievement.xu2." + key, "xu2." + key, x, y, stack, parentAch);
/*     */       
/* 188 */       if (!built) {
/* 189 */         achievement.registerStat();
/*     */       }
/* 191 */       xuAchievement.achievement = achievement;
/*     */       
/* 193 */       achievements.add(achievement);
/*     */     }
/*     */     
/*     */ 
/* 197 */     if (!built) {
/* 198 */       net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new Object() {
/*     */         @SubscribeEvent
/*     */         public void onPickup(PlayerEvent.ItemPickupEvent event) {
/* 201 */           EntityItem pickedUp = event.pickedUp;
/* 202 */           if (pickedUp == null) return;
/* 203 */           AchievementHelper.checkForPotentialAwards(event.player, pickedUp.getEntityItem());
/*     */         }
/*     */         
/*     */         @SubscribeEvent
/*     */         public void onSmelt(PlayerEvent.ItemSmeltedEvent event) {
/* 208 */           AchievementHelper.checkForPotentialAwards(event.player, event.smelting);
/*     */         }
/*     */         
/*     */         @SubscribeEvent
/*     */         public void onCraft(PlayerEvent.ItemCraftedEvent event) {
/* 213 */           AchievementHelper.checkForPotentialAwards(event.player, event.crafting);
/*     */         }
/*     */       });
/*     */     }
/*     */     
/*     */ 
/* 219 */     built = true;
/*     */   }
/*     */   
/*     */   public static void checkForPotentialAwards(EntityPlayer player, ItemStack stack) {
/* 223 */     if ((stack == null) || (player == null)) return;
/* 224 */     Set<XUAchievement> set = dropMap.get(ItemRef.wrap(stack));
/* 225 */     if (!set.isEmpty()) {
/* 226 */       for (XUAchievement achievement : set)
/* 227 */         player.addStat(achievement.achievement);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class XUAchievement {
/*     */     public Achievement achievement;
/*     */     public String name;
/*     */     public String description;
/*     */     @Nonnull
/*     */     public IItemStackMaker entry;
/*     */     @Nullable
/*     */     public IItemStackMaker parent;
/*     */     public XUAchievement achParent;
/*     */     int x;
/*     */     int y;
/*     */     
/*     */     public XUAchievement(String name, String description, @Nonnull IItemStackMaker entry, @Nullable IItemStackMaker parent) {
/* 244 */       this.name = name;
/* 245 */       this.description = description;
/* 246 */       this.entry = entry;
/* 247 */       this.parent = parent;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 252 */       return "XUAchievement{" + this.name + '}';
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Layout
/*     */   {
/*     */     public void buildTree()
/*     */     {
/* 260 */       TreeNode treeNode = new TreeNode(AchievementHelper.achievementChildren.get(null));
/* 261 */       treeNode.buildDepth();
/* 262 */       treeNode.assignValues(0, 0);
/*     */     }
/*     */     
/*     */     private static class TreeNode
/*     */     {
/*     */       public AchievementHelper.XUAchievement xuAchievement;
/* 268 */       public TIntArrayList minPoints = new TIntArrayList();
/* 269 */       public TIntArrayList maxPoints = new TIntArrayList();
/*     */       
/*     */       int shift;
/*     */       
/* 273 */       ArrayList<TreeNode> children = new ArrayList();
/*     */       
/*     */       public TreeNode(Collection<AchievementHelper.XUAchievement> xuChildren) {
/* 276 */         ArrayList<AchievementHelper.XUAchievement> list = new ArrayList(xuChildren);
/* 277 */         java.util.Collections.shuffle(list);
/* 278 */         for (AchievementHelper.XUAchievement achievement : list) {
/* 279 */           this.children.add(new TreeNode(achievement));
/*     */         }
/*     */       }
/*     */       
/*     */       public TreeNode(AchievementHelper.XUAchievement xuAchievement) {
/* 284 */         this.xuAchievement = xuAchievement;
/* 285 */         ArrayList<AchievementHelper.XUAchievement> list = new ArrayList(AchievementHelper.achievementChildren.get(xuAchievement));
/*     */         
/* 287 */         int n = list.size();
/* 288 */         if (n != 0) {
/* 289 */           if (n == 1) {
/* 290 */             this.children.add(new TreeNode(new TreeNode((AchievementHelper.XUAchievement)list.get(0))));
/*     */           } else {
/* 292 */             java.util.Collections.shuffle(list);
/* 293 */             for (int i = 0; i < list.size(); i++) {
/* 294 */               int k = Math.min(i, list.size() - 1 - i);
/* 295 */               AchievementHelper.XUAchievement achievement = (AchievementHelper.XUAchievement)list.get(i);
/* 296 */               this.children.add(linkedChain(new TreeNode(achievement), k));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */       public TreeNode(TreeNode child) {
/* 303 */         this.children.add(child);
/*     */       }
/*     */       
/*     */       public static TreeNode linkedChain(TreeNode child, int chain_length) {
/* 307 */         if (chain_length == 0) return child;
/* 308 */         return new TreeNode(linkedChain(child, chain_length - 1));
/*     */       }
/*     */       
/*     */       void buildDepth()
/*     */       {
/* 313 */         int n = this.children.size();
/* 314 */         if (n == 0) {
/* 315 */           this.minPoints.add(0);
/* 316 */           this.maxPoints.add(0);
/* 317 */         } else if (n == 1) {
/* 318 */           TreeNode child = (TreeNode)this.children.get(0);
/* 319 */           child.buildDepth();
/* 320 */           this.minPoints.add(0);
/* 321 */           this.maxPoints.add(0);
/* 322 */           child.shift = 0;
/* 323 */           this.minPoints.addAll(child.minPoints);
/* 324 */           this.maxPoints.addAll(child.maxPoints);
/*     */         } else {
/* 326 */           int maxDepth = 0;
/* 327 */           for (TreeNode child : this.children) {
/* 328 */             child.buildDepth();
/* 329 */             maxDepth = Math.max(Math.max(maxDepth, child.minPoints.size()), child.maxPoints.size());
/*     */           }
/*     */           
/* 332 */           int maxShift = 0;
/*     */           
/* 334 */           for (int i = 1; i < n; i++) {
/* 335 */             TreeNode curChild = (TreeNode)this.children.get(i);
/* 336 */             curChild.shift = maxShift;
/*     */             
/*     */ 
/* 339 */             curChild.shift += 1;
/* 340 */             for (int j = i - 1;; j--) { if (j < 0) break label249;
/* 341 */               if (overlaps((TreeNode)this.children.get(j), curChild)) break;
/*     */             }
/*     */             label249:
/* 344 */             maxShift = curChild.shift;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 349 */           if ((maxShift & 0x1) != 0) {
/* 350 */             int midPoint = maxShift >> 1;
/* 351 */             for (TreeNode child : this.children) {
/* 352 */               if (child.shift > midPoint)
/* 353 */                 child.shift += 1;
/*     */             }
/* 355 */             maxShift++;
/*     */           }
/*     */           
/* 358 */           int midPoint = maxShift >> 1;
/*     */           
/* 360 */           for (TreeNode child : this.children) {
/* 361 */             child.shift -= midPoint;
/*     */           }
/*     */           
/* 364 */           this.minPoints.add(((TreeNode)this.children.get(0)).shift);
/* 365 */           this.maxPoints.add(((TreeNode)this.children.get(n - 1)).shift);
/*     */           
/* 367 */           for (int i = 0; i < maxDepth; i++) {
/* 368 */             this.minPoints.add(0);
/* 369 */             this.maxPoints.add(0);
/*     */           }
/*     */           
/* 372 */           for (TreeNode child : this.children) {
/* 373 */             for (int i = 0; i < child.minPoints.size(); i++) {
/* 374 */               int x = child.shift + child.minPoints.get(i);
/* 375 */               if (this.minPoints.get(i + 1) > x) {
/* 376 */                 this.minPoints.set(i + 1, x);
/*     */               }
/*     */             }
/*     */             
/* 380 */             for (int i = 0; i < child.maxPoints.size(); i++) {
/* 381 */               int x = child.shift + child.maxPoints.get(i);
/* 382 */               if (this.maxPoints.get(i + 1) < x) {
/* 383 */                 this.maxPoints.set(i + 1, x);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */       public boolean overlaps(TreeNode left, TreeNode right) {
/* 391 */         int size = Math.min(left.maxPoints.size(), right.minPoints.size());
/* 392 */         for (int i = 0; i < size; i++) {
/* 393 */           int l_max = left.shift + left.maxPoints.get(i);
/* 394 */           int r_min = right.shift + right.minPoints.get(i);
/* 395 */           if (r_min <= l_max) { return true;
/*     */           }
/*     */         }
/* 398 */         return false;
/*     */       }
/*     */       
/*     */       public void assignValues(int x, int y) {
/* 402 */         if (this.xuAchievement != null) {
/* 403 */           this.xuAchievement.x = x;
/* 404 */           this.xuAchievement.y = y;
/*     */         }
/*     */         
/* 407 */         for (TreeNode child : this.children) {
/* 408 */           child.assignValues(x + child.shift, y + 1);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Files Needed\sources\extrautils2-1.8.9-alpha-0.0.2-deobf.jar!\com\rwtema\extrautils2\achievements\AchievementHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */